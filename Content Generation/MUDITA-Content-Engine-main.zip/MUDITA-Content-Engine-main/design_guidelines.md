# Mudita Content Engine - Design Guidelines

## Design Approach
**System-Based Approach**: Drawing from Linear's modern SaaS aesthetic and Notion's content-focused clarity, combined with Material Design's robust form patterns. This productivity tool prioritizes efficiency, clarity, and purposeful interactions.

## Typography System

**Font Stack**: Inter (primary), system-ui (fallback) via Google Fonts CDN

**Hierarchy**:
- Page Titles: text-3xl, font-semibold (Brand name/section headers)
- Section Headers: text-xl, font-medium  
- Card Titles: text-lg, font-medium
- Body Text: text-base, font-normal (forms, content)
- Labels: text-sm, font-medium (form labels, metadata)
- Helper Text: text-sm, font-normal (validation, hints)
- Monospace (API keys, URLs): font-mono, text-sm

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-6 to p-8
- Section gaps: gap-6 to gap-8
- Page margins: px-6 md:px-12
- Vertical rhythm: space-y-6 for form sections, space-y-4 for fields

**Container Strategy**:
- Main content: max-w-5xl mx-auto (forms, generation interface)
- Wide layouts: max-w-7xl (dashboard with article cards)
- Narrow content: max-w-2xl (settings, single-column views)

## Core Layout Structure

**Application Shell**:
- Fixed top navigation bar (h-16) with logo left, user menu right
- Sidebar navigation (w-64) on desktop for: Generate, Dashboard, Settings, API Keys
- Mobile: Collapsible hamburger menu
- Main content area with consistent px-6 md:px-12, py-8

**Multi-Step Form Pattern** (Content Generation):
- Progress indicator at top (Step 1 of 3 style with visual dots/line)
- Single-column form layout (max-w-2xl centered)
- Clear "Back" and "Continue" buttons fixed at bottom
- Auto-save indicator in top-right corner

## Component Library

**Form Components**:
- Input Fields: Full-width with floating labels, border-2, rounded-lg, focus ring with offset
- Dropdowns: Custom styled selects with chevron icon (Heroicons)
- Textareas: Minimum h-32 with character counter bottom-right
- Multi-input fields: Tag-style chips for comma-separated values with remove icons
- Validation: Inline error text-sm below field, success checkmark icon right-aligned

**Cards** (Article Display):
- Elevated cards with rounded-xl, p-6
- Header section: Title + metadata row (word count, status badge)
- Content preview: max 3 lines with ellipsis
- Footer actions: Edit, Preview, Publish buttons in flex row
- Hover state: Subtle lift with shadow transition

**Buttons**:
- Primary: Solid fill, rounded-lg, px-6, py-3, font-medium
- Secondary: Border-2, transparent background
- Icon buttons: Squared (w-10 h-10), rounded-lg, centered icon
- Button groups: Connected with border-collapse styling
- Hero/Image overlay buttons: Backdrop blur (backdrop-blur-md) with semi-transparent background

**Status Indicators**:
- Badges: Rounded-full, px-3, py-1, text-xs, font-medium
- States: Draft, Generated, Published, Failed (use icons from Heroicons)
- Loading states: Skeleton screens for content cards, spinner for actions

**Navigation**:
- Tabs: Underline style for content sections (Generated Articles, Scheduled, Published)
- Breadcrumbs: text-sm with chevron separators
- Sidebar items: rounded-md, full-width, hover fill, active state with accent border-left

## Page-Specific Layouts

**Generation Interface** (Task #1):
- Step 1: Form grid (grid-cols-1 md:grid-cols-2 for related fields like ICP details)
- Step 2: Keyword review as tag grid (grid-cols-2 md:grid-cols-3), editable inline
- Step 3: Loading state → Article cards in grid-cols-1 md:grid-cols-2 lg:grid-cols-3

**Dashboard**:
- Filter bar at top with search input + dropdown filters
- Article cards in responsive grid (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- Empty states with illustration placeholder + "Generate Your First Article" CTA

**Settings Page**:
- Vertical tab navigation left sidebar (w-48)
- Content area: Single column forms (max-w-2xl)
- API Keys: Masked input with show/hide toggle, test connection button
- Danger zone: Red-bordered section at bottom for data clearing

## Icons & Assets

**Icon Library**: Heroicons (outline for navigation, solid for actions) via CDN

**Essential Icons**:
- Navigation: DocumentTextIcon, CogIcon, KeyIcon, ChartBarIcon
- Actions: PlusIcon, PencilIcon, TrashIcon, CheckIcon, XMarkIcon
- States: ClockIcon (scheduled), CheckCircleIcon (published), ExclamationCircleIcon (error)

**Images**: 
- No hero image for this application
- Empty state illustrations: Use placeholder comments (<!-- EMPTY STATE: content generation illustration -->)
- Avatar placeholders for user menu

## Interaction Patterns

**Form Flows**:
- Real-time validation with debounced checks
- Progressive disclosure (show related fields only when parent selected)
- Smart defaults (pre-populate industry from website analysis)

**Content Actions**:
- Inline editing: Click-to-edit titles/content with auto-save
- Bulk actions: Checkbox selection with floating action bar
- Export options: Dropdown menu for platform-specific formats

**Feedback**:
- Toast notifications (top-right corner) for success/error states
- Modal confirmations for destructive actions
- Loading overlays for API calls with progress indicators

## Accessibility & Responsive Behavior

- Maintain WCAG 2.1 AA standards throughout
- Mobile: Stack all multi-column layouts to single column
- Touch targets: Minimum 44x44px for all interactive elements
- Keyboard navigation: Full tab-order support with visible focus states
- Form inputs: Associated labels, aria-describedby for helper text