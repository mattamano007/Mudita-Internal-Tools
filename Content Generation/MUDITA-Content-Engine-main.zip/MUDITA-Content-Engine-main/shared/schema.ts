import { z } from "zod";
import { pgTable, serial, text, varchar, timestamp, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// ============================================
// DATABASE TABLES (Drizzle ORM)
// ============================================

// Articles table (Supabase uses UUID primary keys)
export const articles = pgTable("articles", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  metaDescription: text("meta_description"),
  category: varchar("category", { length: 100 }),
  headerImage: text("header_image"),
  imagePrompt: text("image_prompt"),
  keywords: jsonb("keywords").$type<string[]>(),
  geoOptimizations: jsonb("geo_optimizations").$type<{ directAnswers: string[]; keyFacts: string[]; conversationalPhrases: string[] }>(),
  sources: jsonb("sources").$type<Array<{ name?: string; title?: string; url: string; description?: string; publisher?: string; yearPublished?: string; trustScore?: number }>>(),
  publishedPlatforms: jsonb("published_platforms").$type<Array<{ name: string; url: string; publishedAt?: string; method?: string }>>(),
  optimizationScores: jsonb("optimization_scores").$type<{ seo: number; geo: number; readability: number }>(),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  lastPublishedAt: timestamp("last_published_at"),
});

// Platform credentials table (Supabase uses UUID primary keys)
export const platformCredentials = pgTable("platform_credentials", {
  id: text("id").primaryKey(),
  platform: varchar("platform", { length: 50 }).notNull().unique(),
  credentials: jsonb("credentials").$type<{ token: string; username?: string; userId?: string }>().notNull(),
  configuredAt: timestamp("configured_at").defaultNow().notNull(),
  lastUsedAt: timestamp("last_used_at"),
});

// Insert schemas
export const insertArticleSchema = createInsertSchema(articles).omit({ 
  id: true, 
  generatedAt: true, 
  updatedAt: true 
});
export const insertPlatformCredentialSchema = createInsertSchema(platformCredentials).omit({ 
  id: true,
  configuredAt: true,
  lastUsedAt: true
});

// Types from Drizzle
export type DbArticle = typeof articles.$inferSelect;
export type InsertArticle = z.infer<typeof insertArticleSchema>;
export type DbPlatformCredential = typeof platformCredentials.$inferSelect;
export type InsertPlatformCredential = z.infer<typeof insertPlatformCredentialSchema>;

// ============================================
// ZOD SCHEMAS (for validation)
// ============================================

// Industry options
export const INDUSTRIES = [
  "SaaS/Technology",
  "FinTech/Financial Services",
  "FinOps/Cloud Infrastructure",
  "Legal Tech",
  "Healthcare Tech",
  "E-commerce/Retail",
  "Marketing/Advertising",
  "Robotics/Hardware",
  "Gaming/Entertainment",
  "Custom",
] as const;

// Company size options
export const COMPANY_SIZES = [
  "Startup",
  "Series A-C",
  "Enterprise",
] as const;

// ICP Details schema
export const icpDetailsSchema = z.object({
  jobTitles: z.string().min(1, "Job titles are required"),
  painPoints: z.string().min(1, "Pain points are required"),
  companySize: z.enum(COMPANY_SIZES),
});

// Content generation input schema
export const contentInputSchema = z.object({
  brandWebsiteUrl: z.string().url("Please enter a valid URL"),
  industry: z.string().min(1, "Industry is required"),
  customIndustry: z.string().optional(),
  icpDetails: icpDetailsSchema,
  productNiche: z.string().min(1, "Product niche is required"),
  industryVertical: z.string().min(1, "Industry vertical is required"),
}).refine(
  (data) => {
    if (data.industry === "Custom") {
      return data.customIndustry && data.customIndustry.trim().length > 0;
    }
    return true;
  },
  {
    message: "Custom industry is required when 'Custom' is selected",
    path: ["customIndustry"],
  }
);

// Keyword schema
export const keywordSchema = z.object({
  id: z.string(),
  text: z.string(),
  selected: z.boolean(),
});

// Source schema (enhanced for GEO)
export const sourceSchema = z.object({
  name: z.string(),
  title: z.string().optional(),
  url: z.string(),
  description: z.string().optional(),
  publisher: z.string().optional(),
  yearPublished: z.string().optional(),
  trustScore: z.number().optional(),
});

// GEO Optimizations schema
export const geoOptimizationsSchema = z.object({
  directAnswers: z.array(z.string()),
  keyFacts: z.array(z.string()),
  conversationalPhrases: z.array(z.string()),
});

// Optimization scores schema
export const optimizationScoresSchema = z.object({
  seo: z.number(),
  geo: z.number(),
  readability: z.number(),
});

// Published platform schema
export const publishedPlatformSchema = z.object({
  name: z.string(),
  url: z.string(),
});

// Article schema
export const articleSchema = z.object({
  id: z.string(),
  title: z.string(),
  content: z.string(),
  angle: z.string(),
  wordCount: z.number(),
  status: z.enum(["draft", "generated", "published", "failed"]),
  createdAt: z.string(),
  keywords: z.array(z.string()).optional(),
  sources: z.array(sourceSchema).optional(),
  imageUrl: z.string().optional(),
  metaDescription: z.string().optional(),
  geoOptimizations: geoOptimizationsSchema.optional(),
  optimizationScores: optimizationScoresSchema.optional(),
  publishedPlatforms: z.array(publishedPlatformSchema).optional(),
});

// Generation session schema
export const generationSessionSchema = z.object({
  id: z.string(),
  input: contentInputSchema,
  keywords: z.array(keywordSchema),
  articles: z.array(articleSchema),
  status: z.enum(["input", "keywords", "generating", "complete", "error"]),
  createdAt: z.string(),
});

// Types
export type Industry = typeof INDUSTRIES[number];
export type CompanySize = typeof COMPANY_SIZES[number];
export type IcpDetails = z.infer<typeof icpDetailsSchema>;
export type ContentInput = z.infer<typeof contentInputSchema>;
export type Keyword = z.infer<typeof keywordSchema>;
export type Source = z.infer<typeof sourceSchema>;
export type Article = z.infer<typeof articleSchema>;
export type GenerationSession = z.infer<typeof generationSessionSchema>;

// API Request/Response types
export const generateKeywordsRequestSchema = contentInputSchema;
export type GenerateKeywordsRequest = z.infer<typeof generateKeywordsRequestSchema>;

export const generateKeywordsResponseSchema = z.object({
  keywords: z.array(z.string()),
});
export type GenerateKeywordsResponse = z.infer<typeof generateKeywordsResponseSchema>;

export const generateArticlesRequestSchema = z.object({
  input: contentInputSchema,
  keywords: z.array(z.string()),
});
export type GenerateArticlesRequest = z.infer<typeof generateArticlesRequestSchema>;

export const generateArticlesResponseSchema = z.object({
  articles: z.array(articleSchema.omit({ id: true, status: true, createdAt: true })),
});
export type GenerateArticlesResponse = z.infer<typeof generateArticlesResponseSchema>;
