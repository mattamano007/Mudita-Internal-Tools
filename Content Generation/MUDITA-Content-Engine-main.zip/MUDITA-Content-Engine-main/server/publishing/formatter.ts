interface Article {
  id: string;
  title: string;
  content: string;
  keywords?: string[];
  sources?: Array<{ name: string; url: string; description?: string }>;
  headerImage?: string;
  metaDescription?: string;
}

interface FormattedPlatform {
  name: string;
  icon: string;
  formattedContent: string;
  publishUrl: string;
  instructions: string[];
}

interface FormattedArticle {
  articleTitle: string;
  platforms: FormattedPlatform[];
}

function capitalizeFirst(str: string): string {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function getPlatformIcon(platform: string): string {
  const icons: Record<string, string> = {
    medium: 'M',
    devto: 'DEV',
    hashnode: '#',
    linkedin: 'in'
  };
  return icons[platform.toLowerCase()] || 'P';
}

function formatForMedium(article: Article): { content: string; publishUrl: string; instructions: string[] } {
  let content = `# ${article.title}\n\n`;
  
  if (article.headerImage) {
    content += `![Header Image](${article.headerImage})\n\n`;
  }
  
  content += article.content + '\n\n';
  
  if (article.sources && article.sources.length > 0) {
    content += '---\n\n';
    content += '## Sources\n\n';
    article.sources.forEach(source => {
      content += `**[${source.name}](${source.url})**\n\n`;
      if (source.description) {
        content += `> ${source.description}\n\n`;
      }
    });
  }
  
  content += `---\n\n`;
  content += `*Keywords: ${(article.keywords || []).join(', ')}*\n`;
  
  return {
    content,
    publishUrl: 'https://medium.com/new-story',
    instructions: [
      'Click "Import a story" in Medium',
      'Or paste markdown directly into the editor',
      'Add 3-5 tags from the keywords above',
      'Click "Publish"'
    ]
  };
}

function formatForDevTo(article: Article): { content: string; publishUrl: string; instructions: string[] } {
  let content = `---\n`;
  content += `title: ${article.title}\n`;
  content += `published: false\n`;
  content += `description: ${article.metaDescription || ''}\n`;
  content += `tags: ${(article.keywords || []).slice(0, 4).map(k => k.toLowerCase().replace(/\s+/g, '')).join(', ')}\n`;
  
  if (article.headerImage) {
    content += `cover_image: ${article.headerImage}\n`;
  }
  
  content += `---\n\n`;
  
  content += article.content + '\n\n';
  
  if (article.sources && article.sources.length > 0) {
    content += '---\n\n';
    content += '## Sources\n\n';
    article.sources.forEach(source => {
      content += `- **[${source.name}](${source.url})**\n`;
      if (source.description) {
        content += `  > ${source.description}\n`;
      }
    });
  }
  
  return {
    content,
    publishUrl: 'https://dev.to/new',
    instructions: [
      'Go to DEV.to and click "Create Post"',
      'Switch to markdown editor (click "Edit" tab)',
      'Paste the content above',
      'Preview and click "Publish"'
    ]
  };
}

function formatForHashnode(article: Article): { content: string; publishUrl: string; instructions: string[] } {
  let content = article.content + '\n\n';
  
  if (article.sources && article.sources.length > 0) {
    content += '---\n\n';
    content += '## Sources\n\n';
    article.sources.forEach(source => {
      content += `- [${source.name}](${source.url})\n`;
    });
  }
  
  const headerImageInstruction = article.headerImage 
    ? `Header Image URL: ${article.headerImage}` 
    : 'No header image';
  
  const tagsInstruction = `Tags: ${(article.keywords || []).slice(0, 5).join(', ')}`;
  
  return {
    content,
    publishUrl: 'https://hashnode.com/create/story',
    instructions: [
      'Go to Hashnode and click "Write"',
      'Paste title: ' + article.title,
      'Paste content above',
      headerImageInstruction,
      tagsInstruction,
      'Click "Publish"'
    ]
  };
}

function formatForLinkedIn(article: Article): { content: string; publishUrl: string; instructions: string[] } {
  let content = `${article.title}\n\n`;
  
  const maxContentLength = 2500;
  if (article.content.length > maxContentLength) {
    content += article.content.substring(0, maxContentLength) + '...\n\n';
    content += `Read more: [Link to full article]\n\n`;
  } else {
    content += article.content + '\n\n';
  }
  
  if (article.sources && article.sources.length > 0) {
    content += 'Sources:\n';
    article.sources.forEach(source => {
      content += `• ${source.name}: ${source.url}\n`;
    });
    content += '\n';
  }
  
  if (article.keywords && article.keywords.length > 0) {
    article.keywords.slice(0, 3).forEach(keyword => {
      content += `#${keyword.replace(/\s+/g, '')} `;
    });
  }
  
  const imageNote = article.headerImage 
    ? `\n\nAttach this image: ${article.headerImage}` 
    : '';
  
  return {
    content: content + imageNote,
    publishUrl: 'https://www.linkedin.com/feed/?shareActive=true',
    instructions: [
      'Go to LinkedIn and click "Start a post"',
      'Paste the content above',
      article.headerImage ? 'Click photo icon and upload the header image' : 'Skip image',
      'Click "Post"'
    ]
  };
}

function formatForPlatform(article: Article, platform: string): FormattedPlatform {
  const formatters: Record<string, (article: Article) => { content: string; publishUrl: string; instructions: string[] }> = {
    medium: formatForMedium,
    devto: formatForDevTo,
    hashnode: formatForHashnode,
    linkedin: formatForLinkedIn
  };
  
  const formatter = formatters[platform.toLowerCase()];
  
  if (!formatter) {
    throw new Error(`Unknown platform: ${platform}`);
  }
  
  const formatted = formatter(article);
  
  return {
    name: capitalizeFirst(platform),
    icon: getPlatformIcon(platform),
    formattedContent: formatted.content,
    publishUrl: formatted.publishUrl,
    instructions: formatted.instructions
  };
}

export function formatForPlatforms(
  articles: Article[], 
  platforms: string[]
): Record<string, FormattedArticle> {
  const formatted: Record<string, FormattedArticle> = {};
  
  for (const article of articles) {
    formatted[article.id] = {
      articleTitle: article.title,
      platforms: []
    };
    
    for (const platformName of platforms) {
      const platformData = formatForPlatform(article, platformName);
      formatted[article.id].platforms.push(platformData);
    }
  }
  
  return formatted;
}
