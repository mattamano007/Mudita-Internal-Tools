interface LinkedInCredentials {
  token: string;
  userId: string;
}

interface Article {
  id: string;
  title: string;
  content: string;
  keywords?: string[];
  sources?: Array<{ name: string; url: string; description?: string }>;
  headerImage?: string;
}

interface PublishResult {
  url: string;
  id: string;
}

export async function publish(article: Article, credentials: LinkedInCredentials): Promise<PublishResult> {
  const { token, userId } = credentials;
  
  const content = formatArticleForLinkedIn(article);
  
  const postBody: Record<string, unknown> = {
    author: `urn:li:person:${userId}`,
    lifecycleState: 'PUBLISHED',
    specificContent: {
      'com.linkedin.ugc.ShareContent': {
        shareCommentary: {
          text: content
        },
        shareMediaCategory: article.headerImage ? 'IMAGE' : 'NONE',
        ...(article.headerImage && {
          media: [
            {
              status: 'READY',
              description: {
                text: article.title
              },
              media: article.headerImage,
              title: {
                text: article.title
              }
            }
          ]
        })
      }
    },
    visibility: {
      'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC'
    }
  };
  
  const response = await fetch('https://api.linkedin.com/v2/ugcPosts', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'X-Restli-Protocol-Version': '2.0.0'
    },
    body: JSON.stringify(postBody)
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`LinkedIn API error: ${error}`);
  }
  
  const data = await response.json() as { id: string };
  const postId = data.id.split(':').pop() || data.id;
  
  return {
    url: `https://www.linkedin.com/feed/update/${data.id}/`,
    id: postId
  };
}

function formatArticleForLinkedIn(article: Article): string {
  let content = `${article.title}\n\n`;
  
  const maxContentLength = 2500;
  if (article.content.length > maxContentLength) {
    content += article.content.substring(0, maxContentLength) + '...\n\n';
  } else {
    content += article.content + '\n\n';
  }
  
  if (article.sources && article.sources.length > 0) {
    content += 'Sources:\n';
    article.sources.forEach(source => {
      content += `• ${source.name}: ${source.url}\n`;
    });
  }
  
  if (article.keywords && article.keywords.length > 0) {
    content += '\n';
    article.keywords.slice(0, 3).forEach(keyword => {
      content += `#${keyword.replace(/\s+/g, '')} `;
    });
  }
  
  return content;
}

export async function testConnection(token: string): Promise<boolean> {
  try {
    const response = await fetch('https://api.linkedin.com/v2/me', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Connection': 'Keep-Alive'
      }
    });
    
    return response.ok;
  } catch {
    return false;
  }
}
