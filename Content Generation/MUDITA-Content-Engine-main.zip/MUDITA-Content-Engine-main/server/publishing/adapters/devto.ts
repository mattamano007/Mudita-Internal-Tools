interface DevToCredentials {
  token: string;
}

interface Article {
  id: string;
  title: string;
  content: string;
  keywords?: string[];
  sources?: Array<{ name: string; url: string; description?: string }>;
  headerImage?: string;
  canonicalUrl?: string;
  metaDescription?: string;
}

interface PublishResult {
  url: string;
  id: string;
}

export async function publish(article: Article, credentials: DevToCredentials): Promise<PublishResult> {
  const { token } = credentials;
  
  const markdown = formatArticleForDevTo(article);
  
  const response = await fetch('https://dev.to/api/articles', {
    method: 'POST',
    headers: {
      'api-key': token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      article: {
        title: article.title,
        published: true,
        body_markdown: markdown,
        tags: (article.keywords || []).slice(0, 4).map(k => k.toLowerCase().replace(/\s+/g, '')),
        canonical_url: article.canonicalUrl || '',
        description: article.metaDescription || ''
      }
    })
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`DEV.to API error: ${error}`);
  }
  
  const data = await response.json() as { url: string; id: number };
  
  return {
    url: data.url,
    id: String(data.id)
  };
}

function formatArticleForDevTo(article: Article): string {
  let markdown = '';
  
  if (article.headerImage) {
    markdown += `---\n`;
    markdown += `cover_image: ${article.headerImage}\n`;
    markdown += `---\n\n`;
  }
  
  markdown += article.content + '\n\n';
  
  if (article.sources && article.sources.length > 0) {
    markdown += '---\n\n';
    markdown += '## Sources\n\n';
    article.sources.forEach(source => {
      markdown += `- [${source.name}](${source.url})\n`;
      if (source.description) {
        markdown += `  > ${source.description}\n`;
      }
    });
  }
  
  return markdown;
}

export async function testConnection(token: string): Promise<boolean> {
  try {
    const response = await fetch('https://dev.to/api/users/me', {
      headers: {
        'api-key': token
      }
    });
    
    return response.ok;
  } catch {
    return false;
  }
}
