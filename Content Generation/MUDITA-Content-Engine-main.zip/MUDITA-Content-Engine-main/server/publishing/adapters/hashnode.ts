interface HashnodeCredentials {
  token: string;
  username: string;
}

interface Article {
  id: string;
  title: string;
  content: string;
  keywords?: string[];
  sources?: Array<{ name: string; url: string; description?: string }>;
  headerImage?: string;
  metaDescription?: string;
}

interface PublishResult {
  url: string;
  id: string;
}

export async function publish(article: Article, credentials: HashnodeCredentials): Promise<PublishResult> {
  const { token, username } = credentials;
  
  const publicationId = await getPublicationId(token, username);
  
  const markdown = formatArticleForHashnode(article);
  
  const mutation = `
    mutation CreatePost($input: CreateStoryInput!) {
      createPublicationStory(input: $input, publicationId: "${publicationId}") {
        success
        post {
          slug
          cuid
        }
      }
    }
  `;
  
  const variables = {
    input: {
      title: article.title,
      contentMarkdown: markdown,
      tags: (article.keywords || []).slice(0, 5).map(k => ({
        name: k,
        slug: k.toLowerCase().replace(/\s+/g, '-')
      })),
      coverImageURL: article.headerImage || '',
      metaTags: {
        description: article.metaDescription || '',
        image: article.headerImage || ''
      }
    }
  };
  
  const response = await fetch('https://api.hashnode.com', {
    method: 'POST',
    headers: {
      'Authorization': token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: mutation,
      variables
    })
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Hashnode API error: ${error}`);
  }
  
  const data = await response.json() as {
    errors?: unknown[];
    data?: { createPublicationStory: { post: { slug: string; cuid: string } } };
  };
  
  if (data.errors) {
    throw new Error(`Hashnode GraphQL error: ${JSON.stringify(data.errors)}`);
  }
  
  const post = data.data!.createPublicationStory.post;
  
  return {
    url: `https://${username}.hashnode.dev/${post.slug}`,
    id: post.cuid
  };
}

async function getPublicationId(token: string, username: string): Promise<string> {
  const query = `
    query GetUser($username: String!) {
      user(username: $username) {
        publication {
          _id
        }
      }
    }
  `;
  
  const response = await fetch('https://api.hashnode.com', {
    method: 'POST',
    headers: {
      'Authorization': token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query,
      variables: { username }
    })
  });
  
  const data = await response.json() as {
    errors?: unknown[];
    data?: { user: { publication: { _id: string } } };
  };
  
  if (data.errors || !data.data?.user?.publication) {
    throw new Error('Could not get Hashnode publication ID');
  }
  
  return data.data.user.publication._id;
}

function formatArticleForHashnode(article: Article): string {
  let markdown = article.content + '\n\n';
  
  if (article.sources && article.sources.length > 0) {
    markdown += '---\n\n';
    markdown += '## Sources\n\n';
    article.sources.forEach(source => {
      markdown += `- [${source.name}](${source.url})\n`;
    });
  }
  
  return markdown;
}

export async function testConnection(token: string, username: string): Promise<boolean> {
  try {
    const query = `
      query GetUser($username: String!) {
        user(username: $username) {
          _id
        }
      }
    `;
    
    const response = await fetch('https://api.hashnode.com', {
      method: 'POST',
      headers: {
        'Authorization': token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        query,
        variables: { username }
      })
    });
    
    const data = await response.json() as { errors?: unknown[]; data?: { user: unknown } };
    return !data.errors && !!data.data?.user;
  } catch {
    return false;
  }
}
