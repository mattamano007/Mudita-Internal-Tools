interface MediumCredentials {
  token: string;
  username?: string;
}

interface Article {
  id: string;
  title: string;
  content: string;
  keywords?: string[];
  sources?: Array<{ name: string; url: string; description?: string }>;
  headerImage?: string;
  canonicalUrl?: string;
  metaDescription?: string;
}

interface PublishResult {
  url: string;
  id: string;
}

export async function publish(article: Article, credentials: MediumCredentials): Promise<PublishResult> {
  const { token } = credentials;
  
  const userResponse = await fetch('https://api.medium.com/v1/me', {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }
  });
  
  if (!userResponse.ok) {
    throw new Error(`Medium auth failed: ${userResponse.status}`);
  }
  
  const userData = await userResponse.json() as { data: { id: string } };
  const userId = userData.data.id;
  
  const content = formatArticleForMedium(article);
  
  const response = await fetch(`https://api.medium.com/v1/users/${userId}/posts`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({
      title: article.title,
      contentFormat: 'html',
      content: content,
      tags: (article.keywords || []).slice(0, 3),
      publishStatus: 'public',
      canonicalUrl: article.canonicalUrl || ''
    })
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Medium API error: ${error}`);
  }
  
  const data = await response.json() as { data: { url: string; id: string } };
  
  return {
    url: data.data.url,
    id: data.data.id
  };
}

function formatArticleForMedium(article: Article): string {
  let html = '';
  
  if (article.headerImage) {
    html += `<figure><img src="${article.headerImage}" alt="${article.title}" /></figure>\n\n`;
  }
  
  const paragraphs = article.content.split('\n\n');
  paragraphs.forEach(para => {
    if (para.trim()) {
      if (para.startsWith('## ')) {
        html += `<h2>${para.slice(3).trim()}</h2>\n`;
      } else if (para.startsWith('# ')) {
        html += `<h1>${para.slice(2).trim()}</h1>\n`;
      } else {
        html += `<p>${para.trim()}</p>\n`;
      }
    }
  });
  
  if (article.sources && article.sources.length > 0) {
    html += '\n<hr>\n';
    html += '<h3>Sources</h3>\n';
    article.sources.forEach(source => {
      html += `<p><a href="${source.url}" target="_blank" rel="noopener">${source.name}</a></p>\n`;
      if (source.description) {
        html += `<p><em>${source.description}</em></p>\n`;
      }
    });
  }
  
  return html;
}

export async function testConnection(token: string): Promise<boolean> {
  try {
    const response = await fetch('https://api.medium.com/v1/me', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    return response.ok;
  } catch {
    return false;
  }
}
