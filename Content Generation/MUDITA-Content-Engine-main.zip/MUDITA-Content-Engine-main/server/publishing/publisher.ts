import * as mediumAdapter from './adapters/medium';
import * as devtoAdapter from './adapters/devto';
import * as hashnodeAdapter from './adapters/hashnode';
import * as linkedinAdapter from './adapters/linkedin';

interface Article {
  id: string;
  title: string;
  content: string;
  keywords?: string[];
  sources?: Array<{ name: string; url: string; description?: string }>;
  headerImage?: string;
  canonicalUrl?: string;
  metaDescription?: string;
}

interface PlatformCredential {
  token: string;
  username?: string;
  userId?: string;
}

interface PlatformResult {
  name: string;
  url: string | null;
  id?: string;
  success: boolean;
  error?: string;
}

interface ArticlePublishResult {
  articleId: string;
  articleTitle: string;
  platforms: PlatformResult[];
}

const adapters: Record<string, {
  publish: (article: Article, credentials: any) => Promise<{ url: string; id: string }>;
}> = {
  medium: mediumAdapter,
  devto: devtoAdapter,
  hashnode: hashnodeAdapter,
  linkedin: linkedinAdapter
};

function capitalizeFirst(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export async function publishToMultiplePlatforms(
  articles: Article[],
  platforms: string[],
  credentials: Record<string, PlatformCredential>
): Promise<ArticlePublishResult[]> {
  const results: ArticlePublishResult[] = [];
  
  for (const article of articles) {
    const articleResult: ArticlePublishResult = {
      articleId: article.id,
      articleTitle: article.title,
      platforms: []
    };
    
    for (const platformName of platforms) {
      try {
        const adapter = adapters[platformName];
        
        if (!adapter) {
          throw new Error(`Unknown platform: ${platformName}`);
        }
        
        const credential = credentials[platformName];
        
        if (!credential) {
          throw new Error(`No credentials for ${platformName}`);
        }
        
        console.log(`Publishing "${article.title}" to ${platformName}...`);
        
        const result = await adapter.publish(article, credential);
        
        console.log(`Published to ${platformName}: ${result.url}`);
        
        articleResult.platforms.push({
          name: capitalizeFirst(platformName),
          url: result.url,
          id: result.id,
          success: true
        });
        
      } catch (error) {
        console.error(`Failed to publish to ${platformName}:`, error);
        
        articleResult.platforms.push({
          name: capitalizeFirst(platformName),
          url: null,
          error: error instanceof Error ? error.message : 'Unknown error',
          success: false
        });
      }
    }
    
    results.push(articleResult);
  }
  
  return results;
}

export async function testPlatformConnection(
  platform: string,
  token: string,
  username?: string
): Promise<boolean> {
  switch (platform) {
    case 'medium':
      return mediumAdapter.testConnection(token);
    case 'devto':
      return devtoAdapter.testConnection(token);
    case 'hashnode':
      return hashnodeAdapter.testConnection(token, username || '');
    case 'linkedin':
      return linkedinAdapter.testConnection(token);
    default:
      return false;
  }
}
