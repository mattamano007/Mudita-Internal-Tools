import { createClient, SupabaseClient } from "@supabase/supabase-js";

let supabaseInstance: SupabaseClient | null = null;

function getSupabase(): SupabaseClient {
  if (!supabaseInstance) {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseKey) {
      throw new Error("Supabase credentials not configured. Please add SUPABASE_URL and SUPABASE_ANON_KEY to your secrets.");
    }
    
    supabaseInstance = createClient(supabaseUrl, supabaseKey);
  }
  return supabaseInstance;
}

function db() {
  return getSupabase();
}

export interface SupabaseArticle {
  id: string;
  title: string;
  content: string;
  meta_description: string | null;
  category: string | null;
  header_image: string | null;
  image_prompt: string | null;
  keywords: string[];
  geo_optimizations: {
    directAnswers: string[];
    keyFacts: string[];
    conversationalPhrases: string[];
  };
  sources: Array<{
    name?: string;
    title?: string;
    url: string;
    description?: string;
    publisher?: string;
    yearPublished?: string;
    trustScore?: number;
  }>;
  published_platforms: Array<{
    name: string;
    url: string;
    publishedAt?: string;
    method?: string;
  }>;
  optimization_scores: {
    seo: number;
    geo: number;
    readability: number;
  };
  generated_at: string;
  updated_at: string;
  last_published_at: string | null;
}

export interface SupabasePlatformCredential {
  id: string;
  platform: string;
  credentials: {
    token: string;
    username?: string;
    userId?: string;
  };
  configured_at: string;
  last_used_at: string | null;
}

export interface DbArticle {
  id: string;
  externalId: string;
  title: string;
  content: string;
  angle: string;
  wordCount: number;
  status: string;
  keywords: string[] | null;
  sources: Array<{ name?: string; title?: string; url: string; description?: string; publisher?: string; yearPublished?: string; trustScore?: number }> | null;
  geoOptimizations: { directAnswers: string[]; keyFacts: string[]; conversationalPhrases: string[] } | null;
  optimizationScores: { seo: number; geo: number; readability: number } | null;
  imageUrl: string | null;
  metaDescription: string | null;
  headerImage: string | null;
  canonicalUrl: string | null;
  publishedPlatforms: Array<{ name: string; url: string; publishedAt?: string }> | null;
  lastPublishedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface DbPlatformCredential {
  id: string;
  platform: string;
  token: string;
  username: string | null;
  userId: string | null;
  configuredAt: Date;
}

function supabaseToDbArticle(article: SupabaseArticle): DbArticle {
  return {
    id: article.id,
    externalId: article.id,
    title: article.title,
    content: article.content,
    angle: article.category || "General",
    wordCount: article.content.split(/\s+/).length,
    status: article.last_published_at ? "published" : "generated",
    keywords: article.keywords,
    sources: article.sources,
    geoOptimizations: article.geo_optimizations,
    optimizationScores: article.optimization_scores,
    imageUrl: null,
    metaDescription: article.meta_description,
    headerImage: article.header_image,
    canonicalUrl: null,
    publishedPlatforms: article.published_platforms,
    lastPublishedAt: article.last_published_at ? new Date(article.last_published_at) : null,
    createdAt: new Date(article.generated_at),
    updatedAt: new Date(article.updated_at),
  };
}

function supabaseToDbCredential(cred: SupabasePlatformCredential): DbPlatformCredential {
  return {
    id: cred.id,
    platform: cred.platform,
    token: cred.credentials.token,
    username: cred.credentials.username || null,
    userId: cred.credentials.userId || null,
    configuredAt: new Date(cred.configured_at),
  };
}

export async function getArticles(): Promise<DbArticle[]> {
  const { data, error } = await db()
    .from("articles")
    .select("*")
    .order("generated_at", { ascending: false });

  if (error) {
    console.error("Supabase error:", error);
    throw new Error("Failed to fetch articles");
  }

  return (data || []).map(supabaseToDbArticle);
}

export async function getArticleById(externalId: string): Promise<DbArticle | null> {
  const { data, error } = await db()
    .from("articles")
    .select("*")
    .eq("id", externalId)
    .single();

  if (error) {
    if (error.code === "PGRST116") {
      return null;
    }
    console.error("Supabase error:", error);
    throw new Error("Failed to fetch article");
  }

  return data ? supabaseToDbArticle(data) : null;
}

export async function saveArticle(article: {
  externalId?: string;
  title: string;
  content: string;
  angle?: string;
  wordCount?: number;
  status?: string;
  keywords?: string[];
  sources?: Array<{ name?: string; title?: string; url: string; description?: string; publisher?: string; yearPublished?: string; trustScore?: number }>;
  geoOptimizations?: { directAnswers: string[]; keyFacts: string[]; conversationalPhrases: string[] };
  optimizationScores?: { seo: number; geo: number; readability: number };
  metaDescription?: string;
  headerImage?: string;
}): Promise<DbArticle> {
  const { data, error } = await db()
    .from("articles")
    .insert([
      {
        title: article.title,
        content: article.content,
        meta_description: article.metaDescription || null,
        category: article.angle || "General",
        header_image: article.headerImage || null,
        keywords: article.keywords || [],
        geo_optimizations: article.geoOptimizations || {
          directAnswers: [],
          keyFacts: [],
          conversationalPhrases: [],
        },
        sources: article.sources || [],
        optimization_scores: article.optimizationScores || { seo: 0, geo: 0, readability: 0 },
      },
    ])
    .select()
    .single();

  if (error) {
    console.error("Supabase error:", error);
    throw new Error("Failed to save article");
  }

  return supabaseToDbArticle(data);
}

export async function updateArticle(
  externalId: string,
  updates: Partial<{
    title: string;
    content: string;
    status: string;
    keywords: string[];
    sources: Array<{ name?: string; title?: string; url: string; description?: string; publisher?: string; yearPublished?: string; trustScore?: number }>;
    metaDescription: string;
    publishedPlatforms: Array<{ name: string; url: string; publishedAt?: string }>;
    lastPublishedAt: Date;
  }>
): Promise<DbArticle | null> {
  const updateData: Record<string, unknown> = {};

  if (updates.title) updateData.title = updates.title;
  if (updates.content) updateData.content = updates.content;
  if (updates.keywords) updateData.keywords = updates.keywords;
  if (updates.sources) updateData.sources = updates.sources;
  if (updates.metaDescription) updateData.meta_description = updates.metaDescription;
  if (updates.publishedPlatforms) updateData.published_platforms = updates.publishedPlatforms;
  if (updates.lastPublishedAt) updateData.last_published_at = updates.lastPublishedAt.toISOString();

  const { data, error } = await db()
    .from("articles")
    .update(updateData)
    .eq("id", externalId)
    .select()
    .single();

  if (error) {
    console.error("Supabase error:", error);
    throw new Error("Failed to update article");
  }

  return data ? supabaseToDbArticle(data) : null;
}

export async function deleteArticle(externalId: string): Promise<void> {
  const { error } = await db().from("articles").delete().eq("id", externalId);

  if (error) {
    console.error("Supabase error:", error);
    throw new Error("Failed to delete article");
  }
}

export async function getPlatformCredentials(
  platforms?: string[]
): Promise<Record<string, DbPlatformCredential>> {
  let query = db().from("platform_credentials").select("*");

  if (platforms && platforms.length > 0) {
    query = query.in("platform", platforms);
  }

  const { data, error } = await query;

  if (error) {
    console.error("Supabase error:", error);
    throw new Error("Failed to fetch credentials");
  }

  const credentials: Record<string, DbPlatformCredential> = {};
  (data || []).forEach((row: SupabasePlatformCredential) => {
    credentials[row.platform] = supabaseToDbCredential(row);
  });

  return credentials;
}

export async function getPlatformCredential(platform: string): Promise<DbPlatformCredential | null> {
  const { data, error } = await db()
    .from("platform_credentials")
    .select("*")
    .eq("platform", platform)
    .single();

  if (error) {
    if (error.code === "PGRST116") {
      return null;
    }
    console.error("Supabase error:", error);
    throw new Error("Failed to fetch credential");
  }

  return data ? supabaseToDbCredential(data) : null;
}

export async function savePlatformCredential(
  platform: string,
  data: { token: string; username?: string; userId?: string } | null
): Promise<void> {
  if (!data) {
    const { error } = await db()
      .from("platform_credentials")
      .delete()
      .eq("platform", platform);

    if (error) {
      console.error("Supabase error:", error);
      throw new Error("Failed to delete credentials");
    }
    return;
  }

  const { error } = await db().from("platform_credentials").upsert(
    {
      platform,
      credentials: {
        token: data.token,
        username: data.username,
        userId: data.userId,
      },
    },
    { onConflict: "platform" }
  );

  if (error) {
    console.error("Supabase error:", error);
    throw new Error("Failed to save credentials");
  }
}

export async function getAllPlatformStatus(): Promise<
  Record<string, { connected: boolean; configuredAt: Date | null }>
> {
  const allPlatforms = ["medium", "devto", "hashnode", "linkedin"];
  const credentials = await getPlatformCredentials();

  const status: Record<string, { connected: boolean; configuredAt: Date | null }> = {};
  for (const platform of allPlatforms) {
    status[platform] = {
      connected: !!credentials[platform],
      configuredAt: credentials[platform]?.configuredAt || null,
    };
  }
  return status;
}

export async function recordPublishing(
  articleId: string,
  platform: string,
  url: string | null,
  method: string,
  status: "success" | "failed",
  errorMessage: string | null = null
): Promise<void> {
  const { error } = await db().from("publishing_history").insert([
    {
      article_id: articleId,
      platform,
      published_url: url,
      method,
      status,
      error_message: errorMessage,
    },
  ]);

  if (error) {
    console.error("Failed to record publishing:", error);
  }
}

export async function getStats(): Promise<{
  articles: number;
  sessions: number;
}> {
  const { count: articleCount } = await db()
    .from("articles")
    .select("*", { count: "exact", head: true });

  const { count: sessionCount } = await db()
    .from("generation_sessions")
    .select("*", { count: "exact", head: true });

  return {
    articles: articleCount || 0,
    sessions: sessionCount || 0,
  };
}

export async function clearAllData(): Promise<void> {
  const { error: articlesError } = await db()
    .from("articles")
    .delete()
    .neq("id", "00000000-0000-0000-0000-000000000000");

  const { error: sessionsError } = await db()
    .from("generation_sessions")
    .delete()
    .neq("id", "00000000-0000-0000-0000-000000000000");

  if (articlesError || sessionsError) {
    throw new Error("Failed to clear data");
  }
}
