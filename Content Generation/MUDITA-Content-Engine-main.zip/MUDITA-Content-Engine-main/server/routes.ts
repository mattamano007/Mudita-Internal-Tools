import type { Express } from "express";
import { createServer, type Server } from "http";
import Anthropic from "@anthropic-ai/sdk";
import { contentInputSchema, generateArticlesRequestSchema, articleSchema } from "@shared/schema";
import { fromError } from "zod-validation-error";
import { z } from "zod";
import { publishToMultiplePlatforms, testPlatformConnection } from "./publishing/publisher";
import { formatForPlatforms } from "./publishing/formatter";
import * as storage from "./storage";

function getAnthropicClient() {
  const apiKey = process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL;
  
  if (!apiKey || !baseURL) {
    throw new Error("AI integration not configured. Please ensure Replit AI integrations are set up.");
  }
  
  return new Anthropic({
    apiKey,
    baseURL,
  });
}

function capitalizeFirst(str: string): string {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  function extractBrandFromUrl(url: string): string {
    try {
      const urlObj = new URL(url);
      let hostname = urlObj.hostname.replace(/^www\./, '');
      const parts = hostname.split('.');
      if (parts.length >= 2) {
        hostname = parts[0];
      }
      return hostname.charAt(0).toUpperCase() + hostname.slice(1);
    } catch {
      return '';
    }
  }

  // ============================================
  // GENERATION ROUTES
  // ============================================

  app.post("/api/generate/keywords", async (req, res) => {
    try {
      const parseResult = contentInputSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: fromError(parseResult.error).toString() 
        });
      }

      const input = parseResult.data;
      const industry = input.industry === "Custom" ? input.customIndustry : input.industry;
      const brandName = extractBrandFromUrl(input.brandWebsiteUrl);

      const prompt = `You are an SEO and GEO (Generative Engine Optimization) expert. Analyze the following brand information and generate 10-15 target keywords for content optimization.

Brand Website: ${input.brandWebsiteUrl}
Industry: ${industry}
Product Niche: ${input.productNiche}
Industry Vertical: ${input.industryVertical}

Target ICP (Ideal Customer Profile):
- Job Titles: ${input.icpDetails.jobTitles}
- Pain Points: ${input.icpDetails.painPoints}
- Company Size: ${input.icpDetails.companySize}

Generate keywords that are:
1. Highly relevant to the product niche and target audience
2. SEO-optimized for search engines
3. GEO-optimized for AI assistants (ChatGPT, Perplexity, Claude)
4. A mix of short-tail and long-tail keywords
5. Focused on solving the ICP's pain points

Return ONLY a JSON array of keyword strings, no other text or explanation.
Example format: ["keyword 1", "keyword 2", "keyword 3"]`;

      const anthropic = getAnthropicClient();
      const message = await anthropic.messages.create({
        model: "claude-sonnet-4-5",
        max_tokens: 1024,
        messages: [{ role: "user", content: prompt }],
      });

      const content = message.content[0];
      if (content.type !== "text") {
        throw new Error("Unexpected response format");
      }

      const jsonMatch = content.text.match(/\[[\s\S]*\]/);
      if (!jsonMatch) {
        throw new Error("Could not parse keywords from response");
      }

      const generatedKeywords = JSON.parse(jsonMatch[0]) as string[];
      
      const keywords = brandName 
        ? [brandName, ...generatedKeywords.filter(k => k.toLowerCase() !== brandName.toLowerCase())]
        : generatedKeywords;
      
      res.json({ keywords });
    } catch (error) {
      console.error("Error generating keywords:", error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to generate keywords" 
      });
    }
  });

  app.post("/api/generate/articles", async (req, res) => {
    try {
      const parseResult = generateArticlesRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: fromError(parseResult.error).toString() 
        });
      }

      const { input, keywords } = parseResult.data;
      const industry = input.industry === "Custom" ? input.customIndustry : input.industry;

      const angles = [
        { name: "CFO/Financial", perspective: "financial leadership, ROI, cost optimization, budget allocation" },
        { name: "Technical/DevOps", perspective: "technical implementation, efficiency, automation, developer experience" },
        { name: "Business Efficiency", perspective: "operational excellence, productivity, competitive advantage, scalability" },
        { name: "Competitive Edge", perspective: "market differentiation, innovation leadership, strategic advantage" },
        { name: "Future Trends", perspective: "industry evolution, emerging technologies, future-proofing, innovation" },
      ];

      const articles = [];

      for (const angle of angles) {
        const prompt = `Write a 300-350 word article optimized for BOTH traditional search engines (SEO) AND AI search engines (GEO).

BRAND CONTEXT:
- Website: ${input.brandWebsiteUrl}
- Industry: ${industry}
- Product Niche: ${input.productNiche}
- Industry Vertical: ${input.industryVertical}

TARGET AUDIENCE:
- Job Titles: ${input.icpDetails.jobTitles}
- Pain Points: ${input.icpDetails.painPoints}
- Company Size: ${input.icpDetails.companySize}

ARTICLE ANGLE: ${angle.name} perspective - Focus on ${angle.perspective}

**SEO OPTIMIZATION REQUIREMENTS:**
1. Include relevant keywords naturally: ${keywords.join(", ")}
2. Use keyword variations and synonyms
3. Front-load important keywords
4. Write compelling meta description (150 chars)
5. Use clear heading structure

**GEO OPTIMIZATION REQUIREMENTS (CRITICAL):**
1. Write in natural, conversational language (how people actually ask questions)
2. Provide DIRECT, CLEAR answers to common questions
3. Use "you" and "your" to address readers
4. Include specific numbers, statistics, and facts that AI can cite
5. Structure information in scannable chunks
6. Use authoritative sources that AI engines trust
7. Answer "what", "why", "how", "when" questions explicitly
8. Use clear cause-and-effect relationships
9. Avoid marketing fluff - be factual and informative
10. Make statements that are easy for AI to extract and cite

**CONTENT STRUCTURE:**
- Hook: Start with a relatable question or problem (GEO-friendly)
- Problem: Explain the issue with specific details (quotable facts)
- Solution: Provide clear, actionable information (AI can summarize)
- Outcome: Show concrete results with numbers (citable data)

**CRITICAL: Include 2 AUTHORITATIVE SOURCES**
Sources must be from reputable publishers (Harvard Business Review, McKinsey, Gartner, Forbes, academic journals).

EXAMPLES OF GEO-OPTIMIZED WRITING:
BAD: "Our advanced cloud-based solution leverages cutting-edge AI technology to revolutionize business processes."
GOOD: "AI-powered tools can reduce manual data entry by 40%, saving businesses an average of 15 hours per week, according to Gartner's 2024 Automation Report."

Return JSON:
{
  "title": "Compelling, conversational title",
  "content": "Full article (300-350 words) with ## for H2 headings",
  "angle": "${angle.name}",
  "wordCount": 325,
  "metaDescription": "150 char SEO description",
  "keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"],
  "geoOptimizations": {
    "directAnswers": ["Direct answer 1", "Direct answer 2"],
    "keyFacts": ["Quotable fact with data 1", "Quotable fact 2", "Quotable fact 3"],
    "conversationalPhrases": ["How people would ask about this 1", "Natural query 2"]
  },
  "sources": [
    {
      "name": "Source Title 1",
      "title": "Article/Report Title",
      "description": "Why this source is authoritative",
      "url": "https://example.com/article",
      "publisher": "Publisher Name",
      "yearPublished": "2024",
      "trustScore": 8
    },
    {
      "name": "Source Title 2",
      "title": "Second Article/Report Title",
      "description": "Why this second source is authoritative",
      "url": "https://example.com/article2",
      "publisher": "Second Publisher",
      "yearPublished": "2023",
      "trustScore": 9
    }
  ]
}

Only return the JSON object, no additional text.`;

        const anthropic = getAnthropicClient();
        const message = await anthropic.messages.create({
          model: "claude-sonnet-4-5",
          max_tokens: 4000,
          messages: [{ role: "user", content: prompt }],
        });

        const content = message.content[0];
        if (content.type !== "text") {
          throw new Error("Unexpected response format");
        }

        const jsonMatch = content.text.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
          throw new Error(`Could not parse article for angle: ${angle.name}`);
        }

        const article = JSON.parse(jsonMatch[0]);
        
        // Ensure GEO optimizations have defaults
        if (!article.geoOptimizations) {
          article.geoOptimizations = {
            directAnswers: [],
            keyFacts: [],
            conversationalPhrases: []
          };
        }
        
        // Ensure sources array exists
        if (!article.sources || !Array.isArray(article.sources)) {
          article.sources = [];
        }
        
        // Ensure keywords array exists
        if (!article.keywords || !Array.isArray(article.keywords)) {
          article.keywords = keywords.slice(0, 5);
        }
        
        articles.push(article);
      }

      res.json({ articles });
    } catch (error) {
      console.error("Error generating articles:", error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to generate articles" 
      });
    }
  });

  // ============================================
  // ARTICLES ROUTES
  // ============================================

  app.get("/api/articles", async (req, res) => {
    try {
      const articles = await storage.getArticles();
      res.json({
        success: true,
        articles
      });
    } catch (error) {
      console.error("Get articles error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to get articles"
      });
    }
  });

  app.get("/api/articles/:id", async (req, res) => {
    try {
      const article = await storage.getArticleById(req.params.id);
      
      if (!article) {
        return res.status(404).json({
          success: false,
          error: "Article not found"
        });
      }
      
      res.json({
        success: true,
        article
      });
    } catch (error) {
      console.error("Get article error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to get article"
      });
    }
  });

  app.post("/api/articles", async (req, res) => {
    try {
      const article = await storage.saveArticle(req.body);
      
      res.json({
        success: true,
        article
      });
    } catch (error) {
      console.error("Save article error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to save article"
      });
    }
  });

  app.put("/api/articles/:id", async (req, res) => {
    try {
      const updated = await storage.updateArticle(req.params.id, req.body);
      
      if (!updated) {
        return res.status(404).json({
          success: false,
          error: "Article not found"
        });
      }
      
      res.json({
        success: true,
        article: updated
      });
    } catch (error) {
      console.error("Update article error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to update article"
      });
    }
  });

  app.delete("/api/articles/:id", async (req, res) => {
    try {
      await storage.deleteArticle(req.params.id);
      
      res.json({
        success: true,
        message: "Article deleted"
      });
    } catch (error) {
      console.error("Delete article error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to delete article"
      });
    }
  });

  // ============================================
  // DUAL-MODE PUBLISHING ROUTES
  // ============================================

  app.post("/api/publish", async (req, res) => {
    try {
      const { articleIds, platforms } = req.body;
      
      if (!articleIds || articleIds.length === 0) {
        return res.status(400).json({
          success: false,
          error: "No articles selected"
        });
      }
      
      if (!platforms || platforms.length === 0) {
        return res.status(400).json({
          success: false,
          error: "No platforms selected"
        });
      }

      // Get articles from database
      const articles = await Promise.all(
        articleIds.map((id: string) => storage.getArticleById(id))
      );
      const validArticles = articles.filter(Boolean);

      if (validArticles.length === 0) {
        return res.status(404).json({
          success: false,
          error: "No articles found"
        });
      }

      // Get credentials for requested platforms
      const allCredentials = await storage.getPlatformCredentials(platforms);
      
      // Check if we have credentials for all platforms
      const missingPlatforms = platforms.filter((p: string) => !allCredentials[p]);
      if (missingPlatforms.length > 0) {
        return res.status(400).json({
          success: false,
          error: `Missing credentials for: ${missingPlatforms.join(", ")}. Please connect these platforms in Settings first.`
        });
      }

      // Transform credentials for publisher
      const credentials: Record<string, { token: string; username?: string; userId?: string }> = {};
      for (const [platform, cred] of Object.entries(allCredentials)) {
        credentials[platform] = {
          token: cred.token,
          username: cred.username || undefined,
          userId: cred.userId || undefined
        };
      }

      // Convert articles to publisher format
      const publisherArticles = validArticles.map(a => ({
        id: a!.externalId,
        title: a!.title,
        content: a!.content,
        keywords: a!.keywords || [],
        sources: a!.sources || [],
        headerImage: a!.headerImage || undefined,
        metaDescription: a!.metaDescription || undefined
      }));

      // Publish to platforms using real adapters
      const results = await publishToMultiplePlatforms(
        publisherArticles,
        platforms,
        credentials
      );

      // Update articles with published status
      for (const result of results) {
        const successfulPlatforms = result.platforms.filter(p => p.success);
        if (successfulPlatforms.length > 0) {
          await storage.updateArticle(result.articleId, {
            status: "published",
            publishedPlatforms: successfulPlatforms.map(p => ({
              name: p.name,
              url: p.url || ''
            })),
            lastPublishedAt: new Date()
          });
        }
      }

      res.json({
        success: true,
        data: results
      });
    } catch (error) {
      console.error("Publishing error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to publish"
      });
    }
  });

  // ============================================
  // HYBRID MODE - FORMAT FOR PLATFORMS
  // ============================================

  app.post("/api/format-for-platforms", async (req, res) => {
    try {
      const { articleIds, platforms } = req.body;
      
      if (!articleIds || articleIds.length === 0) {
        return res.status(400).json({
          success: false,
          error: "No articles selected"
        });
      }
      
      if (!platforms || platforms.length === 0) {
        return res.status(400).json({
          success: false,
          error: "No platforms selected"
        });
      }

      // Get articles from database
      const articles = await Promise.all(
        articleIds.map((id: string) => storage.getArticleById(id))
      );
      const validArticles = articles.filter(Boolean);

      if (validArticles.length === 0) {
        return res.status(404).json({
          success: false,
          error: "No articles found"
        });
      }

      // Convert to formatter format
      const formatterArticles = validArticles.map(a => ({
        id: a!.externalId,
        title: a!.title,
        content: a!.content,
        keywords: a!.keywords || [],
        sources: a!.sources || [],
        headerImage: a!.headerImage || undefined,
        metaDescription: a!.metaDescription || undefined
      }));

      // Format for each platform
      const formatted = formatForPlatforms(formatterArticles, platforms);

      res.json({
        success: true,
        data: formatted
      });
    } catch (error) {
      console.error("Format error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to format"
      });
    }
  });

  // ============================================
  // MARK AS PUBLISHED (HYBRID MODE)
  // ============================================

  app.post("/api/mark-published", async (req, res) => {
    try {
      const { articleId, platform, url } = req.body;
      
      if (!articleId || !platform || !url) {
        return res.status(400).json({
          success: false,
          error: "Missing required fields"
        });
      }

      const article = await storage.getArticleById(articleId);
      
      if (!article) {
        return res.status(404).json({
          success: false,
          error: "Article not found"
        });
      }

      // Add to published platforms
      const publishedPlatforms = article.publishedPlatforms || [];
      
      // Check if already published to this platform
      const existingIndex = publishedPlatforms.findIndex(
        p => p.name.toLowerCase() === platform.toLowerCase()
      );
      
      if (existingIndex >= 0) {
        publishedPlatforms[existingIndex] = {
          name: capitalizeFirst(platform),
          url,
          publishedAt: new Date().toISOString()
        };
      } else {
        publishedPlatforms.push({
          name: capitalizeFirst(platform),
          url,
          publishedAt: new Date().toISOString()
        });
      }

      await storage.updateArticle(articleId, {
        publishedPlatforms,
        lastPublishedAt: new Date()
      });

      res.json({
        success: true,
        message: "Marked as published"
      });
    } catch (error) {
      console.error("Mark published error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to mark as published"
      });
    }
  });

  // ============================================
  // PLATFORM SETTINGS ROUTES
  // ============================================

  app.get("/api/platforms", async (req, res) => {
    try {
      const status = await storage.getAllPlatformStatus();
      
      res.json({
        success: true,
        platforms: status
      });
    } catch (error) {
      console.error("Get platforms error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to get platforms"
      });
    }
  });

  app.post("/api/platforms/connect", async (req, res) => {
    try {
      const { platform, token, username, userId } = req.body;
      
      if (!platform || !token) {
        return res.status(400).json({
          success: false,
          error: "Platform and token required"
        });
      }

      // Test connection before saving
      const isValid = await testPlatformConnection(platform, token, username);
      
      if (!isValid) {
        return res.status(400).json({
          success: false,
          error: "Invalid credentials or connection failed. Please check your API token."
        });
      }
      
      // Save credentials to database
      await storage.savePlatformCredential(platform, {
        token,
        username,
        userId
      });
      
      console.log(`Platform ${platform} connected successfully`);
      
      res.json({
        success: true,
        message: "Platform connected successfully"
      });
    } catch (error) {
      console.error("Connect platform error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to connect platform"
      });
    }
  });

  app.delete("/api/platforms/:platform", async (req, res) => {
    try {
      await storage.savePlatformCredential(req.params.platform, null);
      
      console.log(`Platform ${req.params.platform} disconnected`);
      
      res.json({
        success: true,
        message: "Platform disconnected"
      });
    } catch (error) {
      console.error("Disconnect platform error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to disconnect platform"
      });
    }
  });

  // ============================================
  // SYSTEM STATUS ROUTE
  // ============================================

  app.get("/api/system/status", async (_req, res) => {
    try {
      const supabaseConfigured = !!(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY);
      
      const status = {
        browserbase: !!process.env.BROWSERBASE_API_KEY,
        anthropic: !!(process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY),
        database: supabaseConfigured
      };

      const details = {
        browserbase: {
          configured: status.browserbase,
          keyPrefix: status.browserbase && process.env.BROWSERBASE_API_KEY 
            ? process.env.BROWSERBASE_API_KEY.substring(0, 6) + "..." 
            : null
        },
        anthropic: {
          configured: status.anthropic,
          provider: process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY ? "Replit AI Integration" : "Direct API Key"
        },
        database: {
          configured: supabaseConfigured,
          type: "Supabase PostgreSQL",
          hasUrl: !!process.env.SUPABASE_URL,
          hasKey: !!process.env.SUPABASE_ANON_KEY
        }
      };

      res.json({
        success: true,
        status,
        details,
        allReady: Object.values(status).every(s => s)
      });
    } catch (error) {
      console.error("System status check error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to check system status"
      });
    }
  });

  return httpServer;
}
