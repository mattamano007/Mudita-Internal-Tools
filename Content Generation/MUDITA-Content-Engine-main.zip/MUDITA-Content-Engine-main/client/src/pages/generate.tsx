import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Sparkles, Globe, Pencil, Rocket, PiggyBank, Laptop, BarChart3, Briefcase, Target, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ProgressSteps } from "@/components/progress-steps";
import { PersonaCard } from "@/components/persona-card";
import { StyleCard } from "@/components/style-card";
import { GeneratingScreen } from "@/components/generating-screen";
import { ArticleCard } from "@/components/article-card";
import { ArticleModal } from "@/components/article-modal";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Article } from "@shared/schema";
import { useLocation } from "wouter";

const steps = [
  { id: 1, label: "Company" },
  { id: 2, label: "Audience" },
  { id: 3, label: "Style" },
  { id: 4, label: "Generate" },
];

const personas: { id: string; icon: LucideIcon; title: string; description: string }[] = [
  {
    id: "founders",
    icon: Rocket,
    title: "Startup Founders",
    description: "Early-stage entrepreneurs building new companies",
  },
  {
    id: "cfo",
    icon: PiggyBank,
    title: "CFOs & Finance Leaders",
    description: "Financial decision-makers at growing companies",
  },
  {
    id: "tech",
    icon: Laptop,
    title: "Tech Professionals",
    description: "Developers, engineers, and technical teams",
  },
  {
    id: "marketing",
    icon: BarChart3,
    title: "Marketing Leaders",
    description: "CMOs and marketing professionals",
  },
  {
    id: "executives",
    icon: Briefcase,
    title: "Business Executives",
    description: "C-suite and senior management",
  },
  {
    id: "sales",
    icon: Target,
    title: "Sales Teams",
    description: "Sales professionals and account managers",
  },
];

const styles = [
  {
    id: "modern-tech",
    title: "Modern Tech",
    description: "Clean, minimalist, tech-focused with soft gradients",
    example: "Ideal for SaaS and tech companies",
    colors: ["#667eea", "#764ba2", "#66a6ff"],
  },
  {
    id: "business",
    title: "Business Professional",
    description: "Corporate, sleek, professional with muted colors",
    example: "Perfect for enterprise and B2B",
    colors: ["#1e3a5f", "#2d5a7b", "#4a7c9b"],
  },
  {
    id: "creative",
    title: "Creative & Bold",
    description: "Colorful, dynamic, eye-catching designs",
    example: "Great for startups and consumer brands",
    colors: ["#f093fb", "#f5576c", "#ffecd2"],
  },
  {
    id: "minimal",
    title: "Minimal & Clean",
    description: "Simple, elegant, focus on content",
    example: "Best for thought leadership",
    colors: ["#c9d6ff", "#e2e2e2", "#ffffff"],
  },
];

interface FormData {
  website: string;
  personas: string[];
  style: string;
}

export default function GeneratePage() {
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    website: "",
    personas: [],
    style: "",
  });
  const [generating, setGenerating] = useState(false);
  const [generatingProgress, setGeneratingProgress] = useState({ step: 1, status: "" });
  const [articles, setArticles] = useState<Article[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const { toast } = useToast();

  const formatPersonas = (personaIds: string[]) => {
    return personaIds
      .map((id) => {
        const persona = personas.find((p) => p.id === id);
        return persona ? persona.title : id;
      })
      .join(", ");
  };

  const togglePersona = (personaId: string) => {
    const current = formData.personas;
    if (current.includes(personaId)) {
      setFormData({ ...formData, personas: current.filter((id) => id !== personaId) });
    } else if (current.length < 3) {
      setFormData({ ...formData, personas: [...current, personaId] });
    }
  };

  const formatStyle = (styleId: string) => {
    const style = styles.find((s) => s.id === styleId);
    return style ? style.title : styleId === "default" ? "Default Style" : styleId;
  };

  const generateMutation = useMutation({
    mutationFn: async () => {
      setGenerating(true);
      setGeneratingProgress({ step: 1, status: "analyzing" });

      const selectedPersonas = formData.personas.map((id) => personas.find((p) => p.id === id)).filter(Boolean);
      const input = {
        brandWebsiteUrl: formData.website,
        industry: "Technology",
        customIndustry: "",
        icpDetails: {
          jobTitles: selectedPersonas.map((p) => p?.title).join(", "),
          painPoints: selectedPersonas.map((p) => p?.description).join("; "),
          companySize: "Startup" as const,
        },
        productNiche: formData.style,
        industryVertical: "B2B",
      };

      setGeneratingProgress({ step: 2, status: "generating topics" });
      const keywordsResponse = await apiRequest("POST", "/api/generate/keywords", input);
      const keywordsData = await keywordsResponse.json();

      setGeneratingProgress({ step: 3, status: "writing articles" });
      const articlesResponse = await apiRequest("POST", "/api/generate/articles", {
        input,
        keywords: keywordsData.keywords.slice(0, 5),
      });
      const articlesData = await articlesResponse.json();

      setGeneratingProgress({ step: 4, status: "optimizing" });
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setGeneratingProgress({ step: 5, status: "finalizing" });
      await new Promise((resolve) => setTimeout(resolve, 500));

      return articlesData.articles;
    },
    onSuccess: (data) => {
      const generatedArticles = data.map((article: any, index: number) => ({
        ...article,
        id: `article-${Date.now()}-${index}`,
        status: "generated" as const,
        createdAt: new Date().toISOString(),
      }));
      setArticles(generatedArticles);
      storage.saveArticles(generatedArticles);
      setGenerating(false);
      setCurrentStep(5);
      toast({
        title: "Articles generated!",
        description: `Successfully generated ${generatedArticles.length} articles.`,
      });
    },
    onError: (error: Error) => {
      setGenerating(false);
      toast({
        title: "Error generating articles",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    generateMutation.mutate();
  };

  const handleStartOver = () => {
    setCurrentStep(1);
    setFormData({ website: "", personas: [], style: "" });
    setArticles([]);
  };

  const handleDeleteArticle = (id: string) => {
    setArticles(articles.filter((a) => a.id !== id));
    storage.deleteArticle(id);
  };

  const isValidUrl = (url: string) => {
    try {
      new URL(url);
      return true;
    } catch {
      return url.includes(".") && url.length > 4;
    }
  };

  if (generating) {
    return <GeneratingScreen progress={generatingProgress} />;
  }

  return (
    <div className="flex flex-col min-h-full bg-black">
      <div className="px-6 md:px-12 py-6 border-b border-white/10 bg-black sticky top-0 z-10">
        <ProgressSteps steps={steps} currentStep={Math.min(currentStep, 4)} />
      </div>

      <div className="flex-1 px-6 md:px-12 py-8">
        <div className="max-w-4xl mx-auto">
          {currentStep === 1 && (
            <div className="text-center">
              <h1 className="text-3xl font-bold text-white mb-3">Tell us about your company</h1>
              <p className="text-[#94a3b8] text-lg mb-10">
                We'll analyze your website to understand your business
              </p>

              <Card className="bg-[#1e293b] border-white/10 max-w-lg mx-auto">
                <CardContent className="p-8">
                  <div className="mb-6">
                    <label className="block text-[#e2e8f0] text-sm font-medium mb-3 text-left">
                      Company Website
                    </label>
                    <div className="flex items-center gap-3 bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-4 focus-within:border-[#a855f7] focus-within:shadow-[0_0_0_3px_rgba(168,85,247,0.1)] transition-all">
                      <Globe className="w-5 h-5 text-[#64748b]" />
                      <input
                        type="url"
                        placeholder="https://yourcompany.com"
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        className="flex-1 bg-transparent border-none text-white text-base outline-none placeholder:text-[#64748b]"
                        data-testid="input-website"
                      />
                    </div>
                    <p className="text-xs text-[#64748b] mt-2 text-left">
                      We'll automatically detect your industry and tone
                    </p>
                  </div>

                  <Button
                    onClick={() => setCurrentStep(2)}
                    disabled={!formData.website || !isValidUrl(formData.website)}
                    className="w-full h-12 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0 text-base font-semibold"
                    data-testid="button-next-audience"
                  >
                    Next: Choose Your Audience
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {currentStep === 2 && (
            <div className="text-center">
              <h1 className="text-3xl font-bold text-white mb-3">Who are you writing for?</h1>
              <p className="text-[#94a3b8] text-lg mb-4">
                Select up to 3 target audiences for your content
              </p>
              <p className="text-sm text-[#64748b] mb-10">
                {formData.personas.length}/3 selected
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                {personas.map((persona) => (
                  <PersonaCard
                    key={persona.id}
                    Icon={persona.icon}
                    title={persona.title}
                    description={persona.description}
                    selected={formData.personas.includes(persona.id)}
                    onClick={() => togglePersona(persona.id)}
                  />
                ))}
              </div>

              <div className="flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(1)}
                  className="h-12 px-6 border-white/20 text-white hover:bg-white/10"
                  data-testid="button-back-company"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Back
                </Button>
                <Button
                  onClick={() => setCurrentStep(3)}
                  disabled={formData.personas.length === 0}
                  className="h-12 px-8 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0 text-base font-semibold"
                  data-testid="button-next-style"
                >
                  Next: Choose Visual Style
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="text-center">
              <h1 className="text-3xl font-bold text-white mb-3">Choose your visual style</h1>
              <p className="text-[#94a3b8] text-lg mb-10">
                We'll generate header images for each article in this style
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {styles.map((style) => (
                  <StyleCard
                    key={style.id}
                    title={style.title}
                    description={style.description}
                    example={style.example}
                    colors={style.colors}
                    selected={formData.style === style.id}
                    onClick={() => setFormData({ ...formData, style: style.id })}
                  />
                ))}
              </div>

              <button
                onClick={() => {
                  setFormData({ ...formData, style: "default" });
                  setCurrentStep(4);
                }}
                className="text-[#64748b] text-sm hover:text-[#94a3b8] mb-8 block mx-auto"
                data-testid="button-skip-style"
              >
                Skip - I'll use the default style
              </button>

              <div className="flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(2)}
                  className="h-12 px-6 border-white/20 text-white hover:bg-white/10"
                  data-testid="button-back-audience"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Back
                </Button>
                <Button
                  onClick={() => setCurrentStep(4)}
                  disabled={!formData.style}
                  className="h-12 px-8 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0 text-base font-semibold"
                  data-testid="button-next-review"
                >
                  Next: Review & Generate
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="text-center max-w-xl mx-auto">
              <h1 className="text-3xl font-bold text-white mb-3">Ready to generate!</h1>
              <p className="text-[#94a3b8] text-lg mb-10">
                We'll create 5 unique articles customized for your business
              </p>

              <Card className="bg-[#1e293b] border-white/10 mb-8">
                <CardContent className="p-6">
                  <h3 className="text-white font-semibold mb-4 text-left">Your Settings</h3>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between py-3 border-b border-white/10">
                      <div className="text-left">
                        <p className="text-xs text-[#64748b] mb-1">Company:</p>
                        <p className="text-white">{formData.website}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setCurrentStep(1)}
                        className="text-[#a855f7] hover:text-[#a855f7]/80 hover:bg-[#a855f7]/10"
                      >
                        <Pencil className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>

                    <div className="flex items-center justify-between py-3 border-b border-white/10">
                      <div className="text-left">
                        <p className="text-xs text-[#64748b] mb-1">Writing for:</p>
                        <p className="text-white">{formatPersonas(formData.personas)}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setCurrentStep(2)}
                        className="text-[#a855f7] hover:text-[#a855f7]/80 hover:bg-[#a855f7]/10"
                      >
                        <Pencil className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>

                    <div className="flex items-center justify-between py-3">
                      <div className="text-left">
                        <p className="text-xs text-[#64748b] mb-1">Image style:</p>
                        <p className="text-white">{formatStyle(formData.style)}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setCurrentStep(3)}
                        className="text-[#a855f7] hover:text-[#a855f7]/80 hover:bg-[#a855f7]/10"
                      >
                        <Pencil className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#0f172a] border-[#334155] mb-8">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="w-5 h-5 text-[#a855f7]" />
                    <span className="text-white font-medium">Each article will include:</span>
                  </div>
                  <ul className="text-left text-[#94a3b8] text-sm space-y-2">
                    <li className="flex items-center gap-2">
                      <span className="text-green-400">✓</span>
                      Custom AI-generated header image (1200x630px)
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-400">✓</span>
                      300-350 words of SEO-optimized content
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-400">✓</span>
                      2 authoritative source links with descriptions
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-400">✓</span>
                      5 relevant keywords for search engines
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-400">✓</span>
                      Meta description for SEO
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-400">✓</span>
                      Ready to publish anywhere
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Button
                onClick={handleGenerate}
                className="w-full h-14 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0 text-lg font-semibold mb-3"
                data-testid="button-generate-articles"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Generate 5 Articles
              </Button>

              <p className="text-[#64748b] text-sm mb-6">Takes about 2-3 minutes</p>

              <button
                onClick={handleStartOver}
                className="text-[#64748b] text-sm hover:text-[#94a3b8]"
                data-testid="button-start-over"
              >
                ← Start over
              </button>
            </div>
          )}

          {currentStep === 5 && (
            <div>
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h1 className="text-3xl font-bold text-white">Generated Articles</h1>
                  <p className="text-[#94a3b8] mt-1">
                    {articles.length} articles generated successfully
                  </p>
                </div>
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={handleStartOver}
                    className="border-white/20 text-white hover:bg-white/10"
                    data-testid="button-start-new"
                  >
                    Start Over
                  </Button>
                  <Button
                    onClick={() => navigate("/dashboard")}
                    className="bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0"
                    data-testid="button-go-dashboard"
                  >
                    Go to Dashboard
                  </Button>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                {articles.map((article) => (
                  <ArticleCard
                    key={article.id}
                    article={article}
                    onDelete={() => handleDeleteArticle(article.id)}
                    onView={() => setSelectedArticle(article)}
                  />
                ))}
              </div>

              <ArticleModal
                article={selectedArticle}
                open={!!selectedArticle}
                onOpenChange={(open) => !open && setSelectedArticle(null)}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
