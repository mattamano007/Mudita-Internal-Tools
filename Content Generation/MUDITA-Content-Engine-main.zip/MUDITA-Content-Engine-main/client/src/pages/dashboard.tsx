import { useState, useMemo } from "react";
import { Link } from "wouter";
import { FileText, Sparkles, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ArticleCard } from "@/components/article-card";
import { ArticleModal } from "@/components/article-modal";
import { PublishingDrawer } from "@/components/publishing-drawer";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import type { Article } from "@shared/schema";

type FilterType = "all" | "generated" | "published";

export default function DashboardPage() {
  const [articles, setArticles] = useState<Article[]>(() => storage.getArticles());
  const [statusFilter, setStatusFilter] = useState<FilterType>("all");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [publishDrawerOpen, setPublishDrawerOpen] = useState(false);
  const { toast } = useToast();

  const filteredArticles = useMemo(() => {
    return articles.filter((article) => {
      if (statusFilter === "all") return true;
      return article.status === statusFilter;
    });
  }, [articles, statusFilter]);

  const selectedArticles = useMemo(() => {
    return articles.filter((a) => selectedIds.has(a.id));
  }, [articles, selectedIds]);

  const handleDeleteArticle = (id: string) => {
    storage.deleteArticle(id);
    setArticles(articles.filter((a) => a.id !== id));
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
    toast({
      title: "Article deleted",
      description: "The article has been removed.",
    });
  };

  const handleSelectAll = () => {
    const allIds = new Set(filteredArticles.map((a) => a.id));
    setSelectedIds(allIds);
  };

  const handleDeselectAll = () => {
    setSelectedIds(new Set());
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleOpenPublishDrawer = () => {
    if (selectedIds.size === 0) {
      toast({
        title: "No articles selected",
        description: "Please select at least one article to publish.",
        variant: "destructive",
      });
      return;
    }
    setPublishDrawerOpen(true);
  };

  const handlePublishComplete = () => {
    const updatedArticles = articles.map((article) =>
      selectedIds.has(article.id) ? { ...article, status: "published" as const } : article
    );
    setArticles(updatedArticles);
    storage.saveArticles(updatedArticles);
    toast({
      title: "Articles published!",
      description: `${selectedIds.size} article(s) have been published successfully.`,
    });
    setSelectedIds(new Set());
  };

  const filters: { key: FilterType; label: string }[] = [
    { key: "all", label: "All Articles" },
    { key: "generated", label: "Generated" },
    { key: "published", label: "Published" },
  ];

  return (
    <div className="px-6 md:px-10 py-10 min-h-full bg-black">
      <div className="max-w-[1400px] mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Dashboard</h1>
            <p className="text-base text-[#94a3b8]">
              Manage and publish your generated articles
            </p>
          </div>
          {selectedIds.size > 0 && (
            <Button
              onClick={handleOpenPublishDrawer}
              className="bg-gradient-to-br from-[#10b981] to-[#059669] hover:opacity-90 border-0 px-7 py-3.5 text-base font-semibold shadow-lg shadow-[#10b981]/30"
              data-testid="button-publish-selected"
            >
              <Send className="h-4 w-4 mr-2" />
              Publish Selected ({selectedIds.size})
            </Button>
          )}
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 p-4 md:p-6 bg-[#1e293b] border border-[#334155] rounded-xl">
          <div className="flex flex-wrap gap-3">
            {filters.map((filter) => (
              <button
                key={filter.key}
                onClick={() => setStatusFilter(filter.key)}
                className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  statusFilter === filter.key
                    ? "bg-gradient-to-r from-[#a855f7] to-[#ec4899] text-white border-transparent"
                    : "bg-transparent border border-[#334155] text-[#94a3b8] hover:border-[#a855f7] hover:text-[#a855f7]"
                }`}
                data-testid={`filter-${filter.key}`}
              >
                {filter.label}
              </button>
            ))}
          </div>

          <div className="flex gap-4">
            <button
              onClick={handleSelectAll}
              className="text-sm text-[#64748b] underline hover:text-[#a855f7] transition-colors"
              data-testid="button-select-all"
            >
              Select All
            </button>
            <button
              onClick={handleDeselectAll}
              className="text-sm text-[#64748b] underline hover:text-[#a855f7] transition-colors"
              data-testid="button-deselect-all"
            >
              Deselect All
            </button>
          </div>
        </div>

        {filteredArticles.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-[#1e293b] mb-6">
              <FileText className="h-10 w-10 text-[#64748b]" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No articles yet</h3>
            <p className="text-[#94a3b8] max-w-sm mb-6">
              {articles.length === 0
                ? "Start by generating your first batch of SEO-optimized articles."
                : "No articles match your current filter."}
            </p>
            {articles.length === 0 && (
              <Link href="/generate">
                <Button
                  className="bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0"
                  data-testid="button-generate-first"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Your First Article
                </Button>
              </Link>
            )}
          </div>
        ) : (
          <div
            className="grid gap-6"
            style={{
              gridTemplateColumns: "repeat(auto-fill, minmax(360px, 1fr))",
            }}
          >
            {filteredArticles.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                selected={selectedIds.has(article.id)}
                onSelect={() => toggleSelect(article.id)}
                onDelete={() => handleDeleteArticle(article.id)}
                onView={() => setSelectedArticle(article)}
              />
            ))}
          </div>
        )}

        <ArticleModal
          article={selectedArticle}
          open={!!selectedArticle}
          onOpenChange={(open) => !open && setSelectedArticle(null)}
        />

        <PublishingDrawer
          isOpen={publishDrawerOpen}
          onClose={() => setPublishDrawerOpen(false)}
          articles={selectedArticles}
          onPublishComplete={handlePublishComplete}
        />
      </div>
    </div>
  );
}
