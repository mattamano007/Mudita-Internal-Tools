import { useState } from "react";
import { useLocation } from "wouter";
import { Mail, Lock } from "lucide-react";
import { auth } from "@/lib/auth";
import muditaLogo from "@assets/mudita-logo-Dc1-cjiV_1768413280612.jpeg";

const APP_TITLE_PART_1 = "Content";
const APP_TITLE_PART_2 = "Engine";
const APP_DESCRIPTION = "Generate SEO-optimized content and publish across platforms";

export default function SignInPage() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const result = auth.login(email, password);
    if (result.success) {
      setLocation("/");
    } else {
      setError(result.error || "An error occurred");
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center px-4">
      <div className="w-full max-w-[480px] flex flex-col items-center">
        <img
          src={muditaLogo}
          alt="Mudita Studios"
          className="w-20 h-20 rounded border-2 border-white object-cover mb-6"
          style={{ borderRadius: "4px" }}
        />

        <h1 className="text-4xl font-bold tracking-tight text-center mb-3">
          <span className="text-white">{APP_TITLE_PART_1} </span>
          <span
            className="bg-clip-text text-transparent"
            style={{
              backgroundImage: "linear-gradient(135deg, #a855f7 0%, #ec4899 100%)",
            }}
          >
            {APP_TITLE_PART_2}
          </span>
        </h1>

        <p className="text-[#a1a1aa] text-base text-center max-w-[600px] mb-12">
          {APP_DESCRIPTION}
        </p>

        <div
          className={`w-full bg-[#1e293b] rounded-2xl p-12 shadow-2xl ${
            shake ? "animate-shake" : ""
          }`}
          style={{ boxShadow: "0 20px 60px rgba(0, 0, 0, 0.5)" }}
        >
          <h2 className="text-white text-[28px] font-semibold mb-2">Welcome back</h2>
          <p className="text-[#94a3b8] text-[15px] mb-8">
            Enter your credentials to access your account
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-[#e2e8f0] text-sm font-medium mb-2">
                Email
              </label>
              <div className="flex items-center gap-3 bg-[#0f172a] border border-[#334155] rounded-[10px] px-4 py-3.5 focus-within:border-[#a855f7] focus-within:shadow-[0_0_0_3px_rgba(168,85,247,0.1)] transition-all">
                <Mail className="w-[18px] h-[18px] text-[#64748b]" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="flex-1 bg-transparent border-none text-white text-[15px] outline-none placeholder:text-[#64748b]"
                  aria-label="Email address"
                  data-testid="input-email"
                />
              </div>
            </div>

            <div>
              <label className="block text-[#e2e8f0] text-sm font-medium mb-2">
                Password
              </label>
              <div className="flex items-center gap-3 bg-[#0f172a] border border-[#334155] rounded-[10px] px-4 py-3.5 focus-within:border-[#a855f7] focus-within:shadow-[0_0_0_3px_rgba(168,85,247,0.1)] transition-all">
                <Lock className="w-[18px] h-[18px] text-[#64748b]" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="flex-1 bg-transparent border-none text-white text-[15px] outline-none placeholder:text-[#64748b]"
                  aria-label="Password"
                  data-testid="input-password"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full h-[52px] mt-2 rounded-[10px] text-white text-base font-semibold tracking-wide transition-all hover:-translate-y-0.5 hover:shadow-[0_12px_24px_rgba(168,85,247,0.4)] active:scale-[0.98]"
              style={{
                background: "linear-gradient(135deg, #a855f7 0%, #ec4899 100%)",
              }}
              aria-label="Sign in to your account"
              data-testid="button-signin"
            >
              Sign In
            </button>

            {error && (
              <p className="text-[#ef4444] text-sm text-center animate-fadeIn" data-testid="text-error">
                {error}
              </p>
            )}
          </form>

          <p className="mt-5 text-center text-sm">
            <span className="text-[#94a3b8]">Don't have an account? </span>
            <span className="text-[#60a5fa] opacity-50 cursor-not-allowed">
              Sign up
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
