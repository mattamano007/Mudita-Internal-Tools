import { useState, useEffect } from "react";
import { 
  AlertTriangle, Info, Trash2, Check, X, Loader2, Lock, Cpu, Link2, Unlink,
  Settings, ChevronDown, ChevronRight, ExternalLink, Copy, Database, Sparkles, Globe
} from "lucide-react";
import { SiMedium, SiDevdotto, SiHashnode, SiLinkedin } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";

interface PlatformStatus {
  connected: boolean;
  username?: string;
  lastConnected?: string;
}

interface Platform {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  fields: string[];
  helpText: string;
}

interface SystemStatus {
  browserbase: boolean;
  anthropic: boolean;
  database: boolean;
}

interface SystemRequirementConfig {
  id: string;
  name: string;
  envVar: string;
  description: string;
  icon: React.ReactNode;
  docsUrl: string;
  setupInstructions: string[];
  required: boolean;
  importance: "critical" | "optional";
}

const systemRequirements: SystemRequirementConfig[] = [
  {
    id: "browserbase",
    name: "Browserbase",
    envVar: "BROWSERBASE_API_KEY",
    description: "Browser automation for automated publishing to all platforms",
    icon: <Globe className="w-5 h-5" />,
    docsUrl: "https://www.browserbase.com/docs",
    setupInstructions: [
      "Sign up at https://www.browserbase.com/",
      "Go to Settings → API Keys",
      "Generate new API key",
      "Add to Replit Secrets: BROWSERBASE_API_KEY=bb_..."
    ],
    required: true,
    importance: "critical"
  },
  {
    id: "anthropic",
    name: "Anthropic Claude",
    envVar: "AI_INTEGRATIONS_ANTHROPIC_API_KEY",
    description: "AI content generation (provided by Replit AI integration)",
    icon: <Sparkles className="w-5 h-5" />,
    docsUrl: "https://docs.anthropic.com/",
    setupInstructions: [
      "Handled automatically by Replit AI",
      "No manual setup required",
      "Usage billed to Replit credits"
    ],
    required: true,
    importance: "critical"
  },
  {
    id: "database",
    name: "Supabase Database",
    envVar: "SUPABASE_URL, SUPABASE_ANON_KEY",
    description: "PostgreSQL database for article storage with real-time features",
    icon: <Database className="w-5 h-5" />,
    docsUrl: "https://supabase.com/docs",
    setupInstructions: [
      "Create account at https://supabase.com/",
      "Create new project (choose region closest to you)",
      "Wait 2 minutes for database to provision",
      "Go to Settings → API",
      "Copy 'Project URL' → Add to Replit Secrets as SUPABASE_URL",
      "Copy 'anon public' key → Add to Replit Secrets as SUPABASE_ANON_KEY",
      "Run the SQL schema in Supabase SQL Editor"
    ],
    required: true,
    importance: "critical"
  }
];

const platforms: Platform[] = [
  {
    id: "medium",
    name: "Medium",
    icon: <SiMedium className="w-8 h-8" />,
    description: "Publish to Medium.com",
    color: "#00ab6c",
    fields: ["token"],
    helpText: "Enter your Medium API token to enable automatic publishing."
  },
  {
    id: "devto",
    name: "DEV.to",
    icon: <SiDevdotto className="w-8 h-8" />,
    description: "Publish to DEV Community",
    color: "#0a0a0a",
    fields: ["token"],
    helpText: "Enter your DEV.to API key from Settings > Extensions > DEV API Keys."
  },
  {
    id: "hashnode",
    name: "Hashnode",
    icon: <SiHashnode className="w-8 h-8" />,
    description: "Publish to Hashnode",
    color: "#2962ff",
    fields: ["token", "username"],
    helpText: "Enter your Hashnode API token and publication username."
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    icon: <SiLinkedin className="w-8 h-8" />,
    description: "Post to LinkedIn feed",
    color: "#0077b5",
    fields: ["token"],
    helpText: "LinkedIn requires OAuth. Use browser automation mode for best results."
  }
];

interface SystemRequirementProps {
  config: SystemRequirementConfig;
  configured: boolean;
}

function SystemRequirement({ config, configured }: SystemRequirementProps) {
  const { toast } = useToast();
  const [showInstructions, setShowInstructions] = useState(false);

  const copyEnvVar = () => {
    navigator.clipboard.writeText(config.envVar);
    toast({
      title: "Copied",
      description: `${config.envVar} copied to clipboard`
    });
  };

  return (
    <div className={`p-5 rounded-xl border-2 transition-all ${
      configured 
        ? "border-[#10b981] bg-[#10b981]/5" 
        : "border-[#f59e0b] bg-[#f59e0b]/5"
    }`}>
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex items-start gap-3">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
            configured ? "bg-[#10b981]/20 text-[#10b981]" : "bg-[#f59e0b]/20 text-[#f59e0b]"
          }`}>
            {config.icon}
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-semibold text-white">{config.name}</h4>
              <Badge 
                variant="outline" 
                className={`text-xs ${
                  config.importance === "critical" 
                    ? "border-[#ef4444]/50 text-[#ef4444] bg-[#ef4444]/10" 
                    : "border-[#f59e0b]/50 text-[#f59e0b] bg-[#f59e0b]/10"
                }`}
              >
                {config.importance === "critical" ? "Required" : "Optional"}
              </Badge>
            </div>
            <p className="text-sm text-[#94a3b8]">{config.description}</p>
          </div>
        </div>
        
        <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium flex-shrink-0 ${
          configured 
            ? "bg-[#10b981]/20 text-[#10b981] border border-[#10b981]/40"
            : "bg-[#f59e0b]/20 text-[#f59e0b] border border-[#f59e0b]/40"
        }`}>
          {configured ? <Check className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
          {configured ? "Configured" : "Not Configured"}
        </span>
      </div>

      <div className="pt-4 border-t border-[#334155]">
        <div className="flex items-center gap-3 p-3 bg-[#0f172a] rounded-lg mb-3">
          <span className="text-xs text-[#64748b] font-medium">ENV VAR:</span>
          <code className="flex-1 text-sm text-[#a855f7] font-mono bg-[#a855f7]/10 px-2 py-1 rounded border border-[#a855f7]/30">
            {config.envVar}
          </code>
          <Button
            size="icon"
            variant="ghost"
            onClick={copyEnvVar}
            className="h-8 w-8 text-[#94a3b8] hover:text-white"
            data-testid={`button-copy-${config.id}`}
          >
            <Copy className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowInstructions(!showInstructions)}
            className="border-[#334155] text-[#e2e8f0] hover:border-[#a855f7] hover:text-[#a855f7]"
            data-testid={`button-instructions-${config.id}`}
          >
            {showInstructions ? <ChevronDown className="w-4 h-4 mr-1" /> : <ChevronRight className="w-4 h-4 mr-1" />}
            Setup Instructions
          </Button>
          <a
            href={config.docsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-sm font-medium bg-[#3b82f6]/10 border border-[#3b82f6]/30 text-[#3b82f6] hover:bg-[#3b82f6]/20 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Documentation
          </a>
        </div>

        {showInstructions && (
          <div className="mt-4 p-4 bg-[#a855f7]/5 border border-[#a855f7]/20 rounded-lg">
            <h5 className="text-sm font-medium text-[#e2e8f0] mb-3">Setup Steps:</h5>
            <ol className="space-y-2 text-sm text-[#cbd5e1]">
              {config.setupInstructions.map((instruction, idx) => (
                <li key={idx} className="flex gap-2">
                  <span className="text-[#a855f7] font-medium">{idx + 1}.</span>
                  {instruction}
                </li>
              ))}
            </ol>
          </div>
        )}
      </div>
    </div>
  );
}

interface PlatformCardProps {
  platform: Platform;
  connected: boolean;
  username?: string;
  onConnect: () => void;
  onDisconnect: () => void;
}

function PlatformCard({ platform, connected, username, onConnect, onDisconnect }: PlatformCardProps) {
  return (
    <div className={`p-5 rounded-xl border-2 transition-all ${
      connected 
        ? "border-[#10b981] bg-[#10b981]/5" 
        : "border-[#334155] bg-[#0f172a] hover:border-[#a855f7]"
    }`}>
      <div className="flex gap-4 mb-4">
        <div 
          className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: `${platform.color}20`, color: platform.color }}
        >
          {platform.icon}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-white font-semibold text-lg">{platform.name}</h3>
          <p className="text-[#94a3b8] text-sm">{platform.description}</p>
          {connected && username && (
            <p className="text-xs text-[#64748b] mt-1">@{username}</p>
          )}
        </div>
      </div>

      {connected ? (
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#10b981]/20 text-[#10b981] text-sm font-medium border border-[#10b981]/40">
            <Check className="w-3.5 h-3.5" />
            Connected
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={onDisconnect}
            className="border-[#ef4444]/50 text-[#ef4444] hover:bg-[#ef4444]/10 hover:text-[#ef4444]"
            data-testid={`button-disconnect-${platform.id}`}
          >
            <Unlink className="w-4 h-4 mr-1" />
            Disconnect
          </Button>
        </div>
      ) : (
        <Button
          onClick={onConnect}
          className="w-full bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0"
          data-testid={`button-connect-${platform.id}`}
        >
          <Link2 className="w-4 h-4 mr-2" />
          Connect Account
        </Button>
      )}
    </div>
  );
}

interface ConnectionModalProps {
  platform: Platform;
  onClose: () => void;
  onSuccess: () => void;
}

function ConnectionModal({ platform, onClose, onSuccess }: ConnectionModalProps) {
  const { toast } = useToast();
  const [credentials, setCredentials] = useState({
    token: "",
    username: ""
  });
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleConnect = async () => {
    if (!credentials.token) {
      setError("API token is required");
      return;
    }

    if (platform.fields.includes("username") && !credentials.username) {
      setError("Username is required");
      return;
    }

    setConnecting(true);
    setError(null);

    try {
      const response = await fetch("/api/platforms/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platform: platform.id,
          token: credentials.token,
          username: credentials.username || undefined
        })
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Platform connected",
          description: `Successfully connected to ${platform.name}.`
        });
        onSuccess();
      } else {
        setError(data.error || "Failed to connect. Please check your credentials.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Connection failed");
    } finally {
      setConnecting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div 
        className="bg-[#0f172a] border border-[#334155] rounded-xl max-w-md w-full overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-[#334155]">
          <h3 className="text-lg font-semibold text-white">Connect {platform.name}</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#1e293b] border border-[#334155] flex items-center justify-center text-[#94a3b8] hover:text-white transition-colors"
            data-testid="button-close-modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          <div className="flex items-start gap-3 p-4 bg-[#3b82f6]/10 border border-[#3b82f6]/30 rounded-xl">
            <Lock className="w-5 h-5 text-[#3b82f6] flex-shrink-0 mt-0.5" />
            <p className="text-sm text-[#cbd5e1] leading-relaxed">{platform.helpText}</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="token" className="text-[#e2e8f0]">API Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your API token"
                value={credentials.token}
                onChange={(e) => setCredentials({ ...credentials, token: e.target.value })}
                className="bg-[#1e293b] border-[#334155] text-white placeholder:text-[#64748b] focus:border-[#a855f7]"
                data-testid="input-api-token"
              />
            </div>

            {platform.fields.includes("username") && (
              <div className="space-y-2">
                <Label htmlFor="username" className="text-[#e2e8f0]">Username / Publication ID</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="yourusername"
                  value={credentials.username}
                  onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                  className="bg-[#1e293b] border-[#334155] text-white placeholder:text-[#64748b] focus:border-[#a855f7]"
                  data-testid="input-username"
                />
              </div>
            )}
          </div>

          {error && (
            <div className="flex items-start gap-2.5 p-3 bg-[#ef4444]/10 border border-[#ef4444]/30 rounded-lg text-[#ef4444]">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div className="flex items-start gap-3 p-4 bg-[#10b981]/10 border border-[#10b981]/30 rounded-xl">
            <Lock className="w-5 h-5 text-[#10b981] flex-shrink-0 mt-0.5" />
            <p className="text-xs text-[#cbd5e1] leading-relaxed">
              Your credentials are stored securely and used only for automated publishing. 
              We never share your data with third parties.
            </p>
          </div>
        </div>

        <div className="flex gap-3 p-5 border-t border-[#334155]">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1 border-[#334155] text-[#94a3b8] hover:text-white"
          >
            Cancel
          </Button>
          <Button
            onClick={handleConnect}
            disabled={connecting || !credentials.token}
            className="flex-1 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0"
            data-testid="button-confirm-connect"
          >
            {connecting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Connecting...
              </>
            ) : (
              "Connect Account"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const { toast } = useToast();
  const [articleCount, setArticleCount] = useState(() => storage.getArticles().length);
  const [sessionCount, setSessionCount] = useState(() => storage.getSessions().length);
  const [platformStatus, setPlatformStatus] = useState<Record<string, PlatformStatus>>({});
  const [connectingPlatform, setConnectingPlatform] = useState<Platform | null>(null);
  const [loadingPlatforms, setLoadingPlatforms] = useState(true);
  const [systemStatus, setSystemStatus] = useState<SystemStatus>({
    browserbase: false,
    anthropic: false,
    database: false
  });
  const [loadingSystem, setLoadingSystem] = useState(true);

  useEffect(() => {
    loadPlatformStatus();
    checkSystemStatus();
  }, []);

  async function checkSystemStatus() {
    setLoadingSystem(true);
    try {
      const response = await fetch("/api/system/status");
      const data = await response.json();
      if (data.success) {
        setSystemStatus(data.status);
      }
    } catch (error) {
      console.error("Failed to check system status:", error);
    } finally {
      setLoadingSystem(false);
    }
  }

  async function loadPlatformStatus() {
    setLoadingPlatforms(true);
    try {
      const response = await fetch("/api/platforms");
      const data = await response.json();
      if (data.success) {
        setPlatformStatus(data.platforms || {});
      }
    } catch (error) {
      console.error("Failed to load platform status:", error);
    } finally {
      setLoadingPlatforms(false);
    }
  }

  async function handleDisconnect(platformId: string) {
    try {
      const response = await fetch(`/api/platforms/${platformId}`, {
        method: "DELETE"
      });
      const data = await response.json();

      if (data.success) {
        toast({
          title: "Platform disconnected",
          description: `Successfully disconnected from ${platformId}.`
        });
        loadPlatformStatus();
      } else {
        toast({
          title: "Disconnect failed",
          description: data.error || "Failed to disconnect platform.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Disconnect failed",
        description: "Network error. Please try again.",
        variant: "destructive"
      });
    }
  }

  const handleClearData = () => {
    storage.clearAllData();
    setArticleCount(0);
    setSessionCount(0);
    toast({
      title: "Data cleared",
      description: "All stored articles and sessions have been removed.",
    });
  };

  const allSystemsReady = systemStatus.browserbase && systemStatus.anthropic && systemStatus.database;

  return (
    <div className="px-6 md:px-12 py-8 min-h-full bg-black">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-semibold text-white">Settings</h1>
          <p className="text-[#94a3b8] mt-1">
            Configure your content engine preferences
          </p>
        </div>

        {/* System Configuration Section */}
        <Card className="bg-gradient-to-br from-[#a855f7]/10 to-[#3b82f6]/10 border-[#a855f7]/30">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <Settings className="w-5 h-5 text-[#a855f7]" />
              System Configuration
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              Required environment variables and API keys (for developers)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loadingSystem ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-[#a855f7] animate-spin" />
              </div>
            ) : (
              <>
                <div className="space-y-4 mb-6">
                  {systemRequirements.map((req) => (
                    <SystemRequirement
                      key={req.id}
                      config={req}
                      configured={systemStatus[req.id as keyof SystemStatus] || false}
                    />
                  ))}
                </div>

                <div className="p-5 bg-[#0f172a] border-2 border-[#334155] rounded-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-[#94a3b8] font-semibold">System Status:</span>
                    <span className={`text-lg font-bold flex items-center gap-2 ${
                      allSystemsReady ? "text-[#10b981]" : "text-[#f59e0b]"
                    }`}>
                      {allSystemsReady ? (
                        <>
                          <Check className="w-5 h-5" />
                          All Systems Ready
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-5 h-5" />
                          Configuration Required
                        </>
                      )}
                    </span>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Platform Connections */}
        <Card className="bg-[#1e293b] border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <Link2 className="w-5 h-5 text-[#a855f7]" />
              Platform Connections
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              Connect your publishing accounts for automated distribution
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loadingPlatforms ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-[#a855f7] animate-spin" />
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {platforms.map((platform) => (
                    <PlatformCard
                      key={platform.id}
                      platform={platform}
                      connected={platformStatus[platform.id]?.connected || false}
                      username={platformStatus[platform.id]?.username}
                      onConnect={() => setConnectingPlatform(platform)}
                      onDisconnect={() => handleDisconnect(platform.id)}
                    />
                  ))}
                </div>

                <div className="flex items-start gap-3 p-4 bg-[#3b82f6]/10 border border-[#3b82f6]/30 rounded-xl">
                  <Info className="w-5 h-5 text-[#3b82f6] flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-[#cbd5e1] leading-relaxed">
                    Your credentials are securely stored and used only for automated publishing. 
                    We use direct API integration to publish on your behalf.
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* AI Integration */}
        <Card className="bg-[#1e293b] border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <Cpu className="w-5 h-5 text-[#a855f7]" />
              AI Integration
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              Mudita Content Engine uses Claude AI for content generation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Alert className="bg-[#a855f7]/10 border-[#a855f7]/30">
              <Info className="h-4 w-4 text-[#a855f7]" />
              <AlertTitle className="text-white">Powered by Replit AI</AlertTitle>
              <AlertDescription className="text-[#cbd5e1]">
                This application uses Replit's AI integration, which provides access to Claude 
                without requiring your own API key. Usage is billed to your Replit credits.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Storage */}
        <Card className="bg-[#1e293b] border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white">Storage</CardTitle>
            <CardDescription className="text-[#94a3b8]">
              Manage your locally stored data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-xl bg-[#0f172a] border border-[#334155]">
                <p className="text-sm text-[#94a3b8] mb-2">Articles</p>
                <p className="text-3xl font-bold text-white mb-1" data-testid="text-article-count">
                  {articleCount}
                </p>
                <p className="text-xs text-[#64748b]">Generated articles stored in browser</p>
              </div>
              <div className="p-5 rounded-xl bg-[#0f172a] border border-[#334155]">
                <p className="text-sm text-[#94a3b8] mb-2">Sessions</p>
                <p className="text-3xl font-bold text-white mb-1" data-testid="text-session-count">
                  {sessionCount}
                </p>
                <p className="text-xs text-[#64748b]">Saved generation sessions</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="bg-[#1e293b] border-[#ef4444]/30">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-[#ef4444]">
              <AlertTriangle className="h-5 w-5" />
              Danger Zone
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              Irreversible actions that will delete your data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl bg-[#0f172a] border border-[#ef4444]/30">
              <div>
                <p className="font-medium text-white">Clear All Data</p>
                <p className="text-sm text-[#94a3b8]">
                  Remove all stored articles and sessions
                </p>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="flex-shrink-0" data-testid="button-clear-data">
                    <Trash2 className="h-4 w-4 mr-2" />
                    Clear Data
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-[#0f172a] border-[#334155]">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-white">Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription className="text-[#94a3b8]">
                      This will permanently delete all your saved articles and generation 
                      sessions. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="bg-[#1e293b] border-[#334155] text-white hover:bg-[#334155]" data-testid="button-cancel-clear">
                      Cancel
                    </AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleClearData}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      data-testid="button-confirm-clear"
                    >
                      Clear All Data
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card className="bg-[#1e293b] border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white">About</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-5 rounded-xl bg-[#0f172a] border border-[#334155] space-y-3">
              <div className="flex justify-between py-2 border-b border-[#334155]">
                <span className="text-[#94a3b8]">Version</span>
                <span className="font-mono text-white">1.9.0</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#334155]">
                <span className="text-[#94a3b8]">Built by</span>
                <span className="font-semibold text-white">Mudita Studios</span>
              </div>
              <p className="text-sm text-[#cbd5e1] pt-2 leading-relaxed">
                Mudita Content Engine generates SEO and GEO-optimized content 
                for modern brands using AI-powered article generation.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {connectingPlatform && (
        <ConnectionModal
          platform={connectingPlatform}
          onClose={() => setConnectingPlatform(null)}
          onSuccess={() => {
            setConnectingPlatform(null);
            loadPlatformStatus();
          }}
        />
      )}
    </div>
  );
}
