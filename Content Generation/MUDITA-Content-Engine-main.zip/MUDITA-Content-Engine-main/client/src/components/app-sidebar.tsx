import { LayoutDashboard, Settings, Sparkles } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import muditaLogo from "@assets/mudita-logo-Dc1-cjiV_1768413280612.jpeg";

const menuItems = [
  {
    title: "Generate",
    url: "/",
    icon: Sparkles,
  },
  {
    title: "Dashboard",
    url: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar>
      <SidebarHeader className="p-6">
        <Link href="/" className="flex items-center gap-3">
          <img 
            src={muditaLogo} 
            alt="Mudita Studios" 
            className="h-10 w-10 rounded object-cover border border-white/20"
          />
          <div className="flex flex-col">
            <span className="text-lg font-semibold text-white">Content</span>
            <span 
              className="text-sm font-semibold bg-clip-text text-transparent"
              style={{ backgroundImage: "linear-gradient(135deg, #a855f7 0%, #ec4899 100%)" }}
            >
              Engine
            </span>
          </div>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive}>
                      <Link href={item.url} data-testid={`link-nav-${item.title.toLowerCase()}`}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <div className="text-xs text-muted-foreground text-center">
          Mudita Studios
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
