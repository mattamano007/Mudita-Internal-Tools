import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface Step {
  id: number;
  label: string;
}

interface ProgressStepsProps {
  steps: Step[];
  currentStep: number;
}

export function ProgressSteps({ steps, currentStep }: ProgressStepsProps) {
  return (
    <div className="flex items-center justify-center gap-2" data-testid="progress-steps">
      {steps.map((step, index) => {
        const isCompleted = step.id < currentStep;
        const isCurrent = step.id === currentStep;
        
        return (
          <div key={step.id} className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <div
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium transition-all",
                  isCompleted && "bg-gradient-to-r from-[#a855f7] to-[#ec4899] text-white",
                  isCurrent && "bg-gradient-to-r from-[#a855f7] to-[#ec4899] text-white ring-4 ring-[#a855f7]/20",
                  !isCompleted && !isCurrent && "bg-[#334155] text-[#94a3b8]"
                )}
              >
                {isCompleted ? (
                  <Check className="h-4 w-4" />
                ) : (
                  step.id
                )}
              </div>
              <span
                className={cn(
                  "text-sm font-medium hidden sm:block",
                  isCurrent && "text-white",
                  !isCurrent && "text-[#94a3b8]"
                )}
              >
                {step.label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div
                className={cn(
                  "h-0.5 w-8 sm:w-16 transition-colors",
                  isCompleted ? "bg-gradient-to-r from-[#a855f7] to-[#ec4899]" : "bg-[#334155]"
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
