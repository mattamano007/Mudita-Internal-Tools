import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface StyleCardProps {
  title: string;
  description: string;
  example: string;
  colors: string[];
  selected: boolean;
  onClick: () => void;
}

export function StyleCard({ title, description, example, colors, selected, onClick }: StyleCardProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl cursor-pointer transition-all border-2",
        "bg-[#1e293b] hover:bg-[#263548]",
        selected 
          ? "border-[#a855f7] shadow-[0_0_20px_rgba(168,85,247,0.3)]" 
          : "border-white/10 hover:border-white/20"
      )}
      onClick={onClick}
      data-testid={`style-card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="h-24 relative overflow-hidden">
        <div 
          className="absolute inset-0"
          style={{
            background: `linear-gradient(135deg, ${colors[0]} 0%, ${colors[1]} 50%, ${colors[2]} 100%)`
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1e293b] to-transparent" />
      </div>
      <div className="p-5">
        <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
        <p className="text-sm text-[#94a3b8] mb-2">{description}</p>
        <p className="text-xs text-[#64748b]">{example}</p>
      </div>
      {selected && (
        <div className="absolute top-3 right-3 w-6 h-6 bg-gradient-to-r from-[#a855f7] to-[#ec4899] rounded-full flex items-center justify-center">
          <Check className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}
