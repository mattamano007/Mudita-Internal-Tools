import { Check, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface PersonaCardProps {
  Icon: LucideIcon;
  title: string;
  description: string;
  selected: boolean;
  onClick: () => void;
}

export function PersonaCard({ Icon, title, description, selected, onClick }: PersonaCardProps) {
  return (
    <div
      className={cn(
        "relative p-6 rounded-xl cursor-pointer transition-all border-2",
        "bg-[#1e293b] hover:bg-[#263548]",
        selected 
          ? "border-[#a855f7] shadow-[0_0_20px_rgba(168,85,247,0.3)]" 
          : "border-white/10 hover:border-white/20"
      )}
      onClick={onClick}
      data-testid={`persona-card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#a855f7]/20 to-[#ec4899]/20 flex items-center justify-center mb-4">
        <Icon className="w-6 h-6 text-[#a855f7]" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
      <p className="text-sm text-[#94a3b8]">{description}</p>
      {selected && (
        <div className="absolute top-4 right-4 w-6 h-6 bg-gradient-to-r from-[#a855f7] to-[#ec4899] rounded-full flex items-center justify-center">
          <Check className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}
