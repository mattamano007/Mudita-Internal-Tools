import { useEffect, useState } from "react";
import { Sparkles, Search, Bot, CheckCircle, Clock, Circle } from "lucide-react";

interface GeneratingScreenProps {
  progress: {
    step: number;
    status: string;
  };
}

const progressSteps = [
  { id: 1, text: "Analyzing your business..." },
  { id: 2, text: "Generating content topics..." },
  { id: 3, text: "Writing articles..." },
  { id: 4, text: "Optimizing for SEO & GEO..." },
  { id: 5, text: "Adding authoritative sources..." },
  { id: 6, text: "Finalizing content..." },
];

export function GeneratingScreen({ progress }: GeneratingScreenProps) {
  const [animatedStep, setAnimatedStep] = useState(progress.step);

  useEffect(() => {
    setAnimatedStep(progress.step);
  }, [progress.step]);

  return (
    <div className="fixed inset-0 bg-black/95 flex items-center justify-center z-50">
      <div className="text-center max-w-lg px-6">
        <div className="relative w-32 h-32 mx-auto mb-8">
          <div className="absolute inset-0 border-4 border-[#a855f7] rounded-full animate-ping opacity-25" />
          <div className="absolute inset-2 border-4 border-[#ec4899] rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
          <div className="absolute inset-4 border-4 border-[#3b82f6] rounded-full animate-pulse" style={{ animationDelay: '0.8s' }} />
          <div className="absolute inset-0 flex items-center justify-center">
            <Sparkles className="w-12 h-12 text-[#a855f7] animate-spin" style={{ animationDuration: '3s' }} />
          </div>
        </div>

        <h2 className="text-3xl font-bold text-white mb-3">Creating your articles...</h2>
        <p className="text-[#94a3b8] text-lg mb-10">
          Analyzing your business, generating content, and optimizing for SEO & GEO
        </p>

        <div className="bg-[#1e293b] border border-[#334155] rounded-xl p-6 mb-6">
          {progressSteps.map((step) => {
            const isComplete = step.id < animatedStep;
            const isActive = step.id === animatedStep;
            const isWaiting = step.id > animatedStep;

            return (
              <div
                key={step.id}
                data-testid={`progress-step-${step.id}`}
                className={`flex items-center gap-3 py-3 text-sm transition-colors duration-300 ${
                  isComplete ? "text-green-400" : isActive ? "text-[#a855f7] font-medium" : "text-[#64748b]"
                }`}
              >
                <span className="w-6 flex items-center justify-center">
                  {isComplete && <CheckCircle className="w-4 h-4" />}
                  {isActive && <Clock className="w-4 h-4 animate-pulse" />}
                  {isWaiting && <Circle className="w-4 h-4" />}
                </span>
                <span className={isActive ? "animate-pulse" : ""}>{step.text}</span>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-[#a855f7]/10 to-[#ec4899]/10 border border-[#a855f7]/30 rounded-xl p-5 mb-6">
          <div className="flex items-center gap-4 mb-3">
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-[#a855f7]" />
              <span className="text-sm text-[#cbd5e1]">
                <span className="font-semibold text-white">SEO:</span> Google, Bing search
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-[#ec4899]" />
              <span className="text-sm text-[#cbd5e1]">
                <span className="font-semibold text-white">GEO:</span> ChatGPT, Perplexity, Claude AI search
              </span>
            </div>
          </div>
        </div>

        <p className="text-sm text-[#64748b] italic">
          About 2 minutes remaining...
        </p>
      </div>
    </div>
  );
}
