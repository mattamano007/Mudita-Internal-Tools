import { Copy, Check, Search, Bot, ExternalLink, Quote, MessageCircle, Lightbulb } from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Article } from "@shared/schema";

interface ArticleModalProps {
  article: Article | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ArticleModal({ article, open, onOpenChange }: ArticleModalProps) {
  const [copied, setCopied] = useState(false);

  if (!article) return null;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(`${article.title}\n\n${article.content}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[85vh] p-0 bg-[#1e293b] border-white/10">
        <DialogHeader className="p-6 pb-0">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <DialogTitle className="text-xl font-semibold leading-snug text-white">
                {article.title}
              </DialogTitle>
              <div className="flex items-center gap-3 mt-2 text-sm text-[#94a3b8] flex-wrap">
                <Badge variant="secondary" data-testid="badge-article-angle-modal" className="bg-[#a855f7]/20 text-[#a855f7] text-xs">
                  {article.angle}
                </Badge>
                <span>{article.wordCount} words</span>
                {article.optimizationScores && (
                  <>
                    <Badge variant="outline" className="border-green-500/50 text-green-400 text-xs">
                      SEO: {article.optimizationScores.seo}%
                    </Badge>
                    <Badge variant="outline" className="border-[#ec4899]/50 text-[#ec4899] text-xs">
                      GEO: {article.optimizationScores.geo}%
                    </Badge>
                  </>
                )}
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleCopy}
              data-testid="button-copy-article-modal"
              className="border-white/20 text-white hover:bg-white/10"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 mr-1" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-1" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </DialogHeader>

        <Tabs defaultValue="content" className="w-full">
          <div className="px-6 pt-4">
            <TabsList className="bg-[#0f172a] border border-white/10">
              <TabsTrigger value="content" data-testid="tab-content" className="data-[state=active]:bg-[#a855f7]/20">
                Content
              </TabsTrigger>
              <TabsTrigger value="optimizations" data-testid="tab-optimizations" className="data-[state=active]:bg-[#a855f7]/20">
                SEO & GEO
              </TabsTrigger>
              <TabsTrigger value="sources" data-testid="tab-sources" className="data-[state=active]:bg-[#a855f7]/20">
                Sources
              </TabsTrigger>
            </TabsList>
          </div>

          <ScrollArea className="h-[55vh]">
            <TabsContent value="content" className="p-6 pt-4 mt-0">
              {article.metaDescription && (
                <div className="mb-6 p-4 bg-[#0f172a] border border-white/10 rounded-lg">
                  <p className="text-xs text-[#64748b] mb-1 uppercase tracking-wide">Meta Description</p>
                  <p className="text-sm text-[#94a3b8] italic">{article.metaDescription}</p>
                </div>
              )}

              <div className="prose prose-sm prose-invert max-w-none">
                {article.content.split('\n\n').map((paragraph, index) => {
                  if (paragraph.startsWith('## ')) {
                    return (
                      <h2 key={index} className="text-lg font-semibold mt-6 mb-3 text-white">
                        {paragraph.replace('## ', '')}
                      </h2>
                    );
                  }
                  return (
                    <p key={index} className="text-sm leading-relaxed text-[#e2e8f0] mb-4">
                      {paragraph}
                    </p>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="optimizations" className="p-6 pt-4 mt-0">
              <div className="space-y-6">
                <div className="p-4 bg-gradient-to-r from-[#ec4899]/10 to-[#a855f7]/10 border border-[#ec4899]/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-4">
                    <Bot className="w-5 h-5 text-[#ec4899]" />
                    <h3 className="font-semibold text-white">GEO: AI-Searchable Content</h3>
                  </div>

                  {article.geoOptimizations?.directAnswers && article.geoOptimizations.directAnswers.length > 0 && (
                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageCircle className="w-4 h-4 text-[#94a3b8]" />
                        <h4 className="text-sm font-medium text-[#94a3b8]">Direct Answers</h4>
                      </div>
                      <ul className="space-y-2">
                        {article.geoOptimizations.directAnswers.map((answer, idx) => (
                          <li key={idx} className="text-sm text-[#e2e8f0] pl-4 border-l-2 border-[#ec4899]/50">
                            {answer}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {article.geoOptimizations?.keyFacts && article.geoOptimizations.keyFacts.length > 0 && (
                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Quote className="w-4 h-4 text-[#94a3b8]" />
                        <h4 className="text-sm font-medium text-[#94a3b8]">Key Facts (AI-Citable)</h4>
                      </div>
                      <ul className="space-y-2">
                        {article.geoOptimizations.keyFacts.map((fact, idx) => (
                          <li key={idx} className="text-sm text-[#e2e8f0] pl-4 border-l-2 border-[#a855f7]/50">
                            {fact}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {article.geoOptimizations?.conversationalPhrases && article.geoOptimizations.conversationalPhrases.length > 0 && (
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Lightbulb className="w-4 h-4 text-[#94a3b8]" />
                        <h4 className="text-sm font-medium text-[#94a3b8]">Natural Language Queries</h4>
                      </div>
                      <ul className="space-y-2">
                        {article.geoOptimizations.conversationalPhrases.map((phrase, idx) => (
                          <li key={idx} className="text-sm text-[#e2e8f0] italic pl-4">
                            "{phrase}"
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {!article.geoOptimizations && (
                    <p className="text-sm text-[#64748b] italic">No GEO optimizations available for this article.</p>
                  )}
                </div>

                <div className="p-4 bg-gradient-to-r from-[#3b82f6]/10 to-green-500/10 border border-[#3b82f6]/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-4">
                    <Search className="w-5 h-5 text-[#3b82f6]" />
                    <h3 className="font-semibold text-white">SEO: Traditional Search</h3>
                  </div>

                  {article.keywords && article.keywords.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-[#94a3b8] mb-2">Target Keywords</h4>
                      <div className="flex flex-wrap gap-2">
                        {article.keywords.map((keyword, idx) => (
                          <Badge key={idx} variant="secondary" className="bg-[#3b82f6]/20 text-[#3b82f6] text-xs">
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {article.metaDescription && (
                    <div>
                      <h4 className="text-sm font-medium text-[#94a3b8] mb-2">Meta Description</h4>
                      <p className="text-sm text-[#e2e8f0] italic">{article.metaDescription}</p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="sources" className="p-6 pt-4 mt-0">
              {article.sources && article.sources.length > 0 ? (
                <div className="space-y-4">
                  <p className="text-sm text-[#94a3b8] mb-4">
                    Authoritative sources cited in this article for credibility with AI search engines.
                  </p>
                  {article.sources.map((source, idx) => (
                    <div key={idx} className="p-4 bg-[#0f172a] border border-white/10 rounded-lg">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <h4 className="font-medium text-white mb-1">
                            {source.title || source.name}
                          </h4>
                          <p className="text-sm text-[#94a3b8] mb-2">
                            {source.publisher && <span className="font-medium">{source.publisher}</span>}
                            {source.yearPublished && <span> ({source.yearPublished})</span>}
                          </p>
                          {source.description && (
                            <p className="text-sm text-[#64748b]">{source.description}</p>
                          )}
                        </div>
                        {source.url && (
                          <a
                            href={source.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#a855f7] hover:text-[#ec4899] transition-colors"
                            data-testid={`link-source-${idx}`}
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-[#64748b]">No sources available for this article.</p>
                </div>
              )}
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
