import { FileText, Copy, Check, Trash2, ExternalLink } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Article } from "@shared/schema";

interface ArticleCardProps {
  article: Article;
  selected?: boolean;
  onSelect?: () => void;
  onDelete?: () => void;
  onView?: () => void;
}

export function ArticleCard({ article, selected, onSelect, onDelete, onView }: ArticleCardProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(`${article.title}\n\n${article.content}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleView = (e: React.MouseEvent) => {
    e.stopPropagation();
    onView?.();
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete?.();
  };

  return (
    <div
      className={`relative bg-[#1e293b] border-2 rounded-2xl overflow-hidden transition-all cursor-pointer ${
        selected
          ? "border-[#a855f7] shadow-[0_0_0_3px_rgba(168,85,247,0.2)]"
          : "border-[#334155] hover:border-[#a855f7]"
      }`}
      onClick={onSelect}
      data-testid={`card-article-${article.id}`}
    >
      <div
        className={`absolute inset-0 z-10 flex items-start justify-end p-4 transition-colors ${
          selected ? "bg-black/20" : "bg-transparent hover:bg-black/30"
        }`}
        style={{ pointerEvents: onSelect ? "auto" : "none" }}
      >
        {onSelect && (
          <div
            className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center transition-all ${
              selected
                ? "bg-[#a855f7] border-[#a855f7]"
                : "bg-[#1e293b] border-[#334155]"
            }`}
          >
            {selected && <Check className="w-5 h-5 text-white" />}
          </div>
        )}
      </div>

      <div className="w-full h-48 bg-[#0f172a] relative">
        {article.imageUrl ? (
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-full object-cover transition-transform hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <FileText className="w-12 h-12 text-[#334155]" />
          </div>
        )}
        {article.status === "published" && (
          <Badge className="absolute top-3 left-3 bg-[#10b981] text-white border-0">
            Published
          </Badge>
        )}
      </div>

      <div className="p-5 relative z-0" onClick={(e) => e.stopPropagation()}>
        <h3
          className="text-lg font-semibold text-white mb-3 line-clamp-2 cursor-pointer hover:text-[#a855f7] transition-colors"
          onClick={handleView}
          data-testid={`title-article-${article.id}`}
        >
          {article.title}
        </h3>

        <p className="text-sm text-[#cbd5e1] leading-relaxed mb-4 line-clamp-3">
          {article.content.substring(0, 150)}...
        </p>

        {article.keywords && article.keywords.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {article.keywords.slice(0, 3).map((keyword, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 text-xs font-medium rounded-xl bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7]"
              >
                {keyword}
              </span>
            ))}
            {article.keywords.length > 3 && (
              <span className="text-xs text-[#64748b]">+{article.keywords.length - 3} more</span>
            )}
          </div>
        )}

        {article.sources && article.sources.length > 0 && (
          <div className="flex items-center gap-2 mb-4 p-3 bg-[#3b82f6]/5 border-l-3 border-[#3b82f6] rounded">
            <ExternalLink className="w-4 h-4 text-[#3b82f6]" />
            <div className="flex gap-2 flex-wrap">
              {article.sources.slice(0, 2).map((source, idx) => (
                <a
                  key={idx}
                  href={source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1 text-xs font-medium rounded-xl bg-[#3b82f6]/10 border border-[#3b82f6]/30 text-[#3b82f6] hover:bg-[#3b82f6]/20 transition-colors"
                  onClick={(e) => e.stopPropagation()}
                >
                  {source.name}
                </a>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-4 border-t border-[#334155]">
          <Button
            variant="outline"
            size="sm"
            onClick={handleView}
            className="flex-1 border-[#334155] text-[#94a3b8] hover:border-[#a855f7] hover:text-[#a855f7] bg-transparent"
            data-testid={`button-view-article-${article.id}`}
          >
            View
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleCopy}
            className="flex-1 border-[#334155] text-[#94a3b8] hover:border-[#a855f7] hover:text-[#a855f7] bg-transparent"
            data-testid={`button-copy-article-${article.id}`}
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </>
            )}
          </Button>
          {onDelete && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleDelete}
              className="border-[#334155] text-[#94a3b8] hover:border-[#ef4444] hover:text-[#ef4444] bg-transparent px-3"
              data-testid={`button-delete-article-${article.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
