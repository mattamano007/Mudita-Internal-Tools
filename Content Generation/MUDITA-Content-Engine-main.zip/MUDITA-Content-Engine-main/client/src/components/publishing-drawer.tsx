import { useState, useEffect } from "react";
import { X, Check, Loader2, ExternalLink, FileText, AlertTriangle, Settings, Copy, Rocket, XCircle } from "lucide-react";
import { SiMedium, SiDevdotto, SiHashnode, SiLinkedin } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import type { Article } from "@shared/schema";

interface Platform {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
}

interface PlatformStatus {
  connected: boolean;
  username?: string;
  lastConnected?: string;
}

interface PublishResult {
  articleId: string;
  articleTitle: string;
  platforms: {
    name: string;
    success: boolean;
    url?: string;
    error?: string;
  }[];
}

interface PublishingDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  articles: Article[];
  onPublishComplete: (results: PublishResult[]) => void;
}

const platforms: Platform[] = [
  { id: "medium", name: "Medium", icon: <SiMedium className="w-5 h-5" />, color: "#00ab6c" },
  { id: "devto", name: "DEV.to", icon: <SiDevdotto className="w-5 h-5" />, color: "#0a0a0a" },
  { id: "hashnode", name: "Hashnode", icon: <SiHashnode className="w-5 h-5" />, color: "#2962ff" },
  { id: "linkedin", name: "LinkedIn", icon: <SiLinkedin className="w-5 h-5" />, color: "#0077b5" },
];

interface PlatformToggleProps {
  platform: Platform;
  connected: boolean;
  username?: string;
  selected: boolean;
  onToggle: () => void;
  onConnect: () => void;
}

function PlatformToggle({ platform, connected, username, selected, onToggle, onConnect }: PlatformToggleProps) {
  return (
    <div className={`rounded-xl border-2 overflow-hidden transition-all ${
      selected ? "border-[#10b981]" : "border-[#334155]"
    }`}>
      <div 
        className={`flex items-center justify-between p-4 bg-[#1e293b] ${connected ? "cursor-pointer" : ""}`}
        onClick={connected ? onToggle : undefined}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: `${platform.color}20`, color: platform.color }}
          >
            {platform.icon}
          </div>
          <div>
            <span className="text-white font-medium block">{platform.name}</span>
            {connected && username && (
              <span className="text-xs text-[#64748b]">@{username}</span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          {connected ? (
            <>
              <span className="text-xs font-semibold px-3 py-1.5 rounded-full bg-[#10b981]/20 text-[#10b981] border border-[#10b981]/40 flex items-center gap-1.5">
                <Check className="w-3 h-3" />
                Connected
              </span>
              <div
                className={`w-12 h-7 rounded-full p-1 transition-colors ${
                  selected ? "bg-[#10b981]" : "bg-[#334155]"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    selected ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </div>
            </>
          ) : (
            <Button
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onConnect();
              }}
              className="bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0 text-xs font-semibold"
              data-testid={`button-connect-${platform.id}`}
            >
              Connect Account
            </Button>
          )}
        </div>
      </div>

      {selected && !connected && (
        <div className="flex items-center gap-2.5 px-4 py-3 bg-[#f59e0b]/10 border-t border-[#f59e0b]/30 text-[#f59e0b] text-sm">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          <span>Account not connected. Click "Connect Account" to enable publishing.</span>
        </div>
      )}
    </div>
  );
}

interface QuickConnectModalProps {
  platform: string;
  onClose: () => void;
}

function QuickConnectModal({ platform, onClose }: QuickConnectModalProps) {
  const [, setLocation] = useLocation();
  
  const platformName = platforms.find(p => p.id === platform)?.name || platform;
  
  return (
    <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4" onClick={onClose}>
      <div 
        className="bg-[#0f172a] border border-[#334155] rounded-xl max-w-md w-full overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-[#334155]">
          <h3 className="text-lg font-semibold text-white">Connect {platformName}</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#1e293b] border border-[#334155] flex items-center justify-center text-[#94a3b8] hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5">
          <p className="text-[#cbd5e1] text-sm mb-2 leading-relaxed">
            You need to connect your {platformName} account to publish automatically.
          </p>
          <p className="text-[#cbd5e1] text-sm mb-6">Would you like to:</p>

          <div className="space-y-3">
            <button
              onClick={() => {
                setLocation("/settings");
                onClose();
              }}
              className="w-full flex items-center gap-3 p-4 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 text-white font-semibold rounded-xl transition-all"
              data-testid="button-go-to-settings"
            >
              <Settings className="w-5 h-5" />
              <span>Connect in Settings</span>
            </button>

            <button
              onClick={onClose}
              className="w-full flex items-center gap-3 p-4 bg-transparent border-2 border-[#334155] hover:border-[#a855f7] text-[#e2e8f0] hover:text-[#a855f7] font-semibold rounded-xl transition-all"
              data-testid="button-use-copy-paste"
            >
              <Copy className="w-5 h-5" />
              <span>Use Copy/Paste Mode</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function PublishingDrawer({ isOpen, onClose, articles, onPublishComplete }: PublishingDrawerProps) {
  const { toast } = useToast();
  const [selectedPlatforms, setSelectedPlatforms] = useState<Record<string, boolean>>({
    medium: false,
    devto: false,
    hashnode: false,
    linkedin: false,
  });
  const [platformStatus, setPlatformStatus] = useState<Record<string, PlatformStatus>>({});
  const [publishing, setPublishing] = useState(false);
  const [results, setResults] = useState<PublishResult[] | null>(null);
  const [publishError, setPublishError] = useState<string | null>(null);
  const [showConnectModal, setShowConnectModal] = useState<string | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);

  useEffect(() => {
    if (isOpen) {
      checkPlatformConnections();
    }
  }, [isOpen]);

  async function checkPlatformConnections() {
    setLoadingStatus(true);
    try {
      const response = await fetch("/api/platforms");
      const data = await response.json();
      
      if (data.success) {
        setPlatformStatus(data.platforms || {});
      }
    } catch (error) {
      console.error("Failed to check platform connections:", error);
    } finally {
      setLoadingStatus(false);
    }
  }

  if (!isOpen) return null;

  const togglePlatform = (id: string) => {
    setSelectedPlatforms((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const selectedCount = Object.values(selectedPlatforms).filter(Boolean).length;
  const connectedSelected = Object.keys(selectedPlatforms).filter(
    (p) => selectedPlatforms[p] && platformStatus[p]?.connected
  ).length;

  const handlePublish = async () => {
    const platformsToPublish = Object.keys(selectedPlatforms).filter(
      (p) => selectedPlatforms[p] && platformStatus[p]?.connected
    );

    if (platformsToPublish.length === 0) {
      toast({
        title: "No connected platforms selected",
        description: "Please connect and select at least one platform to publish.",
        variant: "destructive"
      });
      return;
    }

    setPublishing(true);
    setPublishError(null);

    try {
      const response = await fetch("/api/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          articleIds: articles.map(a => a.id),
          platforms: platformsToPublish
        })
      });

      const data = await response.json();

      if (data.success && data.results) {
        setResults(data.results);
        onPublishComplete(data.results);
        
        const successCount = data.results.reduce((acc: number, r: PublishResult) => 
          acc + r.platforms.filter(p => p.success).length, 0
        );
        
        toast({
          title: "Publishing complete",
          description: `Successfully published to ${successCount} platform${successCount !== 1 ? 's' : ''}.`
        });
      } else {
        const errorMessage = data.error || "Publishing failed. Please check your platform connections and try again.";
        setPublishError(errorMessage);
        toast({
          title: "Publishing failed",
          description: errorMessage,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Publishing failed:", error);
      const errorMessage = error instanceof Error ? error.message : "Network error. Please try again.";
      setPublishError(errorMessage);
      toast({
        title: "Publishing failed",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setPublishing(false);
    }
  };

  const handleClose = () => {
    setResults(null);
    setPublishError(null);
    setSelectedPlatforms({
      medium: false,
      devto: false,
      hashnode: false,
      linkedin: false,
    });
    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/60 z-40" onClick={handleClose} />

      <div className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-[#0f172a] border-l border-[#334155] z-50 flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-[#334155]">
          <div>
            <h2 className="text-xl font-semibold text-white">Publish Articles</h2>
            <p className="text-sm text-[#94a3b8]">
              {articles.length} article{articles.length > 1 ? "s" : ""} selected
            </p>
          </div>
          <button
            onClick={handleClose}
            className="w-10 h-10 rounded-lg bg-[#1e293b] border border-[#334155] flex items-center justify-center text-[#94a3b8] hover:text-white hover:border-[#a855f7] transition-colors"
            data-testid="button-close-drawer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-6">
          {results ? (
            <div className="space-y-6">
              <div className="text-center py-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#10b981]/20 flex items-center justify-center">
                  <Check className="w-8 h-8 text-[#10b981]" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Published Successfully!</h3>
                <p className="text-[#94a3b8]">Your articles are now live on the selected platforms</p>
              </div>

              <div className="space-y-4">
                {results.map((result) => (
                  <div key={result.articleId} className="p-4 bg-[#1e293b] border border-[#334155] rounded-xl">
                    <h4 className="text-white font-medium mb-3 line-clamp-1">{result.articleTitle}</h4>
                    <div className="space-y-2">
                      {result.platforms.map((platform) => (
                        <a
                          key={platform.name}
                          href={platform.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-between p-2 bg-[#10b981]/10 border border-[#10b981]/30 rounded-lg text-[#10b981] hover:bg-[#10b981]/20 transition-colors"
                        >
                          <span className="text-sm font-medium">{platform.name}</span>
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <Button
                onClick={handleClose}
                className="w-full h-12 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0"
              >
                Done
              </Button>
            </div>
          ) : publishing ? (
            <div className="flex flex-col items-center justify-center py-16">
              <Loader2 className="w-12 h-12 text-[#a855f7] animate-spin mb-6" />
              <h3 className="text-xl font-semibold text-white mb-2">Publishing...</h3>
              <p className="text-[#94a3b8] text-center">
                Sending {articles.length} article{articles.length > 1 ? "s" : ""} to {connectedSelected} platform
                {connectedSelected > 1 ? "s" : ""}
              </p>
            </div>
          ) : (
            <>
              <div className="mb-8">
                <h3 className="text-sm font-semibold text-[#e2e8f0] mb-3">Articles to Publish</h3>
                <div className="space-y-2">
                  {articles.map((article) => (
                    <div
                      key={article.id}
                      className="flex items-center gap-3 p-3 bg-[#1e293b] border border-[#334155] rounded-xl"
                    >
                      <div className="w-10 h-10 rounded-lg bg-[#0f172a] flex items-center justify-center text-[#64748b] flex-shrink-0">
                        {article.imageUrl ? (
                          <img src={article.imageUrl} alt="" className="w-full h-full object-cover rounded-lg" />
                        ) : (
                          <FileText className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white text-sm font-medium line-clamp-1">{article.title}</h4>
                        {article.keywords && (
                          <p className="text-xs text-[#64748b] line-clamp-1">{article.keywords.join(", ")}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-sm font-semibold text-[#e2e8f0] mb-2">Select Platforms</h3>
                <p className="text-xs text-[#64748b] mb-4">Choose where to publish your articles</p>

                {loadingStatus ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 text-[#a855f7] animate-spin" />
                  </div>
                ) : (
                  <div className="space-y-3">
                    {platforms.map((platform) => (
                      <PlatformToggle
                        key={platform.id}
                        platform={platform}
                        connected={platformStatus[platform.id]?.connected || false}
                        username={platformStatus[platform.id]?.username}
                        selected={selectedPlatforms[platform.id]}
                        onToggle={() => togglePlatform(platform.id)}
                        onConnect={() => setShowConnectModal(platform.id)}
                      />
                    ))}
                  </div>
                )}
              </div>

              <div className="p-4 bg-[#a855f7]/10 border border-[#a855f7]/30 rounded-xl mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#94a3b8]">Articles</span>
                  <span className="text-white font-medium">{articles.length}</span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#94a3b8]">Platforms</span>
                  <span className="text-white font-medium">{connectedSelected}</span>
                </div>
                <div className="flex justify-between text-sm pt-2 border-t border-[#a855f7]/30">
                  <span className="text-[#94a3b8]">Total Posts</span>
                  <span className="text-[#a855f7] font-semibold text-lg">{articles.length * connectedSelected}</span>
                </div>
              </div>

              {publishError && (
                <div className="flex items-start gap-3 p-4 bg-[#ef4444]/10 border border-[#ef4444]/30 rounded-xl mb-6 text-[#ef4444]">
                  <XCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-sm">Publishing failed</p>
                    <p className="text-sm opacity-80">{publishError}</p>
                  </div>
                </div>
              )}

              <Button
                onClick={handlePublish}
                disabled={connectedSelected === 0}
                className="w-full h-12 bg-gradient-to-r from-[#a855f7] to-[#ec4899] hover:opacity-90 border-0 text-base font-semibold disabled:opacity-50 gap-2"
                data-testid="button-confirm-publish"
              >
                <Rocket className="w-5 h-5" />
                Publish to {connectedSelected} Platform{connectedSelected !== 1 ? "s" : ""}
              </Button>
            </>
          )}
        </div>
      </div>

      {showConnectModal && (
        <QuickConnectModal
          platform={showConnectModal}
          onClose={() => setShowConnectModal(null)}
        />
      )}
    </>
  );
}
