import { X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface KeywordChipProps {
  keyword: string;
  selected: boolean;
  onToggle: () => void;
  onRemove?: () => void;
}

export function KeywordChip({ keyword, selected, onToggle, onRemove }: KeywordChipProps) {
  return (
    <Badge
      variant="secondary"
      className={cn(
        "cursor-pointer px-3 py-1.5 text-sm gap-1.5 transition-all",
        selected && "bg-gradient-to-r from-[#a855f7] to-[#ec4899] text-white hover:opacity-90",
        !selected && "bg-[#334155] text-[#94a3b8] hover:bg-[#475569]"
      )}
      onClick={onToggle}
      data-testid={`chip-keyword-${keyword.replace(/\s+/g, '-').toLowerCase()}`}
    >
      <span className="truncate max-w-[200px]">{keyword}</span>
      {onRemove && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="ml-1 hover:opacity-70"
          data-testid={`button-remove-keyword-${keyword.replace(/\s+/g, '-').toLowerCase()}`}
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </Badge>
  );
}
