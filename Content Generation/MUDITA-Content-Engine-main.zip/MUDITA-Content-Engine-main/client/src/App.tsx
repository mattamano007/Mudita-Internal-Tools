import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { auth } from "@/lib/auth";
import GeneratePage from "@/pages/generate";
import DashboardPage from "@/pages/dashboard";
import SettingsPage from "@/pages/settings";
import SignInPage from "@/pages/signin";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  if (!auth.isAuthenticated()) {
    return <Redirect to="/signin" />;
  }
  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/signin" component={SignInPage} />
      <Route path="/">
        {() => <ProtectedRoute component={GeneratePage} />}
      </Route>
      <Route path="/generate">
        {() => <ProtectedRoute component={GeneratePage} />}
      </Route>
      <Route path="/dashboard">
        {() => <ProtectedRoute component={DashboardPage} />}
      </Route>
      <Route path="/settings">
        {() => <ProtectedRoute component={SettingsPage} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function AppLayout({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  
  const handleLogout = () => {
    auth.logout();
    setLocation("/signin");
  };

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <header className="flex items-center justify-between gap-4 px-4 h-14 border-b border-white/10 bg-black sticky top-0 z-20">
            <SidebarTrigger data-testid="button-sidebar-toggle" className="text-white" />
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              title="Sign out"
              data-testid="button-logout"
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </header>
          <main className="flex-1 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function AppContent() {
  const [location] = useLocation();
  const isSignIn = location === "/signin";
  const isAuthenticated = auth.isAuthenticated();

  if (isSignIn || !isAuthenticated) {
    return <Router />;
  }

  return (
    <AppLayout>
      <Router />
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppContent />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
