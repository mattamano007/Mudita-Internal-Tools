import type { GenerationSession, Article } from "@shared/schema";

const SESSIONS_KEY = "mudita-sessions";
const ARTICLES_KEY = "mudita-articles";

export const storage = {
  getSessions(): GenerationSession[] {
    try {
      const data = localStorage.getItem(SESSIONS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveSession(session: GenerationSession): void {
    const sessions = this.getSessions();
    const index = sessions.findIndex((s) => s.id === session.id);
    if (index >= 0) {
      sessions[index] = session;
    } else {
      sessions.unshift(session);
    }
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  },

  deleteSession(id: string): void {
    const sessions = this.getSessions().filter((s) => s.id !== id);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  },

  getArticles(): Article[] {
    try {
      const data = localStorage.getItem(ARTICLES_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveArticle(article: Article): void {
    const articles = this.getArticles();
    const index = articles.findIndex((a) => a.id === article.id);
    if (index >= 0) {
      articles[index] = article;
    } else {
      articles.unshift(article);
    }
    localStorage.setItem(ARTICLES_KEY, JSON.stringify(articles));
  },

  saveArticles(newArticles: Article[]): void {
    const articles = this.getArticles();
    newArticles.forEach((article) => {
      const index = articles.findIndex((a) => a.id === article.id);
      if (index >= 0) {
        articles[index] = article;
      } else {
        articles.unshift(article);
      }
    });
    localStorage.setItem(ARTICLES_KEY, JSON.stringify(articles));
  },

  deleteArticle(id: string): void {
    const articles = this.getArticles().filter((a) => a.id !== id);
    localStorage.setItem(ARTICLES_KEY, JSON.stringify(articles));
  },

  clearAllData(): void {
    localStorage.removeItem(SESSIONS_KEY);
    localStorage.removeItem(ARTICLES_KEY);
  },
};
