const AUTH_KEY = "muditaAuth";
const USER_EMAIL_KEY = "userEmail";

const VALID_CREDENTIALS = {
  email: "gtm@muditastudios.com",
  password: "Mudita",
};

export const auth = {
  isAuthenticated(): boolean {
    return localStorage.getItem(AUTH_KEY) === "authenticated";
  },

  getUserEmail(): string | null {
    return localStorage.getItem(USER_EMAIL_KEY);
  },

  login(email: string, password: string): { success: boolean; error?: string } {
    if (!email.includes("@")) {
      return { success: false, error: "Please enter a valid email address" };
    }

    if (email === VALID_CREDENTIALS.email && password === VALID_CREDENTIALS.password) {
      localStorage.setItem(AUTH_KEY, "authenticated");
      localStorage.setItem(USER_EMAIL_KEY, email);
      return { success: true };
    }

    return { success: false, error: "Invalid email or password" };
  },

  logout(): void {
    localStorage.removeItem(AUTH_KEY);
    localStorage.removeItem(USER_EMAIL_KEY);
  },
};
