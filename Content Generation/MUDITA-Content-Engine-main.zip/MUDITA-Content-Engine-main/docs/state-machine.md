# Mudita Content Engine - State Machine Diagrams

## Overview

This document describes the state machines that govern the application's behavior.

---

## 1. Content Generation Session States

The generation wizard follows a linear flow with error handling:

```
                                    +-------+
                                    | ERROR |
                                    +-------+
                                        ^
                                        | (failure at any step)
                                        |
+-------+     +----------+     +------------+     +----------+
| INPUT | --> | KEYWORDS | --> | GENERATING | --> | COMPLETE |
+-------+     +----------+     +------------+     +----------+
    |              |                  |                 |
    v              v                  v                 v
 Step 1         Step 2            Steps 3-6         Dashboard
 Company      Select/Edit      AI Processing       View Results
  Info         Keywords        (6 sub-steps)
```

### Session States

| State | Description | User Actions |
|-------|-------------|--------------|
| `input` | User entering company information | Fill form, submit |
| `keywords` | Keywords generated, user reviews/edits | Select keywords, proceed |
| `generating` | AI generating articles | Wait, view progress |
| `complete` | Articles generated successfully | View articles |
| `error` | Generation failed | Retry or start over |

### Generation Sub-Steps (during `generating` state)

```
1. Analyzing your business...
        |
        v
2. Generating content topics...
        |
        v
3. Writing articles...
        |
        v
4. Optimizing for SEO & GEO...
        |
        v
5. Adding authoritative sources...
        |
        v
6. Finalizing content...
```

---

## 2. Article Lifecycle States

Individual articles follow this lifecycle:

```
                 +--------+
                 | DRAFT  |
                 +--------+
                     |
                     v (AI generates content)
                +-----------+
                | GENERATED |<--+
                +-----------+   |
                   |    |       |
        (publish)  |    |       | (republish/update)
                   v    |       |
              +-----------+     |
              | PUBLISHED |-----+
              +-----------+
                     
        (failure)  |
                   v
               +--------+
               | FAILED |
               +--------+
```

### Article States

| State | Description | Available Actions |
|-------|-------------|-------------------|
| `draft` | Content being prepared | Edit |
| `generated` | AI has created the article | View, Edit, Publish, Delete |
| `published` | Article published to platforms | View, Republish, Delete |
| `failed` | Publishing or generation failed | Retry, Delete |

---

## 3. Publishing Flow

When publishing an article:

```
Article (generated/published)
        |
        v
   Select Platforms
   (Medium, DEV.to, Hashnode, LinkedIn)
        |
        v
   Choose Method
        |
   +----+----+
   |         |
   v         v
Direct    Hybrid
 API      (Manual)
   |         |
   v         v
Auto-     Copy &
publish   Paste
   |         |
   v         v
Record   Mark as
 URL     Published
```

### Publishing Methods

| Method | Description |
|--------|-------------|
| Direct API | Automatic publishing via platform APIs (requires credentials) |
| Hybrid | Manual copy/paste with tracking |

---

## 4. Platform Connection States

Each publishing platform has its own connection state:

```
+----------------+     +-----------+     +-----------+
| NOT CONFIGURED | --> | CONNECTED | --> | LAST USED |
+----------------+     +-----------+     +-----------+
        ^                    |                 |
        |                    v                 |
        +------ (disconnect/expire) <----------+
```

---

## 5. System Configuration States

System services can be in these states:

```
+----------------+
| NOT CONFIGURED | (missing env vars/secrets)
+----------------+
        |
        v (add credentials)
+------------+
| CONFIGURED | (ready to use)
+------------+
```

### Tracked Services

- **Browserbase**: Browser automation (optional)
- **Anthropic Claude**: AI content generation (required)
- **Supabase Database**: Data storage (required)

---

## State Transitions Summary

```
User Journey:
=============

[Login] --> [Dashboard] --> [New Content] --> [Step 1: Company Info]
                |                                      |
                |                                      v
                |                              [Step 2: Keywords]
                |                                      |
                |                                      v
                |                              [Step 3: Generate]
                |                                      |
                v                                      v
          [View Articles] <------------------- [View Results]
                |
                v
          [Publish Article]
                |
                v
          [Select Platforms]
                |
                v
          [Published!]
```
