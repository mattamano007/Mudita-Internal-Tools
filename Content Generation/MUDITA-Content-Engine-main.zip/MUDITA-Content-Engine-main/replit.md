# Mudita Content Engine

## Overview

Mudita Content Engine is an AI-powered web application that generates SEO and GEO-optimized content for brands. The platform uses a multi-step workflow where users input brand information, generate target keywords using AI, and then produce optimized articles. Content is stored locally in the browser and can be managed through a dashboard interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, bundled with Vite
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state, React useState for local state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens, supporting light/dark themes
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful endpoints under `/api` prefix
- **AI Integration**: Anthropic Claude API for content generation (keywords and articles)
- **Build**: esbuild for server bundling, Vite for client bundling

### Data Storage
- **Client-side**: Browser localStorage for articles, sessions, and user preferences
- **Database Ready**: Drizzle ORM configured with PostgreSQL (schema in `shared/schema.ts`)
- **No server-side persistence currently**: All user data stored in browser

### Shared Code
- **Location**: `shared/` directory contains schemas shared between client and server
- **Validation**: Zod schemas for type-safe validation on both ends
- **Path Alias**: `@shared/*` maps to shared directory

### Key Design Decisions

1. **Multi-step Form Pattern**: Content generation uses a 3-step wizard (Brand Details → Keywords → Articles) with progress indicators and back/next navigation.

2. **Local-first Storage**: Credentials and generated content stored client-side for privacy. No server-side user data persistence.

3. **Batch Processing Utilities**: Server includes helpers for rate-limited AI API calls with retry logic (`server/replit_integrations/batch/`).

4. **Theme System**: CSS custom properties enable light/dark mode switching, with theme preference persisted to localStorage.

## External Dependencies

### AI Services
- **Anthropic Claude API**: Primary AI for content generation
  - Environment variables: `AI_INTEGRATIONS_ANTHROPIC_API_KEY`, `AI_INTEGRATIONS_ANTHROPIC_BASE_URL`
  - Used for keyword generation and article writing

### Database
- **PostgreSQL**: Configured via Drizzle ORM
  - Environment variable: `DATABASE_URL`
  - Migrations stored in `./migrations`
  - Schema defined in `shared/schema.ts`

### Third-Party Libraries
- **Radix UI**: Accessible component primitives for all UI elements
- **TanStack Query**: Async state management for API calls
- **Zod**: Schema validation shared between client and server
- **date-fns**: Date formatting utilities
- **Embla Carousel**: Carousel component functionality

### Development Tools
- **Vite**: Development server with HMR
- **Drizzle Kit**: Database migration tooling (`npm run db:push`)
- **TypeScript**: Full type coverage across client, server, and shared code