# Tweet Style Generator

## Overview
A Micro SaaS application that generates tweets by learning writing styles from reference Twitter/X accounts. Users can upload content ideas via CSV, and the AI generates tweets matching the learned style with auto-posting capabilities via post-bridge API.

## Current State
MVP complete with core functionality:
- Style learning from reference accounts (AI analyzes writing patterns)
- CSV upload for content ideas
- AI-powered tweet generation matching learned styles
- Kanban-style tweet management (Draft → Scheduled → Posted)
- Post-bridge API integration for auto-posting
- Dark/light mode theme toggle

## Project Architecture

### Frontend (client/src/)
- **Framework**: React with TypeScript, Vite bundler
- **Routing**: Wouter
- **State Management**: TanStack Query
- **UI Components**: shadcn/ui (Radix primitives)
- **Styling**: Tailwind CSS with custom design tokens

### Backend (server/)
- **Framework**: Express.js with TypeScript
- **Storage**: In-memory storage (MemStorage class)
- **AI Integration**: OpenAI via Replit AI Integrations

### Pages
- `/` - Dashboard with stats overview
- `/styles` - Style Library (create/manage style profiles)
- `/upload` - CSV upload for content ideas
- `/generate` - Tweet generation with kanban view
- `/scheduled` - Scheduled posts management
- `/settings` - API keys and preferences

### API Endpoints
```
GET/POST /api/styles - Style profiles CRUD
GET/POST /api/content-ideas - Content ideas management
POST /api/content-ideas/bulk - Bulk CSV import
GET/POST /api/tweets - Tweet management
POST /api/tweets/generate - AI tweet generation
POST /api/tweets/:id/post - Post via post-bridge API
GET/PATCH /api/settings - App settings
```

## Key Features

### Style Learning
1. Add Twitter/X handles as reference accounts
2. AI analyzes writing patterns and generates style guide
3. Style profiles include tone detection and sample analysis

### Tweet Generation
1. Select a learned style profile
2. Provide topics (from CSV or custom input)
3. AI generates tweets matching the style
4. Edit, schedule, or post directly

### Auto-Posting
- Integrates with post-bridge API
- Configure API key in Settings
- Posts tweets to X/Twitter

## Tech Stack
- Frontend: React, TypeScript, Tailwind CSS, shadcn/ui
- Backend: Express.js, TypeScript
- AI: OpenAI GPT-5 via Replit AI Integrations
- Data: In-memory storage (MVP)

## Recent Changes
- 2026-01-07: Initial MVP implementation
  - Complete frontend with 6 pages
  - Full CRUD API for styles, ideas, tweets
  - AI-powered style analysis and tweet generation
  - Post-bridge API integration
  - Dark/light theme support

## Development Commands
- `npm run dev` - Start development server (port 5000)
- Frontend auto-reloads on file changes
