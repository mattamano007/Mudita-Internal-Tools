import { pgTable, text, varchar, integer, timestamp, boolean, index, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

export * from "./models/auth";

export const styleProfiles = pgTable("style_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  referenceAccounts: text("reference_accounts").array().notNull(),
  sampleTweets: text("sample_tweets").array(),
  styleAnalysis: text("style_analysis"),
  tone: text("tone"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertStyleProfileSchema = createInsertSchema(styleProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertStyleProfile = z.infer<typeof insertStyleProfileSchema>;
export type StyleProfile = typeof styleProfiles.$inferSelect;

export const contentIdeas = pgTable("content_ideas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  topic: text("topic").notNull(),
  keywords: text("keywords"),
  notes: text("notes"),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertContentIdeaSchema = createInsertSchema(contentIdeas).omit({
  id: true,
  createdAt: true,
});

export type InsertContentIdea = z.infer<typeof insertContentIdeaSchema>;
export type ContentIdea = typeof contentIdeas.$inferSelect;

export const generatedTweets = pgTable("generated_tweets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  styleProfileId: varchar("style_profile_id").references(() => styleProfiles.id),
  contentIdeaId: varchar("content_idea_id").references(() => contentIdeas.id),
  status: text("status").notNull().default("draft"),
  scheduledFor: timestamp("scheduled_for"),
  postedAt: timestamp("posted_at"),
  postId: text("post_id"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertGeneratedTweetSchema = createInsertSchema(generatedTweets).omit({
  id: true,
  createdAt: true,
});

export type InsertGeneratedTweet = z.infer<typeof insertGeneratedTweetSchema>;
export type GeneratedTweet = typeof generatedTweets.$inferSelect;

export const settings = pgTable("settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postBridgeApiKey: text("post_bridge_api_key"),
  autoPostEnabled: boolean("auto_post_enabled").default(false),
  defaultStyleProfileId: varchar("default_style_profile_id"),
  postingTimezone: text("posting_timezone").default("UTC"),
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
});

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;
