# Tweet Style Generator - Design Guidelines

## Design Approach
**Cursor Light Mode Inspired**
- Pure white backgrounds with subtle warm gray accents
- Neutral, desaturated color palette
- Clean, minimal aesthetic with excellent readability
- Low-contrast borders for subtle separation
- Dark primary buttons for clear CTAs

## Color Philosophy
- **Background:** Pure white (#FFFFFF)
- **Cards/Surfaces:** Very light gray (98% lightness)
- **Sidebar:** Soft neutral gray (96% lightness)
- **Text Primary:** Near-black with slight warmth (10% lightness)
- **Text Muted:** Medium gray (46% lightness)
- **Primary Actions:** Dark charcoal/near-black buttons
- **Borders:** Very subtle, low-contrast separators

## Typography Hierarchy
**Font Stack:** Inter (primary), SF Mono (code/tweets)
- Hero/Page Titles: text-4xl font-bold
- Section Headers: text-2xl font-semibold
- Card Titles: text-lg font-medium
- Body/Interface: text-base font-normal
- Tweet Preview: text-sm leading-relaxed (mimics Twitter)
- Captions/Meta: text-xs text-muted-foreground

## Layout System
**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8 (p-2, gap-4, mb-6, py-8)
- Page padding: px-6 py-8
- Card padding: p-6
- Component gaps: gap-4 or gap-6
- Section spacing: mb-8 or mb-12

**Container Strategy:**
- Dashboard: max-w-7xl mx-auto
- Forms: max-w-2xl
- Full-width data tables/lists

## Core Components

### Navigation
**Sidebar Navigation:** Vertical, collapsible
- Clean white/gray background matching Cursor sidebar
- Subtle hover states using elevate system
- Active state with subtle background accent
- Icon + text for each navigation item

### Dashboard Layout
**3-Column Grid (lg:grid-cols-3):**
- Quick stats cards (tweets generated, scheduled, posted)
- Recent activity feed
- Active style profiles preview

### Style Learning Interface
**Two-Column Form (md:grid-cols-2):**
- Left: Reference account input (Twitter handles with @ prefix)
- Right: Live preview of analyzed tweets
- Bottom: Progress indicator for style extraction
- Account cards with avatar, handle, sample tweets (max 3)

### Content Upload Section
**Single Column, Progressive Disclosure:**
- CSV upload zone (drag-drop, large target area)
- File preview table (showing first 10 rows)
- Column mapping interface (dropdown selectors)
- Validation feedback inline

### Tweet Generation Dashboard
**Kanban-Style Layout:**
- Drafts / Review / Scheduled / Posted columns
- Tweet cards in each column: 280-char preview, edit/delete actions
- Floating action button (bottom-right) for quick generation

### Tweet Card Component
- Clean card with subtle border
- Tweet text in comfortable reading size
- Action bar: Edit, Delete, Schedule icons
- Hover: subtle elevation increase

### Schedule Interface
**Calendar + List Hybrid:**
- Left sidebar: Calendar widget (date picker)
- Right main: Scheduled tweets timeline view
- Each entry: time, tweet preview, status badge

### Settings/API Configuration
**Tabbed Interface:**
- API Keys (secure input with visibility toggle)
- Posting Preferences (checkboxes, time selectors)
- Integration Status indicators with status badges

## Form Elements
**Consistent Implementation:**
- Input fields: Clean borders, subtle focus states
- Dropdowns: Match input styling
- Textareas: min-h-32 for tweet composition
- Buttons: Dark primary, subtle secondary
- Toggle switches for boolean options
- File upload: Dashed border zone, min-h-48

## Data Display
**Tables:** Clean rows, subtle separators, sticky headers
**Lists:** Divided with border-b, comfortable padding
**Cards:** Subtle rounded corners, minimal shadow on hover
**Badges:** Small pill shapes for status (Draft, Scheduled, Posted, Failed)

## Icons
**Lucide Icons (outline style)**
- Upload, Calendar, Settings, User, Edit, Trash, Check, Plus

## Animations
**Minimal, Purposeful:**
- Page transitions: Fade-in only
- Card hovers: Subtle elevation change
- Button clicks: No animation (rely on browser defaults)
- Loading states: Spinner only where necessary

## Empty States
- Large icon centered, helpful text, primary action button
- "No styles learned yet - Upload reference accounts"
- "No tweets scheduled - Generate your first batch"

## Images
**No hero images.** This is a utility dashboard - focus on functional density.
**Profile avatars:** Circular, 40px (tweet cards), 32px (nav), placeholder initials if none

## Responsive Breakpoints
- Mobile (base): Single column, stacked navigation
- Tablet (md:): 2-column grids where appropriate
- Desktop (lg:): Full 3-column layouts, side-by-side forms

## Key UX Principles
- **Workflow clarity:** Clear progression from style learning to content upload to generation to scheduling
- **Preview-first:** Always show tweet previews before actions
- **Bulk actions:** Select multiple tweets for batch operations
- **Error recovery:** Clear validation messages with actionable fixes
- **Status visibility:** Always show API connection status, generation progress, posting queue
