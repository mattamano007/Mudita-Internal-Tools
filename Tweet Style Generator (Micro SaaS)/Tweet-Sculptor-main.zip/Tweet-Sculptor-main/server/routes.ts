import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import OpenAI from "openai";
import { TwitterApi } from "twitter-api-v2";
import { z } from "zod";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

function getTwitterClient(): TwitterApi | null {
  const consumerKey = process.env.TWITTER_CONSUMER_KEY;
  const consumerSecret = process.env.TWITTER_CONSUMER_SECRET;
  const accessToken = process.env.TWITTER_ACCESS_TOKEN;
  const accessTokenSecret = process.env.TWITTER_ACCESS_TOKEN_SECRET;

  if (!consumerKey || !consumerSecret || !accessToken || !accessTokenSecret) {
    return null;
  }

  return new TwitterApi({
    appKey: consumerKey,
    appSecret: consumerSecret,
    accessToken: accessToken,
    accessSecret: accessTokenSecret,
  });
}

const createStyleSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  referenceAccounts: z.array(z.string()).min(1, "At least one reference account is required"),
});

const createContentIdeaSchema = z.object({
  topic: z.string().min(1, "Topic is required"),
  keywords: z.string().optional(),
  notes: z.string().optional(),
});

const bulkContentIdeasSchema = z.object({
  ideas: z.array(createContentIdeaSchema).min(1, "At least one idea is required"),
});

const generateTweetsSchema = z.object({
  styleId: z.string().min(1, "Style ID is required"),
  ideaIds: z.array(z.string()).optional(),
  customTopic: z.string().optional(),
  count: z.number().min(1).max(10).default(3),
});

const updateTweetSchema = z.object({
  content: z.string().max(280).optional(),
  status: z.enum(["draft", "scheduled", "posted"]).optional(),
  scheduledFor: z.string().nullable().optional(),
});

const updateSettingsSchema = z.object({
  postBridgeApiKey: z.string().optional(),
  autoPostEnabled: z.boolean().optional(),
  defaultStyleProfileId: z.string().nullable().optional(),
  postingTimezone: z.string().optional(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/styles", async (req, res) => {
    try {
      const styles = await storage.getStyles();
      res.json(styles);
    } catch (error) {
      console.error("Error fetching styles:", error);
      res.status(500).json({ error: "Failed to fetch styles" });
    }
  });

  app.get("/api/styles/:id", async (req, res) => {
    try {
      const style = await storage.getStyle(req.params.id);
      if (!style) {
        return res.status(404).json({ error: "Style not found" });
      }
      res.json(style);
    } catch (error) {
      console.error("Error fetching style:", error);
      res.status(500).json({ error: "Failed to fetch style" });
    }
  });

  app.post("/api/styles", async (req, res) => {
    try {
      const parsed = createStyleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors[0].message });
      }
      const { name, description, referenceAccounts } = parsed.data;

      const styleAnalysisPrompt = `Analyze the writing style based on these Twitter/X account handles: ${referenceAccounts.join(", ")}.
      
Describe the typical writing style characteristics:
- Tone (casual, professional, humorous, informative, etc.)
- Common patterns (use of questions, calls to action, storytelling, etc.)
- Language style (simple, technical, conversational, etc.)
- Typical tweet length preference
- Use of hashtags, mentions, or emojis

Provide a brief, actionable style guide that can be used to write tweets in a similar voice. Keep it concise (2-3 sentences).`;

      let styleAnalysis = "";
      let tone = "conversational";
      
      try {
        const analysisResponse = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{ role: "user", content: styleAnalysisPrompt }],
          max_completion_tokens: 500,
        });

        styleAnalysis = analysisResponse.choices[0]?.message?.content || "";
        const toneMatch = styleAnalysis.match(/tone[:\s]+([^.]+)/i);
        tone = toneMatch ? toneMatch[1].trim() : "conversational";
      } catch (aiError) {
        console.error("AI analysis failed, using defaults:", aiError);
        styleAnalysis = `Write in a conversational tone similar to these accounts: ${referenceAccounts.join(', ')}. Focus on engaging, concise content.`;
      }

      const style = await storage.createStyle({
        name,
        description,
        referenceAccounts,
        sampleTweets: [],
        styleAnalysis,
        tone,
        isActive: true,
      });

      res.status(201).json(style);
    } catch (error) {
      console.error("Error creating style:", error);
      res.status(500).json({ error: "Failed to create style" });
    }
  });

  app.patch("/api/styles/:id", async (req, res) => {
    try {
      const style = await storage.updateStyle(req.params.id, req.body);
      if (!style) {
        return res.status(404).json({ error: "Style not found" });
      }
      res.json(style);
    } catch (error) {
      console.error("Error updating style:", error);
      res.status(500).json({ error: "Failed to update style" });
    }
  });

  app.delete("/api/styles/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteStyle(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Style not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting style:", error);
      res.status(500).json({ error: "Failed to delete style" });
    }
  });

  app.get("/api/content-ideas", async (req, res) => {
    try {
      const ideas = await storage.getContentIdeas();
      res.json(ideas);
    } catch (error) {
      console.error("Error fetching content ideas:", error);
      res.status(500).json({ error: "Failed to fetch content ideas" });
    }
  });

  app.post("/api/content-ideas", async (req, res) => {
    try {
      const parsed = createContentIdeaSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors[0].message });
      }
      const idea = await storage.createContentIdea(parsed.data);
      res.status(201).json(idea);
    } catch (error) {
      console.error("Error creating content idea:", error);
      res.status(500).json({ error: "Failed to create content idea" });
    }
  });

  app.post("/api/content-ideas/bulk", async (req, res) => {
    try {
      const parsed = bulkContentIdeasSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors[0].message });
      }
      const created = await storage.createContentIdeasBulk(parsed.data.ideas);
      res.status(201).json({ count: created.length, ideas: created });
    } catch (error) {
      console.error("Error creating content ideas:", error);
      res.status(500).json({ error: "Failed to create content ideas" });
    }
  });

  app.delete("/api/content-ideas/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteContentIdea(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Content idea not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting content idea:", error);
      res.status(500).json({ error: "Failed to delete content idea" });
    }
  });

  app.get("/api/tweets", async (req, res) => {
    try {
      const tweets = await storage.getTweets();
      res.json(tweets);
    } catch (error) {
      console.error("Error fetching tweets:", error);
      res.status(500).json({ error: "Failed to fetch tweets" });
    }
  });

  app.post("/api/tweets/generate", async (req, res) => {
    try {
      const parsed = generateTweetsSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors[0].message });
      }
      const { styleId, ideaIds, customTopic, count } = parsed.data;

      const style = await storage.getStyle(styleId);
      if (!style) {
        return res.status(404).json({ error: "Style not found" });
      }

      interface TopicSource {
        topic: string;
        ideaId: string | null;
      }
      
      const topicSources: TopicSource[] = [];
      
      if (ideaIds && ideaIds.length > 0) {
        for (const ideaId of ideaIds) {
          const idea = await storage.getContentIdea(ideaId);
          if (idea) {
            topicSources.push({
              topic: idea.topic + (idea.keywords ? ` (keywords: ${idea.keywords})` : ""),
              ideaId: ideaId,
            });
            await storage.updateContentIdea(ideaId, { isUsed: true });
          }
        }
      }
      
      if (customTopic) {
        topicSources.push({
          topic: customTopic,
          ideaId: null,
        });
      }

      if (topicSources.length === 0) {
        return res.status(400).json({ error: "At least one topic or content idea is required" });
      }

      const topics = topicSources.map(t => t.topic);
      const prompt = `You are a Twitter/X content writer. Generate ${count} unique tweets based on the following:

Style Guide:
${style.styleAnalysis || `Write in a ${style.tone || 'conversational'} tone similar to these accounts: ${style.referenceAccounts.join(', ')}`}

Topics to write about:
${topics.map((t, i) => `${i + 1}. ${t}`).join('\n')}

Requirements:
- Each tweet must be under 280 characters
- Write in the voice/style described above
- Make each tweet unique and engaging
- Do not use hashtags unless the style specifically includes them
- Focus on providing value or entertainment

Return ONLY a JSON array of tweet strings, nothing else. Example:
["First tweet here", "Second tweet here", "Third tweet here"]`;

      let tweetTexts: string[] = [];
      
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{ role: "user", content: prompt }],
          max_completion_tokens: 1000,
        });

        const content = response.choices[0]?.message?.content || "[]";
        
        try {
          tweetTexts = JSON.parse(content);
          if (!Array.isArray(tweetTexts)) {
            throw new Error("Not an array");
          }
        } catch {
          const matches = content.match(/"([^"]+)"/g);
          tweetTexts = matches ? matches.map(m => m.replace(/^"|"$/g, '')) : [];
        }
      } catch (aiError) {
        console.error("AI generation failed:", aiError);
        return res.status(500).json({ error: "Tweet generation failed. Please try again." });
      }

      if (tweetTexts.length === 0) {
        return res.status(500).json({ error: "No tweets could be generated. Please try again." });
      }

      const tweetsToCreate = tweetTexts.slice(0, count).map((text, index) => {
        const sourceIndex = index % topicSources.length;
        return {
          content: text.substring(0, 280),
          styleProfileId: styleId,
          contentIdeaId: topicSources[sourceIndex]?.ideaId || null,
          status: "draft" as const,
        };
      });

      const tweets = await storage.createTweetsBulk(tweetsToCreate);
      res.status(201).json({ tweets });
    } catch (error) {
      console.error("Error generating tweets:", error);
      res.status(500).json({ error: "Failed to generate tweets" });
    }
  });

  app.patch("/api/tweets/:id", async (req, res) => {
    try {
      const parsed = updateTweetSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors[0].message });
      }

      const updateData: Record<string, any> = {};
      if (parsed.data.content !== undefined) updateData.content = parsed.data.content;
      if (parsed.data.status !== undefined) updateData.status = parsed.data.status;
      if (parsed.data.scheduledFor !== undefined) {
        updateData.scheduledFor = parsed.data.scheduledFor ? new Date(parsed.data.scheduledFor) : null;
      }

      const tweet = await storage.updateTweet(req.params.id, updateData);
      if (!tweet) {
        return res.status(404).json({ error: "Tweet not found" });
      }
      res.json(tweet);
    } catch (error) {
      console.error("Error updating tweet:", error);
      res.status(500).json({ error: "Failed to update tweet" });
    }
  });

  app.delete("/api/tweets/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTweet(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Tweet not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting tweet:", error);
      res.status(500).json({ error: "Failed to delete tweet" });
    }
  });

  app.post("/api/tweets/:id/post", async (req, res) => {
    try {
      const tweet = await storage.getTweet(req.params.id);
      if (!tweet) {
        return res.status(404).json({ error: "Tweet not found" });
      }

      const twitterClient = getTwitterClient();
      if (!twitterClient) {
        return res.status(400).json({ 
          error: "X/Twitter API not configured. Please add your API credentials in the Secrets tab." 
        });
      }

      try {
        const result = await twitterClient.v2.tweet(tweet.content);
        
        const updatedTweet = await storage.updateTweet(req.params.id, {
          status: "posted",
          postedAt: new Date(),
          postId: result.data.id,
        });

        res.json(updatedTweet);
      } catch (err: any) {
        console.error("Twitter API error:", err);
        const errorMessage = err.data?.detail || err.message || "Failed to post to X/Twitter";
        res.status(500).json({ error: errorMessage });
      }
    } catch (error) {
      console.error("Error posting tweet:", error);
      res.status(500).json({ error: "Failed to post tweet" });
    }
  });

  app.get("/api/settings", async (req, res) => {
    try {
      let settings = await storage.getSettings();
      if (!settings) {
        settings = await storage.updateSettings({});
      }
      const response = {
        ...settings,
        postBridgeApiKey: settings.postBridgeApiKey ? "********" : null,
      };
      res.json(response);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.patch("/api/settings", async (req, res) => {
    try {
      const parsed = updateSettingsSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors[0].message });
      }
      const settings = await storage.updateSettings(parsed.data);
      const response = {
        ...settings,
        postBridgeApiKey: settings.postBridgeApiKey ? "********" : null,
      };
      res.json(response);
    } catch (error) {
      console.error("Error updating settings:", error);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  app.get("/api/twitter/status", async (req, res) => {
    try {
      const twitterClient = getTwitterClient();
      
      if (!twitterClient) {
        return res.json({ 
          configured: false,
          message: "X/Twitter API credentials not configured"
        });
      }

      try {
        const me = await twitterClient.v2.me();
        res.json({ 
          configured: true,
          connected: true,
          username: me.data.username,
          name: me.data.name,
          message: `Connected as @${me.data.username}`
        });
      } catch (err: any) {
        console.error("Twitter API verification failed:", err);
        res.json({ 
          configured: true,
          connected: false,
          message: err.data?.detail || err.message || "Failed to verify credentials"
        });
      }
    } catch (error) {
      console.error("Error checking Twitter status:", error);
      res.status(500).json({ error: "Failed to check Twitter status" });
    }
  });

  app.post("/api/twitter/test", async (req, res) => {
    try {
      const twitterClient = getTwitterClient();
      
      if (!twitterClient) {
        return res.status(400).json({ 
          success: false,
          error: "X/Twitter API credentials not configured. Add them in the Secrets tab."
        });
      }

      try {
        const me = await twitterClient.v2.me();
        res.json({ 
          success: true,
          username: me.data.username,
          message: `Successfully connected as @${me.data.username}`
        });
      } catch (err: any) {
        console.error("Twitter API test failed:", err);
        res.status(400).json({ 
          success: false,
          error: err.data?.detail || err.message || "Failed to connect to X/Twitter API"
        });
      }
    } catch (error) {
      console.error("Error testing Twitter API:", error);
      res.status(500).json({ success: false, error: "Failed to test connection" });
    }
  });

  return httpServer;
}
