import { 
  type StyleProfile, type InsertStyleProfile,
  type ContentIdea, type InsertContentIdea,
  type GeneratedTweet, type InsertGeneratedTweet,
  type Settings, type InsertSettings,
  styleProfiles,
  contentIdeas,
  generatedTweets,
  settings,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getStyles(): Promise<StyleProfile[]>;
  getStyle(id: string): Promise<StyleProfile | undefined>;
  createStyle(style: InsertStyleProfile): Promise<StyleProfile>;
  updateStyle(id: string, style: Partial<InsertStyleProfile>): Promise<StyleProfile | undefined>;
  deleteStyle(id: string): Promise<boolean>;

  getContentIdeas(): Promise<ContentIdea[]>;
  getContentIdea(id: string): Promise<ContentIdea | undefined>;
  createContentIdea(idea: InsertContentIdea): Promise<ContentIdea>;
  createContentIdeasBulk(ideas: InsertContentIdea[]): Promise<ContentIdea[]>;
  updateContentIdea(id: string, idea: Partial<InsertContentIdea>): Promise<ContentIdea | undefined>;
  deleteContentIdea(id: string): Promise<boolean>;

  getTweets(): Promise<GeneratedTweet[]>;
  getTweet(id: string): Promise<GeneratedTweet | undefined>;
  createTweet(tweet: InsertGeneratedTweet): Promise<GeneratedTweet>;
  createTweetsBulk(tweets: InsertGeneratedTweet[]): Promise<GeneratedTweet[]>;
  updateTweet(id: string, tweet: Partial<InsertGeneratedTweet>): Promise<GeneratedTweet | undefined>;
  deleteTweet(id: string): Promise<boolean>;

  getSettings(): Promise<Settings | undefined>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings>;
}

export class DatabaseStorage implements IStorage {
  async getStyles(): Promise<StyleProfile[]> {
    return db.select().from(styleProfiles).orderBy(desc(styleProfiles.createdAt));
  }

  async getStyle(id: string): Promise<StyleProfile | undefined> {
    const [style] = await db.select().from(styleProfiles).where(eq(styleProfiles.id, id)).limit(1);
    return style;
  }

  async createStyle(insertStyle: InsertStyleProfile): Promise<StyleProfile> {
    const [style] = await db.insert(styleProfiles).values(insertStyle).returning();
    return style;
  }

  async updateStyle(id: string, updates: Partial<InsertStyleProfile>): Promise<StyleProfile | undefined> {
    const [updated] = await db.update(styleProfiles).set(updates).where(eq(styleProfiles.id, id)).returning();
    return updated;
  }

  async deleteStyle(id: string): Promise<boolean> {
    const result = await db.delete(styleProfiles).where(eq(styleProfiles.id, id)).returning();
    return result.length > 0;
  }

  async getContentIdeas(): Promise<ContentIdea[]> {
    return db.select().from(contentIdeas).orderBy(desc(contentIdeas.createdAt));
  }

  async getContentIdea(id: string): Promise<ContentIdea | undefined> {
    const [idea] = await db.select().from(contentIdeas).where(eq(contentIdeas.id, id)).limit(1);
    return idea;
  }

  async createContentIdea(insertIdea: InsertContentIdea): Promise<ContentIdea> {
    const [idea] = await db.insert(contentIdeas).values(insertIdea).returning();
    return idea;
  }

  async createContentIdeasBulk(insertIdeas: InsertContentIdea[]): Promise<ContentIdea[]> {
    if (insertIdeas.length === 0) return [];
    return db.insert(contentIdeas).values(insertIdeas).returning();
  }

  async updateContentIdea(id: string, updates: Partial<InsertContentIdea>): Promise<ContentIdea | undefined> {
    const [updated] = await db.update(contentIdeas).set(updates).where(eq(contentIdeas.id, id)).returning();
    return updated;
  }

  async deleteContentIdea(id: string): Promise<boolean> {
    const result = await db.delete(contentIdeas).where(eq(contentIdeas.id, id)).returning();
    return result.length > 0;
  }

  async getTweets(): Promise<GeneratedTweet[]> {
    return db.select().from(generatedTweets).orderBy(desc(generatedTweets.createdAt));
  }

  async getTweet(id: string): Promise<GeneratedTweet | undefined> {
    const [tweet] = await db.select().from(generatedTweets).where(eq(generatedTweets.id, id)).limit(1);
    return tweet;
  }

  async createTweet(insertTweet: InsertGeneratedTweet): Promise<GeneratedTweet> {
    const [tweet] = await db.insert(generatedTweets).values(insertTweet).returning();
    return tweet;
  }

  async createTweetsBulk(insertTweets: InsertGeneratedTweet[]): Promise<GeneratedTweet[]> {
    if (insertTweets.length === 0) return [];
    return db.insert(generatedTweets).values(insertTweets).returning();
  }

  async updateTweet(id: string, updates: Partial<InsertGeneratedTweet>): Promise<GeneratedTweet | undefined> {
    const [updated] = await db.update(generatedTweets).set(updates).where(eq(generatedTweets.id, id)).returning();
    return updated;
  }

  async deleteTweet(id: string): Promise<boolean> {
    const result = await db.delete(generatedTweets).where(eq(generatedTweets.id, id)).returning();
    return result.length > 0;
  }

  async getSettings(): Promise<Settings | undefined> {
    const [setting] = await db.select().from(settings).limit(1);
    return setting;
  }

  async updateSettings(updates: Partial<InsertSettings>): Promise<Settings> {
    const existing = await this.getSettings();
    if (existing) {
      const [updated] = await db.update(settings).set(updates).where(eq(settings.id, existing.id)).returning();
      return updated;
    } else {
      const defaultSettings = {
        postBridgeApiKey: null,
        autoPostEnabled: false,
        defaultStyleProfileId: null,
        postingTimezone: "UTC",
        ...updates,
      };
      const [created] = await db.insert(settings).values(defaultSettings).returning();
      return created;
    }
  }
}

export const storage = new DatabaseStorage();
