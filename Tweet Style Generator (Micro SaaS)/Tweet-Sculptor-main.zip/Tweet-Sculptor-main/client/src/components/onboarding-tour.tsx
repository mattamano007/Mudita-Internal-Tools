import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { X, ArrowRight, ArrowLeft, RotateCcw } from "lucide-react";

interface TourStep {
  id: string;
  target: string;
  title: string;
  content: string;
  placement?: "top" | "bottom" | "left" | "right";
}

const tourSteps: TourStep[] = [
  {
    id: "welcome",
    target: "[data-onboarding='welcome']",
    title: "Welcome to Tweet Style Generator",
    content: "This app helps you create tweets that match the writing style of your favorite accounts. Let me show you how it works.",
    placement: "bottom",
  },
  {
    id: "styles",
    target: "[data-onboarding='nav-styles']",
    title: "Step 1: Learn a Style",
    content: "Start here. Add Twitter/X handles you want to emulate. The AI will analyze their writing patterns and create a style profile.",
    placement: "right",
  },
  {
    id: "upload",
    target: "[data-onboarding='nav-upload']",
    title: "Step 2: Add Content Ideas",
    content: "Upload a CSV with topics you want to tweet about, or add them manually later when generating.",
    placement: "right",
  },
  {
    id: "generate",
    target: "[data-onboarding='nav-generate']",
    title: "Step 3: Generate Tweets",
    content: "Pick a style and topics, then let AI create tweets matching that voice. Edit, schedule, or post directly.",
    placement: "right",
  },
  {
    id: "scheduled",
    target: "[data-onboarding='nav-scheduled']",
    title: "Step 4: Manage Schedule",
    content: "View and manage all your scheduled tweets in a timeline view.",
    placement: "right",
  },
  {
    id: "settings",
    target: "[data-onboarding='nav-settings']",
    title: "Configure API",
    content: "Add your post-bridge API key here to enable auto-posting to Twitter/X. You can restart this tour anytime from Settings.",
    placement: "right",
  },
];

interface OnboardingContextType {
  isActive: boolean;
  currentStep: number;
  startTour: () => void;
  endTour: () => void;
  nextStep: () => void;
  prevStep: () => void;
  hasCompletedTour: boolean;
}

const OnboardingContext = createContext<OnboardingContextType | null>(null);

export function useOnboarding() {
  const context = useContext(OnboardingContext);
  if (!context) {
    throw new Error("useOnboarding must be used within OnboardingProvider");
  }
  return context;
}

const STORAGE_KEY = "tweetstyle:onboardingCompleted";

export function OnboardingProvider({ children }: { children: React.ReactNode }) {
  const [isActive, setIsActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [hasCompletedTour, setHasCompletedTour] = useState(false);

  useEffect(() => {
    const completed = localStorage.getItem(STORAGE_KEY);
    if (completed === "true") {
      setHasCompletedTour(true);
    } else {
      setTimeout(() => setIsActive(true), 500);
    }
  }, []);

  const startTour = useCallback(() => {
    setCurrentStep(0);
    setIsActive(true);
  }, []);

  const endTour = useCallback(() => {
    setIsActive(false);
    setHasCompletedTour(true);
    localStorage.setItem(STORAGE_KEY, "true");
  }, []);

  const nextStep = useCallback(() => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      endTour();
    }
  }, [currentStep, endTour]);

  const prevStep = useCallback(() => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  }, [currentStep]);

  return (
    <OnboardingContext.Provider
      value={{
        isActive,
        currentStep,
        startTour,
        endTour,
        nextStep,
        prevStep,
        hasCompletedTour,
      }}
    >
      {children}
      {isActive && <TourOverlay />}
    </OnboardingContext.Provider>
  );
}

function TourOverlay() {
  const { currentStep, nextStep, prevStep, endTour } = useOnboarding();
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);

  const step = tourSteps[currentStep];

  useEffect(() => {
    const updatePosition = () => {
      const target = document.querySelector(step.target);
      if (target) {
        const rect = target.getBoundingClientRect();
        setTargetRect(rect);

        let top = 0;
        let left = 0;

        const tooltipWidth = 320;
        const tooltipHeight = 180;
        const offset = 12;

        switch (step.placement) {
          case "right":
            top = rect.top + rect.height / 2 - tooltipHeight / 2;
            left = rect.right + offset;
            break;
          case "left":
            top = rect.top + rect.height / 2 - tooltipHeight / 2;
            left = rect.left - tooltipWidth - offset;
            break;
          case "top":
            top = rect.top - tooltipHeight - offset;
            left = rect.left + rect.width / 2 - tooltipWidth / 2;
            break;
          case "bottom":
          default:
            top = rect.bottom + offset;
            left = rect.left + rect.width / 2 - tooltipWidth / 2;
            break;
        }

        top = Math.max(16, Math.min(top, window.innerHeight - tooltipHeight - 16));
        left = Math.max(16, Math.min(left, window.innerWidth - tooltipWidth - 16));

        setPosition({ top, left });
      }
    };

    updatePosition();
    window.addEventListener("resize", updatePosition);
    window.addEventListener("scroll", updatePosition);

    return () => {
      window.removeEventListener("resize", updatePosition);
      window.removeEventListener("scroll", updatePosition);
    };
  }, [step]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        endTour();
      } else if (e.key === "ArrowRight" || e.key === "Enter") {
        nextStep();
      } else if (e.key === "ArrowLeft") {
        prevStep();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [endTour, nextStep, prevStep]);

  return (
    <>
      <div 
        className="fixed inset-0 bg-black/40 z-[9998]" 
        onClick={endTour}
        data-testid="onboarding-overlay"
      />

      {targetRect && (
        <div
          className="fixed z-[9999] rounded-md ring-2 ring-primary ring-offset-2 ring-offset-background pointer-events-none"
          style={{
            top: targetRect.top - 4,
            left: targetRect.left - 4,
            width: targetRect.width + 8,
            height: targetRect.height + 8,
          }}
        />
      )}

      <Card
        className="fixed z-[10000] w-80 p-4 shadow-lg"
        style={{ top: position.top, left: position.left }}
        data-testid="onboarding-tooltip"
      >
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-semibold text-base">{step.title}</h3>
          <Button
            size="icon"
            variant="ghost"
            onClick={endTour}
            className="shrink-0 -mt-1 -mr-1"
            data-testid="button-close-tour"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <p className="text-sm text-muted-foreground mb-4">{step.content}</p>

        <div className="flex items-center justify-between gap-2">
          <span className="text-xs text-muted-foreground">
            {currentStep + 1} of {tourSteps.length}
          </span>

          <div className="flex items-center gap-2">
            {currentStep > 0 && (
              <Button
                size="sm"
                variant="ghost"
                onClick={prevStep}
                data-testid="button-prev-step"
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back
              </Button>
            )}
            <Button
              size="sm"
              onClick={nextStep}
              data-testid="button-next-step"
            >
              {currentStep === tourSteps.length - 1 ? "Done" : "Next"}
              {currentStep < tourSteps.length - 1 && <ArrowRight className="h-4 w-4 ml-1" />}
            </Button>
          </div>
        </div>
      </Card>
    </>
  );
}

export function RestartTourButton() {
  const { startTour, hasCompletedTour } = useOnboarding();

  if (!hasCompletedTour) return null;

  return (
    <Button
      variant="outline"
      onClick={startTour}
      className="gap-2"
      data-testid="button-restart-tour"
    >
      <RotateCcw className="h-4 w-4" />
      Restart Onboarding Tour
    </Button>
  );
}
