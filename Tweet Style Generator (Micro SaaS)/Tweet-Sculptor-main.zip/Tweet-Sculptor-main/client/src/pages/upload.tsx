import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Upload, FileText, Trash2, Loader2, CheckCircle, Plus, X } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import type { ContentIdea } from "@shared/schema";

interface ParsedRow {
  topic: string;
  keywords?: string;
  notes?: string;
}

const TOPIC_CATEGORIES = [
  {
    name: "Tech & AI",
    topics: [
      "AI trends and predictions",
      "Productivity tools I use",
      "Tech industry hot takes",
      "Software development tips",
      "Future of remote work",
      "Startup lessons learned",
    ]
  },
  {
    name: "Business & Growth",
    topics: [
      "Building in public updates",
      "Revenue milestones",
      "Customer success stories",
      "Marketing strategies that work",
      "Hiring and team building",
      "Lessons from failures",
    ]
  },
  {
    name: "Personal Brand",
    topics: [
      "Daily routines and habits",
      "Books that changed my thinking",
      "Unpopular opinions",
      "Career advice",
      "Behind the scenes",
      "Personal wins and losses",
    ]
  },
  {
    name: "Content & Creator",
    topics: [
      "Content creation tips",
      "Growing an audience",
      "Monetization strategies",
      "Engagement tactics",
      "Platform-specific advice",
      "Creator economy insights",
    ]
  },
];

export default function UploadPage() {
  const [isDragging, setIsDragging] = useState(false);
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [uploadStatus, setUploadStatus] = useState<"idle" | "parsing" | "parsed" | "uploading" | "done">("idle");
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [customTopic, setCustomTopic] = useState("");
  const { toast } = useToast();

  const { data: ideas, isLoading } = useQuery<ContentIdea[]>({
    queryKey: ["/api/content-ideas"],
  });

  const uploadMutation = useMutation({
    mutationFn: async (rows: ParsedRow[]) => {
      const res = await apiRequest("POST", "/api/content-ideas/bulk", { ideas: rows });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/content-ideas"] });
      toast({ 
        title: "Content uploaded", 
        description: `${data.count} ideas added successfully` 
      });
      setParsedRows([]);
      setUploadStatus("done");
      setTimeout(() => setUploadStatus("idle"), 2000);
    },
    onError: (error: Error) => {
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
      setUploadStatus("parsed");
    },
  });

  const topicsMutation = useMutation({
    mutationFn: async (topics: string[]) => {
      const rows = topics.map(topic => ({ topic }));
      const res = await apiRequest("POST", "/api/content-ideas/bulk", { ideas: rows });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/content-ideas"] });
      toast({ 
        title: "Topics added", 
        description: `${data.count} topics added to your ideas` 
      });
      setSelectedTopics([]);
    },
    onError: (error: Error) => {
      toast({ title: "Failed to add topics", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/content-ideas/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/content-ideas"] });
      toast({ title: "Idea deleted" });
    },
  });

  const parseCSV = (text: string): ParsedRow[] => {
    const lines = text.trim().split('\n');
    if (lines.length < 2) return [];
    
    const headers = lines[0].toLowerCase().split(',').map(h => h.trim());
    const topicIdx = headers.findIndex(h => h.includes('topic') || h.includes('idea') || h.includes('title'));
    const keywordsIdx = headers.findIndex(h => h.includes('keyword') || h.includes('tag'));
    const notesIdx = headers.findIndex(h => h.includes('note') || h.includes('description'));
    
    if (topicIdx === -1) {
      const rows: ParsedRow[] = [];
      for (let i = 0; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/^["']|["']$/g, ''));
        if (values[0]) {
          rows.push({
            topic: values[0],
            keywords: values[1] || undefined,
            notes: values[2] || undefined,
          });
        }
      }
      return rows;
    }

    const rows: ParsedRow[] = [];
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/^["']|["']$/g, ''));
      if (values[topicIdx]) {
        rows.push({
          topic: values[topicIdx],
          keywords: keywordsIdx >= 0 ? values[keywordsIdx] : undefined,
          notes: notesIdx >= 0 ? values[notesIdx] : undefined,
        });
      }
    }
    return rows;
  };

  const handleFile = useCallback((file: File) => {
    if (!file.name.endsWith('.csv')) {
      toast({ title: "Invalid file", description: "Please upload a CSV file", variant: "destructive" });
      return;
    }

    setUploadStatus("parsing");
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const parsed = parseCSV(text);
      if (parsed.length === 0) {
        toast({ title: "Empty file", description: "No content ideas found in CSV", variant: "destructive" });
        setUploadStatus("idle");
        return;
      }
      setParsedRows(parsed);
      setUploadStatus("parsed");
    };
    reader.readAsText(file);
  }, [toast]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const confirmUpload = () => {
    setUploadStatus("uploading");
    uploadMutation.mutate(parsedRows);
  };

  const toggleTopic = (topic: string) => {
    setSelectedTopics(prev => 
      prev.includes(topic) 
        ? prev.filter(t => t !== topic)
        : [...prev, topic]
    );
  };

  const addCustomTopic = () => {
    if (customTopic.trim() && !selectedTopics.includes(customTopic.trim())) {
      setSelectedTopics(prev => [...prev, customTopic.trim()]);
      setCustomTopic("");
    }
  };

  const handleCustomTopicKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addCustomTopic();
    }
  };

  const addSelectedTopics = () => {
    if (selectedTopics.length > 0) {
      topicsMutation.mutate(selectedTopics);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Add Content Ideas</h1>
        <p className="text-muted-foreground mt-1">
          Pick topics or upload a CSV to generate tweets from
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Quick Topic Picker</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {TOPIC_CATEGORIES.map((category) => (
              <div key={category.name}>
                <h3 className="text-sm font-medium text-muted-foreground mb-3">{category.name}</h3>
                <div className="flex flex-wrap gap-2">
                  {category.topics.map((topic) => (
                    <Badge
                      key={topic}
                      variant={selectedTopics.includes(topic) ? "default" : "outline"}
                      className="cursor-pointer py-1.5 px-3 text-sm"
                      onClick={() => toggleTopic(topic)}
                      data-testid={`badge-topic-${topic.replace(/\s+/g, '-').toLowerCase()}`}
                    >
                      {selectedTopics.includes(topic) && <CheckCircle className="w-3 h-3 mr-1.5" />}
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}

            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-3">Add Custom Topic</h3>
              <div className="flex gap-2">
                <Input
                  value={customTopic}
                  onChange={(e) => setCustomTopic(e.target.value)}
                  onKeyDown={handleCustomTopicKeyDown}
                  placeholder="Type your own topic..."
                  className="max-w-md"
                  data-testid="input-custom-topic"
                />
                <Button 
                  variant="outline" 
                  onClick={addCustomTopic}
                  disabled={!customTopic.trim()}
                  data-testid="button-add-custom-topic"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {selectedTopics.length > 0 && (
              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium">Selected Topics ({selectedTopics.length})</h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setSelectedTopics([])}
                  >
                    Clear all
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedTopics.map((topic) => (
                    <Badge key={topic} variant="secondary" className="py-1.5 px-3">
                      {topic}
                      <button 
                        onClick={() => toggleTopic(topic)}
                        className="ml-2 hover:text-destructive"
                        data-testid={`button-remove-topic-${topic.replace(/\s+/g, '-').toLowerCase()}`}
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
                <Button 
                  onClick={addSelectedTopics}
                  disabled={topicsMutation.isPending}
                  data-testid="button-add-selected-topics"
                >
                  {topicsMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : null}
                  Add {selectedTopics.length} Topic{selectedTopics.length !== 1 ? 's' : ''} to Ideas
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Or Upload CSV</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragging 
                  ? "border-primary bg-primary/5" 
                  : "border-muted-foreground/25 hover:border-muted-foreground/50"
              }`}
            >
              <input
                type="file"
                accept=".csv"
                onChange={handleInputChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                data-testid="input-csv-upload"
              />
              {uploadStatus === "done" ? (
                <>
                  <CheckCircle className="w-12 h-12 mx-auto text-chart-2 mb-3" />
                  <p className="font-medium text-chart-2">Upload Complete!</p>
                </>
              ) : uploadStatus === "parsing" || uploadStatus === "uploading" ? (
                <>
                  <Loader2 className="w-12 h-12 mx-auto text-primary mb-3 animate-spin" />
                  <p className="font-medium">{uploadStatus === "parsing" ? "Parsing CSV..." : "Uploading..."}</p>
                </>
              ) : (
                <>
                  <Upload className="w-10 h-10 mx-auto text-muted-foreground/50 mb-3" />
                  <p className="font-medium mb-1">Drop your CSV here</p>
                  <p className="text-sm text-muted-foreground">or click to browse</p>
                </>
              )}
            </div>

            <div className="mt-4 p-4 bg-muted rounded-md">
              <p className="text-sm font-medium mb-2">Expected CSV Format:</p>
              <code className="text-xs font-mono block text-muted-foreground">
                topic,keywords,notes<br/>
                "AI trends 2025","AI, technology","Focus on practical applications"
              </code>
            </div>
          </CardContent>
        </Card>

        {parsedRows.length > 0 && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle className="text-lg">Preview ({parsedRows.length} rows)</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => { setParsedRows([]); setUploadStatus("idle"); }}>
                  Cancel
                </Button>
                <Button onClick={confirmUpload} disabled={uploadMutation.isPending} data-testid="button-confirm-upload">
                  {uploadMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : null}
                  Confirm Upload
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="max-h-64 overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Topic</TableHead>
                      <TableHead>Keywords</TableHead>
                      <TableHead>Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parsedRows.slice(0, 10).map((row, i) => (
                      <TableRow key={i}>
                        <TableCell className="font-medium">{row.topic}</TableCell>
                        <TableCell className="text-muted-foreground">{row.keywords || "-"}</TableCell>
                        <TableCell className="text-muted-foreground max-w-48 truncate">{row.notes || "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              {parsedRows.length > 10 && (
                <p className="text-xs text-muted-foreground text-center mt-2">
                  Showing first 10 of {parsedRows.length} rows
                </p>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <Card className="mt-8">
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="text-lg">Your Content Ideas ({ideas?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : ideas && ideas.length > 0 ? (
            <div className="max-h-96 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Topic</TableHead>
                    <TableHead>Keywords</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-20"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ideas.map((idea) => (
                    <TableRow key={idea.id} data-testid={`row-idea-${idea.id}`}>
                      <TableCell className="font-medium">{idea.topic}</TableCell>
                      <TableCell className="text-muted-foreground">{idea.keywords || "-"}</TableCell>
                      <TableCell>
                        <Badge variant={idea.isUsed ? "secondary" : "default"}>
                          {idea.isUsed ? "Used" : "Available"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(idea.id)}
                          data-testid={`button-delete-idea-${idea.id}`}
                        >
                          <Trash2 className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="py-12 text-center">
              <FileText className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
              <p className="text-muted-foreground">No content ideas yet</p>
              <p className="text-sm text-muted-foreground mt-1">Pick topics above or upload a CSV</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
