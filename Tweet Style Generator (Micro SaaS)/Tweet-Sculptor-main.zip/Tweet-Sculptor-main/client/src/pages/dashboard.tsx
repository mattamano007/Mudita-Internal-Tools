import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { FileText, Calendar, CheckCircle, Palette, ArrowRight, Sparkles, Clock } from "lucide-react";
import type { StyleProfile, GeneratedTweet } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  subtitle,
  loading 
}: { 
  title: string; 
  value: number | string; 
  icon: React.ElementType;
  subtitle?: string;
  loading?: boolean;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="w-4 h-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-8 w-20" />
        ) : (
          <>
            <div className="text-2xl font-bold" data-testid={`text-stat-${title.toLowerCase().replace(' ', '-')}`}>{value}</div>
            {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function RecentTweetCard({ tweet }: { tweet: GeneratedTweet }) {
  const statusColors: Record<string, string> = {
    draft: "bg-muted text-muted-foreground",
    scheduled: "bg-chart-4/20 text-chart-4",
    posted: "bg-chart-2/20 text-chart-2",
    failed: "bg-destructive/20 text-destructive",
  };

  return (
    <div className="p-4 border-b last:border-b-0">
      <div className="flex items-start justify-between gap-4">
        <p className="text-sm font-mono line-clamp-2 flex-1" data-testid={`text-tweet-${tweet.id}`}>
          {tweet.content}
        </p>
        <Badge variant="secondary" className={statusColors[tweet.status] || ""}>
          {tweet.status}
        </Badge>
      </div>
      <p className="text-xs text-muted-foreground mt-2">
        {formatDistanceToNow(new Date(tweet.createdAt), { addSuffix: true })}
      </p>
    </div>
  );
}

export default function Dashboard() {
  const { data: tweets, isLoading: tweetsLoading } = useQuery<GeneratedTweet[]>({
    queryKey: ["/api/tweets"],
  });

  const { data: styles, isLoading: stylesLoading } = useQuery<StyleProfile[]>({
    queryKey: ["/api/styles"],
  });

  const draftCount = tweets?.filter(t => t.status === "draft").length || 0;
  const scheduledCount = tweets?.filter(t => t.status === "scheduled").length || 0;
  const postedCount = tweets?.filter(t => t.status === "posted").length || 0;
  const recentTweets = tweets?.slice(0, 5) || [];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Overview of your tweet generation workflow
          </p>
        </div>
        <Link href="/generate">
          <Button data-testid="button-quick-generate">
            <Sparkles className="w-4 h-4 mr-2" />
            Generate Tweets
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <StatCard
          title="Style Profiles"
          value={styles?.length || 0}
          icon={Palette}
          subtitle="Active styles"
          loading={stylesLoading}
        />
        <StatCard
          title="Drafts"
          value={draftCount}
          icon={FileText}
          subtitle="Ready to review"
          loading={tweetsLoading}
        />
        <StatCard
          title="Scheduled"
          value={scheduledCount}
          icon={Calendar}
          subtitle="Queued for posting"
          loading={tweetsLoading}
        />
        <StatCard
          title="Posted"
          value={postedCount}
          icon={CheckCircle}
          subtitle="Successfully sent"
          loading={tweetsLoading}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle className="text-lg">Recent Tweets</CardTitle>
            <Link href="/generate">
              <Button variant="ghost" size="sm" data-testid="link-view-all-tweets">
                View All <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {tweetsLoading ? (
              <div className="p-4 space-y-4">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : recentTweets.length > 0 ? (
              recentTweets.map(tweet => (
                <RecentTweetCard key={tweet.id} tweet={tweet} />
              ))
            ) : (
              <div className="p-8 text-center">
                <FileText className="w-12 h-12 mx-auto text-muted-foreground/50 mb-3" />
                <p className="text-muted-foreground">No tweets generated yet</p>
                <Link href="/generate">
                  <Button variant="outline" className="mt-4" data-testid="button-generate-first">
                    Generate Your First Batch
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle className="text-lg">Style Profiles</CardTitle>
            <Link href="/styles">
              <Button variant="ghost" size="sm" data-testid="link-view-styles">
                Manage <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {stylesLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : styles && styles.length > 0 ? (
              <div className="space-y-3">
                {styles.slice(0, 4).map(style => (
                  <div 
                    key={style.id} 
                    className="flex items-center gap-3 p-3 rounded-md bg-muted/50"
                    data-testid={`card-style-${style.id}`}
                  >
                    <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                      <Palette className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{style.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {style.referenceAccounts.length} reference account{style.referenceAccounts.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <Palette className="w-10 h-10 mx-auto text-muted-foreground/50 mb-3" />
                <p className="text-sm text-muted-foreground">No styles created yet</p>
                <Link href="/styles">
                  <Button variant="outline" size="sm" className="mt-3" data-testid="button-create-style">
                    Create First Style
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-3">
        <Card className="hover-elevate cursor-pointer" onClick={() => window.location.href = '/styles'}>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="w-12 h-12 rounded-md bg-chart-3/10 flex items-center justify-center">
              <Palette className="w-6 h-6 text-chart-3" />
            </div>
            <div>
              <h3 className="font-medium">Learn New Style</h3>
              <p className="text-sm text-muted-foreground">Add reference accounts</p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover-elevate cursor-pointer" onClick={() => window.location.href = '/upload'}>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="w-12 h-12 rounded-md bg-chart-2/10 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-chart-2" />
            </div>
            <div>
              <h3 className="font-medium">Upload Content Ideas</h3>
              <p className="text-sm text-muted-foreground">Import from CSV</p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover-elevate cursor-pointer" onClick={() => window.location.href = '/scheduled'}>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="w-12 h-12 rounded-md bg-chart-4/10 flex items-center justify-center">
              <Clock className="w-6 h-6 text-chart-4" />
            </div>
            <div>
              <h3 className="font-medium">View Schedule</h3>
              <p className="text-sm text-muted-foreground">Manage posting queue</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
