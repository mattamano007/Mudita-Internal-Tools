import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Clock, Send, X, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import type { GeneratedTweet } from "@shared/schema";
import { format, formatDistanceToNow, isSameDay, addDays, startOfDay } from "date-fns";

function groupByDate(tweets: GeneratedTweet[]): Record<string, GeneratedTweet[]> {
  const groups: Record<string, GeneratedTweet[]> = {};
  tweets.forEach(tweet => {
    if (!tweet.scheduledFor) return;
    const date = startOfDay(new Date(tweet.scheduledFor)).toISOString();
    if (!groups[date]) groups[date] = [];
    groups[date].push(tweet);
  });
  Object.keys(groups).forEach(date => {
    groups[date].sort((a, b) => 
      new Date(a.scheduledFor!).getTime() - new Date(b.scheduledFor!).getTime()
    );
  });
  return groups;
}

function formatDateHeader(dateStr: string): string {
  const date = new Date(dateStr);
  const today = startOfDay(new Date());
  const tomorrow = addDays(today, 1);
  
  if (isSameDay(date, today)) return "Today";
  if (isSameDay(date, tomorrow)) return "Tomorrow";
  return format(date, "EEEE, MMMM d");
}

export default function Scheduled() {
  const { toast } = useToast();

  const { data: tweets, isLoading } = useQuery<GeneratedTweet[]>({
    queryKey: ["/api/tweets"],
  });

  const unscheduleMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("PATCH", `/api/tweets/${id}`, { 
        status: "draft",
        scheduledFor: null 
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tweets"] });
      toast({ title: "Tweet unscheduled", description: "Moved back to drafts" });
    },
  });

  const postNowMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/tweets/${id}/post`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tweets"] });
      toast({ title: "Tweet posted!", description: "Successfully posted to X" });
    },
    onError: (error: Error) => {
      toast({ title: "Post failed", description: error.message, variant: "destructive" });
    },
  });

  const scheduledTweets = tweets?.filter(t => t.status === "scheduled") || [];
  const postedTweets = tweets?.filter(t => t.status === "posted").slice(0, 10) || [];
  const groupedScheduled = groupByDate(scheduledTweets);
  const sortedDates = Object.keys(groupedScheduled).sort();

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Scheduled Posts</h1>
        <p className="text-muted-foreground mt-1">
          Manage your tweet posting queue
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center gap-3 p-3 rounded-md bg-chart-4/10">
            <Calendar className="w-5 h-5 text-chart-4" />
            <span className="font-medium">Upcoming ({scheduledTweets.length})</span>
          </div>

          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : sortedDates.length > 0 ? (
            sortedDates.map(date => (
              <div key={date}>
                <h3 className="text-sm font-medium text-muted-foreground mb-3">
                  {formatDateHeader(date)}
                </h3>
                <div className="space-y-3">
                  {groupedScheduled[date].map(tweet => (
                    <Card key={tweet.id} data-testid={`card-scheduled-${tweet.id}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className="flex flex-col items-center text-center min-w-16">
                            <Clock className="w-4 h-4 text-muted-foreground mb-1" />
                            <span className="text-lg font-bold">
                              {format(new Date(tweet.scheduledFor!), "HH:mm")}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-mono leading-relaxed line-clamp-3">
                              {tweet.content}
                            </p>
                            <p className="text-xs text-muted-foreground mt-2">
                              {formatDistanceToNow(new Date(tweet.scheduledFor!), { addSuffix: true })}
                            </p>
                          </div>
                          <div className="flex flex-col gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => postNowMutation.mutate(tweet.id)}
                              disabled={postNowMutation.isPending}
                              data-testid={`button-post-now-${tweet.id}`}
                            >
                              {postNowMutation.isPending ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <Send className="w-3 h-3 mr-1" />
                              )}
                              Post Now
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => unscheduleMutation.mutate(tweet.id)}
                              data-testid={`button-unschedule-${tweet.id}`}
                            >
                              <X className="w-3 h-3 mr-1" />
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <Card className="border-dashed">
              <CardContent className="py-12 text-center">
                <Calendar className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
                <h3 className="font-medium mb-1">No Scheduled Tweets</h3>
                <p className="text-sm text-muted-foreground">
                  Schedule tweets from the Generate page to see them here
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        <div>
          <div className="flex items-center gap-3 p-3 rounded-md bg-chart-2/10 mb-4">
            <CheckCircle className="w-5 h-5 text-chart-2" />
            <span className="font-medium">Recently Posted</span>
          </div>
          
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : postedTweets.length > 0 ? (
            <div className="space-y-3">
              {postedTweets.map(tweet => (
                <Card key={tweet.id} className="bg-chart-2/5">
                  <CardContent className="p-4">
                    <p className="text-sm font-mono line-clamp-2 mb-2">
                      {tweet.content}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <CheckCircle className="w-3 h-3 text-chart-2" />
                      <span>
                        Posted {tweet.postedAt ? formatDistanceToNow(new Date(tweet.postedAt), { addSuffix: true }) : "recently"}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="border-dashed">
              <CardContent className="py-8 text-center">
                <CheckCircle className="w-8 h-8 mx-auto text-muted-foreground/30 mb-2" />
                <p className="text-sm text-muted-foreground">No posts yet</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
