import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Trash2, Palette, AtSign, Loader2, Sparkles, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import type { StyleProfile } from "@shared/schema";

function StyleCard({ 
  style, 
  onDelete 
}: { 
  style: StyleProfile; 
  onDelete: (id: string) => void;
}) {
  return (
    <Card data-testid={`card-style-${style.id}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-4 pb-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
            <Palette className="w-5 h-5 text-primary" />
          </div>
          <div>
            <CardTitle className="text-lg">{style.name}</CardTitle>
            {style.description && (
              <p className="text-sm text-muted-foreground mt-1">{style.description}</p>
            )}
          </div>
        </div>
        <Button
          size="icon"
          variant="ghost"
          onClick={() => onDelete(style.id)}
          data-testid={`button-delete-style-${style.id}`}
        >
          <Trash2 className="w-4 h-4 text-muted-foreground" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-xs text-muted-foreground mb-2 block">Reference Accounts</Label>
          <div className="flex flex-wrap gap-2">
            {style.referenceAccounts.map((account, i) => (
              <Badge key={i} variant="secondary" className="font-mono">
                <AtSign className="w-3 h-3 mr-1" />
                {account.replace('@', '')}
              </Badge>
            ))}
          </div>
        </div>
        {style.tone && (
          <div>
            <Label className="text-xs text-muted-foreground mb-1 block">Detected Tone</Label>
            <p className="text-sm">{style.tone}</p>
          </div>
        )}
        {style.sampleTweets && style.sampleTweets.length > 0 && (
          <div>
            <Label className="text-xs text-muted-foreground mb-2 block">Sample Tweets</Label>
            <div className="space-y-2">
              {style.sampleTweets.slice(0, 2).map((tweet, i) => (
                <p key={i} className="text-xs font-mono p-2 bg-muted rounded-md line-clamp-2">
                  {tweet}
                </p>
              ))}
            </div>
          </div>
        )}
        <div className="flex items-center justify-between pt-2">
          <Badge variant={style.isActive ? "default" : "secondary"}>
            {style.isActive ? "Active" : "Inactive"}
          </Badge>
          <span className="text-xs text-muted-foreground">
            Created {new Date(style.createdAt).toLocaleDateString()}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

function CreateStyleDialog({ 
  open, 
  onOpenChange 
}: { 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [accounts, setAccounts] = useState<string[]>([]);
  const [accountInput, setAccountInput] = useState("");
  const { toast } = useToast();

  const createMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string; referenceAccounts: string[] }) => {
      const res = await apiRequest("POST", "/api/styles", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/styles"] });
      toast({ title: "Style profile created", description: "AI is analyzing the writing style..." });
      onOpenChange(false);
      setName("");
      setDescription("");
      setAccounts([]);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const addAccount = () => {
    const cleaned = accountInput.replace('@', '').trim();
    if (cleaned && !accounts.includes(cleaned)) {
      setAccounts([...accounts, cleaned]);
      setAccountInput("");
    }
  };

  const removeAccount = (account: string) => {
    setAccounts(accounts.filter(a => a !== account));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || accounts.length === 0) return;
    createMutation.mutate({
      name,
      description: description || undefined,
      referenceAccounts: accounts.map(a => `@${a}`),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Create Style Profile
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Profile Name</Label>
            <Input
              id="name"
              placeholder="e.g., Tech Influencer Style"
              value={name}
              onChange={(e) => setName(e.target.value)}
              data-testid="input-style-name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description (optional)</Label>
            <Textarea
              id="description"
              placeholder="Describe the writing style you want to capture..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="min-h-20"
              data-testid="input-style-description"
            />
          </div>
          <div className="space-y-2">
            <Label>Reference Accounts</Label>
            <p className="text-xs text-muted-foreground mb-2">
              Add Twitter/X handles to learn their writing style
            </p>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="username"
                  value={accountInput}
                  onChange={(e) => setAccountInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addAccount())}
                  className="pl-9"
                  data-testid="input-reference-account"
                />
              </div>
              <Button type="button" variant="secondary" onClick={addAccount} data-testid="button-add-account">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {accounts.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {accounts.map(account => (
                  <Badge key={account} variant="secondary" className="pr-1 font-mono">
                    @{account}
                    <button
                      type="button"
                      onClick={() => removeAccount(account)}
                      className="ml-1 p-0.5 hover:bg-muted rounded"
                      data-testid={`button-remove-account-${account}`}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!name || accounts.length === 0 || createMutation.isPending}
              data-testid="button-create-style"
            >
              {createMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                "Create Style"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Styles() {
  const [createOpen, setCreateOpen] = useState(false);
  const { toast } = useToast();

  const { data: styles, isLoading } = useQuery<StyleProfile[]>({
    queryKey: ["/api/styles"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/styles/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/styles"] });
      toast({ title: "Style deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Style Library</h1>
          <p className="text-muted-foreground mt-1">
            Create style profiles by adding reference accounts to learn from
          </p>
        </div>
        <Button onClick={() => setCreateOpen(true)} data-testid="button-new-style">
          <Plus className="w-4 h-4 mr-2" />
          New Style
        </Button>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-48" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : styles && styles.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {styles.map(style => (
            <StyleCard
              key={style.id}
              style={style}
              onDelete={(id) => deleteMutation.mutate(id)}
            />
          ))}
        </div>
      ) : (
        <Card className="max-w-lg mx-auto">
          <CardContent className="py-12 text-center">
            <Palette className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-medium mb-2">No Style Profiles Yet</h3>
            <p className="text-muted-foreground mb-6">
              Create your first style profile by adding Twitter/X reference accounts.
              The AI will analyze their writing patterns and learn their unique style.
            </p>
            <Button onClick={() => setCreateOpen(true)} data-testid="button-create-first-style">
              <Plus className="w-4 h-4 mr-2" />
              Create First Style
            </Button>
          </CardContent>
        </Card>
      )}

      <CreateStyleDialog open={createOpen} onOpenChange={setCreateOpen} />
    </div>
  );
}
