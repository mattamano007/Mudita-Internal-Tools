import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, FileText, Calendar, CheckCircle, Trash2, Edit2, Loader2, Clock, Send, X, Save } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import type { GeneratedTweet, StyleProfile, ContentIdea } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

const STATUS_COLUMNS = ["draft", "scheduled", "posted"] as const;

const statusConfig = {
  draft: { label: "Drafts", icon: FileText, color: "bg-muted" },
  scheduled: { label: "Scheduled", icon: Clock, color: "bg-chart-4/10" },
  posted: { label: "Posted", icon: CheckCircle, color: "bg-chart-2/10" },
};

function TweetCard({ 
  tweet, 
  onEdit,
  onDelete,
  onSchedule,
  onPost,
}: { 
  tweet: GeneratedTweet;
  onEdit: (tweet: GeneratedTweet) => void;
  onDelete: (id: string) => void;
  onSchedule: (tweet: GeneratedTweet) => void;
  onPost: (id: string) => void;
}) {
  const charCount = tweet.content.length;
  const charColor = charCount > 280 ? "text-destructive" : charCount > 260 ? "text-chart-4" : "text-muted-foreground";

  return (
    <Card className="hover-elevate" data-testid={`card-tweet-${tweet.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
            <span className="text-xs font-medium">AI</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-mono leading-relaxed" data-testid={`text-tweet-content-${tweet.id}`}>
              {tweet.content}
            </p>
          </div>
        </div>
        <div className="flex items-center justify-between gap-2">
          <span className={`text-xs ${charColor}`}>{charCount}/280</span>
          <div className="flex items-center gap-1">
            {tweet.status === "draft" && (
              <>
                <Button size="icon" variant="ghost" onClick={() => onEdit(tweet)} data-testid={`button-edit-${tweet.id}`}>
                  <Edit2 className="w-3 h-3" />
                </Button>
                <Button size="icon" variant="ghost" onClick={() => onSchedule(tweet)} data-testid={`button-schedule-${tweet.id}`}>
                  <Calendar className="w-3 h-3" />
                </Button>
                <Button size="icon" variant="ghost" onClick={() => onPost(tweet.id)} data-testid={`button-post-${tweet.id}`}>
                  <Send className="w-3 h-3" />
                </Button>
              </>
            )}
            <Button size="icon" variant="ghost" onClick={() => onDelete(tweet.id)} data-testid={`button-delete-tweet-${tweet.id}`}>
              <Trash2 className="w-3 h-3 text-muted-foreground" />
            </Button>
          </div>
        </div>
        {tweet.scheduledFor && (
          <p className="text-xs text-muted-foreground mt-2">
            Scheduled for {new Date(tweet.scheduledFor).toLocaleString()}
          </p>
        )}
        {tweet.postedAt && (
          <p className="text-xs text-muted-foreground mt-2">
            Posted {formatDistanceToNow(new Date(tweet.postedAt), { addSuffix: true })}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function GenerateDialog({ 
  open, 
  onOpenChange,
  styles,
  ideas,
}: { 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
  styles: StyleProfile[];
  ideas: ContentIdea[];
}) {
  const [selectedStyle, setSelectedStyle] = useState<string>("");
  const [selectedIdeas, setSelectedIdeas] = useState<string[]>([]);
  const [customTopic, setCustomTopic] = useState("");
  const [count, setCount] = useState("3");
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: { styleId: string; ideaIds?: string[]; customTopic?: string; count: number }) => {
      const res = await apiRequest("POST", "/api/tweets/generate", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tweets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/content-ideas"] });
      toast({ title: "Tweets generated!", description: `${data.tweets.length} tweets created` });
      onOpenChange(false);
      setSelectedStyle("");
      setSelectedIdeas([]);
      setCustomTopic("");
      setIsGenerating(false);
      setProgress(0);
    },
    onError: (error: Error) => {
      toast({ title: "Generation failed", description: error.message, variant: "destructive" });
      setIsGenerating(false);
      setProgress(0);
    },
  });

  const handleGenerate = () => {
    if (!selectedStyle) return;
    setIsGenerating(true);
    
    const interval = setInterval(() => {
      setProgress(p => Math.min(p + 10, 90));
    }, 500);

    generateMutation.mutate({
      styleId: selectedStyle,
      ideaIds: selectedIdeas.length > 0 ? selectedIdeas : undefined,
      customTopic: customTopic || undefined,
      count: parseInt(count),
    });

    generateMutation.mutate({
      styleId: selectedStyle,
      ideaIds: selectedIdeas.length > 0 ? selectedIdeas : undefined,
      customTopic: customTopic || undefined,
      count: parseInt(count),
    }, {
      onSettled: () => {
        clearInterval(interval);
        setProgress(100);
      }
    });
  };

  const availableIdeas = ideas.filter(i => !i.isUsed);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Generate Tweets
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Style Profile</Label>
            <Select value={selectedStyle} onValueChange={setSelectedStyle}>
              <SelectTrigger data-testid="select-style">
                <SelectValue placeholder="Select a style..." />
              </SelectTrigger>
              <SelectContent>
                {styles.map(style => (
                  <SelectItem key={style.id} value={style.id}>
                    {style.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Content Source</Label>
            {availableIdeas.length > 0 ? (
              <div className="max-h-32 overflow-auto space-y-1 p-2 border rounded-md">
                {availableIdeas.map(idea => (
                  <label 
                    key={idea.id} 
                    className="flex items-center gap-2 p-2 rounded hover:bg-muted cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={selectedIdeas.includes(idea.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedIdeas([...selectedIdeas, idea.id]);
                        } else {
                          setSelectedIdeas(selectedIdeas.filter(id => id !== idea.id));
                        }
                      }}
                      className="rounded"
                      data-testid={`checkbox-idea-${idea.id}`}
                    />
                    <span className="text-sm">{idea.topic}</span>
                  </label>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground p-2 border rounded-md">
                No unused content ideas. Enter a custom topic below.
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label>Or Custom Topic</Label>
            <Textarea
              placeholder="Enter a topic or theme for tweets..."
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              className="min-h-20"
              data-testid="input-custom-topic"
            />
          </div>

          <div className="space-y-2">
            <Label>Number of Tweets</Label>
            <Select value={count} onValueChange={setCount}>
              <SelectTrigger data-testid="select-count">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[1, 3, 5, 10].map(n => (
                  <SelectItem key={n} value={String(n)}>{n} tweet{n > 1 ? 's' : ''}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isGenerating && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Generating...</span>
                <span>{progress}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-300" 
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleGenerate}
              disabled={!selectedStyle || (!selectedIdeas.length && !customTopic) || isGenerating}
              data-testid="button-generate"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EditDialog({
  tweet,
  open,
  onOpenChange,
}: {
  tweet: GeneratedTweet | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [content, setContent] = useState(tweet?.content || "");
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async ({ id, content }: { id: string; content: string }) => {
      const res = await apiRequest("PATCH", `/api/tweets/${id}`, { content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tweets"] });
      toast({ title: "Tweet updated" });
      onOpenChange(false);
    },
  });

  if (!tweet) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Tweet</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-32 font-mono"
            data-testid="input-edit-content"
          />
          <div className="flex justify-between items-center">
            <span className={`text-sm ${content.length > 280 ? "text-destructive" : "text-muted-foreground"}`}>
              {content.length}/280
            </span>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button 
                onClick={() => updateMutation.mutate({ id: tweet.id, content })}
                disabled={content.length > 280 || updateMutation.isPending}
                data-testid="button-save-edit"
              >
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ScheduleDialog({
  tweet,
  open,
  onOpenChange,
}: {
  tweet: GeneratedTweet | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const { toast } = useToast();

  const scheduleMutation = useMutation({
    mutationFn: async ({ id, scheduledFor }: { id: string; scheduledFor: string }) => {
      const res = await apiRequest("PATCH", `/api/tweets/${id}`, { 
        status: "scheduled",
        scheduledFor 
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tweets"] });
      toast({ title: "Tweet scheduled" });
      onOpenChange(false);
    },
  });

  if (!tweet) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Schedule Tweet</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-sm font-mono p-3 bg-muted rounded-md line-clamp-3">
            {tweet.content}
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Date</Label>
              <Input 
                type="date" 
                value={date} 
                onChange={(e) => setDate(e.target.value)}
                data-testid="input-schedule-date"
              />
            </div>
            <div className="space-y-2">
              <Label>Time</Label>
              <Input 
                type="time" 
                value={time} 
                onChange={(e) => setTime(e.target.value)}
                data-testid="input-schedule-time"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button 
              onClick={() => {
                const scheduledFor = new Date(`${date}T${time}`).toISOString();
                scheduleMutation.mutate({ id: tweet.id, scheduledFor });
              }}
              disabled={!date || !time || scheduleMutation.isPending}
              data-testid="button-confirm-schedule"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Schedule
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Generate() {
  const [generateOpen, setGenerateOpen] = useState(false);
  const [editingTweet, setEditingTweet] = useState<GeneratedTweet | null>(null);
  const [schedulingTweet, setSchedulingTweet] = useState<GeneratedTweet | null>(null);
  const { toast } = useToast();

  const { data: tweets, isLoading: tweetsLoading } = useQuery<GeneratedTweet[]>({
    queryKey: ["/api/tweets"],
  });

  const { data: styles, isLoading: stylesLoading } = useQuery<StyleProfile[]>({
    queryKey: ["/api/styles"],
  });

  const { data: ideas, isLoading: ideasLoading } = useQuery<ContentIdea[]>({
    queryKey: ["/api/content-ideas"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/tweets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tweets"] });
      toast({ title: "Tweet deleted" });
    },
  });

  const postMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/tweets/${id}/post`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tweets"] });
      toast({ title: "Tweet posted!", description: "Successfully posted to X" });
    },
    onError: (error: Error) => {
      toast({ title: "Post failed", description: error.message, variant: "destructive" });
    },
  });

  const getTweetsByStatus = (status: string) => 
    tweets?.filter(t => t.status === status) || [];

  const isLoading = tweetsLoading || stylesLoading || ideasLoading;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Generate Tweets</h1>
          <p className="text-muted-foreground mt-1">
            AI-powered tweet generation using your learned styles
          </p>
        </div>
        <Button onClick={() => setGenerateOpen(true)} data-testid="button-open-generate">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate New
        </Button>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-3">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-24" />
              </CardHeader>
              <CardContent className="space-y-3">
                {[1, 2].map(j => (
                  <Skeleton key={j} className="h-24 w-full" />
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-3">
          {STATUS_COLUMNS.map(status => {
            const config = statusConfig[status];
            const statusTweets = getTweetsByStatus(status);
            
            return (
              <div key={status}>
                <div className={`flex items-center gap-2 mb-4 p-3 rounded-md ${config.color}`}>
                  <config.icon className="w-4 h-4" />
                  <span className="font-medium">{config.label}</span>
                  <Badge variant="secondary" className="ml-auto">
                    {statusTweets.length}
                  </Badge>
                </div>
                <div className="space-y-3">
                  {statusTweets.length > 0 ? (
                    statusTweets.map(tweet => (
                      <TweetCard
                        key={tweet.id}
                        tweet={tweet}
                        onEdit={setEditingTweet}
                        onDelete={(id) => deleteMutation.mutate(id)}
                        onSchedule={setSchedulingTweet}
                        onPost={(id) => postMutation.mutate(id)}
                      />
                    ))
                  ) : (
                    <Card className="border-dashed">
                      <CardContent className="py-8 text-center">
                        <config.icon className="w-8 h-8 mx-auto text-muted-foreground/30 mb-2" />
                        <p className="text-sm text-muted-foreground">No {config.label.toLowerCase()}</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <GenerateDialog 
        open={generateOpen} 
        onOpenChange={setGenerateOpen}
        styles={styles || []}
        ideas={ideas || []}
      />
      <EditDialog
        tweet={editingTweet}
        open={!!editingTweet}
        onOpenChange={(open) => !open && setEditingTweet(null)}
      />
      <ScheduleDialog
        tweet={schedulingTweet}
        open={!!schedulingTweet}
        onOpenChange={(open) => !open && setSchedulingTweet(null)}
      />
    </div>
  );
}
