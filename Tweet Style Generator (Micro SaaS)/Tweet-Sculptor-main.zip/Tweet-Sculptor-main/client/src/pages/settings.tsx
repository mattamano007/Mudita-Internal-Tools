import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Settings as SettingsIcon, Zap, Save, Loader2, CheckCircle, AlertCircle, ExternalLink, Copy, Check } from "lucide-react";
import { SiX } from "react-icons/si";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RestartTourButton } from "@/components/onboarding-tour";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import type { Settings, StyleProfile } from "@shared/schema";

const TIMEZONES = [
  "UTC",
  "America/New_York",
  "America/Los_Angeles",
  "America/Chicago",
  "Europe/London",
  "Europe/Paris",
  "Asia/Tokyo",
  "Asia/Singapore",
  "Australia/Sydney",
];

interface TwitterStatus {
  configured: boolean;
  connected?: boolean;
  username?: string;
  name?: string;
  message: string;
}

export default function SettingsPage() {
  const { toast } = useToast();
  const [autoPost, setAutoPost] = useState(false);
  const [defaultStyle, setDefaultStyle] = useState("");
  const [timezone, setTimezone] = useState("UTC");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const { data: settings, isLoading } = useQuery<Settings>({
    queryKey: ["/api/settings"],
  });

  const { data: styles } = useQuery<StyleProfile[]>({
    queryKey: ["/api/styles"],
  });

  const { data: twitterStatus, isLoading: isLoadingTwitter } = useQuery<TwitterStatus>({
    queryKey: ["/api/twitter/status"],
  });

  useEffect(() => {
    if (settings) {
      setAutoPost(settings.autoPostEnabled || false);
      setDefaultStyle(settings.defaultStyleProfileId || "");
      setTimezone(settings.postingTimezone || "UTC");
    }
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: async (data: Partial<Settings>) => {
      const res = await apiRequest("PATCH", "/api/settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Settings saved" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const testTwitterMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/twitter/test");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/twitter/status"] });
      toast({ title: "Connected!", description: data.message });
    },
    onError: (error: Error) => {
      toast({ title: "Connection Failed", description: error.message, variant: "destructive" });
    },
  });

  const handleSave = () => {
    saveMutation.mutate({
      autoPostEnabled: autoPost,
      defaultStyleProfileId: defaultStyle && defaultStyle !== "none" ? defaultStyle : null,
      postingTimezone: timezone,
    });
  };

  const copyToClipboard = (key: string, value: string) => {
    navigator.clipboard.writeText(value);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const secretKeys = [
    { key: "TWITTER_CONSUMER_KEY", label: "API Key (Consumer Key)" },
    { key: "TWITTER_CONSUMER_SECRET", label: "API Secret (Consumer Secret)" },
    { key: "TWITTER_ACCESS_TOKEN", label: "Access Token" },
    { key: "TWITTER_ACCESS_TOKEN_SECRET", label: "Access Token Secret" },
  ];

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Configure your X/Twitter connection and posting preferences
        </p>
      </div>

      <Tabs defaultValue="twitter" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="twitter" data-testid="tab-twitter">X/Twitter API</TabsTrigger>
          <TabsTrigger value="posting" data-testid="tab-posting">Posting</TabsTrigger>
          <TabsTrigger value="defaults" data-testid="tab-defaults">Defaults</TabsTrigger>
        </TabsList>

        <TabsContent value="twitter">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <SiX className="w-5 h-5" />
                X/Twitter API Connection
              </CardTitle>
              <CardDescription>
                Connect your X/Twitter developer account to enable auto-posting
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 rounded-lg border bg-muted/30">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    {isLoadingTwitter ? (
                      <Skeleton className="w-3 h-3 rounded-full" />
                    ) : twitterStatus?.connected ? (
                      <div className="w-3 h-3 rounded-full bg-chart-2" />
                    ) : twitterStatus?.configured ? (
                      <div className="w-3 h-3 rounded-full bg-chart-5" />
                    ) : (
                      <div className="w-3 h-3 rounded-full bg-muted-foreground" />
                    )}
                    <div>
                      <p className="font-medium">
                        {isLoadingTwitter ? "Checking..." : twitterStatus?.connected 
                          ? `Connected as @${twitterStatus.username}` 
                          : twitterStatus?.configured 
                            ? "Credentials configured but not verified"
                            : "Not connected"}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {twitterStatus?.connected 
                          ? "Ready to post tweets" 
                          : "Add your API credentials to connect"}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => testTwitterMutation.mutate()}
                    disabled={testTwitterMutation.isPending}
                    data-testid="button-test-twitter"
                  >
                    {testTwitterMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Zap className="w-4 h-4 mr-2" />
                    )}
                    Test Connection
                  </Button>
                </div>
              </div>

              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="setup">
                  <AccordionTrigger data-testid="accordion-setup">
                    How to set up X/Twitter API credentials
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 text-sm">
                      <div className="p-4 rounded-lg bg-muted/50 space-y-3">
                        <h4 className="font-semibold">Step 1: Create a Developer Account</h4>
                        <p className="text-muted-foreground">
                          Go to the X Developer Portal and sign up for a free developer account.
                        </p>
                        <Button variant="outline" size="sm" asChild>
                          <a 
                            href="https://developer.x.com" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="gap-2"
                          >
                            <ExternalLink className="w-4 h-4" />
                            Open X Developer Portal
                          </a>
                        </Button>
                      </div>

                      <div className="p-4 rounded-lg bg-muted/50 space-y-3">
                        <h4 className="font-semibold">Step 2: Create a Project & App</h4>
                        <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                          <li>Go to "Projects & Apps" in the Developer Portal</li>
                          <li>Click "Create Project" and give it a name</li>
                          <li>Create an App within your project</li>
                        </ol>
                      </div>

                      <div className="p-4 rounded-lg bg-muted/50 space-y-3">
                        <h4 className="font-semibold">Step 3: Enable User Authentication</h4>
                        <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                          <li>Go to your App's Settings tab</li>
                          <li>Click "Set up" under User authentication settings</li>
                          <li>Select "Read and write" permissions</li>
                          <li>Choose "Web App, Automated App or Bot"</li>
                          <li>Add any callback URL (e.g., https://example.com)</li>
                          <li>Save your settings</li>
                        </ol>
                      </div>

                      <div className="p-4 rounded-lg bg-muted/50 space-y-3">
                        <h4 className="font-semibold">Step 4: Generate Your Keys</h4>
                        <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                          <li>Go to "Keys and Tokens" tab in your App</li>
                          <li>Copy your "API Key" and "API Secret"</li>
                          <li>Generate "Access Token and Secret"</li>
                          <li>Copy all 4 values</li>
                        </ol>
                      </div>

                      <div className="p-4 rounded-lg border-2 border-primary/20 bg-primary/5 space-y-3">
                        <h4 className="font-semibold">Step 5: Add to Replit Secrets</h4>
                        <p className="text-muted-foreground">
                          Add each credential as a secret in the Replit Secrets tab. 
                          Click the key names below to copy them:
                        </p>
                        <div className="space-y-2">
                          {secretKeys.map((item) => (
                            <div 
                              key={item.key}
                              className="flex items-center justify-between p-2 rounded bg-background border"
                            >
                              <div>
                                <code className="text-xs font-mono text-primary">{item.key}</code>
                                <p className="text-xs text-muted-foreground">{item.label}</p>
                              </div>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => copyToClipboard(item.key, item.key)}
                                data-testid={`button-copy-${item.key}`}
                              >
                                {copiedKey === item.key ? (
                                  <Check className="w-4 h-4 text-chart-2" />
                                ) : (
                                  <Copy className="w-4 h-4" />
                                )}
                              </Button>
                            </div>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          After adding all 4 secrets, click "Test Connection" above to verify.
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>

              {twitterStatus?.connected && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-chart-2/10 border border-chart-2/20">
                  <CheckCircle className="w-5 h-5 text-chart-2" />
                  <span className="text-sm">
                    Your X/Twitter account is connected and ready to post!
                  </span>
                </div>
              )}

              {twitterStatus?.configured && !twitterStatus?.connected && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-chart-5/10 border border-chart-5/20">
                  <AlertCircle className="w-5 h-5 text-chart-5" />
                  <span className="text-sm">
                    Credentials found but verification failed: {twitterStatus.message}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="posting">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Posting Preferences
              </CardTitle>
              <CardDescription>
                Configure how and when your tweets get posted
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between gap-4">
                    <div className="space-y-1">
                      <Label>Auto-Post Scheduled Tweets</Label>
                      <p className="text-xs text-muted-foreground">
                        Automatically post tweets at their scheduled time
                      </p>
                    </div>
                    <Switch
                      checked={autoPost}
                      onCheckedChange={setAutoPost}
                      data-testid="switch-auto-post"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Timezone</Label>
                    <Select value={timezone} onValueChange={setTimezone}>
                      <SelectTrigger data-testid="select-timezone">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {TIMEZONES.map(tz => (
                          <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      All scheduled times will be interpreted in this timezone
                    </p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="defaults">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <SettingsIcon className="w-5 h-5" />
                Default Settings
              </CardTitle>
              <CardDescription>
                Set default values for tweet generation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {isLoading ? (
                <Skeleton className="h-10 w-full" />
              ) : (
                <div className="space-y-2">
                  <Label>Default Style Profile</Label>
                  <Select value={defaultStyle} onValueChange={setDefaultStyle}>
                    <SelectTrigger data-testid="select-default-style">
                      <SelectValue placeholder="Select a default style..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {styles?.map(style => (
                        <SelectItem key={style.id} value={style.id}>{style.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    This style will be pre-selected when generating new tweets
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex items-center justify-between mt-6">
        <RestartTourButton />
        <Button 
          onClick={handleSave} 
          disabled={saveMutation.isPending}
          data-testid="button-save-settings"
        >
          {saveMutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Save Settings
        </Button>
      </div>
    </div>
  );
}
