# AI SDR Multi-Agent System

## Overview

This is a multi-agent AI Sales Development Representative (SDR) system built as a web application. The platform uses three specialized AI agents that work sequentially to research prospects, analyze opportunities, and generate personalized sales outreach materials. The pipeline flows: Scout (Research) → Strategist (Analysis) → Wordsmith (Copy), with each agent passing structured data to the next.

## User Preferences

Preferred communication style: Simple, everyday language.

## Design System (Updated: January 2026)

### Visual Design
- **Style**: Replit-inspired clean, utilitarian, developer-focused aesthetic
- **Philosophy**: Steve Jobs principles - clarity, simplicity, obvious user flow
- **Background**: Neutral dark (HSL 220 13% 10%)
- **Primary Accent**: Green (HSL 151 55% 42%)
- **Typography**: IBM Plex Sans for all text, IBM Plex Mono for code

### Design Principles Applied
- Single clear CTA on each page
- Minimal visual noise - no gradients or glows
- 3-step processing indicator with clear active state
- Pain points displayed as clean list with colored left borders
- Compact panels instead of ornate cards

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and data fetching
- **Styling**: Tailwind CSS with Replit-inspired neutral dark theme
- **Component Library**: shadcn/ui components built on Radix UI primitives

### Backend Architecture
- **Runtime**: Node.js with Express
- **API Structure**: RESTful endpoints under `/api/` prefix
- **AI Integration**: Anthropic Claude API for all three AI agents
- **Agent Pipeline**: Sequential processing (Research → Analysis → Copy) with status tracking per agent

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` contains all database table definitions
- **Storage Pattern**: Interface-based storage abstraction (`IStorage`) with in-memory fallback implementation

### Key Design Patterns
- **Monorepo Structure**: Client code in `client/`, server in `server/`, shared types in `shared/`
- **Path Aliases**: `@/` maps to client source, `@shared/` maps to shared code
- **Type Safety**: Zod schemas generated from Drizzle tables using drizzle-zod
- **Agent Status Tracking**: Each prospect tracks individual agent states (idle, working, complete, error)

### Build System
- **Development**: Vite dev server with HMR, proxied through Express
- **Production**: Vite builds client to `dist/public`, esbuild bundles server to `dist/index.cjs`

## Authentication

- **Method**: Hardcoded credentials for demo
- **Credentials**: gtm@muditastudios.com / Mudita
- **Storage**: localStorage key "muditaAuth"

## External Dependencies

### AI Services
- **Anthropic Claude API**: Powers all three AI agents (Scout, Strategist, Wordsmith)
  - Environment variables: `AI_INTEGRATIONS_ANTHROPIC_API_KEY`, `AI_INTEGRATIONS_ANTHROPIC_BASE_URL`

### Database
- **PostgreSQL**: Primary database via `DATABASE_URL` environment variable
- **Drizzle Kit**: Database migrations stored in `migrations/` directory

### Third-Party Libraries
- **Radix UI**: Headless UI primitives for accessible components
- **Lucide React**: Icon library
- **Recharts**: Analytics and data visualization
- **date-fns**: Date formatting utilities
- **react-hook-form**: Form state management with Zod validation

### Replit Integrations
- **Batch Processing**: Rate-limited batch processing utilities for Anthropic API calls
- **Chat Module**: Reusable chat storage and routes for conversation handling
- **Vite Plugins**: Runtime error overlay, cartographer, and dev banner for Replit environment
