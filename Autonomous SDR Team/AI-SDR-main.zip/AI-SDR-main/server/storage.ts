import { 
  type Prospect, type InsertProspect,
  type AgentLog, type InsertAgentLog,
  type Setting, type InsertSetting,
  type User, type InsertUser 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Prospect operations
  getProspects(): Promise<Prospect[]>;
  getProspect(id: number): Promise<Prospect | undefined>;
  createProspect(prospect: InsertProspect): Promise<Prospect>;
  updateProspect(id: number, updates: Partial<Prospect>): Promise<Prospect | undefined>;
  deleteProspect(id: number): Promise<void>;

  // Agent log operations
  getLogsByProspect(prospectId: number): Promise<AgentLog[]>;
  createLog(log: InsertAgentLog): Promise<AgentLog>;

  // Settings operations
  getSetting(key: string): Promise<Setting | undefined>;
  getSettings(): Promise<Setting[]>;
  setSetting(key: string, value: string): Promise<Setting>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private prospects: Map<number, Prospect>;
  private logs: Map<number, AgentLog>;
  private settings: Map<string, Setting>;
  private prospectIdCounter: number;
  private logIdCounter: number;
  private settingIdCounter: number;

  constructor() {
    this.users = new Map();
    this.prospects = new Map();
    this.logs = new Map();
    this.settings = new Map();
    this.prospectIdCounter = 1;
    this.logIdCounter = 1;
    this.settingIdCounter = 1;

    // Initialize default settings
    this.setSetting("company_name", "Your Company");
    this.setSetting("company_description", "We help businesses automate their workflows and scale faster.");
    this.setSetting("crawl_depth", "4");
    this.setSetting("email_tone", "professional");
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Prospect operations
  async getProspects(): Promise<Prospect[]> {
    return Array.from(this.prospects.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getProspect(id: number): Promise<Prospect | undefined> {
    return this.prospects.get(id);
  }

  async createProspect(insertProspect: InsertProspect): Promise<Prospect> {
    const id = this.prospectIdCounter++;
    const now = new Date();
    const prospect: Prospect = {
      id,
      url: insertProspect.url,
      companyName: insertProspect.companyName || null,
      status: insertProspect.status || "pending",
      priorityScore: insertProspect.priorityScore || null,
      agent1Status: insertProspect.agent1Status || "idle",
      agent1CompletedAt: insertProspect.agent1CompletedAt || null,
      agent2Status: insertProspect.agent2Status || "idle",
      agent2CompletedAt: insertProspect.agent2CompletedAt || null,
      agent3Status: insertProspect.agent3Status || "idle",
      agent3CompletedAt: insertProspect.agent3CompletedAt || null,
      researchData: insertProspect.researchData || null,
      analysisData: insertProspect.analysisData || null,
      copyData: insertProspect.copyData || null,
      createdAt: now,
      updatedAt: now,
    };
    this.prospects.set(id, prospect);
    return prospect;
  }

  async updateProspect(id: number, updates: Partial<Prospect>): Promise<Prospect | undefined> {
    const prospect = this.prospects.get(id);
    if (!prospect) return undefined;

    const updated: Prospect = {
      ...prospect,
      ...updates,
      updatedAt: new Date(),
    };
    this.prospects.set(id, updated);
    return updated;
  }

  async deleteProspect(id: number): Promise<void> {
    this.prospects.delete(id);
    // Delete associated logs
    for (const [logId, log] of this.logs) {
      if (log.prospectId === id) {
        this.logs.delete(logId);
      }
    }
  }

  // Agent log operations
  async getLogsByProspect(prospectId: number): Promise<AgentLog[]> {
    return Array.from(this.logs.values())
      .filter((log) => log.prospectId === prospectId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async createLog(insertLog: InsertAgentLog): Promise<AgentLog> {
    const id = this.logIdCounter++;
    const log: AgentLog = {
      id,
      prospectId: insertLog.prospectId || null,
      agentName: insertLog.agentName,
      logType: insertLog.logType,
      message: insertLog.message,
      timestamp: new Date(),
    };
    this.logs.set(id, log);
    return log;
  }

  // Settings operations
  async getSetting(key: string): Promise<Setting | undefined> {
    return this.settings.get(key);
  }

  async getSettings(): Promise<Setting[]> {
    return Array.from(this.settings.values());
  }

  async setSetting(key: string, value: string): Promise<Setting> {
    const existing = this.settings.get(key);
    const now = new Date();

    if (existing) {
      const updated: Setting = { ...existing, value, updatedAt: now };
      this.settings.set(key, updated);
      return updated;
    }

    const id = this.settingIdCounter++;
    const setting: Setting = { id, key, value, updatedAt: now };
    this.settings.set(key, setting);
    return setting;
  }
}

export const storage = new MemStorage();
