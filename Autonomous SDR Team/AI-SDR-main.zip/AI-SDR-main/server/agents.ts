import Anthropic from "@anthropic-ai/sdk";
import { storage } from "./storage";
import type { ResearchData, AnalysisData, CopyData } from "@shared/schema";

const anthropic = new Anthropic({
  apiKey: process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL,
});

async function log(prospectId: number, agentName: string, logType: string, message: string) {
  await storage.createLog({
    prospectId,
    agentName,
    logType,
    message,
  });
}

async function fetchWebPage(url: string): Promise<string> {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; AIBot/1.0)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch: ${response.status}`);
    }

    const html = await response.text();
    
    // Basic HTML to text conversion - strip tags and get text content
    const textContent = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
      .replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, "")
      .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, "")
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 15000); // Limit content size

    return textContent;
  } catch (error) {
    console.error(`Error fetching ${url}:`, error);
    return "";
  }
}

async function crawlWebsite(baseUrl: string): Promise<Array<{ url: string; content: string }>> {
  const pages: Array<{ url: string; content: string }> = [];
  const baseHost = new URL(baseUrl).host;

  // List of common pages to try
  const pagePaths = [
    "",
    "/about",
    "/about-us",
    "/pricing",
    "/products",
    "/customers",
    "/case-studies",
    "/blog",
    "/team",
    "/company",
  ];

  for (const path of pagePaths) {
    try {
      const url = new URL(path, baseUrl).toString();
      const content = await fetchWebPage(url);
      
      if (content && content.length > 100) {
        pages.push({ url, content });
        
        if (pages.length >= 4) break; // Limit to 4 pages
      }
    } catch (error) {
      // Skip invalid URLs
    }
  }

  // If we didn't get enough pages, at least include the homepage
  if (pages.length === 0) {
    const homeContent = await fetchWebPage(baseUrl);
    if (homeContent) {
      pages.push({ url: baseUrl, content: homeContent });
    }
  }

  return pages;
}

export async function runAgent1Research(prospectId: number, url: string): Promise<ResearchData> {
  await log(prospectId, "scout", "info", `Starting research on ${url}`);
  await storage.updateProspect(prospectId, { agent1Status: "working" });

  try {
    // Crawl the website
    await log(prospectId, "scout", "info", "Crawling website pages...");
    const pages = await crawlWebsite(url);
    await log(prospectId, "scout", "info", `Crawled ${pages.length} pages, extracting data...`);

    const pagesContent = pages.map((p) => `URL: ${p.url}\nContent: ${p.content}`).join("\n\n---\n\n");

    const prompt = `You are Agent 1 (Scout), a research specialist for an SDR (Sales Development Representative) team.

Analyze these ${pages.length} pages from ${url} and extract comprehensive information.

Pages Content:
${pagesContent}

Extract and return a JSON object with this exact structure:
{
  "prospect_url": "${url}",
  "company_name": "Company name from the website",
  "pages_crawled": ${pages.length},
  "crawl_timestamp": "${new Date().toISOString()}",
  "tech_stack": {
    "frontend": ["List visible frontend technologies"],
    "backend": ["Infer backend technologies if mentioned"],
    "tools": ["Third-party tools/integrations mentioned"],
    "infrastructure": ["Hosting/cloud providers mentioned"]
  },
  "pricing": {
    "model": "Pricing model type (freemium, subscription, usage-based, etc.)",
    "tiers": ["List of pricing tiers with prices"],
    "free_trial": true/false,
    "starting_price": number or null,
    "payment_terms": "monthly/annual/etc."
  },
  "customers": {
    "count": "Approximate customer count if mentioned",
    "notable_brands": ["List of customer logos/names"],
    "industries": ["Industries they serve"],
    "case_studies": [{"company": "name", "result": "key result"}]
  },
  "pain_points": [
    {
      "pain": "Specific pain point from their messaging",
      "source": "Where you found this (homepage, about, etc.)",
      "urgency": "high/medium/low"
    }
  ],
  "company_info": {
    "description": "Brief company description",
    "team_size": "Estimated team size if available",
    "funding_stage": "Funding stage if mentioned",
    "location": "Company location"
  },
  "confidence_score": 0-100
}

Be thorough but realistic. Only include information you can actually find or reasonably infer. Return ONLY the JSON object, no other text.`;

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 4096,
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.content[0];
    if (content.type !== "text") {
      throw new Error("Unexpected response type");
    }

    // Parse the JSON response
    const jsonMatch = content.text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON found in response");
    }

    const researchData: ResearchData = JSON.parse(jsonMatch[0]);

    await log(prospectId, "scout", "success", `Identified ${researchData.pain_points.length} pain points`);
    await log(prospectId, "scout", "handoff", "Passing research report to Strategist");

    await storage.updateProspect(prospectId, {
      agent1Status: "complete",
      agent1CompletedAt: new Date(),
      companyName: researchData.company_name,
      researchData: researchData as any,
    });

    return researchData;
  } catch (error) {
    await log(prospectId, "scout", "error", `Research failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    await storage.updateProspect(prospectId, { agent1Status: "error" });
    throw error;
  }
}

export async function runAgent2Analysis(prospectId: number, researchData: ResearchData): Promise<AnalysisData> {
  await log(prospectId, "strategist", "info", `Analyzing ${researchData.company_name}...`);
  await storage.updateProspect(prospectId, { agent2Status: "working" });

  try {
    // Get company settings for matching
    const companyName = (await storage.getSetting("company_name"))?.value || "Your Company";
    const companyDescription = (await storage.getSetting("company_description"))?.value || "";

    const prompt = `You are Agent 2 (Strategist), an analysis specialist for an SDR team.

Based on this research from Agent 1:
${JSON.stringify(researchData, null, 2)}

Our company: ${companyName}
What we do: ${companyDescription}

Analyze this prospect and return a JSON object with this exact structure:
{
  "prospect_url": "${researchData.prospect_url}",
  "company_name": "${researchData.company_name}",
  "analysis_timestamp": "${new Date().toISOString()}",
  "priority_score": 0-100,
  "priority_tier": "High/Medium/Low",
  "buying_likelihood": {
    "score": 0-100,
    "tier": "High Priority/Medium Priority/Low Priority",
    "reasoning": "Explanation of the score",
    "timeline_estimate": "30-60 days / 60-90 days / 90+ days",
    "deal_size_estimate": "$X-$Y ARR"
  },
  "offer_angles": [
    {
      "angle": "Main angle name",
      "match_strength": 0-100,
      "pain_points_addressed": ["List of pain points this addresses"],
      "recommended_hook": "One sentence hook",
      "supporting_evidence": "Why this angle works"
    }
  ],
  "decision_makers": {
    "likely_roles": ["VP Engineering", "CTO", etc.],
    "org_structure": "centralized/distributed",
    "buying_committee_size": "2-4 people",
    "budget_authority": "Who likely holds budget",
    "decision_patterns": ["Pattern 1", "Pattern 2"]
  },
  "competitive_positioning": {
    "current_solutions": ["What they likely use now"],
    "switching_cost": "low/medium/high",
    "differentiation_opportunities": ["How we can differentiate"]
  },
  "recommended_next_steps": [
    "Step 1",
    "Step 2",
    "Step 3"
  ]
}

Score based on:
- Intent signals (job postings, funding, etc.): 0-25 points
- Fit with our solution: 0-25 points  
- Pain point severity: 0-25 points
- Budget indicators: 0-25 points

Return ONLY the JSON object, no other text.`;

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 4096,
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.content[0];
    if (content.type !== "text") {
      throw new Error("Unexpected response type");
    }

    const jsonMatch = content.text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON found in response");
    }

    const analysisData: AnalysisData = JSON.parse(jsonMatch[0]);

    await log(prospectId, "strategist", "success", `Priority score: ${analysisData.priority_score}/100 (${analysisData.priority_tier})`);
    await log(prospectId, "strategist", "info", `Matched ${analysisData.offer_angles.length} offer angles`);
    await log(prospectId, "strategist", "handoff", "Passing analysis report to Wordsmith");

    await storage.updateProspect(prospectId, {
      agent2Status: "complete",
      agent2CompletedAt: new Date(),
      priorityScore: analysisData.priority_score,
      analysisData: analysisData as any,
    });

    return analysisData;
  } catch (error) {
    await log(prospectId, "strategist", "error", `Analysis failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    await storage.updateProspect(prospectId, { agent2Status: "error" });
    throw error;
  }
}

export async function runAgent3Copy(
  prospectId: number,
  researchData: ResearchData,
  analysisData: AnalysisData
): Promise<CopyData> {
  await log(prospectId, "wordsmith", "info", `Crafting outreach for ${researchData.company_name}...`);
  await storage.updateProspect(prospectId, { agent3Status: "working" });

  try {
    const companyName = (await storage.getSetting("company_name"))?.value || "Your Company";
    const emailTone = (await storage.getSetting("email_tone"))?.value || "professional";

    const prompt = `You are Agent 3 (Wordsmith), a copywriting specialist for an SDR team.

Research data:
${JSON.stringify(researchData, null, 2)}

Analysis data:
${JSON.stringify(analysisData, null, 2)}

Our company: ${companyName}
Email tone: ${emailTone}

Create personalized outreach materials. Use specific details from the research.
Use [First Name], [Company], and [Your Name] as placeholders.

Return a JSON object with this exact structure:
{
  "prospect_url": "${researchData.prospect_url}",
  "company_name": "${researchData.company_name}",
  "copy_timestamp": "${new Date().toISOString()}",
  "email_sequences": [
    {
      "sequence_name": "Main Outreach Sequence",
      "emails": [
        {
          "email_number": 1,
          "subject": "Subject line (personalized)",
          "preview_text": "Preview text for inbox",
          "body": "Full email body with personalization",
          "cta": "Call to action",
          "send_delay": "Day 1"
        }
      ]
    }
  ],
  "call_scripts": [
    {
      "script_name": "Cold Call Script",
      "opening": "15-second opener",
      "discovery_questions": ["Question 1", "Question 2", "Question 3", "Question 4"],
      "value_prop": "Value proposition statement",
      "closing": "Closing statement",
      "next_steps": "What to do after the call"
    }
  ],
  "objection_handlers": [
    {
      "objection": "Common objection",
      "response": "Response to the objection",
      "proof_points": ["Evidence 1", "Evidence 2"]
    }
  ],
  "linkedin_outreach": {
    "connection_request": "Connection request message (under 300 chars)",
    "follow_up_message": "Follow-up after connection"
  }
}

Create:
- 3-5 emails in the sequence (different angles for each)
- 2 call scripts (cold call and warm follow-up)
- 4-5 objection handlers for common concerns
- LinkedIn messages

Make everything highly personalized using specific details from the research.
Return ONLY the JSON object, no other text.`;

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 8192,
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.content[0];
    if (content.type !== "text") {
      throw new Error("Unexpected response type");
    }

    const jsonMatch = content.text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON found in response");
    }

    const copyData: CopyData = JSON.parse(jsonMatch[0]);

    const emailCount = copyData.email_sequences.reduce((acc, seq) => acc + seq.emails.length, 0);
    await log(prospectId, "wordsmith", "success", `Generated ${emailCount}-email sequence`);
    await log(prospectId, "wordsmith", "success", `Created ${copyData.call_scripts.length} call scripts`);
    await log(prospectId, "wordsmith", "success", "Complete! Ready for review");

    await storage.updateProspect(prospectId, {
      agent3Status: "complete",
      agent3CompletedAt: new Date(),
      status: "complete",
      copyData: copyData as any,
    });

    return copyData;
  } catch (error) {
    await log(prospectId, "wordsmith", "error", `Copy generation failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    await storage.updateProspect(prospectId, { agent3Status: "error" });
    throw error;
  }
}

export async function runAgentPipeline(prospectId: number, url: string): Promise<void> {
  try {
    // Agent 1: Research
    const researchData = await runAgent1Research(prospectId, url);

    // Agent 2: Analysis
    const analysisData = await runAgent2Analysis(prospectId, researchData);

    // Agent 3: Copy
    await runAgent3Copy(prospectId, researchData, analysisData);
  } catch (error) {
    console.error(`Pipeline failed for prospect ${prospectId}:`, error);
    await storage.updateProspect(prospectId, { status: "error" });
  }
}

interface ProductInfo {
  name: string;
  features: string;
  industries: string;
  icp: string;
}

interface ResearchPipelineResult {
  companyName: string;
  websiteUrl: string;
  industry: string;
  productOffered: string;
  painPoints: Array<{
    painPoint: string;
    businessOpportunity: string;
    severity: string;
  }>;
  buyingLikelihood: string;
  buyingSignals: string[];
  recommendedAngles: string[];
  decisionMakers: string[];
  emailSequence: string;
  callScript: string;
  objectionHandlers: string;
}

type ProgressCallback = (update: { agent: string; status: string; message?: string }) => void;

export async function runResearchPipeline(
  url: string,
  productInfo: ProductInfo | null,
  onProgress: ProgressCallback
): Promise<ResearchPipelineResult> {
  // Scout Phase - Research
  onProgress({ agent: "scout", status: "working", message: "Crawling website..." });
  
  const pages = await crawlWebsite(url);
  onProgress({ agent: "scout", status: "working", message: `Analyzed ${pages.length} pages` });

  const pagesContent = pages.map((p) => `URL: ${p.url}\nContent: ${p.content}`).join("\n\n---\n\n");

  const scoutPrompt = `Analyze this company website content and extract information:

Website content from ${pages.length} pages:
${pagesContent}

Return a JSON object with:
{
  "company_name": "Company name",
  "industry": "Industry/vertical",
  "product_offered": "Main product/service offered (concise, 1-2 sentences)",
  "tech_stack": ["Detected technologies"],
  "pricing_model": "Pricing model if found",
  "customers": ["Notable customers if mentioned"],
  "messaging": {
    "headlines": ["Key headlines"],
    "value_props": ["Value propositions"],
    "pain_points_addressed": ["Pain points from their messaging"]
  }
}

Return ONLY the JSON object.`;

  const scoutResponse = await anthropic.messages.create({
    model: "claude-sonnet-4-5",
    max_tokens: 4096,
    messages: [{ role: "user", content: scoutPrompt }],
  });

  const scoutContent = scoutResponse.content[0];
  if (scoutContent.type !== "text") throw new Error("Scout response error");
  
  const scoutMatch = scoutContent.text.match(/\{[\s\S]*\}/);
  if (!scoutMatch) throw new Error("Failed to parse scout data");
  
  const scoutData = JSON.parse(scoutMatch[0]);
  onProgress({ agent: "scout", status: "complete" });

  // Strategist Phase - Analysis
  onProgress({ agent: "strategist", status: "working", message: "Analyzing pain points..." });

  const productContext = productInfo
    ? `Our product: ${productInfo.name}
Our value prop: ${productInfo.features}
Target industries: ${productInfo.industries}
Our ICP: ${productInfo.icp}`
    : "No specific product information provided - provide generic B2B sales analysis.";

  const strategistPrompt = `You are a B2B sales strategist. Analyze this prospect company:

Company: ${scoutData.company_name}
Industry: ${scoutData.industry}
Product: ${scoutData.product_offered}
Pain points they address: ${JSON.stringify(scoutData.messaging?.pain_points_addressed || [])}

${productContext}

Tasks:
1. Identify 3-5 pain points this company likely experiences
2. For each pain point, explain why it's a potential business opportunity
3. Rate buying likelihood (High/Medium/Low) with reasoning
4. Suggest 2-3 outreach angles that would resonate
5. Identify likely decision makers (roles, not names)

Return JSON:
{
  "identified_pain_points": [
    {
      "pain_point": "15 word max description",
      "business_opportunity": "Why this is an opportunity",
      "severity": "High/Medium/Low"
    }
  ],
  "buying_likelihood": "High/Medium/Low",
  "buying_signals": ["Signal 1", "Signal 2"],
  "recommended_angles": ["Angle 1", "Angle 2"],
  "decision_maker_patterns": ["VP Engineering", "Head of Ops"]
}

Return ONLY the JSON object.`;

  const strategistResponse = await anthropic.messages.create({
    model: "claude-sonnet-4-5",
    max_tokens: 4096,
    messages: [{ role: "user", content: strategistPrompt }],
  });

  const strategistContent = strategistResponse.content[0];
  if (strategistContent.type !== "text") throw new Error("Strategist response error");
  
  const strategistMatch = strategistContent.text.match(/\{[\s\S]*\}/);
  if (!strategistMatch) throw new Error("Failed to parse strategist data");
  
  const strategistData = JSON.parse(strategistMatch[0]);
  onProgress({ agent: "strategist", status: "complete" });

  // Wordsmith Phase - Copy Generation
  onProgress({ agent: "wordsmith", status: "working", message: "Generating outreach..." });

  const wordsmithPrompt = `Generate cold outreach materials for:

Prospect: ${scoutData.company_name}
Industry: ${scoutData.industry}
Pain points: ${JSON.stringify(strategistData.identified_pain_points)}
Recommended angle: ${strategistData.recommended_angles[0]}

${productInfo ? `Our solution: ${productInfo.name} - ${productInfo.features}` : "Generic B2B solution approach"}

Generate:

1. EMAIL SEQUENCE (3 emails):
- Email 1: Short, curiosity-driven (75-100 words)
- Email 2: Value-focused, address specific pain point (100-125 words)
- Email 3: Social proof + clear CTA (100-125 words)
- Professional but conversational tone
- No sales jargon
- Include specific details about their company

2. CALL SCRIPT (max 200 words):
- Opening (10 seconds)
- Permission question
- Context/research share
- Value proposition (tie to their pain point)
- Discovery question
- Close for next step

3. OBJECTION HANDLERS (5 handlers for common objections):
- "We're happy with our current solution"
- "Not the right time"
- "Send me some info"
- "Too expensive"
- "We don't have budget"

For each handler: Acknowledge, pivot to their pain point, suggest low-commitment next step.

Return JSON:
{
  "email_sequence": "Full formatted email sequence with subjects and bodies",
  "call_script": "Complete call script",
  "objection_handlers": "All 5 handlers formatted"
}

Return ONLY the JSON object.`;

  const wordsmithResponse = await anthropic.messages.create({
    model: "claude-sonnet-4-5",
    max_tokens: 8192,
    messages: [{ role: "user", content: wordsmithPrompt }],
  });

  const wordsmithContent = wordsmithResponse.content[0];
  if (wordsmithContent.type !== "text") throw new Error("Wordsmith response error");
  
  const wordsmithMatch = wordsmithContent.text.match(/\{[\s\S]*\}/);
  if (!wordsmithMatch) throw new Error("Failed to parse wordsmith data");
  
  const wordsmithData = JSON.parse(wordsmithMatch[0]);
  onProgress({ agent: "wordsmith", status: "complete" });

  // Compile final result
  return {
    companyName: scoutData.company_name || "Unknown Company",
    websiteUrl: url,
    industry: scoutData.industry || "Unknown",
    productOffered: scoutData.product_offered || "Unknown",
    painPoints: (strategistData.identified_pain_points || []).map((p: any) => ({
      painPoint: p.pain_point,
      businessOpportunity: p.business_opportunity,
      severity: p.severity,
    })),
    buyingLikelihood: strategistData.buying_likelihood || "Medium",
    buyingSignals: strategistData.buying_signals || [],
    recommendedAngles: strategistData.recommended_angles || [],
    decisionMakers: strategistData.decision_maker_patterns || [],
    emailSequence: wordsmithData.email_sequence || "",
    callScript: wordsmithData.call_script || "",
    objectionHandlers: wordsmithData.objection_handlers || "",
  };
}
