import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { runAgentPipeline, runResearchPipeline } from "./agents";
import { z } from "zod";

const createProspectSchema = z.object({
  url: z.string().url(),
});

const researchSchema = z.object({
  url: z.string().min(1),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get all prospects
  app.get("/api/prospects", async (req, res) => {
    try {
      const prospects = await storage.getProspects();
      res.json(prospects);
    } catch (error) {
      console.error("Error fetching prospects:", error);
      res.status(500).json({ error: "Failed to fetch prospects" });
    }
  });

  // Get single prospect with logs
  app.get("/api/prospects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid prospect ID" });
      }

      const prospect = await storage.getProspect(id);
      if (!prospect) {
        return res.status(404).json({ error: "Prospect not found" });
      }

      const logs = await storage.getLogsByProspect(id);
      res.json({ ...prospect, logs });
    } catch (error) {
      console.error("Error fetching prospect:", error);
      res.status(500).json({ error: "Failed to fetch prospect" });
    }
  });

  // Create new prospect and start pipeline
  app.post("/api/prospects", async (req, res) => {
    try {
      const validation = createProspectSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.errors[0].message });
      }

      const { url } = validation.data;

      // Create the prospect
      const prospect = await storage.createProspect({
        url,
        status: "processing",
        agent1Status: "idle",
        agent2Status: "idle",
        agent3Status: "idle",
      });

      // Start the agent pipeline asynchronously
      runAgentPipeline(prospect.id, url).catch((error) => {
        console.error(`Pipeline error for prospect ${prospect.id}:`, error);
      });

      res.status(201).json(prospect);
    } catch (error) {
      console.error("Error creating prospect:", error);
      res.status(500).json({ error: "Failed to create prospect" });
    }
  });

  // Re-run pipeline for a prospect
  app.post("/api/prospects/:id/rerun", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid prospect ID" });
      }

      const prospect = await storage.getProspect(id);
      if (!prospect) {
        return res.status(404).json({ error: "Prospect not found" });
      }

      // Reset the prospect status
      await storage.updateProspect(id, {
        status: "processing",
        agent1Status: "idle",
        agent2Status: "idle",
        agent3Status: "idle",
        researchData: null,
        analysisData: null,
        copyData: null,
        priorityScore: null,
      });

      // Start the pipeline again
      runAgentPipeline(id, prospect.url).catch((error) => {
        console.error(`Pipeline error for prospect ${id}:`, error);
      });

      const updated = await storage.getProspect(id);
      res.json(updated);
    } catch (error) {
      console.error("Error re-running pipeline:", error);
      res.status(500).json({ error: "Failed to re-run pipeline" });
    }
  });

  // Delete prospect
  app.delete("/api/prospects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid prospect ID" });
      }

      await storage.deleteProspect(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting prospect:", error);
      res.status(500).json({ error: "Failed to delete prospect" });
    }
  });

  // Get settings
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  // Update setting
  app.patch("/api/settings/:key", async (req, res) => {
    try {
      const { key } = req.params;
      const { value } = req.body;

      if (!value || typeof value !== "string") {
        return res.status(400).json({ error: "Value is required" });
      }

      const setting = await storage.setSetting(key, value);
      res.json(setting);
    } catch (error) {
      console.error("Error updating setting:", error);
      res.status(500).json({ error: "Failed to update setting" });
    }
  });

  // Get agent status overview
  app.get("/api/agents/status", async (req, res) => {
    try {
      const prospects = await storage.getProspects();

      const status = {
        scout: { idle: 0, working: 0, complete: 0, error: 0 },
        strategist: { idle: 0, working: 0, complete: 0, error: 0 },
        wordsmith: { idle: 0, working: 0, complete: 0, error: 0 },
        totalProspects: prospects.length,
        completedProspects: prospects.filter((p) => p.agent3Status === "complete").length,
      };

      prospects.forEach((p) => {
        const a1 = p.agent1Status as keyof typeof status.scout;
        const a2 = p.agent2Status as keyof typeof status.strategist;
        const a3 = p.agent3Status as keyof typeof status.wordsmith;

        if (status.scout[a1] !== undefined) status.scout[a1]++;
        if (status.strategist[a2] !== undefined) status.strategist[a2]++;
        if (status.wordsmith[a3] !== undefined) status.wordsmith[a3]++;
      });

      res.json(status);
    } catch (error) {
      console.error("Error fetching agent status:", error);
      res.status(500).json({ error: "Failed to fetch agent status" });
    }
  });

  // Research endpoint - single URL research with streaming
  app.post("/api/research", async (req, res) => {
    try {
      const validation = researchSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: "Please enter a valid URL" });
      }

      let { url } = validation.data;
      
      // Add https if not present
      if (!url.startsWith("http://") && !url.startsWith("https://")) {
        url = "https://" + url;
      }

      // Check if Anthropic API is configured
      if (!process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY) {
        return res.status(500).json({ 
          error: "AI service not configured. Please ensure the Anthropic API key is set." 
        });
      }

      // Set up streaming response
      res.setHeader("Content-Type", "application/x-ndjson");
      res.setHeader("Transfer-Encoding", "chunked");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      // Get product info from request if provided
      const productInfo = req.body.productInfo || null;

      try {
        // Run the research pipeline with progress updates
        const result = await runResearchPipeline(url, productInfo, (update) => {
          res.write(JSON.stringify(update) + "\n");
        });

        // Send final result
        res.write(JSON.stringify(result) + "\n");
        res.end();
      } catch (pipelineError) {
        console.error("Pipeline error:", pipelineError);
        res.write(JSON.stringify({ 
          error: true, 
          message: pipelineError instanceof Error ? pipelineError.message : "Research pipeline failed" 
        }) + "\n");
        res.end();
      }
    } catch (error) {
      console.error("Research error:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Research failed. Please try again." });
      }
    }
  });

  // Analytics endpoint
  app.get("/api/analytics", async (req, res) => {
    try {
      const prospects = await storage.getProspects();
      const completedProspects = prospects.filter((p) => p.agent3Status === "complete");

      const analytics = {
        totalProspects: prospects.length,
        completedProspects: completedProspects.length,
        successRate: prospects.length > 0 
          ? Math.round((completedProspects.length / prospects.length) * 100) 
          : 0,
        averageScore: completedProspects.length > 0
          ? Math.round(
              completedProspects
                .filter((p) => p.priorityScore !== null)
                .reduce((acc, p) => acc + (p.priorityScore || 0), 0) /
                completedProspects.filter((p) => p.priorityScore !== null).length
            )
          : 0,
        highPriorityCount: prospects.filter(
          (p) => p.priorityScore !== null && p.priorityScore >= 80
        ).length,
        mediumPriorityCount: prospects.filter(
          (p) => p.priorityScore !== null && p.priorityScore >= 60 && p.priorityScore < 80
        ).length,
        lowPriorityCount: prospects.filter(
          (p) => p.priorityScore !== null && p.priorityScore < 60
        ).length,
      };

      res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  return httpServer;
}
