import { formatDistanceToNow } from "date-fns";
import { ArrowRight, Search, Brain, FileText, CheckCircle2, AlertCircle, Info } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import type { AgentLog } from "@shared/schema";

interface AgentLogsProps {
  logs: AgentLog[];
  className?: string;
}

const agentIcons: Record<string, typeof Search> = {
  scout: Search,
  strategist: Brain,
  wordsmith: FileText,
};

const agentColors: Record<string, string> = {
  scout: "text-cyan-400",
  strategist: "text-purple-400",
  wordsmith: "text-emerald-400",
};

const logTypeIcons: Record<string, typeof Info> = {
  info: Info,
  success: CheckCircle2,
  error: AlertCircle,
  handoff: ArrowRight,
};

const logTypeColors: Record<string, string> = {
  info: "text-muted-foreground",
  success: "text-emerald-400",
  error: "text-red-400",
  handoff: "text-purple-400",
};

export function AgentLogs({ logs, className }: AgentLogsProps) {
  if (logs.length === 0) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="text-base">Agent Communication</CardTitle>
          <CardDescription>No activity yet</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted mb-3">
              <Info className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">
              Agent activity will appear here once processing begins.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-base">Agent Communication</CardTitle>
        <CardDescription>
          {logs.length} log {logs.length !== 1 ? "entries" : "entry"}
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[300px]">
          <div className="space-y-0 divide-y divide-border">
            {logs.map((log) => {
              const AgentIcon = agentIcons[log.agentName.toLowerCase()] || Info;
              const LogTypeIcon = logTypeIcons[log.logType] || Info;
              const agentColor = agentColors[log.agentName.toLowerCase()] || "text-foreground";
              const logColor = logTypeColors[log.logType] || "text-muted-foreground";

              return (
                <div
                  key={log.id}
                  className="flex items-start gap-3 px-4 py-3 hover-elevate"
                  data-testid={`log-entry-${log.id}`}
                >
                  <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-muted")}>
                    <AgentIcon className={cn("h-4 w-4", agentColor)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={cn("text-sm font-medium capitalize", agentColor)}>
                        {log.agentName}
                      </span>
                      <LogTypeIcon className={cn("h-3.5 w-3.5", logColor)} />
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(log.timestamp), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm text-foreground">{log.message}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
