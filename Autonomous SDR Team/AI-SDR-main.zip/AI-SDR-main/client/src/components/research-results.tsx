import { useState } from "react";
import { Copy, Download, ExternalLink, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface PainPoint {
  painPoint: string;
  businessOpportunity: string;
  severity: string;
}

interface ResearchResult {
  companyName: string;
  websiteUrl: string;
  industry: string;
  productOffered: string;
  painPoints: PainPoint[];
  buyingLikelihood: string;
  buyingSignals: string[];
  recommendedAngles: string[];
  decisionMakers: string[];
  emailSequence: string;
  callScript: string;
  objectionHandlers: string;
}

interface ResearchResultsProps {
  results: ResearchResult;
}

export function ResearchResults({ results }: ResearchResultsProps) {
  const { toast } = useToast();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const copyToClipboard = async (text: string, field: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedField(field);
    toast({ title: "Copied", description: `${field} copied to clipboard.` });
    setTimeout(() => setCopiedField(null), 2000);
  };

  const downloadCSV = () => {
    const escapeCSV = (str: string) => {
      const cellStr = String(str || "");
      if (cellStr.includes(",") || cellStr.includes("\n") || cellStr.includes('"')) {
        return `"${cellStr.replace(/"/g, '""')}"`;
      }
      return cellStr;
    };

    const truncateWords = (text: string, maxWords: number) => {
      const words = text.split(" ");
      if (words.length <= maxWords) return text;
      return words.slice(0, maxWords).join(" ") + "...";
    };

    const priorityOrder: Record<string, number> = { High: 1, Medium: 2, Low: 3 };
    const sortedPainPoints = [...results.painPoints].sort(
      (a, b) => (priorityOrder[a.severity] || 3) - (priorityOrder[b.severity] || 3)
    );

    const rows: string[][] = [];
    rows.push([
      "Company Name", "Website URL", "Industry", "Product Offered",
      "Buying Likelihood", "Decision Makers", "Email Sequence", "Call Script", "Objection Handlers",
    ]);
    rows.push([
      results.companyName || "", results.websiteUrl || "", results.industry || "",
      results.productOffered || "", results.buyingLikelihood || "",
      results.decisionMakers?.join(", ") || "", results.emailSequence || "",
      results.callScript || "", results.objectionHandlers || "",
    ]);
    rows.push([""]);
    rows.push(["PAIN POINTS BY PRIORITY", "", "", "", "", "", "", "", ""]);
    sortedPainPoints.forEach((pp) => {
      rows.push([pp.severity, truncateWords(pp.painPoint, 20), truncateWords(pp.businessOpportunity, 20), "", "", "", "", "", ""]);
    });

    const csvContent = rows.map((row) => row.map(escapeCSV).join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(results.companyName || "report").replace(/\s+/g, "_")}_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded", description: "CSV report saved." });
  };

  const sortedPainPoints = [...results.painPoints].sort((a, b) => {
    const order: Record<string, number> = { High: 0, Medium: 1, Low: 2 };
    return (order[a.severity] || 2) - (order[b.severity] || 2);
  });

  return (
    <div className="panel animate-fade-in" data-testid="card-results">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 pb-4 mb-4 border-b border-border">
        <div>
          <h2 className="text-lg font-semibold text-foreground" data-testid="text-company-name">
            {results.companyName}
          </h2>
          <a
            href={results.websiteUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1"
            data-testid="link-website"
          >
            {results.websiteUrl}
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs" data-testid="badge-industry">
            {results.industry}
          </Badge>
          <Button variant="outline" size="sm" onClick={downloadCSV} data-testid="button-download-csv">
            <Download className="w-3.5 h-3.5 mr-1.5" />
            CSV
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="overview" className="text-xs" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="outreach" className="text-xs" data-testid="tab-outreach">Outreach</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-5">
          {/* Summary row */}
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Likelihood</p>
              <p className={`text-sm font-medium ${
                results.buyingLikelihood === "High" ? "text-primary" :
                results.buyingLikelihood === "Medium" ? "text-yellow-400" : "text-muted-foreground"
              }`} data-testid="text-buying-likelihood">
                {results.buyingLikelihood}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Decision Makers</p>
              <p className="text-sm text-foreground">{results.decisionMakers?.slice(0, 2).join(", ")}</p>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Pain Points</p>
              <p className="text-sm text-foreground">{results.painPoints?.length || 0} identified</p>
            </div>
          </div>

          {/* Product */}
          <div>
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-1">Product</p>
            <p className="text-sm text-foreground" data-testid="text-product">{results.productOffered}</p>
          </div>

          {/* Pain Points - Clean list */}
          <div>
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-2">Pain Points</p>
            <div className="space-y-2">
              {sortedPainPoints.map((point, index) => (
                <div
                  key={index}
                  className={`pain-point-item priority-${point.severity.toLowerCase()}`}
                  data-testid={`card-pain-point-${index}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-medium text-foreground">{point.painPoint}</p>
                    <span className={`priority-badge priority-${point.severity.toLowerCase()}`}>
                      {point.severity}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{point.businessOpportunity}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Signals & Angles */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-2">Buying Signals</p>
              <ul className="space-y-1">
                {results.buyingSignals?.slice(0, 3).map((signal, i) => (
                  <li key={i} className="text-xs text-foreground flex items-start gap-1.5">
                    <span className="w-1 h-1 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                    {signal}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide mb-2">Recommended Angles</p>
              <ul className="space-y-1">
                {results.recommendedAngles?.slice(0, 3).map((angle, i) => (
                  <li key={i} className="text-xs text-foreground flex items-start gap-1.5">
                    <span className="w-1 h-1 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                    {angle}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="outreach" className="space-y-5">
          {/* Email Sequence */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Email Sequence</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => copyToClipboard(results.emailSequence, "Emails")}
                data-testid="button-copy-emails"
              >
                {copiedField === "Emails" ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                Copy
              </Button>
            </div>
            <pre className="bg-accent/50 rounded-md p-3 text-xs text-foreground whitespace-pre-wrap max-h-60 overflow-auto" data-testid="text-email-sequence">
              {results.emailSequence}
            </pre>
          </div>

          {/* Call Script */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Call Script</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => copyToClipboard(results.callScript, "Script")}
                data-testid="button-copy-script"
              >
                {copiedField === "Script" ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                Copy
              </Button>
            </div>
            <pre className="bg-accent/50 rounded-md p-3 text-xs text-foreground whitespace-pre-wrap max-h-60 overflow-auto" data-testid="text-call-script">
              {results.callScript}
            </pre>
          </div>

          {/* Objection Handlers */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Objection Handlers</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => copyToClipboard(results.objectionHandlers, "Handlers")}
                data-testid="button-copy-handlers"
              >
                {copiedField === "Handlers" ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                Copy
              </Button>
            </div>
            <pre className="bg-accent/50 rounded-md p-3 text-xs text-foreground whitespace-pre-wrap max-h-60 overflow-auto" data-testid="text-objection-handlers">
              {results.objectionHandlers}
            </pre>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
