import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface ProductInfo {
  name: string;
  features: string;
  industries: string;
  icp: string;
}

export function SettingsForm() {
  const { toast } = useToast();
  const [productInfo, setProductInfo] = useState<ProductInfo>({
    name: "",
    features: "",
    industries: "",
    icp: "",
  });

  useEffect(() => {
    const stored = localStorage.getItem("productInfo");
    if (stored) {
      setProductInfo(JSON.parse(stored));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem("productInfo", JSON.stringify(productInfo));
    toast({
      title: "Settings saved",
      description: "Your product information has been saved.",
    });
  };

  const handleClear = () => {
    setProductInfo({ name: "", features: "", industries: "", icp: "" });
    localStorage.removeItem("productInfo");
    toast({
      title: "Settings cleared",
      description: "Your product information has been removed.",
    });
  };

  return (
    <div className="space-y-6 py-4">
      <p className="text-sm text-muted-foreground">
        This information helps AI SDR match prospect pain points to your business opportunities. 
        Leave blank for generic analysis.
      </p>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="product-name">Product/Service Name</Label>
          <Input
            id="product-name"
            placeholder="e.g., Cloud Cost Optimization Platform"
            value={productInfo.name}
            onChange={(e) => setProductInfo({ ...productInfo, name: e.target.value })}
            data-testid="input-product-name"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="features">Key Features/Benefits</Label>
          <Textarea
            id="features"
            placeholder="e.g., Autonomous FinOps, policy-gated controls, 40% cost reduction"
            value={productInfo.features}
            onChange={(e) => setProductInfo({ ...productInfo, features: e.target.value })}
            rows={3}
            data-testid="input-features"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="industries">Target Industries</Label>
          <Input
            id="industries"
            placeholder="e.g., SaaS, FinTech, E-commerce"
            value={productInfo.industries}
            onChange={(e) => setProductInfo({ ...productInfo, industries: e.target.value })}
            data-testid="input-industries"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="icp">Ideal Customer Profile</Label>
          <Input
            id="icp"
            placeholder="e.g., Series B-C companies with $500K+ cloud spend"
            value={productInfo.icp}
            onChange={(e) => setProductInfo({ ...productInfo, icp: e.target.value })}
            data-testid="input-icp"
          />
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button onClick={handleSave} className="btn-gradient flex-1" data-testid="button-save-settings">
          Save
        </Button>
        <Button variant="outline" onClick={handleClear} data-testid="button-clear-settings">
          Clear
        </Button>
      </div>
    </div>
  );
}
