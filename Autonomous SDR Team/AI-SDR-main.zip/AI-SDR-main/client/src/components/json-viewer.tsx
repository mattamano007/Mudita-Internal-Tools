import { useState } from "react";
import { Check, ChevronDown, ChevronRight, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface JsonViewerProps {
  data: unknown;
  className?: string;
  maxHeight?: string;
}

export function JsonViewer({ data, className, maxHeight = "400px" }: JsonViewerProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={cn("relative rounded-lg bg-black/30 border border-border", className)}>
      <div className="absolute right-2 top-2 z-10">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleCopy}
          className="h-7 w-7"
          data-testid="button-copy-json"
        >
          {copied ? (
            <Check className="h-3.5 w-3.5 text-emerald-400" />
          ) : (
            <Copy className="h-3.5 w-3.5" />
          )}
        </Button>
      </div>
      <ScrollArea style={{ maxHeight }}>
        <pre className="p-4 text-sm font-mono overflow-x-auto">
          <JsonNode data={data} />
        </pre>
      </ScrollArea>
    </div>
  );
}

interface JsonNodeProps {
  data: unknown;
  depth?: number;
}

function JsonNode({ data, depth = 0 }: JsonNodeProps) {
  const [collapsed, setCollapsed] = useState(depth > 2);
  const indent = "  ".repeat(depth);

  if (data === null) {
    return <span className="text-orange-400">null</span>;
  }

  if (typeof data === "boolean") {
    return <span className="text-purple-400">{data.toString()}</span>;
  }

  if (typeof data === "number") {
    return <span className="text-cyan-400">{data}</span>;
  }

  if (typeof data === "string") {
    return <span className="text-emerald-400">"{data}"</span>;
  }

  if (Array.isArray(data)) {
    if (data.length === 0) {
      return <span className="text-muted-foreground">[]</span>;
    }

    if (collapsed) {
      return (
        <span
          className="cursor-pointer hover:text-foreground text-muted-foreground"
          onClick={() => setCollapsed(false)}
        >
          <ChevronRight className="inline h-3 w-3 mr-1" />
          [{data.length} items]
        </span>
      );
    }

    return (
      <span>
        <span
          className="cursor-pointer hover:text-foreground text-muted-foreground"
          onClick={() => setCollapsed(true)}
        >
          <ChevronDown className="inline h-3 w-3 mr-1" />
        </span>
        {"[\n"}
        {data.map((item, index) => (
          <span key={index}>
            {indent}  <JsonNode data={item} depth={depth + 1} />
            {index < data.length - 1 && ","}
            {"\n"}
          </span>
        ))}
        {indent}]
      </span>
    );
  }

  if (typeof data === "object") {
    const entries = Object.entries(data);
    if (entries.length === 0) {
      return <span className="text-muted-foreground">{"{}"}</span>;
    }

    if (collapsed) {
      return (
        <span
          className="cursor-pointer hover:text-foreground text-muted-foreground"
          onClick={() => setCollapsed(false)}
        >
          <ChevronRight className="inline h-3 w-3 mr-1" />
          {"{"}...{"}"}
        </span>
      );
    }

    return (
      <span>
        <span
          className="cursor-pointer hover:text-foreground text-muted-foreground"
          onClick={() => setCollapsed(true)}
        >
          <ChevronDown className="inline h-3 w-3 mr-1" />
        </span>
        {"{\n"}
        {entries.map(([key, value], index) => (
          <span key={key}>
            {indent}  <span className="text-blue-400">"{key}"</span>
            <span className="text-muted-foreground">: </span>
            <JsonNode data={value} depth={depth + 1} />
            {index < entries.length - 1 && ","}
            {"\n"}
          </span>
        ))}
        {indent}{"}"}
      </span>
    );
  }

  return <span className="text-muted-foreground">{String(data)}</span>;
}
