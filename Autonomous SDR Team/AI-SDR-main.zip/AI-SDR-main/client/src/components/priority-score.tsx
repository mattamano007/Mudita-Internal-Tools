import { cn } from "@/lib/utils";

interface PriorityScoreProps {
  score: number;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
}

function getScoreConfig(score: number) {
  if (score >= 80) {
    return {
      tier: "High",
      color: "text-emerald-400",
      bgColor: "bg-emerald-500/10",
      borderColor: "border-emerald-500/30",
      ringColor: "ring-emerald-500/50",
    };
  }
  if (score >= 60) {
    return {
      tier: "Medium",
      color: "text-purple-400",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/30",
      ringColor: "ring-purple-500/50",
    };
  }
  if (score >= 40) {
    return {
      tier: "Low",
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/10",
      borderColor: "border-yellow-500/30",
      ringColor: "ring-yellow-500/50",
    };
  }
  return {
    tier: "Very Low",
    color: "text-red-400",
    bgColor: "bg-red-500/10",
    borderColor: "border-red-500/30",
    ringColor: "ring-red-500/50",
  };
}

const sizeConfig = {
  sm: {
    container: "h-8 w-8",
    text: "text-xs font-semibold",
  },
  md: {
    container: "h-12 w-12",
    text: "text-base font-bold",
  },
  lg: {
    container: "h-16 w-16",
    text: "text-xl font-bold",
  },
};

export function PriorityScore({ score, size = "md", showLabel = false }: PriorityScoreProps) {
  const config = getScoreConfig(score);
  const sizeStyles = sizeConfig[size];

  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className={cn(
          "flex items-center justify-center rounded-full border-2",
          sizeStyles.container,
          config.bgColor,
          config.borderColor
        )}
      >
        <span className={cn(sizeStyles.text, config.color)}>{score}</span>
      </div>
      {showLabel && (
        <span className={cn("text-xs font-medium", config.color)}>{config.tier}</span>
      )}
    </div>
  );
}

export function PriorityScoreBadge({ score }: { score: number }) {
  const config = getScoreConfig(score);

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1",
        config.bgColor,
        config.borderColor
      )}
    >
      <span className={cn("text-sm font-bold", config.color)}>{score}</span>
      <span className={cn("text-xs font-medium", config.color)}>{config.tier}</span>
    </div>
  );
}
