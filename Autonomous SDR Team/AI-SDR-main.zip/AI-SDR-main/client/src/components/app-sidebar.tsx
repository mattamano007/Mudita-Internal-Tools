import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Home, Search, Clock } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";

interface ResearchHistoryItem {
  id: string;
  companyName: string;
  date: string;
  url: string;
}

const navItems = [
  { title: "Home", url: "/", icon: Home },
  { title: "New Research", url: "/research", icon: Search },
];

export function AppSidebar() {
  const [location] = useLocation();
  const [history, setHistory] = useState<ResearchHistoryItem[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("researchHistory");
    if (stored) {
      setHistory(JSON.parse(stored));
    }
  }, []);

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-primary flex items-center justify-center">
            <Search className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <span className="font-semibold text-sm">AI SDR</span>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={`link-${item.title.toLowerCase().replace(' ', '-')}`}
                  >
                    <Link href={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {history.length > 0 && (
          <SidebarGroup>
            <div className="px-3 py-2 text-xs font-medium text-muted-foreground flex items-center gap-1.5">
              <Clock className="w-3 h-3" />
              Recent
            </div>
            <SidebarGroupContent>
              <SidebarMenu>
                {history.slice(0, 5).map((item) => (
                  <SidebarMenuItem key={item.id}>
                    <SidebarMenuButton
                      className="text-xs"
                      data-testid={`history-${item.id}`}
                    >
                      <span className="truncate">{item.companyName}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-3 border-t border-sidebar-border">
        <div className="text-[11px] text-muted-foreground flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
          Powered by Claude
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
