import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { ExternalLink, Eye, RotateCcw, Trash2, Users } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { AgentStatusBadge } from "@/components/agent-status-badge";
import { PriorityScoreBadge } from "@/components/priority-score";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Prospect, AgentStatus } from "@shared/schema";

interface ProspectsTableProps {
  prospects: Prospect[];
  isLoading: boolean;
}

export function ProspectsTable({ prospects, isLoading }: ProspectsTableProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/prospects/${id}`);
    },
    onSuccess: () => {
      toast({ title: "Prospect deleted" });
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete prospect", variant: "destructive" });
    },
  });

  const rerunMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/prospects/${id}/rerun`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Pipeline restarted" });
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to restart pipeline", variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="font-display">Recent Prospects</CardTitle>
          <CardDescription>Loading prospect data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (prospects.length === 0) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="font-display">Recent Prospects</CardTitle>
          <CardDescription>No prospects yet</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 border border-primary/30 mb-4 glow-border">
              <Users className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold font-display mb-2">No prospects added yet</h3>
            <p className="text-sm text-muted-foreground max-w-sm">
              Add a company URL above to start researching prospects with our AI agents.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20 border border-primary/30">
            <Users className="h-5 w-5 text-primary" />
          </div>
          <div>
            <CardTitle className="font-display">Recent Prospects</CardTitle>
            <CardDescription>
              {prospects.length} prospect{prospects.length !== 1 ? "s" : ""} in your pipeline
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="custom-scrollbar overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="font-display">Company</TableHead>
                <TableHead className="font-display">Score</TableHead>
                <TableHead className="font-display">Agent Status</TableHead>
                <TableHead className="font-display">Added</TableHead>
                <TableHead className="text-right font-display">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {prospects.map((prospect) => (
                <TableRow key={prospect.id} className="hover-elevate" data-testid={`row-prospect-${prospect.id}`}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium text-foreground">
                        {prospect.companyName || "Unknown Company"}
                      </span>
                      <span className="text-xs text-muted-foreground font-mono truncate max-w-[200px]">
                        {prospect.url}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    {prospect.priorityScore !== null ? (
                      <PriorityScoreBadge score={prospect.priorityScore} />
                    ) : (
                      <span className="text-sm text-muted-foreground">Pending</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1.5">
                      <AgentStatusBadge 
                        agentName="scout" 
                        status={prospect.agent1Status as AgentStatus} 
                      />
                      <AgentStatusBadge 
                        agentName="strategist" 
                        status={prospect.agent2Status as AgentStatus} 
                      />
                      <AgentStatusBadge 
                        agentName="wordsmith" 
                        status={prospect.agent3Status as AgentStatus} 
                      />
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-muted-foreground">
                      {formatDistanceToNow(new Date(prospect.createdAt), { addSuffix: true })}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-1">
                      <Link href={`/prospects/${prospect.id}`}>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          data-testid={`button-view-prospect-${prospect.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => rerunMutation.mutate(prospect.id)}
                        disabled={rerunMutation.isPending}
                        data-testid={`button-rerun-prospect-${prospect.id}`}
                      >
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteMutation.mutate(prospect.id)}
                        disabled={deleteMutation.isPending}
                        data-testid={`button-delete-prospect-${prospect.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
