import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Globe, Loader2, Plus, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const prospectFormSchema = z.object({
  url: z.string().url("Please enter a valid URL").min(1, "URL is required"),
});

type ProspectFormValues = z.infer<typeof prospectFormSchema>;

export function ProspectInputForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ProspectFormValues>({
    resolver: zodResolver(prospectFormSchema),
    defaultValues: {
      url: "",
    },
  });

  const addProspectMutation = useMutation({
    mutationFn: async (values: ProspectFormValues) => {
      const response = await apiRequest("POST", "/api/prospects", values);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Prospect added",
        description: `Starting research on ${data.companyName || data.url}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add prospect",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: ProspectFormValues) => {
    addProspectMutation.mutate(values);
  };

  return (
    <Card className="glass-card border-primary/20 hover-glow">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20 border border-primary/30 animate-pulse-glow">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div>
            <CardTitle className="text-lg font-display">Add New Prospect</CardTitle>
            <CardDescription>
              Enter a company URL to start the AI research pipeline
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex gap-3">
            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="https://example.com"
                        className="pl-10 font-mono text-sm bg-background/50"
                        data-testid="input-prospect-url"
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button
              type="submit"
              disabled={addProspectMutation.isPending}
              className="glow-border"
              data-testid="button-add-prospect"
            >
              {addProspectMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
              <span className="ml-2">Research</span>
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
