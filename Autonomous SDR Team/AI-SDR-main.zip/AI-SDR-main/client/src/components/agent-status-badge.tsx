import { Badge } from "@/components/ui/badge";
import { Search, Brain, FileText, Loader2, CheckCircle2, AlertCircle, Circle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AgentStatus } from "@shared/schema";

interface AgentStatusBadgeProps {
  agentName: "scout" | "strategist" | "wordsmith";
  status: AgentStatus;
  className?: string;
}

const agentConfig = {
  scout: {
    label: "Scout",
    icon: Search,
    accentColor: "text-cyan-400",
    bgColor: "bg-cyan-500/10",
    borderColor: "border-cyan-500/30",
    glowClass: "glow-border-cyan",
    pulseGlow: "animate-pulse-glow-cyan",
  },
  strategist: {
    label: "Strategist",
    icon: Brain,
    accentColor: "text-purple-400",
    bgColor: "bg-purple-500/10",
    borderColor: "border-purple-500/30",
    glowClass: "glow-border",
    pulseGlow: "animate-pulse-glow",
  },
  wordsmith: {
    label: "Wordsmith",
    icon: FileText,
    accentColor: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
    borderColor: "border-emerald-500/30",
    glowClass: "",
    pulseGlow: "",
  },
};

const statusConfig: Record<AgentStatus, {
  label: string;
  icon: typeof Circle;
  color: string;
  bgColor: string;
  animate?: boolean;
}> = {
  idle: {
    label: "Idle",
    icon: Circle,
    color: "text-muted-foreground",
    bgColor: "bg-muted/50",
  },
  working: {
    label: "Working",
    icon: Loader2,
    color: "text-purple-400",
    bgColor: "bg-purple-500/10",
    animate: true,
  },
  complete: {
    label: "Complete",
    icon: CheckCircle2,
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
  },
  error: {
    label: "Error",
    icon: AlertCircle,
    color: "text-red-400",
    bgColor: "bg-red-500/10",
  },
};

export function AgentStatusBadge({ agentName, status, className }: AgentStatusBadgeProps) {
  const agent = agentConfig[agentName];
  const statusInfo = statusConfig[status];
  const AgentIcon = agent.icon;
  const StatusIcon = statusInfo.icon;

  return (
    <Badge
      variant="outline"
      className={cn(
        "inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium",
        agent.bgColor,
        agent.borderColor,
        status === "working" && "animate-pulse",
        className
      )}
    >
      <AgentIcon className={cn("h-3.5 w-3.5", agent.accentColor)} />
      <span className="text-foreground">{agent.label}</span>
      <span className="mx-1 text-muted-foreground">|</span>
      <StatusIcon
        className={cn(
          "h-3.5 w-3.5",
          statusInfo.color,
          statusInfo.animate && "animate-spin"
        )}
      />
      <span className={statusInfo.color}>{statusInfo.label}</span>
    </Badge>
  );
}

export function AgentStatusCard({ 
  agentName, 
  status, 
  description 
}: { 
  agentName: "scout" | "strategist" | "wordsmith"; 
  status: AgentStatus;
  description?: string;
}) {
  const agent = agentConfig[agentName];
  const statusInfo = statusConfig[status];
  const AgentIcon = agent.icon;
  const StatusIcon = statusInfo.icon;

  return (
    <div
      className={cn(
        "relative overflow-visible rounded-lg border p-4 glass-card hover-lift transition-all duration-300",
        agent.bgColor,
        agent.borderColor,
        status === "working" && agent.pulseGlow
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={cn(
            "flex h-10 w-10 items-center justify-center rounded-lg",
            agent.bgColor,
            "border",
            agent.borderColor,
            status === "working" && "animate-pulse"
          )}>
            <AgentIcon className={cn("h-5 w-5", agent.accentColor)} />
          </div>
          <div>
            <h3 className="font-semibold font-display text-foreground">{agent.label}</h3>
            {description && (
              <p className="text-sm text-muted-foreground">{description}</p>
            )}
          </div>
        </div>
        <div className={cn(
          "flex items-center gap-1.5 rounded-full px-2.5 py-1",
          statusInfo.bgColor
        )}>
          <StatusIcon
            className={cn(
              "h-3.5 w-3.5",
              statusInfo.color,
              statusInfo.animate && "animate-spin"
            )}
          />
          <span className={cn("text-xs font-medium", statusInfo.color)}>
            {statusInfo.label}
          </span>
        </div>
      </div>
    </div>
  );
}
