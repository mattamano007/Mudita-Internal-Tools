import { Switch, Route, Redirect, Router } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider } from "@/components/ui/sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { AppSidebar } from "@/components/app-sidebar";
import { AppHeader } from "@/components/app-header";
import Dashboard from "@/pages/dashboard";
import Research from "@/pages/research";
import ProspectDetail from "@/pages/prospect-detail";
import SignIn from "@/pages/sign-in";
import NotFound from "@/pages/not-found";

function isAuthenticated(): boolean {
  return localStorage.getItem("muditaAuth") === "authenticated";
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  if (!isAuthenticated()) {
    return <Redirect to="/signin" />;
  }
  return <Component />;
}

function AuthCheck({ children }: { children: React.ReactNode }) {
  if (!isAuthenticated()) {
    return <Redirect to="/signin" />;
  }
  return <>{children}</>;
}

function AppLayout({ children }: { children: React.ReactNode }) {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full bg-background">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <AppHeader />
          <main className="flex-1 overflow-hidden">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Router>
            <Switch>
              <Route path="/signin" component={SignIn} />
              <Route path="/">
                <AuthCheck>
                  <AppLayout>
                    <Dashboard />
                  </AppLayout>
                </AuthCheck>
              </Route>
              <Route path="/research">
                <AuthCheck>
                  <AppLayout>
                    <Research />
                  </AppLayout>
                </AuthCheck>
              </Route>
              <Route path="/prospects/:id">
                <AuthCheck>
                  <AppLayout>
                    <ProspectDetail />
                  </AppLayout>
                </AuthCheck>
              </Route>
              <Route component={NotFound} />
            </Switch>
          </Router>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
