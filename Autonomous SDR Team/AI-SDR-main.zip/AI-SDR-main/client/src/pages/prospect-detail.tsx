import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { 
  ArrowLeft, 
  Search, 
  Brain, 
  FileText, 
  Globe, 
  Building2, 
  Users, 
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Target,
  Lightbulb,
  Mail,
  Phone,
  MessageSquare,
  Linkedin,
  Copy,
  Check,
  ChevronDown,
  ChevronRight
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { AgentStatusBadge } from "@/components/agent-status-badge";
import { PriorityScore } from "@/components/priority-score";
import { AgentLogs } from "@/components/agent-logs";
import { JsonViewer } from "@/components/json-viewer";
import { cn } from "@/lib/utils";
import type { Prospect, AgentLog, ResearchData, AnalysisData, CopyData, AgentStatus } from "@shared/schema";

interface ProspectDetailData extends Prospect {
  logs: AgentLog[];
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Button variant="ghost" size="icon" onClick={handleCopy} className="h-7 w-7">
      {copied ? (
        <Check className="h-3.5 w-3.5 text-emerald-400" />
      ) : (
        <Copy className="h-3.5 w-3.5" />
      )}
    </Button>
  );
}

function ResearchColumn({ data }: { data: ResearchData | null }) {
  if (!data) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Search className="h-12 w-12 text-muted-foreground/50 mb-4" />
        <h3 className="text-lg font-medium mb-2">Research Pending</h3>
        <p className="text-sm text-muted-foreground">
          Agent 1 (Scout) is analyzing the website...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Building2 className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Company Overview
          </h3>
        </div>
        <Card>
          <CardContent className="pt-4">
            <h4 className="font-semibold text-lg mb-2">{data.company_name}</h4>
            <p className="text-sm text-muted-foreground mb-4">{data.company_info.description}</p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Team Size:</span>
                <span className="ml-2 font-medium">{data.company_info.team_size}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Location:</span>
                <span className="ml-2 font-medium">{data.company_info.location}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Funding:</span>
                <span className="ml-2 font-medium">{data.company_info.funding_stage}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Confidence:</span>
                <span className="ml-2 font-medium">{data.confidence_score}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Globe className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Tech Stack
          </h3>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {data.tech_stack.frontend.map((tech) => (
            <Badge key={tech} variant="secondary" className="bg-cyan-500/10 text-cyan-400 border-cyan-500/30">
              {tech}
            </Badge>
          ))}
          {data.tech_stack.backend.map((tech) => (
            <Badge key={tech} variant="secondary" className="bg-purple-500/10 text-purple-400 border-purple-500/30">
              {tech}
            </Badge>
          ))}
          {data.tech_stack.tools.map((tech) => (
            <Badge key={tech} variant="secondary" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
              {tech}
            </Badge>
          ))}
          {data.tech_stack.infrastructure.map((tech) => (
            <Badge key={tech} variant="secondary" className="bg-yellow-500/10 text-yellow-400 border-yellow-500/30">
              {tech}
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Pricing
          </h3>
        </div>
        <Card>
          <CardContent className="pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Model:</span>
              <span className="text-sm font-medium">{data.pricing.model}</span>
            </div>
            {data.pricing.starting_price && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Starting Price:</span>
                <span className="text-sm font-medium">${data.pricing.starting_price}/mo</span>
              </div>
            )}
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Free Trial:</span>
              <span className={cn("text-sm font-medium", data.pricing.free_trial ? "text-emerald-400" : "text-muted-foreground")}>
                {data.pricing.free_trial ? "Yes" : "No"}
              </span>
            </div>
            <div className="pt-2 border-t border-border">
              <span className="text-xs text-muted-foreground block mb-2">Tiers:</span>
              <div className="flex flex-wrap gap-1.5">
                {data.pricing.tiers.map((tier, i) => (
                  <Badge key={i} variant="outline" className="text-xs">
                    {tier}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Customers ({data.customers.count})
          </h3>
        </div>
        <div className="flex flex-wrap gap-1.5 mb-3">
          {data.customers.notable_brands.map((brand) => (
            <Badge key={brand} variant="secondary">
              {brand}
            </Badge>
          ))}
        </div>
        {data.customers.case_studies.length > 0 && (
          <div className="space-y-2">
            {data.customers.case_studies.map((study, i) => (
              <Card key={i}>
                <CardContent className="pt-4">
                  <p className="text-sm font-medium">{study.company}</p>
                  <p className="text-sm text-emerald-400">{study.result}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Pain Points
          </h3>
        </div>
        <div className="space-y-2">
          {data.pain_points.map((pain, i) => (
            <Card key={i}>
              <CardContent className="pt-4">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-medium">{pain.pain}</p>
                  <Badge
                    variant="secondary"
                    className={cn(
                      "shrink-0 text-xs",
                      pain.urgency === "high" && "bg-red-500/10 text-red-400 border-red-500/30",
                      pain.urgency === "medium" && "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
                      pain.urgency === "low" && "bg-muted text-muted-foreground"
                    )}
                  >
                    {pain.urgency}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Source: {pain.source}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

function AnalysisColumn({ data }: { data: AnalysisData | null }) {
  if (!data) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Brain className="h-12 w-12 text-muted-foreground/50 mb-4" />
        <h3 className="text-lg font-medium mb-2">Analysis Pending</h3>
        <p className="text-sm text-muted-foreground">
          Waiting for research data from Agent 1...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center py-4">
        <PriorityScore score={data.priority_score} size="lg" showLabel />
        <p className="text-sm text-muted-foreground mt-2">{data.buying_likelihood.reasoning}</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Buying Likelihood</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Tier:</span>
            <span className="font-medium">{data.buying_likelihood.tier}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Timeline:</span>
            <span className="font-medium">{data.buying_likelihood.timeline_estimate}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Deal Size:</span>
            <span className="font-medium text-emerald-400">{data.buying_likelihood.deal_size_estimate}</span>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Target className="h-4 w-4 text-purple-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Offer Angles
          </h3>
        </div>
        <div className="space-y-3">
          {data.offer_angles.map((angle, i) => (
            <Card key={i}>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{angle.angle}</h4>
                  <Badge
                    variant="secondary"
                    className={cn(
                      "text-xs",
                      angle.match_strength >= 80 && "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
                      angle.match_strength >= 60 && angle.match_strength < 80 && "bg-purple-500/10 text-purple-400 border-purple-500/30",
                      angle.match_strength < 60 && "bg-muted text-muted-foreground"
                    )}
                  >
                    {angle.match_strength}% match
                  </Badge>
                </div>
                <p className="text-sm text-emerald-400 mb-2">"{angle.recommended_hook}"</p>
                <p className="text-xs text-muted-foreground mb-2">{angle.supporting_evidence}</p>
                <div className="flex flex-wrap gap-1">
                  {angle.pain_points_addressed.map((pain, j) => (
                    <Badge key={j} variant="outline" className="text-xs">
                      {pain}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-purple-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Decision Makers
          </h3>
        </div>
        <Card>
          <CardContent className="pt-4 space-y-3">
            <div>
              <span className="text-xs text-muted-foreground block mb-1">Likely Roles:</span>
              <div className="flex flex-wrap gap-1.5">
                {data.decision_makers.likely_roles.map((role, i) => (
                  <Badge key={i} variant="secondary">
                    {role}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="text-sm">
              <span className="text-muted-foreground">Org Structure:</span>
              <span className="ml-2 font-medium">{data.decision_makers.org_structure}</span>
            </div>
            <div className="text-sm">
              <span className="text-muted-foreground">Committee Size:</span>
              <span className="ml-2 font-medium">{data.decision_makers.buying_committee_size}</span>
            </div>
            <div className="text-sm">
              <span className="text-muted-foreground">Budget Authority:</span>
              <span className="ml-2 font-medium">{data.decision_makers.budget_authority}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Lightbulb className="h-4 w-4 text-purple-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Recommended Next Steps
          </h3>
        </div>
        <div className="space-y-2">
          {data.recommended_next_steps.map((step, i) => (
            <div key={i} className="flex items-start gap-2">
              <CheckCircle2 className="h-4 w-4 text-purple-400 mt-0.5 shrink-0" />
              <span className="text-sm">{step}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CopyColumn({ data }: { data: CopyData | null }) {
  if (!data) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <FileText className="h-12 w-12 text-muted-foreground/50 mb-4" />
        <h3 className="text-lg font-medium mb-2">Copy Pending</h3>
        <p className="text-sm text-muted-foreground">
          Waiting for analysis data from Agent 2...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="emails">
        <TabsList className="w-full grid grid-cols-4">
          <TabsTrigger value="emails" className="text-xs">
            <Mail className="h-3.5 w-3.5 mr-1.5" />
            Emails
          </TabsTrigger>
          <TabsTrigger value="calls" className="text-xs">
            <Phone className="h-3.5 w-3.5 mr-1.5" />
            Calls
          </TabsTrigger>
          <TabsTrigger value="objections" className="text-xs">
            <MessageSquare className="h-3.5 w-3.5 mr-1.5" />
            Objections
          </TabsTrigger>
          <TabsTrigger value="linkedin" className="text-xs">
            <Linkedin className="h-3.5 w-3.5 mr-1.5" />
            LinkedIn
          </TabsTrigger>
        </TabsList>

        <TabsContent value="emails" className="mt-4 space-y-4">
          {data.email_sequences.map((sequence, i) => (
            <div key={i}>
              <h4 className="font-medium mb-3">{sequence.sequence_name}</h4>
              <Accordion type="single" collapsible className="space-y-2">
                {sequence.emails.map((email) => (
                  <AccordionItem key={email.email_number} value={`email-${email.email_number}`} className="border rounded-lg">
                    <AccordionTrigger className="px-4 py-3 hover:no-underline">
                      <div className="flex items-center gap-3 text-left">
                        <Badge variant="secondary" className="shrink-0 text-xs">
                          {email.send_delay}
                        </Badge>
                        <span className="text-sm font-medium">{email.subject}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-muted-foreground">Preview: {email.preview_text}</span>
                        <CopyButton text={email.body} />
                      </div>
                      <div className="bg-muted/50 rounded-lg p-4 text-sm whitespace-pre-wrap font-mono">
                        {email.body}
                      </div>
                      <div className="mt-3 flex items-center justify-between">
                        <Badge variant="outline" className="text-xs">
                          CTA: {email.cta}
                        </Badge>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="calls" className="mt-4 space-y-4">
          {data.call_scripts.map((script, i) => (
            <Card key={i}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">{script.script_name}</CardTitle>
                  <CopyButton text={`${script.opening}\n\n${script.value_prop}\n\n${script.closing}`} />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h5 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                    Opening (15 sec)
                  </h5>
                  <p className="text-sm bg-muted/50 rounded-lg p-3">{script.opening}</p>
                </div>
                <div>
                  <h5 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                    Discovery Questions
                  </h5>
                  <ul className="space-y-1.5">
                    {script.discovery_questions.map((q, j) => (
                      <li key={j} className="text-sm flex items-start gap-2">
                        <span className="text-muted-foreground">{j + 1}.</span>
                        {q}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h5 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                    Value Proposition
                  </h5>
                  <p className="text-sm bg-emerald-500/10 text-emerald-400 rounded-lg p-3 border border-emerald-500/30">
                    {script.value_prop}
                  </p>
                </div>
                <div>
                  <h5 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                    Closing
                  </h5>
                  <p className="text-sm bg-muted/50 rounded-lg p-3">{script.closing}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="objections" className="mt-4">
          <Accordion type="single" collapsible className="space-y-2">
            {data.objection_handlers.map((handler, i) => (
              <AccordionItem key={i} value={`objection-${i}`} className="border rounded-lg">
                <AccordionTrigger className="px-4 py-3 hover:no-underline">
                  <div className="flex items-center gap-2 text-left">
                    <AlertTriangle className="h-4 w-4 text-yellow-400 shrink-0" />
                    <span className="text-sm font-medium">"{handler.objection}"</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <div className="flex items-center justify-end mb-2">
                    <CopyButton text={handler.response} />
                  </div>
                  <div className="bg-muted/50 rounded-lg p-4 text-sm mb-3">
                    {handler.response}
                  </div>
                  <div>
                    <span className="text-xs text-muted-foreground block mb-1.5">Proof Points:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {handler.proof_points.map((point, j) => (
                        <Badge key={j} variant="outline" className="text-xs">
                          {point}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </TabsContent>

        <TabsContent value="linkedin" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">Connection Request</CardTitle>
                <CopyButton text={data.linkedin_outreach.connection_request} />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm bg-muted/50 rounded-lg p-3">
                {data.linkedin_outreach.connection_request}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">Follow-up Message</CardTitle>
                <CopyButton text={data.linkedin_outreach.follow_up_message} />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm bg-muted/50 rounded-lg p-3">
                {data.linkedin_outreach.follow_up_message}
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function ProspectDetail() {
  const [, params] = useRoute("/prospects/:id");
  const id = params?.id;

  const { data: prospect, isLoading } = useQuery<ProspectDetailData>({
    queryKey: ["/api/prospects", id],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="flex-1 overflow-auto custom-scrollbar">
        <div className="max-w-screen-2xl mx-auto px-8 py-8">
          <Skeleton className="h-10 w-48 mb-8" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Skeleton className="h-[600px]" />
            <Skeleton className="h-[600px]" />
            <Skeleton className="h-[600px]" />
          </div>
        </div>
      </div>
    );
  }

  if (!prospect) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold font-display mb-2">Prospect not found</h2>
          <Link href="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const researchData = prospect.researchData as ResearchData | null;
  const analysisData = prospect.analysisData as AnalysisData | null;
  const copyData = prospect.copyData as CopyData | null;

  return (
    <div className="flex-1 overflow-auto custom-scrollbar">
      <div className="max-w-screen-2xl mx-auto px-8 py-8">
        <div className="flex items-center justify-between mb-8 animate-fade-in">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold font-display text-gradient" data-testid="text-company-name">
                {prospect.companyName || "Unknown Company"}
              </h1>
              <p className="text-sm text-muted-foreground font-mono">{prospect.url}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <AgentStatusBadge agentName="scout" status={prospect.agent1Status as AgentStatus} />
            <AgentStatusBadge agentName="strategist" status={prospect.agent2Status as AgentStatus} />
            <AgentStatusBadge agentName="wordsmith" status={prospect.agent3Status as AgentStatus} />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8 animate-slide-up stagger-1">
          <Card className="glass-card border-cyan-500/30 hover-lift">
            <CardHeader className="border-b border-border sticky top-0 bg-card/80 backdrop-blur-md z-10">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 glow-border-cyan">
                  <Search className="h-4 w-4 text-cyan-400" />
                </div>
                <div>
                  <CardTitle className="text-sm font-display">Research</CardTitle>
                  <CardDescription className="text-xs">Agent 1: Scout</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <ScrollArea className="h-[600px] pr-4 custom-scrollbar">
                <ResearchColumn data={researchData} />
              </ScrollArea>
            </CardContent>
          </Card>

          <Card className="glass-card border-purple-500/30 hover-lift">
            <CardHeader className="border-b border-border sticky top-0 bg-card/80 backdrop-blur-md z-10">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-500/10 border border-purple-500/30 glow-border">
                  <Brain className="h-4 w-4 text-purple-400" />
                </div>
                <div>
                  <CardTitle className="text-sm font-display">Analysis</CardTitle>
                  <CardDescription className="text-xs">Agent 2: Strategist</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <ScrollArea className="h-[600px] pr-4 custom-scrollbar">
                <AnalysisColumn data={analysisData} />
              </ScrollArea>
            </CardContent>
          </Card>

          <Card className="glass-card border-emerald-500/30 hover-lift">
            <CardHeader className="border-b border-border sticky top-0 bg-card/80 backdrop-blur-md z-10">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                  <FileText className="h-4 w-4 text-emerald-400" />
                </div>
                <div>
                  <CardTitle className="text-sm font-display">Outreach</CardTitle>
                  <CardDescription className="text-xs">Agent 3: Wordsmith</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <ScrollArea className="h-[600px] pr-4 custom-scrollbar">
                <CopyColumn data={copyData} />
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        <div className="animate-slide-up stagger-2">
          <AgentLogs logs={prospect.logs || []} />
        </div>
      </div>
    </div>
  );
}
