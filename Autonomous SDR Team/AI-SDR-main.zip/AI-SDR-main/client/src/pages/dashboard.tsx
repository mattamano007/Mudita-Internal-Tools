import { Link } from "wouter";
import { ArrowRight, Search, Brain, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";

const steps = [
  { icon: Search, title: "Scout", desc: "Crawls website, extracts data" },
  { icon: Brain, title: "Strategist", desc: "Identifies pain points" },
  { icon: FileText, title: "Wordsmith", desc: "Generates outreach" },
];

export default function Dashboard() {
  return (
    <div className="flex-1 overflow-auto custom-scrollbar">
      <div className="max-w-xl mx-auto px-6 py-16">
        <div className="text-center mb-10">
          <h1 className="text-xl font-semibold text-foreground mb-2" data-testid="text-page-title">
            Sales Intelligence
          </h1>
          <p className="text-muted-foreground text-sm max-w-sm mx-auto">
            Research companies and generate personalized outreach
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <Link href="/research">
            <Button size="lg" data-testid="button-start-research">
              New Research
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        <div className="border-t border-border pt-10">
          <p className="text-xs text-muted-foreground text-center mb-6">How it works</p>
          
          <div className="flex items-center justify-center gap-3">
            {steps.map((step, i) => (
              <div key={step.title} className="flex items-center gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center mb-2">
                    <step.icon className="w-4 h-4 text-foreground" />
                  </div>
                  <span className="text-xs font-medium">{step.title}</span>
                  <span className="text-[10px] text-muted-foreground">{step.desc}</span>
                </div>
                {i < steps.length - 1 && (
                  <ArrowRight className="w-3 h-3 text-muted-foreground mt-[-20px]" />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 p-4 rounded-lg bg-card border border-border">
          <p className="text-xs text-muted-foreground mb-3">What you get:</p>
          <div className="grid grid-cols-2 gap-2 text-xs text-foreground">
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-primary" />
              Pain point analysis
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-primary" />
              3-email sequence
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-primary" />
              Cold call script
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-primary" />
              Objection handlers
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-primary" />
              Buying signals
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-primary" />
              CSV export
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
