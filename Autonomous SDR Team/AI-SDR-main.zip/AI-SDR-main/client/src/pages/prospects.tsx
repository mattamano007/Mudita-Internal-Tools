import { useQuery } from "@tanstack/react-query";
import { ProspectInputForm } from "@/components/prospect-input-form";
import { ProspectsTable } from "@/components/prospects-table";
import type { Prospect } from "@shared/schema";

export default function Prospects() {
  const { data: prospects = [], isLoading } = useQuery<Prospect[]>({
    queryKey: ["/api/prospects"],
  });

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-screen-2xl mx-auto px-8 py-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-page-title">
            All Prospects
          </h1>
          <p className="text-muted-foreground">
            View and manage all prospects in your pipeline
          </p>
        </div>

        <ProspectInputForm />

        <ProspectsTable prospects={prospects} isLoading={isLoading} />
      </div>
    </div>
  );
}
