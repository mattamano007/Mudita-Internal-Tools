import { useState } from "react";
import { Search, Loader2, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ResearchResults } from "@/components/research-results";

interface AgentStatus {
  scout: "idle" | "working" | "complete" | "error";
  strategist: "idle" | "working" | "complete" | "error";
  wordsmith: "idle" | "working" | "complete" | "error";
}

interface ResearchResult {
  companyName: string;
  websiteUrl: string;
  industry: string;
  productOffered: string;
  painPoints: Array<{
    painPoint: string;
    businessOpportunity: string;
    severity: string;
  }>;
  buyingLikelihood: string;
  buyingSignals: string[];
  recommendedAngles: string[];
  decisionMakers: string[];
  emailSequence: string;
  callScript: string;
  objectionHandlers: string;
}

export default function Research() {
  const { toast } = useToast();
  const [url, setUrl] = useState("");
  const [agentStatus, setAgentStatus] = useState<AgentStatus>({
    scout: "idle",
    strategist: "idle",
    wordsmith: "idle",
  });
  const [results, setResults] = useState<ResearchResult | null>(null);

  const researchMutation = useMutation({
    mutationFn: async (companyUrl: string) => {
      setAgentStatus({ scout: "working", strategist: "idle", wordsmith: "idle" });
      
      const response = await apiRequest("POST", "/api/research", { url: companyUrl });
      const reader = response.body?.getReader();
      
      if (!reader) {
        throw new Error("No response body");
      }

      const decoder = new TextDecoder();
      let result = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        result += decoder.decode(value, { stream: true });
        
        if (result.includes('"agent":"scout"') && result.includes('"status":"complete"')) {
          setAgentStatus((prev) => ({ ...prev, scout: "complete", strategist: "working" }));
        }
        if (result.includes('"agent":"strategist"') && result.includes('"status":"complete"')) {
          setAgentStatus((prev) => ({ ...prev, strategist: "complete", wordsmith: "working" }));
        }
        if (result.includes('"agent":"wordsmith"') && result.includes('"status":"complete"')) {
          setAgentStatus((prev) => ({ ...prev, wordsmith: "complete" }));
        }
      }

      const lines = result.trim().split("\n");
      const lastLine = lines[lines.length - 1];
      return JSON.parse(lastLine);
    },
    onSuccess: (data) => {
      setResults(data);
      
      const historyItem = {
        id: Date.now().toString(),
        companyName: data.companyName,
        date: new Date().toLocaleDateString(),
        url: data.websiteUrl,
      };
      
      const existingHistory = JSON.parse(localStorage.getItem("researchHistory") || "[]");
      const updatedHistory = [historyItem, ...existingHistory].slice(0, 10);
      localStorage.setItem("researchHistory", JSON.stringify(updatedHistory));
      
      toast({
        title: "Research complete",
        description: `Analyzed ${data.companyName}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Research failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
      setAgentStatus({ scout: "idle", strategist: "idle", wordsmith: "idle" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url.trim()) {
      toast({
        title: "URL required",
        description: "Enter a company website URL.",
        variant: "destructive",
      });
      return;
    }

    let processedUrl = url;
    if (!url.includes("http")) {
      processedUrl = "https://" + url;
      setUrl(processedUrl);
    }

    setResults(null);
    researchMutation.mutate(processedUrl);
  };

  const isProcessing = researchMutation.isPending;

  const StatusStep = ({ label, status, step }: { label: string; status: string; step: number }) => (
    <div className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-all ${
      status === "complete" ? "text-primary bg-primary/10" : 
      status === "working" ? "bg-primary text-primary-foreground font-medium" : 
      "text-muted-foreground bg-accent/50"
    }`}>
      <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-medium ${
        status === "complete" ? "bg-primary text-primary-foreground" :
        status === "working" ? "bg-primary-foreground text-primary" :
        "bg-muted-foreground/30 text-muted-foreground"
      }`}>
        {status === "complete" ? (
          <Check className="w-3 h-3" />
        ) : (
          step
        )}
      </span>
      {label}
      {status === "working" && <Loader2 className="w-3 h-3 animate-spin ml-auto" />}
    </div>
  );

  return (
    <div className="results-container">
      <div className="max-w-2xl mx-auto px-6 py-8">
        <div className="mb-6">
          <h1 className="text-xl font-semibold text-foreground mb-1" data-testid="text-page-title">
            New Research
          </h1>
          <p className="text-sm text-muted-foreground" data-testid="text-page-subtitle">
            Enter a company website to analyze
          </p>
        </div>

        <div className="panel mb-6" data-testid="card-url-input">
          <form onSubmit={handleSubmit}>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="example.com"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                disabled={isProcessing}
                className="input-field flex-1"
                data-testid="input-company-url"
              />
              <Button
                type="submit"
                disabled={isProcessing || !url.trim()}
                data-testid="button-start-research"
              >
                {isProcessing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Search className="w-4 h-4" />
                )}
              </Button>
            </div>
          </form>
        </div>

        {isProcessing && (
          <div className="panel mb-6 animate-fade-in" data-testid="card-processing">
            <p className="text-xs text-muted-foreground mb-3">
              Analyzing {url.replace(/^https?:\/\//, "").split("/")[0]}
            </p>
            <div className="flex gap-2">
              <StatusStep label="Scout" status={agentStatus.scout} step={1} />
              <StatusStep label="Strategist" status={agentStatus.strategist} step={2} />
              <StatusStep label="Wordsmith" status={agentStatus.wordsmith} step={3} />
            </div>
          </div>
        )}

        {results && <ResearchResults results={results} />}
      </div>
    </div>
  );
}
