# Mudita Studios Design System

A cohesive design system for Mudita Studios applications featuring a Deep Space Blue theme with Electric Violet accents.

## Design Approach

**Selected Approach:** Design System - Linear/Vercel Hybrid
**Core Principles:**
- Workflow-First: Agent pipeline is the hero, not decorative elements
- Information Density: Maximize data visibility without clutter
- Dark Theme Foundation: Deep Space Blue + Electric Violet
- Professional Trust: Enterprise-grade polish and reliability signals

---

## Color Palette

### Primary Colors
- **Electric Violet** (Primary): `hsl(265 85% 65%)` - `#8B5CF6`
- **Cyan** (Secondary for accents): `hsl(190 90% 50%)` - `#06B6D4`
- **Deep Space Blue** (Background): `hsl(230 35% 7%)` - `#0C0F1A`

### Surface Colors
- **Card**: `hsl(230 35% 10%)`
- **Muted**: `hsl(230 25% 18%)`
- **Border**: `hsl(230 25% 18%)`

### Status Colors
- **Success/Beta** (Green): `rgb(34 197 94)`
- **Building** (Blue): `rgb(59 130 246)`
- **Concept** (Purple): `rgb(168 85 247)`

---

## Typography

**Font Stack:**
- **Display/Headings**: Outfit (via Google Fonts CDN)
- **Body/Sans**: DM Sans (via Google Fonts CDN)
- **Monospace**: Menlo (for code, URLs, JSON data)

**Hierarchy:**
- Hero/Dashboard Titles: `text-4xl font-bold font-display` (36px)
- Section Headers: `text-2xl font-semibold font-display` (24px)
- Card Titles: `text-lg font-medium` (18px)
- Body Text: `text-base font-normal` (16px)
- Small/Meta: `text-sm font-normal` (14px)
- Tiny/Labels: `text-xs font-medium` (12px, uppercase tracking)

---

## Layout System

**Spacing Primitives:** Use Tailwind units of **2, 4, 8, 12, 16** exclusively
- Component padding: `p-4` or `p-8`
- Section gaps: `gap-8` or `gap-12`
- Page margins: `px-8` desktop, `px-4` mobile
- Vertical rhythm: `space-y-8` for major sections

**Container Strategy:**
- Dashboard: Full-width with `max-w-screen-2xl mx-auto px-8`
- Prospect Detail: 3-column grid (`grid-cols-3 gap-8`)
- Forms/Inputs: Centered `max-w-2xl` for focused actions

---

## Utility Classes

### Glassmorphism
```html
<!-- Full glass effect with blur and border -->
<div class="glass-card">Content</div>

<!-- Subtle glass panel -->
<div class="glass-panel">Content</div>
```

### Gradient Text
```html
<h1 class="text-gradient">Shaping the Future</h1>
```

### Neon Glow
```html
<span class="neon-glow">Glowing Text</span>
<span class="neon-glow-cyan">Cyan Glow</span>
```

### Status Badges
```html
<span class="status-beta">Beta</span>
<span class="status-building">Building</span>
<span class="status-concept">Concept</span>
```

### Animations
```html
<div class="animate-fade-in">Fades in</div>
<div class="animate-slide-up">Slides up</div>
<div class="animate-scale-in">Scales in</div>
<div class="animate-pulse-glow">Pulsing glow</div>

<!-- Staggered animations -->
<div class="animate-slide-up stagger-1">First</div>
<div class="animate-slide-up stagger-2">Second</div>
<div class="animate-slide-up stagger-3">Third</div>
```

### Hover Effects
```html
<div class="hover-lift">Lifts on hover</div>
<div class="hover-glow">Glows on hover</div>
```

---

## Component Library

### Core UI Elements

**Cards:**
- Dark background with subtle border
- `rounded-lg border p-6`
- Use `glass-card` for glassmorphism effect
- Header + content area pattern throughout

**Agent Status Indicators:**
- Pill-shaped badges with icons
- States: Idle (gray), Working (purple animated pulse), Complete (green), Error (red)
- `inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium`

**Data Tables:**
- Sticky headers for long lists
- Alternating row backgrounds for readability
- Compact spacing: `py-3 px-4`
- Right-aligned numerical data
- Action buttons in rightmost column

**Progress Indicators:**
- Linear progress bars for agent processing
- Pipeline visualization: horizontal stepper showing Agent 1 → 2 → 3 flow
- Percentage completion overlays

### Navigation

**Sidebar:**
- Fixed left sidebar, 256px wide
- Logo at top
- Primary nav items with icons
- Compact spacing: `py-2 px-4` for nav items
- Active state: purple accent + bolder font

### Forms

**Input Fields:**
- Full-width with labels above
- `rounded-md border px-4 py-2`
- Focus state: purple ring
- Error state: red border + message below
- URL input: Monospace font for URLs

**Buttons:**
- Primary: Electric Violet background, white text
- Secondary: Transparent with border
- Use built-in button variants
- Icons positioned left of text

### Data Displays

**Metrics/Stats:**
- Large number + small label format
- Grid layout: `grid-cols-4 gap-4` for stat panels
- Icon + number alignment

**JSON Viewer:**
- Code block styling with syntax highlighting
- Collapsible sections for nested objects
- Copy-to-clipboard button
- `bg-muted rounded-lg p-4 font-mono text-sm`

**Score Badges:**
- Priority scores (0-100): Color-coded circles with number inside
- 80-100: Green, 60-79: Purple, 40-59: Yellow, 0-39: Red
- `w-12 h-12 rounded-full flex items-center justify-center font-bold`

---

## Best Practices

1. **Dark Mode First**: This theme is designed for dark mode. Add `class="dark"` to your `<html>` element.

2. **Glassmorphism**: Use sparingly for key UI elements like cards, modals, and navigation.

3. **Gradient Text**: Reserve for headlines and important callouts.

4. **Animations**: Use subtle, purposeful animations. Avoid excessive motion.

5. **Contrast**: Ensure sufficient contrast for accessibility. Use `--foreground` for primary text and `--muted-foreground` for secondary text.

6. **Elevation System**: Use `hover-elevate` and `active-elevate-2` for interactive elements. Buttons and Badges have built-in hover/active states.

---

## Page-Specific Layouts

**Dashboard:**
- Top: Agent Status Panel (3-column grid showing each agent)
- Middle: Prospect Input form (centered, max-w-2xl)
- Bottom: Recent Results table (full-width)

**Prospect Detail (3-Column):**
- Column 1 (33%): Research Report (Agent 1 output)
- Column 2 (33%): Analysis Report (Agent 2 output)  
- Column 3 (34%): Copy/Outreach Materials (Agent 3 output)
- Each column: Scrollable independently, sticky header with agent icon

**Mobile:** Stack columns vertically, tab-based navigation between agents
