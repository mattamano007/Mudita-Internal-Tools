import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (keeping for compatibility)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Agent Status Types
export type AgentStatus = "idle" | "working" | "complete" | "error";

// Prospects table
export const prospects = pgTable("prospects", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  companyName: text("company_name"),
  status: text("status").notNull().default("pending"),
  priorityScore: integer("priority_score"),
  agent1Status: text("agent1_status").notNull().default("idle"),
  agent1CompletedAt: timestamp("agent1_completed_at"),
  agent2Status: text("agent2_status").notNull().default("idle"),
  agent2CompletedAt: timestamp("agent2_completed_at"),
  agent3Status: text("agent3_status").notNull().default("idle"),
  agent3CompletedAt: timestamp("agent3_completed_at"),
  researchData: jsonb("research_data"),
  analysisData: jsonb("analysis_data"),
  copyData: jsonb("copy_data"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertProspectSchema = createInsertSchema(prospects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProspect = z.infer<typeof insertProspectSchema>;
export type Prospect = typeof prospects.$inferSelect;

// Agent Logs table
export const agentLogs = pgTable("agent_logs", {
  id: serial("id").primaryKey(),
  prospectId: integer("prospect_id").references(() => prospects.id, { onDelete: "cascade" }),
  agentName: text("agent_name").notNull(),
  logType: text("log_type").notNull(),
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertAgentLogSchema = createInsertSchema(agentLogs).omit({
  id: true,
  timestamp: true,
});

export type InsertAgentLog = z.infer<typeof insertAgentLogSchema>;
export type AgentLog = typeof agentLogs.$inferSelect;

// Settings table
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertSettingSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true,
});

export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type Setting = typeof settings.$inferSelect;

// Research Data Structure
export interface ResearchData {
  prospect_url: string;
  company_name: string;
  pages_crawled: number;
  crawl_timestamp: string;
  tech_stack: {
    frontend: string[];
    backend: string[];
    tools: string[];
    infrastructure: string[];
  };
  pricing: {
    model: string;
    tiers: string[];
    free_trial: boolean;
    starting_price: number | null;
    payment_terms: string;
  };
  customers: {
    count: string;
    notable_brands: string[];
    industries: string[];
    case_studies: Array<{
      company: string;
      result: string;
    }>;
  };
  pain_points: Array<{
    pain: string;
    source: string;
    urgency: "high" | "medium" | "low";
  }>;
  company_info: {
    description: string;
    team_size: string;
    funding_stage: string;
    location: string;
  };
  confidence_score: number;
}

// Analysis Data Structure
export interface AnalysisData {
  prospect_url: string;
  company_name: string;
  analysis_timestamp: string;
  priority_score: number;
  priority_tier: "High" | "Medium" | "Low";
  buying_likelihood: {
    score: number;
    tier: string;
    reasoning: string;
    timeline_estimate: string;
    deal_size_estimate: string;
  };
  offer_angles: Array<{
    angle: string;
    match_strength: number;
    pain_points_addressed: string[];
    recommended_hook: string;
    supporting_evidence: string;
  }>;
  decision_makers: {
    likely_roles: string[];
    org_structure: string;
    buying_committee_size: string;
    budget_authority: string;
    decision_patterns: string[];
  };
  competitive_positioning: {
    current_solutions: string[];
    switching_cost: string;
    differentiation_opportunities: string[];
  };
  recommended_next_steps: string[];
}

// Copy Data Structure
export interface CopyData {
  prospect_url: string;
  company_name: string;
  copy_timestamp: string;
  email_sequences: Array<{
    sequence_name: string;
    emails: Array<{
      email_number: number;
      subject: string;
      preview_text: string;
      body: string;
      cta: string;
      send_delay: string;
    }>;
  }>;
  call_scripts: Array<{
    script_name: string;
    opening: string;
    discovery_questions: string[];
    value_prop: string;
    closing: string;
    next_steps: string;
  }>;
  objection_handlers: Array<{
    objection: string;
    response: string;
    proof_points: string[];
  }>;
  linkedin_outreach: {
    connection_request: string;
    follow_up_message: string;
  };
}
