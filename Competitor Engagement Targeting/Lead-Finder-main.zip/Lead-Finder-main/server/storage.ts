import {
  competitors,
  posts,
  leads,
  engagements,
  campaigns,
  outreachHistory,
  competitiveInsights,
  type Competitor,
  type InsertCompetitor,
  type Post,
  type InsertPost,
  type Lead,
  type InsertLead,
  type Engagement,
  type InsertEngagement,
  type Campaign,
  type InsertCampaign,
  type OutreachHistory,
  type InsertOutreachHistory,
  type CompetitiveInsight,
  type InsertCompetitiveInsight,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte } from "drizzle-orm";

export interface IStorage {
  // Competitors
  getCompetitors(): Promise<Competitor[]>;
  getCompetitor(id: string): Promise<Competitor | undefined>;
  createCompetitor(data: InsertCompetitor): Promise<Competitor>;
  updateCompetitor(id: string, data: Partial<InsertCompetitor>): Promise<Competitor | undefined>;
  deleteCompetitor(id: string): Promise<boolean>;

  // Posts
  getPosts(): Promise<Post[]>;
  getPostsByCompetitor(competitorId: string): Promise<Post[]>;
  getPost(id: string): Promise<Post | undefined>;
  createPost(data: InsertPost): Promise<Post>;
  updatePost(id: string, data: Partial<InsertPost>): Promise<Post | undefined>;
  deletePost(id: string): Promise<boolean>;

  // Leads
  getLeads(): Promise<Lead[]>;
  getLead(id: string): Promise<Lead | undefined>;
  createLead(data: InsertLead): Promise<Lead>;
  updateLead(id: string, data: Partial<InsertLead>): Promise<Lead | undefined>;
  deleteLead(id: string): Promise<boolean>;

  // Engagements
  getEngagements(): Promise<Engagement[]>;
  getEngagementsByLead(leadId: string): Promise<Engagement[]>;
  getEngagementsByPost(postId: string): Promise<Engagement[]>;
  createEngagement(data: InsertEngagement): Promise<Engagement>;

  // Campaigns
  getCampaigns(): Promise<Campaign[]>;
  getCampaign(id: string): Promise<Campaign | undefined>;
  createCampaign(data: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: string, data: Partial<InsertCampaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: string): Promise<boolean>;

  // Outreach History
  getOutreachHistory(): Promise<OutreachHistory[]>;
  getOutreachByLead(leadId: string): Promise<OutreachHistory[]>;
  createOutreach(data: InsertOutreachHistory): Promise<OutreachHistory>;
  updateOutreach(id: string, data: Partial<InsertOutreachHistory>): Promise<OutreachHistory | undefined>;

  // Stats
  getStats(): Promise<{
    totalLeads: number;
    activeCampaigns: number;
    avgWarmthScore: number;
    replyRate: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // Competitors
  async getCompetitors(): Promise<Competitor[]> {
    return db.select().from(competitors).orderBy(desc(competitors.createdAt));
  }

  async getCompetitor(id: string): Promise<Competitor | undefined> {
    const [competitor] = await db.select().from(competitors).where(eq(competitors.id, id));
    return competitor || undefined;
  }

  async createCompetitor(data: InsertCompetitor): Promise<Competitor> {
    const [competitor] = await db.insert(competitors).values(data).returning();
    return competitor;
  }

  async updateCompetitor(id: string, data: Partial<InsertCompetitor>): Promise<Competitor | undefined> {
    const [competitor] = await db
      .update(competitors)
      .set(data)
      .where(eq(competitors.id, id))
      .returning();
    return competitor || undefined;
  }

  async deleteCompetitor(id: string): Promise<boolean> {
    const result = await db.delete(competitors).where(eq(competitors.id, id)).returning();
    return result.length > 0;
  }

  // Posts
  async getPosts(): Promise<Post[]> {
    return db.select().from(posts).orderBy(desc(posts.createdAt));
  }

  async getPostsByCompetitor(competitorId: string): Promise<Post[]> {
    return db
      .select()
      .from(posts)
      .where(eq(posts.competitorId, competitorId))
      .orderBy(desc(posts.createdAt));
  }

  async getPost(id: string): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post || undefined;
  }

  async createPost(data: InsertPost): Promise<Post> {
    const [post] = await db.insert(posts).values(data).returning();
    // Update competitor posts count
    await db
      .update(competitors)
      .set({ postsTracked: sql`${competitors.postsTracked} + 1` })
      .where(eq(competitors.id, data.competitorId));
    return post;
  }

  async updatePost(id: string, data: Partial<InsertPost>): Promise<Post | undefined> {
    const [post] = await db.update(posts).set(data).where(eq(posts.id, id)).returning();
    return post || undefined;
  }

  async deletePost(id: string): Promise<boolean> {
    const result = await db.delete(posts).where(eq(posts.id, id)).returning();
    return result.length > 0;
  }

  // Leads
  async getLeads(): Promise<Lead[]> {
    return db.select().from(leads).orderBy(desc(leads.createdAt));
  }

  async getLead(id: string): Promise<Lead | undefined> {
    const [lead] = await db.select().from(leads).where(eq(leads.id, id));
    return lead || undefined;
  }

  async createLead(data: InsertLead): Promise<Lead> {
    const [lead] = await db.insert(leads).values(data).returning();
    return lead;
  }

  async updateLead(id: string, data: Partial<InsertLead>): Promise<Lead | undefined> {
    const [lead] = await db.update(leads).set(data).where(eq(leads.id, id)).returning();
    return lead || undefined;
  }

  async deleteLead(id: string): Promise<boolean> {
    const result = await db.delete(leads).where(eq(leads.id, id)).returning();
    return result.length > 0;
  }

  // Engagements
  async getEngagements(): Promise<Engagement[]> {
    return db.select().from(engagements).orderBy(desc(engagements.createdAt));
  }

  async getEngagementsByLead(leadId: string): Promise<Engagement[]> {
    return db
      .select()
      .from(engagements)
      .where(eq(engagements.leadId, leadId))
      .orderBy(desc(engagements.createdAt));
  }

  async getEngagementsByPost(postId: string): Promise<Engagement[]> {
    return db
      .select()
      .from(engagements)
      .where(eq(engagements.postId, postId))
      .orderBy(desc(engagements.createdAt));
  }

  async createEngagement(data: InsertEngagement): Promise<Engagement> {
    const [engagement] = await db.insert(engagements).values(data).returning();
    // Update lead engagement count
    await db
      .update(leads)
      .set({ totalEngagements: sql`${leads.totalEngagements} + 1` })
      .where(eq(leads.id, data.leadId));
    return engagement;
  }

  // Campaigns
  async getCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns).orderBy(desc(campaigns.createdAt));
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign || undefined;
  }

  async createCampaign(data: InsertCampaign): Promise<Campaign> {
    const [campaign] = await db.insert(campaigns).values(data).returning();
    return campaign;
  }

  async updateCampaign(id: string, data: Partial<InsertCampaign>): Promise<Campaign | undefined> {
    const [campaign] = await db
      .update(campaigns)
      .set(data)
      .where(eq(campaigns.id, id))
      .returning();
    return campaign || undefined;
  }

  async deleteCampaign(id: string): Promise<boolean> {
    const result = await db.delete(campaigns).where(eq(campaigns.id, id)).returning();
    return result.length > 0;
  }

  // Outreach History
  async getOutreachHistory(): Promise<OutreachHistory[]> {
    return db.select().from(outreachHistory).orderBy(desc(outreachHistory.createdAt));
  }

  async getOutreachByLead(leadId: string): Promise<OutreachHistory[]> {
    return db
      .select()
      .from(outreachHistory)
      .where(eq(outreachHistory.leadId, leadId))
      .orderBy(desc(outreachHistory.createdAt));
  }

  async createOutreach(data: InsertOutreachHistory): Promise<OutreachHistory> {
    const [outreach] = await db.insert(outreachHistory).values(data).returning();
    return outreach;
  }

  async updateOutreach(
    id: string,
    data: Partial<InsertOutreachHistory>
  ): Promise<OutreachHistory | undefined> {
    const [outreach] = await db
      .update(outreachHistory)
      .set(data)
      .where(eq(outreachHistory.id, id))
      .returning();
    return outreach || undefined;
  }

  // Stats
  async getStats(): Promise<{
    totalLeads: number;
    activeCampaigns: number;
    avgWarmthScore: number;
    replyRate: number;
  }> {
    const allLeads = await db.select().from(leads);
    const activeCampaignsResult = await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.status, "active"));
    const allOutreach = await db.select().from(outreachHistory);

    const totalLeads = allLeads.length;
    const activeCampaigns = activeCampaignsResult.length;
    const avgWarmthScore =
      totalLeads > 0
        ? Math.round(
            allLeads.reduce((sum, lead) => sum + (lead.warmthScore || 0), 0) / totalLeads
          )
        : 0;
    const repliedCount = allOutreach.filter((o) => o.status === "replied").length;
    const sentCount = allOutreach.filter(
      (o) => o.status === "sent" || o.status === "accepted" || o.status === "replied"
    ).length;
    const replyRate = sentCount > 0 ? Math.round((repliedCount / sentCount) * 100) : 0;

    return {
      totalLeads,
      activeCampaigns,
      avgWarmthScore,
      replyRate,
    };
  }
}

export const storage = new DatabaseStorage();
