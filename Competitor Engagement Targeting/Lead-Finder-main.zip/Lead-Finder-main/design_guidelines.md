# LeadPulse Design Guidelines - Mudita Studios Theme

## Color Palette

### Primary Colors
- **Electric Violet** (Primary): `hsl(265 85% 65%)` - `#8B5CF6`
- **Cyan** (Secondary): `hsl(190 90% 50%)` - `#06B6D4`
- **Deep Space Blue** (Background): `hsl(230 35% 7%)` - `#0C0F1A`

### Surface Colors
- **Card**: `hsl(230 35% 10%)`
- **Muted**: `hsl(230 25% 18%)`
- **Border**: `hsl(230 25% 18%)`

### Warmth Scoring Colors
Visual indicators for lead warmth scores:
- **Hot (80-100)**: Red with glow - `rgb(239 68 68)` / `.glow-hot`
- **Warm (60-79)**: Orange with glow - `rgb(249 115 22)` / `.glow-warm`
- **Cool (40-59)**: Blue with glow - `rgb(59 130 246)` / `.glow-cool`
- **Cold (0-39)**: Gray with subtle glow - `rgb(107 114 128)` / `.glow-cold`

## Typography

### Font Families
- **Display/Headings**: Outfit (weights: 400-800) - `font-display`
- **Body/Sans**: DM Sans (weights: 400-700) - `font-sans`

### Hierarchy
- Hero/Page Titles: text-4xl font-bold font-display
- Section Headers: text-2xl font-semibold font-display
- Card Titles: text-lg font-semibold
- Body: text-base font-normal
- Small/Meta: text-sm font-medium
- Micro/Labels: text-xs font-medium uppercase tracking-wide

## Utility Classes

### Glassmorphism
```html
<div class="glass-card">Full glass effect with blur</div>
<div class="glass-panel">Subtle glass panel</div>
```

### Gradient Text
```html
<h1 class="text-gradient">Electric Violet to Cyan</h1>
```

### Neon Glow
```html
<span class="neon-glow">Violet Glow</span>
<span class="neon-glow-cyan">Cyan Glow</span>
```

### Warmth Badge Glows
```html
<Badge class="glow-hot">Hot Lead</Badge>
<Badge class="glow-warm">Warm Lead</Badge>
<Badge class="glow-cool">Cool Lead</Badge>
<Badge class="glow-cold">Cold Lead</Badge>
```

### Animations
```html
<div class="animate-fade-in">Fades in</div>
<div class="animate-slide-up">Slides up</div>
<div class="animate-scale-in">Scales in</div>
<div class="animate-pulse-glow">Pulsing violet glow</div>

<!-- Staggered animations -->
<div class="animate-slide-up stagger-1">First</div>
<div class="animate-slide-up stagger-2">Second</div>
```

### Hover Effects
```html
<div class="hover-lift">Lifts on hover with shadow</div>
<div class="hover-glow">Glows violet on hover</div>
```

## Component Guidelines

### Cards
- Use shadcn `<Card>` component
- Apply `glass-card` class for glassmorphism on important sections
- Cards have subtle borders and elevated backgrounds
- Never nest cards inside cards

### Buttons
- Primary: Electric Violet background for main actions
- Secondary: For secondary actions
- Ghost/Outline: For tertiary actions
- Always use shadcn Button variants

### Badges
- Use warmth color coding for lead scores
- Apply appropriate glow class based on score range
- Keep badges compact with built-in sizing

### Sidebar
- Deep Space Blue background
- Electric Violet for active/selected items
- Use shadcn Sidebar primitives

### Data Tables
- Dark theme with subtle row dividers
- Header with muted background
- Hover states on rows

## Layout

### Spacing
- Component padding: p-6
- Section spacing: space-y-8
- Card gaps: gap-6
- Container padding: p-6

### Responsive
- Desktop-first with mobile responsiveness
- Grid cols: 1 on mobile, 2-4 on desktop for stats
- Tables: Horizontal scroll on mobile

## Best Practices

1. **Dark Mode First**: Theme is designed for dark mode by default
2. **Glassmorphism**: Use sparingly for key UI elements
3. **Gradient Text**: Reserve for headlines and callouts
4. **Animations**: Subtle and purposeful
5. **Contrast**: Use foreground/muted-foreground for readability
6. **Warmth Indicators**: Consistent color coding for lead scores
