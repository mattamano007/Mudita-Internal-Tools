import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { LeadTable } from "@/components/lead-table";
import { WarmthBadge } from "@/components/warmth-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { Copy, Check, ExternalLink } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Lead } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const addLeadSchema = z.object({
  name: z.string().min(1, "Name is required"),
  linkedinUrl: z.string().url("Please enter a valid LinkedIn URL").optional().or(z.literal("")),
  jobTitle: z.string().optional(),
  companyName: z.string().optional(),
  headline: z.string().optional(),
  location: z.string().optional(),
  seniorityLevel: z.string().optional(),
  department: z.string().optional(),
  warmthScore: z.preprocess(
    (val) => (val === "" || val === undefined ? undefined : Number(val)),
    z.number().min(0).max(100).optional()
  ),
});

type AddLeadForm = z.infer<typeof addLeadSchema>;

export default function Leads() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterWarmth, setFilterWarmth] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: leads, isLoading } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const form = useForm<AddLeadForm>({
    resolver: zodResolver(addLeadSchema),
    defaultValues: {
      name: "",
      linkedinUrl: "",
      jobTitle: "",
      companyName: "",
      headline: "",
      location: "",
      seniorityLevel: "",
      department: "",
      warmthScore: 50,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: AddLeadForm) => {
      return apiRequest("POST", "/api/leads", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({
        title: "Lead added",
        description: "The lead has been added successfully.",
      });
      setDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add lead. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredLeads = leads?.filter((lead) => {
    const matchesSearch =
      lead.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.companyName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.jobTitle?.toLowerCase().includes(searchQuery.toLowerCase());
    
    let matchesWarmth = true;
    if (filterWarmth === "hot") matchesWarmth = (lead.warmthScore || 0) >= 80;
    else if (filterWarmth === "warm") matchesWarmth = (lead.warmthScore || 0) >= 60 && (lead.warmthScore || 0) < 80;
    else if (filterWarmth === "cool") matchesWarmth = (lead.warmthScore || 0) >= 40 && (lead.warmthScore || 0) < 60;
    else if (filterWarmth === "cold") matchesWarmth = (lead.warmthScore || 0) < 40;

    return matchesSearch && matchesWarmth;
  });

  const onSubmit = (data: AddLeadForm) => {
    createMutation.mutate(data);
  };

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const generateConnectionRequest = (lead: Lead) => {
    return `Hi ${lead.name.split(" ")[0]} - saw you engage with competitor content about our space. We're solving similar problems with a unique approach. Would love to connect and share insights.`;
  };

  const generateFollowUp = (lead: Lead) => {
    return `Thanks for connecting, ${lead.name.split(" ")[0]}!

I noticed you're interested in topics related to ${lead.department || "your industry"}. We help companies like ${lead.companyName || "yours"} tackle these challenges differently.

Similar customers have seen 30%+ improvements in key metrics within 3 months.

Worth a quick chat?`;
  };

  const generateEmail = (lead: Lead) => {
    return `Subject: Re: Industry trends you've been following

Hi ${lead.name.split(" ")[0]},

Noticed your engagement with content in our space - clearly this is top of mind for you at ${lead.companyName || "your company"}.

We're approaching the same challenges from a different angle that's been getting great results for companies in ${lead.department || "similar roles"}.

Would you be open to a 15-min conversation about how this could apply to your situation?

Best regards`;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <h1 className="text-2xl font-bold">Leads</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-add-lead">
              Add
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Add Lead</DialogTitle>
            </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="John Doe"
                              {...field}
                              data-testid="input-lead-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Acme Inc"
                              {...field}
                              data-testid="input-lead-company"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="jobTitle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Job Title</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="VP of Sales"
                            {...field}
                            data-testid="input-lead-title"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="linkedinUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>LinkedIn URL (optional)</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="https://linkedin.com/in/..."
                            {...field}
                            data-testid="input-lead-linkedin"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="seniorityLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Seniority</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-seniority">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="C-Suite">C-Suite</SelectItem>
                              <SelectItem value="VP">VP</SelectItem>
                              <SelectItem value="Director">Director</SelectItem>
                              <SelectItem value="Manager">Manager</SelectItem>
                              <SelectItem value="IC">IC</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="department"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Department</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-department">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Sales">Sales</SelectItem>
                              <SelectItem value="Marketing">Marketing</SelectItem>
                              <SelectItem value="Engineering">Engineering</SelectItem>
                              <SelectItem value="Product">Product</SelectItem>
                              <SelectItem value="Operations">Operations</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="warmthScore"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Warmth Score (0-100)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min={0}
                            max={100}
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            data-testid="input-warmth-score"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-lead">
                      {createMutation.isPending ? "Adding..." : "Add Lead"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <Input
          placeholder="Search..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-xs"
          data-testid="input-search-leads"
        />
        <Select value={filterWarmth} onValueChange={setFilterWarmth}>
          <SelectTrigger className="w-[140px]" data-testid="filter-warmth">
            <SelectValue placeholder="Warmth" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="hot">Hot</SelectItem>
            <SelectItem value="warm">Warm</SelectItem>
            <SelectItem value="cool">Cool</SelectItem>
            <SelectItem value="cold">Cold</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <Skeleton className="h-96" />
      ) : filteredLeads && filteredLeads.length > 0 ? (
        <LeadTable
          leads={filteredLeads}
          onViewLead={setSelectedLead}
          onSendOutreach={setSelectedLead}
        />
      ) : (
        <div className="text-center py-16">
          <p className="text-muted-foreground mb-4">No leads yet</p>
          <Button onClick={() => setDialogOpen(true)} data-testid="button-add-first-lead">
            Add your first lead
          </Button>
        </div>
      )}

      <Sheet open={!!selectedLead} onOpenChange={() => setSelectedLead(null)}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          {selectedLead && (
            <>
              <SheetHeader>
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={selectedLead.profilePicture || undefined} />
                    <AvatarFallback className="bg-primary/20 text-primary text-lg">
                      {selectedLead.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <SheetTitle className="text-xl">{selectedLead.name}</SheetTitle>
                    <SheetDescription>
                      {selectedLead.jobTitle || selectedLead.headline}
                    </SheetDescription>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <WarmthBadge score={selectedLead.warmthScore || 0} />
                      {selectedLead.seniorityLevel && (
                        <Badge variant="secondary">{selectedLead.seniorityLevel}</Badge>
                      )}
                    </div>
                  </div>
                </div>
              </SheetHeader>

              <div className="mt-6 space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Lead Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-sm text-muted-foreground">Company</span>
                      <span className="font-medium">{selectedLead.companyName || "Unknown"}</span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-sm text-muted-foreground">Location</span>
                      <span className="font-medium">{selectedLead.location || "Unknown"}</span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-sm text-muted-foreground">Department</span>
                      <span className="font-medium">{selectedLead.department || "Unknown"}</span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-sm text-muted-foreground">Engagements</span>
                      <span className="font-medium">{selectedLead.totalEngagements || 0}</span>
                    </div>
                    {selectedLead.linkedinUrl && (
                      <Button variant="outline" className="w-full mt-2" asChild>
                        <a href={selectedLead.linkedinUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          View LinkedIn Profile
                        </a>
                      </Button>
                    )}
                  </CardContent>
                </Card>

                <Tabs defaultValue="connection" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="connection" data-testid="tab-connection">
                      Connect
                    </TabsTrigger>
                    <TabsTrigger value="followup" data-testid="tab-followup">
                      Follow-up
                    </TabsTrigger>
                    <TabsTrigger value="email" data-testid="tab-email">
                      Email
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="connection" className="mt-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between gap-4">
                          <CardTitle className="text-sm">Connection Request</CardTitle>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(generateConnectionRequest(selectedLead), "connection")}
                            data-testid="button-copy-connection"
                          >
                            {copiedField === "connection" ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <Textarea
                          value={generateConnectionRequest(selectedLead)}
                          readOnly
                          className="min-h-[120px] resize-none"
                        />
                        <p className="text-xs text-muted-foreground mt-2">
                          300 character limit for LinkedIn connection requests
                        </p>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  <TabsContent value="followup" className="mt-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between gap-4">
                          <CardTitle className="text-sm">Follow-up Message</CardTitle>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(generateFollowUp(selectedLead), "followup")}
                            data-testid="button-copy-followup"
                          >
                            {copiedField === "followup" ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <Textarea
                          value={generateFollowUp(selectedLead)}
                          readOnly
                          className="min-h-[200px] resize-none"
                        />
                      </CardContent>
                    </Card>
                  </TabsContent>
                  <TabsContent value="email" className="mt-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between gap-4">
                          <CardTitle className="text-sm">Email Template</CardTitle>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(generateEmail(selectedLead), "email")}
                            data-testid="button-copy-email"
                          >
                            {copiedField === "email" ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <Textarea
                          value={generateEmail(selectedLead)}
                          readOnly
                          className="min-h-[240px] resize-none"
                        />
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
