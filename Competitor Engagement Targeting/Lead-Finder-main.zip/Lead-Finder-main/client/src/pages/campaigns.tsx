import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { CampaignCard } from "@/components/campaign-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Campaign, Competitor } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

const createCampaignSchema = z.object({
  name: z.string().min(1, "Campaign name is required"),
  competitorId: z.string().optional(),
  minWarmthScore: z.preprocess(
    (val) => (val === "" || val === undefined ? undefined : Number(val)),
    z.number().min(0).max(100).optional()
  ),
  seniorityLevels: z.array(z.string()).optional(),
  departments: z.array(z.string()).optional(),
});

type CreateCampaignForm = z.infer<typeof createCampaignSchema>;

const seniorityOptions = ["C-Suite", "VP", "Director", "Manager", "IC"];
const departmentOptions = ["Sales", "Marketing", "Engineering", "Product", "Operations"];

export default function Campaigns() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [minWarmth, setMinWarmth] = useState([50]);
  const { toast } = useToast();

  const { data: campaigns, isLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
  });

  const { data: competitors } = useQuery<Competitor[]>({
    queryKey: ["/api/competitors"],
  });

  const form = useForm<CreateCampaignForm>({
    resolver: zodResolver(createCampaignSchema),
    defaultValues: {
      name: "",
      competitorId: "",
      minWarmthScore: 50,
      seniorityLevels: [],
      departments: [],
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: CreateCampaignForm) => {
      const payload = {
        name: data.name,
        competitorId: data.competitorId || null,
        filterCriteria: {
          minWarmthScore: minWarmth[0],
          seniorityLevels: data.seniorityLevels,
          departments: data.departments,
        },
        status: "draft",
        leadsCount: 0,
      };
      return apiRequest("POST", "/api/campaigns", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Campaign created",
        description: "Your campaign has been created successfully.",
      });
      setDialogOpen(false);
      form.reset();
      setMinWarmth([50]);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create campaign. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredCampaigns = campaigns?.filter((campaign) => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === "all" || campaign.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const onSubmit = (data: CreateCampaignForm) => {
    createMutation.mutate(data);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <h1 className="text-2xl font-bold">Campaigns</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-create-campaign">
              Create
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Campaign</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Campaign Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., Q1 Sales Leaders - Competitor X"
                          {...field}
                          data-testid="input-campaign-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="competitorId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Competitor (optional)</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-campaign-competitor">
                            <SelectValue placeholder="Select a competitor" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="all">All Competitors</SelectItem>
                          {competitors?.map((c) => (
                            <SelectItem key={c.id} value={c.id}>
                              {c.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Filter leads from a specific competitor
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="space-y-3">
                  <Label>Minimum Warmth Score: {minWarmth[0]}</Label>
                  <Slider
                    value={minWarmth}
                    onValueChange={setMinWarmth}
                    max={100}
                    step={5}
                    className="w-full"
                    data-testid="slider-warmth"
                  />
                  <p className="text-xs text-muted-foreground">
                    Only include leads with a warmth score of {minWarmth[0]} or higher
                  </p>
                </div>

                <FormField
                  control={form.control}
                  name="seniorityLevels"
                  render={() => (
                    <FormItem>
                      <FormLabel>Seniority Levels</FormLabel>
                      <div className="grid grid-cols-2 gap-3 mt-2">
                        {seniorityOptions.map((level) => (
                          <FormField
                            key={level}
                            control={form.control}
                            name="seniorityLevels"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(level)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, level]);
                                      } else {
                                        field.onChange(current.filter((v) => v !== level));
                                      }
                                    }}
                                    data-testid={`checkbox-seniority-${level.toLowerCase()}`}
                                  />
                                </FormControl>
                                <Label className="text-sm font-normal">{level}</Label>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="departments"
                  render={() => (
                    <FormItem>
                      <FormLabel>Departments</FormLabel>
                      <div className="grid grid-cols-2 gap-3 mt-2">
                        {departmentOptions.map((dept) => (
                          <FormField
                            key={dept}
                            control={form.control}
                            name="departments"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(dept)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, dept]);
                                      } else {
                                        field.onChange(current.filter((v) => v !== dept));
                                      }
                                    }}
                                    data-testid={`checkbox-dept-${dept.toLowerCase()}`}
                                  />
                                </FormControl>
                                <Label className="text-sm font-normal">{dept}</Label>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-campaign">
                    {createMutation.isPending ? "Creating..." : "Create Campaign"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <Input
          placeholder="Search..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-xs"
          data-testid="input-search-campaigns"
        />
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[120px]" data-testid="filter-status">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="completed">Done</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-72" />
          ))}
        </div>
      ) : filteredCampaigns && filteredCampaigns.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCampaigns.map((campaign) => (
            <CampaignCard key={campaign.id} campaign={campaign} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-muted-foreground mb-4">No campaigns yet</p>
          <Button onClick={() => setDialogOpen(true)} data-testid="button-create-first-campaign">
            Create your first campaign
          </Button>
        </div>
      )}
    </div>
  );
}
