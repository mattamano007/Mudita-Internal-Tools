import { useQuery } from "@tanstack/react-query";
import { LeadTable } from "@/components/lead-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { Competitor, Lead } from "@shared/schema";

interface DashboardStats {
  totalLeads: number;
  activeCampaigns: number;
  avgWarmthScore: number;
  replyRate: number;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  const { data: competitors, isLoading: competitorsLoading } = useQuery<Competitor[]>({
    queryKey: ["/api/competitors"],
  });

  const { data: leads, isLoading: leadsLoading } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const recentLeads = leads?.slice(0, 5) || [];
  const topCompetitors = competitors?.slice(0, 3) || [];
  const hotLeads = leads?.filter((l) => (l.warmthScore || 0) >= 80).length || 0;

  return (
    <div className="p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold" data-testid="dashboard-title">LeadPulse</h1>
        <p className="text-muted-foreground mt-1">
          Turn LinkedIn competitor engagement into warm leads
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" data-testid="stats-grid">
        {statsLoading ? (
          [1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-24" />)
        ) : (
          <>
            <Card className="p-4" data-testid="stat-leads">
              <p className="text-sm text-muted-foreground">Leads</p>
              <p className="text-2xl font-bold mt-1">{stats?.totalLeads || 0}</p>
            </Card>
            <Card className="p-4" data-testid="stat-hot">
              <p className="text-sm text-muted-foreground">Hot</p>
              <p className="text-2xl font-bold mt-1 text-primary">{hotLeads}</p>
            </Card>
            <Card className="p-4" data-testid="stat-warmth">
              <p className="text-sm text-muted-foreground">Avg Score</p>
              <p className="text-2xl font-bold mt-1">{stats?.avgWarmthScore || 0}</p>
            </Card>
            <Card className="p-4" data-testid="stat-campaigns">
              <p className="text-sm text-muted-foreground">Campaigns</p>
              <p className="text-2xl font-bold mt-1">{stats?.activeCampaigns || 0}</p>
            </Card>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2" data-testid="recent-leads-card">
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
            <CardTitle className="text-lg">Recent Leads</CardTitle>
            <Link href="/leads">
              <Button variant="ghost" size="sm" data-testid="button-view-all-leads">
                View all
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {leadsLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => <Skeleton key={i} className="h-14" />)}
              </div>
            ) : recentLeads.length > 0 ? (
              <LeadTable leads={recentLeads} />
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">
                No leads yet. Start by adding competitors.
              </p>
            )}
          </CardContent>
        </Card>

        <Card data-testid="competitors-card">
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
            <CardTitle className="text-lg">Competitors</CardTitle>
            <Link href="/competitors">
              <Button variant="ghost" size="sm" data-testid="button-view-competitors">
                View all
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {competitorsLoading ? (
              [1, 2, 3].map((i) => <Skeleton key={i} className="h-12" />)
            ) : topCompetitors.length > 0 ? (
              topCompetitors.map((competitor) => (
                <div
                  key={competitor.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/30"
                  data-testid={`competitor-${competitor.id}`}
                >
                  <span className="font-medium truncate">{competitor.name}</span>
                  <span className="text-sm text-muted-foreground">
                    {competitor.leadsGenerated || 0}
                  </span>
                </div>
              ))
            ) : (
              <div className="text-center py-6">
                <p className="text-sm text-muted-foreground mb-3">No competitors yet</p>
                <Link href="/competitors">
                  <Button size="sm" data-testid="button-add-first-competitor">
                    Add competitor
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
