import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Competitors from "@/pages/competitors";
import Leads from "@/pages/leads";
import Campaigns from "@/pages/campaigns";
import { OnboardingTour } from "@/components/onboarding-tour";
import bgImage from "@assets/abstract_digital_innovation_mesh_gradient_background_1767905201472.png";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/competitors" component={Competitors} />
      <Route path="/leads" component={Leads} />
      <Route path="/campaigns" component={Campaigns} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <SidebarProvider style={style as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar />
              <div 
                className="flex flex-col flex-1 overflow-hidden relative"
                style={{
                  backgroundImage: `linear-gradient(to bottom, hsla(230, 35%, 7%, 0.85) 0%, hsla(230, 35%, 7%, 0.95) 100%), url(${bgImage})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  backgroundAttachment: 'fixed',
                }}
              >
                <header className="flex h-14 items-center justify-between gap-4 border-b border-white/10 px-4 shrink-0 backdrop-blur-sm bg-background/50">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <ThemeToggle />
                </header>
                <main className="flex-1 overflow-auto">
                  <Router />
                </main>
              </div>
            </div>
          </SidebarProvider>
          <Toaster />
          <OnboardingTour />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
