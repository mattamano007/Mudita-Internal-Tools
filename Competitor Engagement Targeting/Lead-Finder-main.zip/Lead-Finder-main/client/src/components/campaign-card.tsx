import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, Send, CheckCircle, MessageSquare, Calendar } from "lucide-react";
import type { Campaign } from "@shared/schema";
import { Link } from "wouter";

interface CampaignCardProps {
  campaign: Campaign;
}

export function CampaignCard({ campaign }: CampaignCardProps) {
  const getStatusBadge = (status: string | null) => {
    const statusConfig: Record<string, { label: string; className: string }> = {
      draft: { label: "Draft", className: "bg-gray-500/20 text-gray-400" },
      active: { label: "Active", className: "bg-green-500/20 text-green-400" },
      paused: { label: "Paused", className: "bg-yellow-500/20 text-yellow-400" },
      completed: { label: "Completed", className: "bg-blue-500/20 text-blue-400" },
    };
    const config = statusConfig[status || "draft"] || statusConfig.draft;
    return (
      <Badge variant="secondary" className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const acceptanceRate = campaign.connectionsSent
    ? Math.round((campaign.connectionsAccepted || 0) / campaign.connectionsSent * 100)
    : 0;

  const replyRate = campaign.connectionsSent
    ? Math.round((campaign.repliesReceived || 0) / campaign.connectionsSent * 100)
    : 0;

  return (
    <Card className="overflow-visible hover-elevate" data-testid={`card-campaign-${campaign.id}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold truncate">{campaign.name}</CardTitle>
        {getStatusBadge(campaign.status)}
      </CardHeader>
      <CardContent className="p-6 pt-2">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span className="text-xs">Leads</span>
            </div>
            <p className="text-xl font-semibold">{campaign.leadsCount || 0}</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Send className="h-4 w-4" />
              <span className="text-xs">Sent</span>
            </div>
            <p className="text-xl font-semibold">{campaign.connectionsSent || 0}</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground">
              <CheckCircle className="h-4 w-4" />
              <span className="text-xs">Accepted</span>
            </div>
            <p className="text-xl font-semibold">{campaign.connectionsAccepted || 0}</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-muted-foreground">
              <MessageSquare className="h-4 w-4" />
              <span className="text-xs">Replies</span>
            </div>
            <p className="text-xl font-semibold">{campaign.repliesReceived || 0}</p>
          </div>
        </div>
        <div className="space-y-3">
          <div className="space-y-1">
            <div className="flex items-center justify-between gap-4 text-sm">
              <span className="text-muted-foreground">Acceptance Rate</span>
              <span className="font-medium">{acceptanceRate}%</span>
            </div>
            <Progress value={acceptanceRate} className="h-2" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center justify-between gap-4 text-sm">
              <span className="text-muted-foreground">Reply Rate</span>
              <span className="font-medium">{replyRate}%</span>
            </div>
            <Progress value={replyRate} className="h-2" />
          </div>
        </div>
        {campaign.meetingsBooked && campaign.meetingsBooked > 0 && (
          <div className="flex items-center gap-2 mt-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
            <Calendar className="h-4 w-4 text-emerald-400" />
            <span className="text-sm text-emerald-400 font-medium">
              {campaign.meetingsBooked} meetings booked
            </span>
          </div>
        )}
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Link href={`/campaigns/${campaign.id}`} className="w-full">
          <Button variant="secondary" className="w-full" data-testid={`button-view-campaign-${campaign.id}`}>
            Manage Campaign
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
