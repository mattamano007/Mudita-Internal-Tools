import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { WarmthBadge } from "./warmth-badge";
import { ExternalLink, Mail, MessageSquare, MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Lead } from "@shared/schema";

interface LeadTableProps {
  leads: Lead[];
  onViewLead?: (lead: Lead) => void;
  onSendOutreach?: (lead: Lead) => void;
}

export function LeadTable({ leads, onViewLead, onSendOutreach }: LeadTableProps) {
  const getInitials = (name: string) =>
    name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

  const getStatusBadge = (status: string | null) => {
    const statusConfig: Record<string, { label: string; className: string }> = {
      new: { label: "New", className: "bg-blue-500/20 text-blue-400" },
      contacted: { label: "Contacted", className: "bg-yellow-500/20 text-yellow-400" },
      replied: { label: "Replied", className: "bg-green-500/20 text-green-400" },
      qualified: { label: "Qualified", className: "bg-purple-500/20 text-purple-400" },
      converted: { label: "Converted", className: "bg-emerald-500/20 text-emerald-400" },
    };
    const config = statusConfig[status || "new"] || statusConfig.new;
    return (
      <Badge variant="secondary" className={config.className}>
        {config.label}
      </Badge>
    );
  };

  return (
    <div className="rounded-lg border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[300px]">Lead</TableHead>
            <TableHead>Company</TableHead>
            <TableHead>Seniority</TableHead>
            <TableHead>Warmth</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {leads.map((lead) => (
            <TableRow key={lead.id} data-testid={`row-lead-${lead.id}`}>
              <TableCell>
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={lead.profilePicture || undefined} alt={lead.name} />
                    <AvatarFallback className="bg-primary/20 text-primary text-sm">
                      {getInitials(lead.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{lead.name}</p>
                    <p className="text-sm text-muted-foreground truncate max-w-[200px]">
                      {lead.jobTitle || lead.headline || "No title"}
                    </p>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <p className="text-sm">{lead.companyName || "Unknown"}</p>
              </TableCell>
              <TableCell>
                <Badge variant="secondary" className="text-xs">
                  {lead.seniorityLevel || "N/A"}
                </Badge>
              </TableCell>
              <TableCell>
                <WarmthBadge score={lead.warmthScore || 0} />
              </TableCell>
              <TableCell>{getStatusBadge(lead.status)}</TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end gap-1">
                  {lead.linkedinUrl && (
                    <Button
                      variant="ghost"
                      size="icon"
                      asChild
                      data-testid={`button-linkedin-${lead.id}`}
                    >
                      <a
                        href={lead.linkedinUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                  )}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" data-testid={`button-actions-${lead.id}`}>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onViewLead?.(lead)}>
                        <MessageSquare className="h-4 w-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onSendOutreach?.(lead)}>
                        <Mail className="h-4 w-4 mr-2" />
                        Send Outreach
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </TableCell>
            </TableRow>
          ))}
          {leads.length === 0 && (
            <TableRow>
              <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                No leads found. Import leads or track competitor posts to get started.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
