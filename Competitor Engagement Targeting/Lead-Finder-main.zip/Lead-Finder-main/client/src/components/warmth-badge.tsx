import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface WarmthBadgeProps {
  score: number;
  className?: string;
}

export function WarmthBadge({ score, className }: WarmthBadgeProps) {
  const getWarmthConfig = (score: number) => {
    if (score >= 80) {
      return {
        label: "Hot",
        className: "bg-red-500/20 text-red-400 border-red-500/30",
        glowClass: "shadow-[0_0_12px_rgba(239,68,68,0.4)]",
      };
    }
    if (score >= 60) {
      return {
        label: "Warm",
        className: "bg-orange-500/20 text-orange-400 border-orange-500/30",
        glowClass: "shadow-[0_0_12px_rgba(249,115,22,0.4)]",
      };
    }
    if (score >= 40) {
      return {
        label: "Cool",
        className: "bg-blue-500/20 text-blue-400 border-blue-500/30",
        glowClass: "shadow-[0_0_12px_rgba(59,130,246,0.4)]",
      };
    }
    return {
      label: "Cold",
      className: "bg-gray-500/20 text-gray-400 border-gray-500/30",
      glowClass: "",
    };
  };

  const config = getWarmthConfig(score);

  return (
    <Badge
      variant="outline"
      className={cn(
        "font-semibold border",
        config.className,
        config.glowClass,
        className
      )}
    >
      {score} - {config.label}
    </Badge>
  );
}
