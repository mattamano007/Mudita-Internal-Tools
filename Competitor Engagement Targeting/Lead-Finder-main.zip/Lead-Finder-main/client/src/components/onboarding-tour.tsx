import { useState, useEffect } from "react";
import Joyride, { CallBackProps, STATUS, Step } from "react-joyride";

const steps: Step[] = [
  {
    target: '[data-testid="dashboard-title"]',
    content: "Welcome to LeadPulse. Find warm leads from your competitors' LinkedIn engagement.",
    placement: "bottom",
    disableBeacon: true,
  },
  {
    target: '[data-testid="stats-grid"]',
    content: "Track your key metrics at a glance: total leads, hot prospects, average warmth scores, and active campaigns.",
    placement: "bottom",
  },
  {
    target: '[data-testid="competitors-card"]',
    content: "Start by adding competitors. We'll track who engages with their content.",
    placement: "left",
  },
  {
    target: '[data-testid="recent-leads-card"]',
    content: "Your warmest leads appear here, scored by their engagement patterns.",
    placement: "top",
  },
  {
    target: '[data-testid="nav-competitors"]',
    content: "Add LinkedIn profiles or company pages you want to monitor.",
    placement: "right",
  },
  {
    target: '[data-testid="nav-leads"]',
    content: "View and filter all your captured leads by warmth score.",
    placement: "right",
  },
  {
    target: '[data-testid="nav-campaigns"]',
    content: "Create targeted outreach campaigns for your best leads.",
    placement: "right",
  },
];

export function OnboardingTour() {
  const [run, setRun] = useState(false);

  useEffect(() => {
    const hasSeenTour = localStorage.getItem("leadpulse_tour_completed");
    if (!hasSeenTour) {
      const timer = setTimeout(() => setRun(true), 500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleCallback = (data: CallBackProps) => {
    const { status } = data;
    if (status === STATUS.FINISHED || status === STATUS.SKIPPED) {
      setRun(false);
      localStorage.setItem("leadpulse_tour_completed", "true");
    }
  };

  return (
    <Joyride
      steps={steps}
      run={run}
      continuous
      showProgress
      showSkipButton
      callback={handleCallback}
      styles={{
        options: {
          primaryColor: "hsl(var(--primary))",
          backgroundColor: "hsl(var(--card))",
          textColor: "hsl(var(--foreground))",
          arrowColor: "hsl(var(--card))",
          overlayColor: "rgba(0, 0, 0, 0.7)",
          zIndex: 10000,
        },
        tooltip: {
          borderRadius: 8,
          padding: 20,
          border: "1px solid hsl(var(--border))",
        },
        tooltipContent: {
          padding: "8px 0",
        },
        buttonNext: {
          backgroundColor: "hsl(var(--primary))",
          borderRadius: 6,
          padding: "8px 16px",
        },
        buttonBack: {
          color: "hsl(var(--muted-foreground))",
          marginRight: 8,
        },
        buttonSkip: {
          color: "hsl(var(--muted-foreground))",
        },
        spotlight: {
          borderRadius: 8,
        },
      }}
      floaterProps={{
        disableAnimation: true,
      }}
    />
  );
}
