import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ExternalLink, Users, FileText, TrendingUp } from "lucide-react";
import type { Competitor } from "@shared/schema";
import { Link } from "wouter";

interface CompetitorCardProps {
  competitor: Competitor;
}

export function CompetitorCard({ competitor }: CompetitorCardProps) {
  const initials = competitor.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="overflow-visible hover-elevate" data-testid={`card-competitor-${competitor.id}`}>
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="h-14 w-14 ring-2 ring-primary/20">
            <AvatarImage src={competitor.profilePicture || undefined} alt={competitor.name} />
            <AvatarFallback className="bg-primary/20 text-primary font-semibold">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold truncate">{competitor.name}</h3>
              {competitor.trackingActive && (
                <Badge variant="secondary" className="text-xs">
                  Active
                </Badge>
              )}
            </div>
            <a
              href={competitor.linkedinUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-muted-foreground hover:text-primary flex items-center gap-1 mt-1"
              data-testid={`link-competitor-linkedin-${competitor.id}`}
            >
              LinkedIn Profile
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
              <Users className="h-3 w-3" />
            </div>
            <p className="text-lg font-semibold">
              {competitor.followerCount?.toLocaleString() || 0}
            </p>
            <p className="text-xs text-muted-foreground">Followers</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
              <FileText className="h-3 w-3" />
            </div>
            <p className="text-lg font-semibold">{competitor.postsTracked || 0}</p>
            <p className="text-xs text-muted-foreground">Posts</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
              <TrendingUp className="h-3 w-3" />
            </div>
            <p className="text-lg font-semibold">{competitor.leadsGenerated || 0}</p>
            <p className="text-xs text-muted-foreground">Leads</p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Link href={`/competitors/${competitor.id}`} className="w-full">
          <Button variant="secondary" className="w-full" data-testid={`button-view-competitor-${competitor.id}`}>
            View Details
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
