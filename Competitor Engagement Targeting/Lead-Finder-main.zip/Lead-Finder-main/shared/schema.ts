import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Competitors table - companies/profiles we're tracking
export const competitors = pgTable("competitors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  linkedinUrl: text("linkedin_url").notNull(),
  profilePicture: text("profile_picture"),
  followerCount: integer("follower_count").default(0),
  postsTracked: integer("posts_tracked").default(0),
  leadsGenerated: integer("leads_generated").default(0),
  lastScrapedAt: timestamp("last_scraped_at"),
  trackingActive: boolean("tracking_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Posts from competitors
export const posts = pgTable("posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  competitorId: varchar("competitor_id").notNull().references(() => competitors.id, { onDelete: "cascade" }),
  linkedinPostUrl: text("linkedin_post_url").notNull(),
  postText: text("post_text"),
  postDate: timestamp("post_date"),
  likesCount: integer("likes_count").default(0),
  commentsCount: integer("comments_count").default(0),
  sharesCount: integer("shares_count").default(0),
  engagementRate: integer("engagement_rate").default(0),
  contentType: text("content_type").default("text"),
  topicTags: text("topic_tags").array(),
  scrapedAt: timestamp("scraped_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Leads - people who engaged with competitor posts
export const leads = pgTable("leads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  linkedinUrl: text("linkedin_url"),
  name: text("name").notNull(),
  headline: text("headline"),
  jobTitle: text("job_title"),
  companyName: text("company_name"),
  location: text("location"),
  profilePicture: text("profile_picture"),
  connectionDegree: text("connection_degree"),
  warmthScore: integer("warmth_score").default(0),
  seniorityLevel: text("seniority_level"),
  department: text("department"),
  firstEngagedPostId: varchar("first_engaged_post_id"),
  totalEngagements: integer("total_engagements").default(0),
  lastEngagementDate: timestamp("last_engagement_date"),
  status: text("status").default("new"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Engagements - likes/comments on posts
export const engagements = pgTable("engagements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  postId: varchar("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
  engagementType: text("engagement_type").notNull(),
  commentText: text("comment_text"),
  engagementDate: timestamp("engagement_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Campaigns for outreach
export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  competitorId: varchar("competitor_id").references(() => competitors.id),
  filterCriteria: json("filter_criteria"),
  outreachSequence: json("outreach_sequence"),
  status: text("status").default("draft"),
  leadsCount: integer("leads_count").default(0),
  connectionsSent: integer("connections_sent").default(0),
  connectionsAccepted: integer("connections_accepted").default(0),
  repliesReceived: integer("replies_received").default(0),
  meetingsBooked: integer("meetings_booked").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Outreach history
export const outreachHistory = pgTable("outreach_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
  outreachType: text("outreach_type").notNull(),
  content: text("content"),
  sentAt: timestamp("sent_at"),
  status: text("status").default("pending"),
  replyText: text("reply_text"),
  nextFollowup: timestamp("next_followup"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Competitive insights from AI analysis
export const competitiveInsights = pgTable("competitive_insights", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
  painPoints: json("pain_points"),
  messagingThemes: json("messaging_themes"),
  suggestedCounterposition: json("suggested_counterposition"),
  analyzedAt: timestamp("analyzed_at").defaultNow(),
});

// Relations
export const competitorsRelations = relations(competitors, ({ many }) => ({
  posts: many(posts),
  campaigns: many(campaigns),
}));

export const postsRelations = relations(posts, ({ one, many }) => ({
  competitor: one(competitors, {
    fields: [posts.competitorId],
    references: [competitors.id],
  }),
  engagements: many(engagements),
  insights: many(competitiveInsights),
}));

export const leadsRelations = relations(leads, ({ many }) => ({
  engagements: many(engagements),
  outreachHistory: many(outreachHistory),
}));

export const engagementsRelations = relations(engagements, ({ one }) => ({
  lead: one(leads, {
    fields: [engagements.leadId],
    references: [leads.id],
  }),
  post: one(posts, {
    fields: [engagements.postId],
    references: [posts.id],
  }),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  competitor: one(competitors, {
    fields: [campaigns.competitorId],
    references: [competitors.id],
  }),
  outreachHistory: many(outreachHistory),
}));

export const outreachHistoryRelations = relations(outreachHistory, ({ one }) => ({
  lead: one(leads, {
    fields: [outreachHistory.leadId],
    references: [leads.id],
  }),
  campaign: one(campaigns, {
    fields: [outreachHistory.campaignId],
    references: [campaigns.id],
  }),
}));

export const competitiveInsightsRelations = relations(competitiveInsights, ({ one }) => ({
  post: one(posts, {
    fields: [competitiveInsights.postId],
    references: [posts.id],
  }),
}));

// Insert Schemas
export const insertCompetitorSchema = createInsertSchema(competitors).omit({
  id: true,
  createdAt: true,
  postsTracked: true,
  leadsGenerated: true,
  lastScrapedAt: true,
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
  scrapedAt: true,
});

export const insertLeadSchema = createInsertSchema(leads).omit({
  id: true,
  createdAt: true,
});

export const insertEngagementSchema = createInsertSchema(engagements).omit({
  id: true,
  createdAt: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
  connectionsSent: true,
  connectionsAccepted: true,
  repliesReceived: true,
  meetingsBooked: true,
});

export const insertOutreachHistorySchema = createInsertSchema(outreachHistory).omit({
  id: true,
  createdAt: true,
});

export const insertCompetitiveInsightSchema = createInsertSchema(competitiveInsights).omit({
  id: true,
  analyzedAt: true,
});

// Types
export type Competitor = typeof competitors.$inferSelect;
export type InsertCompetitor = z.infer<typeof insertCompetitorSchema>;

export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;

export type Lead = typeof leads.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;

export type Engagement = typeof engagements.$inferSelect;
export type InsertEngagement = z.infer<typeof insertEngagementSchema>;

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;

export type OutreachHistory = typeof outreachHistory.$inferSelect;
export type InsertOutreachHistory = z.infer<typeof insertOutreachHistorySchema>;

export type CompetitiveInsight = typeof competitiveInsights.$inferSelect;
export type InsertCompetitiveInsight = z.infer<typeof insertCompetitiveInsightSchema>;

// Legacy user schema for compatibility
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
