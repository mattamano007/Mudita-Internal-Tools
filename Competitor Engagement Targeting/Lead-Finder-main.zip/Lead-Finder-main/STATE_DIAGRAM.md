# LeadPulse State Machine Diagram

```mermaid
stateDiagram-v2
    [*] --> FirstVisit

    state "First Visit" as FirstVisit
    state "Onboarding Tour" as Onboarding
    state "Dashboard" as Dashboard
    state "Competitors" as Competitors
    state "Leads" as Leads
    state "Campaigns" as Campaigns

    FirstVisit --> Onboarding: New User
    Onboarding --> Dashboard: Tour Complete/Skip

    Dashboard --> Competitors: Navigate
    Dashboard --> Leads: Navigate
    Dashboard --> Campaigns: Navigate

    Competitors --> Dashboard: Navigate
    Leads --> Dashboard: Navigate
    Campaigns --> Dashboard: Navigate

    state Competitors {
        [*] --> ViewCompetitors
        ViewCompetitors --> AddCompetitor: Add
        AddCompetitor --> ViewCompetitors: Save/Cancel
        ViewCompetitors --> EditCompetitor: Edit
        EditCompetitor --> ViewCompetitors: Save/Cancel
        ViewCompetitors --> DeleteCompetitor: Delete
        DeleteCompetitor --> ViewCompetitors: Confirm
    }

    state Leads {
        [*] --> ViewLeads
        ViewLeads --> AddLead: Add
        AddLead --> ViewLeads: Save/Cancel
        ViewLeads --> ViewLeadDetails: Select
        ViewLeadDetails --> ViewLeads: Close
        ViewLeads --> FilterLeads: Filter by Warmth
        FilterLeads --> ViewLeads: Apply
    }

    state Campaigns {
        [*] --> ViewCampaigns
        ViewCampaigns --> CreateCampaign: Create
        CreateCampaign --> ViewCampaigns: Save/Cancel
        ViewCampaigns --> EditCampaign: Edit
        EditCampaign --> ViewCampaigns: Save/Cancel
        ViewCampaigns --> DeleteCampaign: Delete
        DeleteCampaign --> ViewCampaigns: Confirm
    }
```

## State Descriptions

| State | Description |
|-------|-------------|
| First Visit | User lands on app for the first time |
| Onboarding Tour | Interactive tooltip tour explaining features |
| Dashboard | Main hub showing stats and recent activity |
| Competitors | Manage tracked LinkedIn competitors |
| Leads | View and manage captured leads with warmth scores |
| Campaigns | Create and manage outreach campaigns |

## Lead Warmth States

```mermaid
stateDiagram-v2
    [*] --> Cold
    Cold --> Cool: Engagement +20
    Cool --> Warm: Engagement +20
    Warm --> Hot: Engagement +20
    
    state "Cold (0-39)" as Cold
    state "Cool (40-59)" as Cool
    state "Warm (60-79)" as Warm
    state "Hot (80-100)" as Hot
```
