# LeadPulse - LinkedIn Lead Generation Tool

## Overview

LeadPulse is a LinkedIn lead generation application that identifies warm prospects by finding people who engage with competitors' top-performing content. The core value proposition is that these leads are pre-qualified: they're active on LinkedIn, care about your space, and have demonstrated interest through engagement actions.

The application allows users to:
- Track competitor LinkedIn profiles and their posts
- Identify top-performing content by engagement metrics
- Capture leads who liked/commented on competitor posts
- Score leads by "warmth" based on engagement patterns
- Create outreach campaigns targeting qualified leads
- Generate personalized outreach messages

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, bundled with Vite
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state, local React state for UI
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with a custom dark purple theme (Mudita Studios aesthetic)
- **Design System**: Glassmorphism cards, warmth-score color coding (hot/warm/cool/cold), Inter font

### Backend Architecture
- **Runtime**: Node.js with Express
- **API Pattern**: RESTful JSON API under `/api/*` prefix
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Validation**: Zod schemas generated from Drizzle schema using drizzle-zod
- **Build System**: esbuild for server bundling, Vite for client bundling

### Data Model
Core entities and relationships:
- **Competitors**: LinkedIn profiles/pages being tracked
- **Posts**: Content from competitors with engagement metrics
- **Leads**: People who engaged with competitor posts, scored by warmth
- **Engagements**: Junction table linking leads to posts with engagement type
- **Campaigns**: Outreach campaigns targeting filtered lead segments
- **OutreachHistory**: Record of messages sent to leads
- **CompetitiveInsights**: Analyzed patterns from competitor content

### Key Design Decisions

**Warmth Scoring System**: Leads are scored 0-100 based on engagement patterns. Visual indicators use color-coded badges with glow effects (red for hot 80+, orange for warm 60-79, blue for cool 40-59, gray for cold 0-39).

**Monorepo Structure**: Single repository with clear separation:
- `/client` - React frontend application
- `/server` - Express backend API
- `/shared` - Shared types and database schema

**Component Architecture**: Custom business components (CompetitorCard, LeadTable, WarmthBadge, etc.) built on top of shadcn/ui primitives, following the design guidelines for the dark theme aesthetic.

## External Dependencies

### Database
- **PostgreSQL**: Primary database accessed via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries with automatic migrations via `drizzle-kit push`

### Third-Party Services (Planned)
- **LinkedIn API/Scraping**: For fetching competitor posts and engagers (Puppeteer/Playwright mentioned in requirements)
- **Anthropic Claude API**: For content analysis and personalized outreach generation

### Key NPM Packages
- `@tanstack/react-query`: Server state management
- `drizzle-orm` + `drizzle-zod`: Database ORM and schema validation
- `express` + `express-session`: HTTP server and session management
- `react-hook-form` + `@hookform/resolvers`: Form handling with Zod validation
- `wouter`: Client-side routing
- `date-fns`: Date formatting utilities
- `lucide-react`: Icon library