# Mudita Voice Drops

A mobile-first web app for collecting team voice notes that get turned into newsletter content. Features a Tinder-style swipe interface for browsing questions and a voice recording experience.

## Features

- **Swipeable Card Interface**: Tinder-style swiping to browse questions
- **Voice Recording**: Record voice notes with waveform visualization
- **Auto-Transcription**: Uses OpenAI Whisper API for transcription
- **AI Content Transformation**: Uses Claude API to transform raw transcripts into polished newsletter snippets
- **Admin Dashboard**: Review all submitted voice notes with transcripts and transformed content
- **Mobile-First Design**: Optimized for mobile with large touch targets and smooth animations

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: TailwindCSS
- **Animations**: Framer Motion
- **Backend/Storage**: Supabase
- **Transcription**: OpenAI Whisper API
- **Content Transformation**: Anthropic Claude API

## Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn
- Supabase account
- OpenAI API key
- Anthropic API key

### 1. Clone and Install

```bash
cd mudita-voice-drops
npm install
```

### 2. Set Up Supabase

1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Run the SQL schema in `supabase-schema.sql` in your Supabase SQL Editor
3. Create a storage bucket named `voice-notes` and make it public
4. Copy your project URL and API keys

### 3. Configure Environment Variables

Copy `.env.example` to `.env.local` and fill in your values:

```bash
cp .env.example .env.local
```

Required environment variables:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
OPENAI_API_KEY=your_openai_api_key
ANTHROPIC_API_KEY=your_anthropic_api_key
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser (or use mobile browser for best experience).

## Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── process/       # Full processing pipeline endpoint
│   │   ├── transcribe/    # Whisper transcription endpoint
│   │   ├── transform/     # Claude transformation endpoint
│   │   └── voice-notes/   # Fetch voice notes endpoint
│   ├── admin/             # Admin dashboard page
│   ├── globals.css        # Global styles
│   ├── layout.tsx         # Root layout
│   └── page.tsx           # Main app page
├── components/
│   ├── EmptyState.tsx     # Shown when all questions answered
│   ├── NameModal.tsx      # First-time user name input
│   ├── SubmissionModal.tsx # Processing/success states
│   ├── SwipeableCard.tsx  # Swipeable question card
│   └── VoiceRecorder.tsx  # Voice recording interface
├── data/
│   └── questions.json     # 50 questions database
├── hooks/
│   ├── useLocalUser.ts    # Local user persistence
│   └── useVoiceRecorder.ts # Voice recording logic
├── lib/
│   ├── api.ts             # API utility functions
│   ├── questions.ts       # Question utilities
│   └── supabase.ts        # Supabase client
└── types/
    └── index.ts           # TypeScript types
```

## Usage

### Recording a Voice Drop

1. Open the app on your mobile device
2. Enter your name on first visit
3. Swipe right on a question to record, or swipe left to skip
4. Record your voice note (tap stop when done)
5. Review and submit or re-record
6. Your voice note is automatically transcribed and transformed

### Admin Dashboard

Access the admin dashboard at `/admin` to:
- View all submitted voice notes
- Listen to original audio
- Read transcripts and transformed newsletter snippets
- Copy content to clipboard
- Filter by status (completed/pending)

## Question Categories

Questions are organized into 4 categories:

- **Tools & Workflows** (25%): Questions about tools and processes
- **Shipping & Building** (30%): Questions about projects and building
- **Takes & Opinions** (25%): Hot takes and professional opinions
- **Tips & Hacks** (20%): Productivity tips and tricks

## API Endpoints

### POST /api/process

Full processing pipeline - uploads audio, transcribes, transforms, and saves to database.

**Form Data:**
- `audio`: Audio file (webm)
- `questionText`: The question being answered
- `questionId`: Question ID
- `userName`: User's name
- `userId`: User's ID

### POST /api/transcribe

Transcribe audio only.

**Form Data:**
- `audio`: Audio file (webm)

### POST /api/transform

Transform transcript to newsletter snippet.

**JSON Body:**
- `transcript`: The transcribed text
- `questionText`: The question
- `userName`: Speaker's name

### GET /api/voice-notes

Fetch all voice notes (for admin view).

## Deployment

### Vercel (Recommended)

1. Push to GitHub
2. Import to Vercel
3. Add environment variables
4. Deploy

### Other Platforms

The app is a standard Next.js application and can be deployed to any platform that supports Next.js (Netlify, Railway, etc.).

## Future Improvements (V2)

- User authentication
- Edit submissions before sending
- Analytics dashboard
- Email notifications
- Slack integration
- Batch export for newsletters
