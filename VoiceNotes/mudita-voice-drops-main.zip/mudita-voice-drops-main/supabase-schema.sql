-- Supabase Schema for Mudita Voice Drops
-- Run this SQL in your Supabase SQL Editor to set up the database

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Voice notes table
CREATE TABLE IF NOT EXISTS voice_notes (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  question_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  audio_url TEXT,
  transcript TEXT,
  newsletter_snippet TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'transcribing', 'processing', 'completed', 'error')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  processed_at TIMESTAMPTZ
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_voice_notes_user_id ON voice_notes(user_id);
CREATE INDEX IF NOT EXISTS idx_voice_notes_status ON voice_notes(status);
CREATE INDEX IF NOT EXISTS idx_voice_notes_created_at ON voice_notes(created_at DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE voice_notes ENABLE ROW LEVEL SECURITY;

-- Policy: Allow anyone to insert (for now, since we're not using auth)
CREATE POLICY "Allow public insert" ON voice_notes
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Policy: Allow anyone to select (for admin view)
CREATE POLICY "Allow public select" ON voice_notes
  FOR SELECT
  TO public
  USING (true);

-- Policy: Allow anyone to update (for processing pipeline)
CREATE POLICY "Allow public update" ON voice_notes
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Create storage bucket for voice notes
-- Note: Run this in Supabase Dashboard > Storage > Create a new bucket
-- Bucket name: voice-notes
-- Public bucket: Yes (for simplicity in V1)

-- Storage policy for voice-notes bucket (run in Supabase Dashboard > Storage > Policies)
-- Allow public uploads:
-- CREATE POLICY "Allow public uploads" ON storage.objects
--   FOR INSERT
--   TO public
--   WITH CHECK (bucket_id = 'voice-notes');

-- Allow public downloads:
-- CREATE POLICY "Allow public downloads" ON storage.objects
--   FOR SELECT
--   TO public
--   USING (bucket_id = 'voice-notes');
