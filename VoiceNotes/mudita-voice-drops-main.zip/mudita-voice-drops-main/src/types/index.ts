export type QuestionCategory =
  | 'tools-workflows'
  | 'shipping-building'
  | 'takes-opinions'
  | 'tips-hacks';

export interface Question {
  id: string;
  text: string;
  category: QuestionCategory;
  followUp?: string;
}

export interface VoiceNote {
  id: string;
  questionId: string;
  userId: string;
  userName: string;
  audioUrl: string;
  transcript?: string;
  newsletterSnippet?: string;
  status: 'pending' | 'transcribing' | 'processing' | 'completed' | 'error';
  createdAt: string;
  processedAt?: string;
}

export interface User {
  id: string;
  name: string;
  answeredQuestionIds: string[];
  createdAt: string;
}

export interface RecordingState {
  isRecording: boolean;
  isPaused: boolean;
  duration: number;
  audioBlob?: Blob;
  audioUrl?: string;
  waveformData: number[];
}

export interface SwipeDirection {
  direction: 'left' | 'right' | null;
}
