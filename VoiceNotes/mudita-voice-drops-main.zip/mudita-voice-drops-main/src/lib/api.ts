// API utility functions for transcription and content transformation

export async function transcribeAudio(audioBlob: Blob): Promise<string | null> {
  const formData = new FormData();
  formData.append('audio', audioBlob, 'recording.webm');

  try {
    const response = await fetch('/api/transcribe', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Transcription failed');
    }

    const data = await response.json();
    return data.transcript;
  } catch (error) {
    console.error('Transcription error:', error);
    return null;
  }
}

export async function transformToNewsletter(
  transcript: string,
  questionText: string,
  userName: string
): Promise<string | null> {
  try {
    const response = await fetch('/api/transform', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        transcript,
        questionText,
        userName,
      }),
    });

    if (!response.ok) {
      throw new Error('Transformation failed');
    }

    const data = await response.json();
    return data.snippet;
  } catch (error) {
    console.error('Transformation error:', error);
    return null;
  }
}

export async function processVoiceNote(
  voiceNoteId: string,
  audioBlob: Blob,
  questionText: string,
  userName: string
): Promise<{ transcript: string; snippet: string } | null> {
  try {
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');
    formData.append('voiceNoteId', voiceNoteId);
    formData.append('questionText', questionText);
    formData.append('userName', userName);

    const response = await fetch('/api/process', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Processing failed');
    }

    const data = await response.json();
    return {
      transcript: data.transcript,
      snippet: data.snippet,
    };
  } catch (error) {
    console.error('Processing error:', error);
    return null;
  }
}
