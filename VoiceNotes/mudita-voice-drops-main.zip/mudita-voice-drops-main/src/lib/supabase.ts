import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Storage bucket name for voice notes
export const VOICE_NOTES_BUCKET = 'voice-notes';

// Upload audio file to Supabase Storage
export async function uploadAudio(
  audioBlob: Blob,
  fileName: string
): Promise<string | null> {
  const { data, error } = await supabase.storage
    .from(VOICE_NOTES_BUCKET)
    .upload(fileName, audioBlob, {
      contentType: 'audio/webm',
      upsert: false,
    });

  if (error) {
    console.error('Error uploading audio:', error);
    return null;
  }

  // Get public URL
  const { data: urlData } = supabase.storage
    .from(VOICE_NOTES_BUCKET)
    .getPublicUrl(data.path);

  return urlData.publicUrl;
}

// Save voice note record to database
export async function saveVoiceNote(voiceNote: {
  questionId: string;
  userId: string;
  userName: string;
  audioUrl: string;
}) {
  const { data, error } = await supabase
    .from('voice_notes')
    .insert({
      question_id: voiceNote.questionId,
      user_id: voiceNote.userId,
      user_name: voiceNote.userName,
      audio_url: voiceNote.audioUrl,
      status: 'pending',
      created_at: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    console.error('Error saving voice note:', error);
    return null;
  }

  return data;
}

// Update voice note with transcript and newsletter snippet
export async function updateVoiceNote(
  id: string,
  updates: {
    transcript?: string;
    newsletter_snippet?: string;
    status?: string;
    processed_at?: string;
  }
) {
  const { data, error } = await supabase
    .from('voice_notes')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating voice note:', error);
    return null;
  }

  return data;
}

// Get all voice notes (for admin view)
export async function getVoiceNotes() {
  const { data, error } = await supabase
    .from('voice_notes')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching voice notes:', error);
    return [];
  }

  return data;
}

// Get voice notes by user
export async function getVoiceNotesByUser(userId: string) {
  const { data, error } = await supabase
    .from('voice_notes')
    .select('question_id')
    .eq('user_id', userId);

  if (error) {
    console.error('Error fetching user voice notes:', error);
    return [];
  }

  return data.map((note) => note.question_id);
}
