import questionsData from '@/data/questions.json';
import { Question } from '@/types';

const questions: Question[] = questionsData.questions as Question[];

// Get a random question that the user hasn't answered yet
export function getRandomQuestion(answeredIds: string[]): Question | null {
  const unanswered = questions.filter((q) => !answeredIds.includes(q.id));

  if (unanswered.length === 0) {
    return null; // User has answered all questions
  }

  const randomIndex = Math.floor(Math.random() * unanswered.length);
  return unanswered[randomIndex];
}

// Get multiple random questions
export function getRandomQuestions(
  answeredIds: string[],
  count: number = 5
): Question[] {
  const unanswered = questions.filter((q) => !answeredIds.includes(q.id));
  const shuffled = [...unanswered].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

// Get question by ID
export function getQuestionById(id: string): Question | undefined {
  return questions.find((q) => q.id === id);
}

// Get all questions
export function getAllQuestions(): Question[] {
  return questions;
}

// Get questions by category
export function getQuestionsByCategory(
  category: Question['category']
): Question[] {
  return questions.filter((q) => q.category === category);
}

// Get category display name
export function getCategoryDisplayName(category: Question['category']): string {
  const names: Record<Question['category'], string> = {
    'tools-workflows': 'Tools & Workflows',
    'shipping-building': 'Shipping & Building',
    'takes-opinions': 'Takes & Opinions',
    'tips-hacks': 'Tips & Hacks',
  };
  return names[category];
}

// Get category color
export function getCategoryColor(category: Question['category']): string {
  const colors: Record<Question['category'], string> = {
    'tools-workflows': 'bg-blue-500',
    'shipping-building': 'bg-green-500',
    'takes-opinions': 'bg-purple-500',
    'tips-hacks': 'bg-orange-500',
  };
  return colors[category];
}
