'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Submission {
  id: string;
  questionId: string;
  questionText: string;
  userName: string;
  transcript: string;
  snippet: string;
  createdAt: string;
}

const SUBMISSIONS_KEY = 'mudita-voice-drops-submissions';

export default function AdminPage() {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    // Load from localStorage
    const stored = localStorage.getItem(SUBMISSIONS_KEY);
    if (stored) {
      setSubmissions(JSON.parse(stored));
    }
    setLoading(false);
  }, []);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const copyAllSnippets = () => {
    const allSnippets = submissions
      .map((s) => `**Q: ${s.questionText}**\n\n${s.snippet}`)
      .join('\n\n---\n\n');
    navigator.clipboard.writeText(allSnippets);
    setCopied('all');
    setTimeout(() => setCopied(null), 2000);
  };

  const clearSubmissions = () => {
    if (confirm('Are you sure you want to clear all submissions?')) {
      localStorage.removeItem(SUBMISSIONS_KEY);
      setSubmissions([]);
    }
  };

  const exportToCSV = () => {
    if (submissions.length === 0) return;

    // CSV header
    const headers = ['Date', 'User', 'Question', 'Transcript', 'Newsletter Snippet'];

    // Escape CSV values (handle commas, quotes, newlines)
    const escapeCSV = (str: string) => {
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    // Build CSV rows
    const rows = submissions.map((s) => [
      formatDate(s.createdAt),
      escapeCSV(s.userName),
      escapeCSV(s.questionText),
      escapeCSV(s.transcript),
      escapeCSV(s.snippet),
    ].join(','));

    // Combine header and rows
    const csv = [headers.join(','), ...rows].join('\n');

    // Download file
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `voice-drops-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading submissions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Voice Drops</h1>
              <p className="text-sm text-gray-500">
                {submissions.length} submission{submissions.length !== 1 ? 's' : ''}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <a
                href="/"
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
              >
                Back
              </a>
            </div>
          </div>

          {/* Actions */}
          {submissions.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-4">
              <button
                onClick={exportToCSV}
                className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors text-sm flex items-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Export CSV
              </button>
              <button
                onClick={copyAllSnippets}
                className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors text-sm"
              >
                {copied === 'all' ? 'Copied!' : 'Copy All Snippets'}
              </button>
              <button
                onClick={clearSubmissions}
                className="px-4 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors text-sm"
              >
                Clear All
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        {submissions.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
            <p className="text-gray-500 mb-4">No voice drops yet</p>
            <a
              href="/"
              className="inline-block px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
            >
              Record Your First Voice Drop
            </a>
          </div>
        ) : (
          <div className="space-y-4">
            {submissions.map((submission) => (
              <motion.div
                key={submission.id}
                className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                {/* Card header */}
                <div className="p-4 border-b border-gray-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-500">
                      {submission.userName} &bull; {formatDate(submission.createdAt)}
                    </span>
                    <button
                      onClick={() => setSelectedSubmission(submission)}
                      className="text-sm text-purple-600 hover:text-purple-700"
                    >
                      View Full
                    </button>
                  </div>
                  <p className="text-sm font-medium text-gray-900">
                    Q: {submission.questionText}
                  </p>
                </div>

                {/* Snippet */}
                <div className="p-4 bg-purple-50">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xs font-medium text-purple-700 uppercase tracking-wide">
                      Newsletter Snippet
                    </h3>
                    <button
                      onClick={() => copyToClipboard(submission.snippet, submission.id)}
                      className="text-xs text-purple-600 hover:text-purple-700"
                    >
                      {copied === submission.id ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-sm text-gray-800 whitespace-pre-wrap">
                    {submission.snippet}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </main>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedSubmission && (
          <motion.div
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedSubmission(null)}
          >
            <motion.div
              className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal header */}
              <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-900">Voice Drop Details</h2>
                <button
                  onClick={() => setSelectedSubmission(null)}
                  className="p-2 text-gray-400 hover:text-gray-600"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              {/* Modal content */}
              <div className="p-4 space-y-4">
                {/* Meta info */}
                <div className="text-sm text-gray-500">
                  {selectedSubmission.userName} &bull; {formatDate(selectedSubmission.createdAt)}
                </div>

                {/* Question */}
                <div className="bg-gray-50 rounded-lg p-3">
                  <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Question</h3>
                  <p className="text-gray-900">{selectedSubmission.questionText}</p>
                </div>

                {/* Transcript */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide">Transcript</h3>
                    <button
                      onClick={() => copyToClipboard(selectedSubmission.transcript, 'transcript')}
                      className="text-xs text-purple-600 hover:text-purple-700"
                    >
                      {copied === 'transcript' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">
                      {selectedSubmission.transcript}
                    </p>
                  </div>
                </div>

                {/* Newsletter Snippet */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide">Newsletter Snippet</h3>
                    <button
                      onClick={() => copyToClipboard(selectedSubmission.snippet, 'snippet')}
                      className="text-xs text-purple-600 hover:text-purple-700"
                    >
                      {copied === 'snippet' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <div className="bg-purple-50 border border-purple-100 rounded-lg p-3">
                    <p className="text-sm text-gray-800 whitespace-pre-wrap">
                      {selectedSubmission.snippet}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
