import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@supabase/supabase-js';

const VOICE_NOTES_BUCKET = 'voice-notes';
const USE_MOCK = process.env.USE_MOCK === 'true' || !process.env.OPENAI_API_KEY;

// Mock responses for demo mode
const MOCK_TRANSCRIPTS = [
  "I've been using Cursor IDE lately and it's completely changed how I write code. The AI integration is seamless and it actually understands context really well.",
  "One thing I learned recently is to ship smaller features more frequently. Instead of working on something for weeks, I break it into tiny pieces and get feedback faster.",
  "My hot take is that most productivity tools are actually productivity killers. I've gone back to just using a simple text file for my todos.",
  "The best debugging tip I have is to explain the problem out loud. Rubber duck debugging sounds silly but it works every time.",
  "I think the whole microservices trend went too far. A well-structured monolith is actually better for most teams.",
];

const MOCK_SNIPPETS = [
  "**Cursor IDE has become my secret weapon.** The AI integration isn't just a gimmick—it genuinely understands context and speeds up coding significantly. If you haven't tried it yet, it's worth checking out for the productivity boost alone.",
  "**Ship small, ship often.** Instead of disappearing for weeks on a feature, break it into tiny, shippable pieces. You'll get feedback faster, course-correct sooner, and actually feel the momentum of progress. Big releases are overrated.",
  "**Hot take: most productivity tools kill productivity.** After trying every app under the sun, I'm back to a simple text file for todos. No sync issues, no notifications, no friction. Sometimes the boring solution is the right one.",
  "**Rubber duck debugging actually works.** When stuck, explain the problem out loud—to a rubber duck, a pet, or just the void. The act of articulating the issue often reveals the solution. It sounds silly until you try it.",
  "**Microservices went too far.** For most teams, a well-structured monolith is simpler, faster to develop, and easier to debug. Don't let architecture astronauts convince you otherwise. Match your architecture to your team size.",
];

// Lazy initialization of clients
function getOpenAI() {
  return new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });
}

function getAnthropic() {
  return new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });
}

function getSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !key) {
    return null;
  }

  return createClient(url, key);
}

const SYSTEM_PROMPT = `You are a content editor transforming raw voice note transcripts into polished newsletter snippets. Your goal is to preserve the speaker's authentic voice while making the content clear, engaging, and ready for publication.

## Guidelines

### Voice & Tone
- Keep the speaker's personality and speaking style intact
- Preserve interesting phrases, metaphors, and expressions they use
- Don't make it sound overly formal or corporate
- Maintain any humor, enthusiasm, or passion that comes through

### Structure
- Create a compelling opening hook (1-2 sentences)
- Keep the main insight clear and actionable
- If relevant, include a specific example or story they mentioned
- End with a memorable takeaway or call-to-action

### Length
- Target 100-200 words
- If the original is very short, don't pad it—keep it punchy
- If very long, focus on the most valuable insight

### Formatting
- Use short paragraphs (2-3 sentences max)
- Bold key phrases sparingly for emphasis
- Can use bullet points if listing multiple items
- No headers needed for short snippets

### What to Fix
- Remove filler words (um, like, you know, basically)
- Fix grammar and incomplete sentences
- Clarify confusing references
- Cut repetition and tangents

### What to Keep
- Specific tools, names, or resources mentioned
- Concrete numbers or timeframes
- Personal anecdotes and examples
- Strong opinions and hot takes

## Output Format
Return ONLY the polished newsletter snippet, nothing else. No preamble, no explanation.`;

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const audioFile = formData.get('audio') as File;
    const voiceNoteId = formData.get('voiceNoteId') as string;
    const questionText = formData.get('questionText') as string;
    const userName = formData.get('userName') as string;
    const questionId = formData.get('questionId') as string;
    const userId = formData.get('userId') as string;

    if (!audioFile || !questionText) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Mock mode - return fake data for testing
    if (USE_MOCK) {
      const randomIndex = Math.floor(Math.random() * MOCK_TRANSCRIPTS.length);

      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      return NextResponse.json({
        transcript: MOCK_TRANSCRIPTS[randomIndex],
        snippet: MOCK_SNIPPETS[randomIndex],
        audioUrl: '',
        mock: true,
      });
    }

    const openai = getOpenAI();
    const anthropic = getAnthropic();
    const supabase = getSupabase();

    let audioUrl = '';

    // Step 1: Upload audio to Supabase Storage (if configured)
    if (supabase) {
      const fileName = `${userId || 'anonymous'}_${Date.now()}.webm`;
      const arrayBuffer = await audioFile.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(VOICE_NOTES_BUCKET)
        .upload(fileName, buffer, {
          contentType: 'audio/webm',
          upsert: false,
        });

      if (!uploadError && uploadData) {
        const { data: urlData } = supabase.storage
          .from(VOICE_NOTES_BUCKET)
          .getPublicUrl(uploadData.path);
        audioUrl = urlData.publicUrl;
      }
    }

    // Step 2: Transcribe with Whisper
    const transcription = await openai.audio.transcriptions.create({
      file: audioFile,
      model: 'whisper-1',
      response_format: 'text',
    });

    const transcript = transcription as unknown as string;

    // Step 3: Transform with Claude
    const userPrompt = `Transform this voice note into a newsletter snippet.

**Question asked:** "${questionText}"

**Speaker:** ${userName || 'Anonymous'}

**Raw transcript:**
${transcript}

Remember: Return ONLY the polished newsletter snippet.`;

    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: userPrompt,
        },
      ],
      system: SYSTEM_PROMPT,
    });

    const snippet =
      message.content[0].type === 'text' ? message.content[0].text : '';

    // Step 4: Save to database (if Supabase configured)
    if (supabase) {
      if (voiceNoteId) {
        await supabase
          .from('voice_notes')
          .update({
            audio_url: audioUrl,
            transcript,
            newsletter_snippet: snippet,
            status: 'completed',
            processed_at: new Date().toISOString(),
          })
          .eq('id', voiceNoteId);
      } else {
        await supabase.from('voice_notes').insert({
          question_id: questionId,
          user_id: userId,
          user_name: userName,
          audio_url: audioUrl,
          transcript,
          newsletter_snippet: snippet,
          status: 'completed',
          created_at: new Date().toISOString(),
          processed_at: new Date().toISOString(),
        });
      }
    }

    return NextResponse.json({
      transcript,
      snippet,
      audioUrl,
    });
  } catch (error) {
    console.error('Processing error:', error);

    // Fallback to mock on error
    const randomIndex = Math.floor(Math.random() * MOCK_TRANSCRIPTS.length);
    return NextResponse.json({
      transcript: MOCK_TRANSCRIPTS[randomIndex],
      snippet: MOCK_SNIPPETS[randomIndex],
      audioUrl: '',
      mock: true,
      fallback: true,
    });
  }
}
