import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

function getAnthropic() {
  return new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });
}

const SYSTEM_PROMPT = `You are a content editor transforming raw voice note transcripts into polished newsletter snippets. Your goal is to preserve the speaker's authentic voice while making the content clear, engaging, and ready for publication.

## Guidelines

### Voice & Tone
- Keep the speaker's personality and speaking style intact
- Preserve interesting phrases, metaphors, and expressions they use
- Don't make it sound overly formal or corporate
- Maintain any humor, enthusiasm, or passion that comes through

### Structure
- Create a compelling opening hook (1-2 sentences)
- Keep the main insight clear and actionable
- If relevant, include a specific example or story they mentioned
- End with a memorable takeaway or call-to-action

### Length
- Target 100-200 words
- If the original is very short, don't pad it—keep it punchy
- If very long, focus on the most valuable insight

### Formatting
- Use short paragraphs (2-3 sentences max)
- Bold key phrases sparingly for emphasis
- Can use bullet points if listing multiple items
- No headers needed for short snippets

### What to Fix
- Remove filler words (um, like, you know, basically)
- Fix grammar and incomplete sentences
- Clarify confusing references
- Cut repetition and tangents

### What to Keep
- Specific tools, names, or resources mentioned
- Concrete numbers or timeframes
- Personal anecdotes and examples
- Strong opinions and hot takes

## Output Format
Return ONLY the polished newsletter snippet, nothing else. No preamble, no explanation.`;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { transcript, questionText, userName } = body;

    if (!transcript || !questionText) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const anthropic = getAnthropic();

    const userPrompt = `Transform this voice note into a newsletter snippet.

**Question asked:** "${questionText}"

**Speaker:** ${userName || 'Anonymous'}

**Raw transcript:**
${transcript}

Remember: Return ONLY the polished newsletter snippet.`;

    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: userPrompt,
        },
      ],
      system: SYSTEM_PROMPT,
    });

    // Extract text from the response
    const snippet =
      message.content[0].type === 'text' ? message.content[0].text : '';

    return NextResponse.json({ snippet });
  } catch (error) {
    console.error('Transformation error:', error);
    return NextResponse.json(
      { error: 'Failed to transform content' },
      { status: 500 }
    );
  }
}
