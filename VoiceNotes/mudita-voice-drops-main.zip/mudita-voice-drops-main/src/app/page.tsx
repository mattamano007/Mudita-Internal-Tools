'use client';

import { useState, useEffect, useCallback } from 'react';
import { AnimatePresence } from 'framer-motion';
import { SwipeableCard } from '@/components/SwipeableCard';
import { VoiceRecorder } from '@/components/VoiceRecorder';
import { NameModal } from '@/components/NameModal';
import { SubmissionModal } from '@/components/SubmissionModal';
import { EmptyState } from '@/components/EmptyState';
import { useLocalUser } from '@/hooks/useLocalUser';
import { getRandomQuestions } from '@/lib/questions';
import { Question } from '@/types';

// Local storage key for submissions
const SUBMISSIONS_KEY = 'mudita-voice-drops-submissions';

interface Submission {
  id: string;
  questionId: string;
  questionText: string;
  userName: string;
  transcript: string;
  snippet: string;
  createdAt: string;
}

function saveSubmission(submission: Submission) {
  if (typeof window === 'undefined') return;

  const existing = localStorage.getItem(SUBMISSIONS_KEY);
  const submissions: Submission[] = existing ? JSON.parse(existing) : [];
  submissions.unshift(submission);
  localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
}

export default function Home() {
  const { user, isLoading, setUserName, addAnsweredQuestion, clearUser } = useLocalUser();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showRecorder, setShowRecorder] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState<
    'uploading' | 'processing' | 'success' | 'error' | null
  >(null);
  const [submissionError, setSubmissionError] = useState<string | undefined>();
  const [submissionResult, setSubmissionResult] = useState<{
    transcript: string;
    snippet: string;
  } | undefined>();

  // Load questions when user is available
  const loadQuestions = useCallback(() => {
    if (user) {
      const newQuestions = getRandomQuestions(user.answeredQuestionIds, 10);
      setQuestions(newQuestions);
      setCurrentIndex(0);
    }
  }, [user]);

  useEffect(() => {
    loadQuestions();
  }, [loadQuestions]);

  const currentQuestion = questions[currentIndex];
  const nextQuestion = questions[currentIndex + 1];

  const handleSwipeLeft = () => {
    // Skip question
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Load more questions
      loadQuestions();
    }
  };

  const handleSwipeRight = () => {
    // Record answer
    setShowRecorder(true);
  };

  const handleRecorderCancel = () => {
    setShowRecorder(false);
  };

  const handleRecorderSubmit = async (audioBlob: Blob) => {
    setShowRecorder(false);
    setSubmissionStatus('uploading');
    setSubmissionResult(undefined);

    try {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'recording.webm');
      formData.append('questionText', currentQuestion.text);
      formData.append('questionId', currentQuestion.id);
      formData.append('userName', user?.name || 'Anonymous');
      formData.append('userId', user?.id || 'anonymous');

      setSubmissionStatus('processing');

      const response = await fetch('/api/process', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to process voice note');
      }

      const data = await response.json();

      // Store the result
      setSubmissionResult({
        transcript: data.transcript,
        snippet: data.snippet,
      });

      // Save to local storage
      saveSubmission({
        id: `sub_${Date.now()}`,
        questionId: currentQuestion.id,
        questionText: currentQuestion.text,
        userName: user?.name || 'Anonymous',
        transcript: data.transcript,
        snippet: data.snippet,
        createdAt: new Date().toISOString(),
      });

      // Mark question as answered
      addAnsweredQuestion(currentQuestion.id);

      setSubmissionStatus('success');
    } catch (error) {
      console.error('Submission error:', error);
      setSubmissionError(
        error instanceof Error ? error.message : 'Something went wrong'
      );
      setSubmissionStatus('error');
    }
  };

  const handleSubmissionClose = () => {
    if (submissionStatus === 'success') {
      // Move to next question
      if (currentIndex < questions.length - 1) {
        setCurrentIndex((prev) => prev + 1);
      } else {
        loadQuestions();
      }
    }
    setSubmissionStatus(null);
    setSubmissionError(undefined);
    setSubmissionResult(undefined);
  };

  const handleReset = () => {
    clearUser();
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Name input
  if (!user) {
    return <NameModal onSubmit={setUserName} />;
  }

  // Empty state
  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header userName={user.name} onAdminClick={() => {}} />
        <EmptyState
          answeredCount={user.answeredQuestionIds.length}
          onReset={handleReset}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <Header userName={user.name} />

      {/* Main content */}
      <main className="flex-1 relative overflow-hidden">
        {/* Card stack */}
        <div className="absolute inset-0">
          {/* Background card */}
          {nextQuestion && (
            <SwipeableCard
              key={nextQuestion.id}
              question={nextQuestion}
              onSwipeLeft={() => {}}
              onSwipeRight={() => {}}
              isTopCard={false}
            />
          )}

          {/* Top card */}
          {currentQuestion && (
            <SwipeableCard
              key={currentQuestion.id}
              question={currentQuestion}
              onSwipeLeft={handleSwipeLeft}
              onSwipeRight={handleSwipeRight}
              isTopCard={true}
            />
          )}
        </div>
      </main>

      {/* Bottom action buttons */}
      <div className="p-6 pb-10 safe-area-inset-bottom flex justify-center gap-6">
        <button
          onClick={handleSwipeLeft}
          className="w-16 h-16 bg-white rounded-full shadow-lg flex items-center justify-center text-red-500 hover:bg-red-50 transition-colors"
          aria-label="Skip question"
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>

        <button
          onClick={handleSwipeRight}
          className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full shadow-lg flex items-center justify-center text-white hover:opacity-90 transition-opacity"
          aria-label="Record answer"
        >
          <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"
            />
          </svg>
        </button>

        <button
          onClick={handleSwipeLeft}
          className="w-16 h-16 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-400 hover:bg-gray-50 transition-colors"
          aria-label="Skip question"
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M13 5l7 7-7 7M5 5l7 7-7 7"
            />
          </svg>
        </button>
      </div>

      {/* Progress indicator */}
      <div className="pb-6 flex justify-center gap-1">
        {questions.slice(0, 5).map((_, index) => (
          <div
            key={index}
            className={`w-2 h-2 rounded-full transition-colors ${
              index === currentIndex ? 'bg-purple-500' : 'bg-gray-300'
            }`}
          />
        ))}
        {questions.length > 5 && (
          <div className="w-2 h-2 rounded-full bg-gray-300" />
        )}
      </div>

      {/* Voice Recorder Modal */}
      <AnimatePresence>
        {showRecorder && currentQuestion && (
          <VoiceRecorder
            question={currentQuestion}
            onSubmit={handleRecorderSubmit}
            onCancel={handleRecorderCancel}
          />
        )}
      </AnimatePresence>

      {/* Submission Modal */}
      <AnimatePresence>
        {submissionStatus && (
          <SubmissionModal
            status={submissionStatus}
            onClose={handleSubmissionClose}
            error={submissionError}
            result={submissionResult}
            questionText={currentQuestion?.text}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function Header({ userName }: { userName: string; onAdminClick?: () => void }) {
  return (
    <header className="p-4 flex items-center justify-between">
      <div>
        <h1 className="text-lg font-bold text-gray-900">Voice Drops</h1>
        <p className="text-sm text-gray-500">Hi, {userName}</p>
      </div>
      <a
        href="/admin"
        className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
        aria-label="Admin panel"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
          />
        </svg>
      </a>
    </header>
  );
}
