'use client';

import { useState } from 'react';
import { motion, useMotionValue, useTransform, PanInfo, animate } from 'framer-motion';
import { Question } from '@/types';
import { getCategoryDisplayName, getCategoryColor } from '@/lib/questions';

interface SwipeableCardProps {
  question: Question;
  onSwipeLeft: () => void;
  onSwipeRight: () => void;
  isTopCard?: boolean;
}

export function SwipeableCard({
  question,
  onSwipeLeft,
  onSwipeRight,
  isTopCard = false,
}: SwipeableCardProps) {
  const [exitDirection, setExitDirection] = useState<'left' | 'right' | null>(null);
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 0, 200], [-15, 0, 15]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0.5, 1, 1, 1, 0.5]);

  // Overlay indicators
  const skipOpacity = useTransform(x, [-150, -50, 0], [1, 0, 0]);
  const recordOpacity = useTransform(x, [0, 50, 150], [0, 0, 1]);

  const handleDragEnd = (_: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const threshold = 80; // Lowered threshold for easier swiping
    const velocity = info.velocity.x;
    const offset = info.offset.x;

    // Check both offset and velocity for better UX
    if (offset > threshold || velocity > 500) {
      // Swipe right - animate off screen then trigger callback
      setExitDirection('right');
      animate(x, 500, { type: 'spring', stiffness: 300, damping: 30 }).then(() => {
        onSwipeRight();
      });
    } else if (offset < -threshold || velocity < -500) {
      // Swipe left - animate off screen then trigger callback
      setExitDirection('left');
      animate(x, -500, { type: 'spring', stiffness: 300, damping: 30 }).then(() => {
        onSwipeLeft();
      });
    } else {
      // Snap back to center
      animate(x, 0, { type: 'spring', stiffness: 500, damping: 30 });
    }
  };

  return (
    <motion.div
      className={`absolute inset-4 ${isTopCard ? 'z-10' : 'z-0'} touch-pan-y`}
      style={{ x, rotate, opacity }}
      drag={isTopCard ? 'x' : false}
      dragConstraints={{ left: -500, right: 500 }}
      dragElastic={0.9}
      onDragEnd={handleDragEnd}
      initial={{ scale: isTopCard ? 1 : 0.95, y: isTopCard ? 0 : 10 }}
      animate={{
        scale: isTopCard ? 1 : 0.95,
        y: isTopCard ? 0 : 10,
        opacity: exitDirection ? 0 : 1
      }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
    >
      <div className="relative h-full bg-white rounded-3xl shadow-xl overflow-hidden">
        {/* Skip indicator */}
        <motion.div
          className="absolute top-6 right-6 z-20 px-4 py-2 border-4 border-red-500 rounded-lg rotate-12"
          style={{ opacity: skipOpacity }}
        >
          <span className="text-2xl font-bold text-red-500">SKIP</span>
        </motion.div>

        {/* Record indicator */}
        <motion.div
          className="absolute top-6 left-6 z-20 px-4 py-2 border-4 border-green-500 rounded-lg -rotate-12"
          style={{ opacity: recordOpacity }}
        >
          <span className="text-2xl font-bold text-green-500">RECORD</span>
        </motion.div>

        {/* Card content */}
        <div className="flex flex-col h-full p-6 pt-20">
          {/* Category badge */}
          <div className="mb-6">
            <span
              className={`inline-block px-3 py-1 text-sm font-medium text-white rounded-full ${getCategoryColor(
                question.category
              )}`}
            >
              {getCategoryDisplayName(question.category)}
            </span>
          </div>

          {/* Question text */}
          <div className="flex-1 flex items-center justify-center">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 text-center leading-relaxed">
              {question.text}
            </h2>
          </div>

          {/* Follow-up hint */}
          {question.followUp && (
            <div className="mt-4 p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-600 text-center">
                <span className="font-medium">Hint:</span> {question.followUp}
              </p>
            </div>
          )}

          {/* Swipe instructions */}
          <div className="mt-6 flex justify-between text-sm text-gray-400">
            <div className="flex items-center gap-2">
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
              <span>Skip</span>
            </div>
            <div className="flex items-center gap-2">
              <span>Record</span>
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M14 5l7 7m0 0l-7 7m7-7H3"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
