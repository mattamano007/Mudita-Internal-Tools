'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface SubmissionResult {
  transcript: string;
  snippet: string;
}

interface SubmissionModalProps {
  status: 'uploading' | 'processing' | 'success' | 'error';
  onClose: () => void;
  error?: string;
  result?: SubmissionResult;
  questionText?: string;
}

export function SubmissionModal({ status, onClose, error, result, questionText }: SubmissionModalProps) {
  const [copied, setCopied] = useState<'transcript' | 'snippet' | null>(null);

  const copyToClipboard = (text: string, type: 'transcript' | 'snippet') => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  const messages = {
    uploading: {
      title: 'Uploading...',
      subtitle: 'Sending your voice drop',
      icon: (
        <motion.div
          className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full"
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
        />
      ),
    },
    processing: {
      title: 'Processing...',
      subtitle: 'Transcribing and transforming your content',
      icon: (
        <motion.div
          className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full"
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
        />
      ),
    },
    success: {
      title: 'Success!',
      subtitle: 'Your voice drop has been processed',
      icon: (
        <motion.div
          className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 10 }}
        >
          <motion.svg
            className="w-6 h-6 text-white"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M5 13l4 4L19 7"
            />
          </motion.svg>
        </motion.div>
      ),
    },
    error: {
      title: 'Oops!',
      subtitle: error || 'Something went wrong. Please try again.',
      icon: (
        <motion.div
          className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 10 }}
        >
          <svg
            className="w-8 h-8 text-white"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </motion.div>
      ),
    },
  };

  const current = messages[status];
  const canClose = status === 'success' || status === 'error';
  const showResult = status === 'success' && result;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className={`w-full bg-white rounded-2xl p-6 ${showResult ? 'max-w-lg' : 'max-w-sm'}`}
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
        >
          {/* Header */}
          <div className={`flex items-center gap-4 ${showResult ? 'mb-4' : 'flex-col text-center mb-6'}`}>
            <div className="flex justify-center">{current.icon}</div>
            <div>
              <h2 className={`font-bold text-gray-900 ${showResult ? 'text-xl' : 'text-2xl'}`}>{current.title}</h2>
              {!showResult && <p className="text-gray-600 mt-2">{current.subtitle}</p>}
            </div>
          </div>

          {/* Result content */}
          {showResult && (
            <div className="space-y-4 mb-6">
              {/* Question */}
              {questionText && (
                <div className="text-sm text-gray-500 bg-gray-50 p-3 rounded-lg">
                  <span className="font-medium">Q:</span> {questionText}
                </div>
              )}

              {/* Transcript */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-gray-700">Transcript</h3>
                  <button
                    onClick={() => copyToClipboard(result.transcript, 'transcript')}
                    className="text-xs text-purple-600 hover:text-purple-700"
                  >
                    {copied === 'transcript' ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 max-h-24 overflow-y-auto">
                  <p className="text-sm text-gray-600">{result.transcript}</p>
                </div>
              </div>

              {/* Newsletter Snippet */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-gray-700">Newsletter Snippet</h3>
                  <button
                    onClick={() => copyToClipboard(result.snippet, 'snippet')}
                    className="text-xs text-purple-600 hover:text-purple-700"
                  >
                    {copied === 'snippet' ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <div className="bg-purple-50 border border-purple-100 rounded-lg p-3 max-h-32 overflow-y-auto">
                  <p className="text-sm text-gray-800 whitespace-pre-wrap">{result.snippet}</p>
                </div>
              </div>
            </div>
          )}

          {/* Action buttons */}
          {canClose && (
            <div className="flex gap-3">
              {showResult && (
                <a
                  href="/admin"
                  className="flex-1 py-3 rounded-xl font-medium text-center bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
                >
                  View All
                </a>
              )}
              <button
                onClick={onClose}
                className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                  status === 'success'
                    ? 'bg-green-500 text-white hover:bg-green-600'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {status === 'success' ? 'Next Question' : 'Try Again'}
              </button>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
