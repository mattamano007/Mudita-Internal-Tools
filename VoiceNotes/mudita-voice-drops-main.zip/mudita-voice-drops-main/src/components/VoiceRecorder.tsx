'use client';

import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useVoiceRecorder } from '@/hooks/useVoiceRecorder';
import { Question } from '@/types';

interface VoiceRecorderProps {
  question: Question;
  onSubmit: (audioBlob: Blob) => void;
  onCancel: () => void;
}

export function VoiceRecorder({ question, onSubmit, onCancel }: VoiceRecorderProps) {
  const {
    state,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    resetRecording,
    isSupported,
  } = useVoiceRecorder();

  // Auto-start recording when component mounts
  useEffect(() => {
    if (isSupported && !state.isRecording && !state.audioBlob) {
      startRecording();
    }
  }, [isSupported, startRecording, state.isRecording, state.audioBlob]);

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSubmit = () => {
    if (state.audioBlob) {
      onSubmit(state.audioBlob);
    }
  };

  const handleReRecord = () => {
    resetRecording();
    setTimeout(() => startRecording(), 100);
  };

  if (!isSupported) {
    return (
      <div className="fixed inset-0 z-50 bg-gray-900 flex items-center justify-center p-6">
        <div className="text-center text-white">
          <div className="text-6xl mb-4">:-(</div>
          <h2 className="text-xl font-bold mb-2">Recording Not Supported</h2>
          <p className="text-gray-400 mb-6">
            Your browser doesn&apos;t support audio recording. Please try a modern browser
            like Chrome, Firefox, or Safari.
          </p>
          <button
            onClick={onCancel}
            className="px-6 py-3 bg-white text-gray-900 rounded-full font-medium"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      className="fixed inset-0 z-50 bg-gray-900 flex flex-col"
      initial={{ opacity: 0, y: '100%' }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
    >
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <button
          onClick={() => {
            stopRecording();
            onCancel();
          }}
          className="p-2 text-gray-400 hover:text-white transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
        <span className="text-gray-400 text-sm">Voice Drop</span>
        <div className="w-10" /> {/* Spacer */}
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6">
        {/* Question */}
        <div className="text-center mb-8">
          <p className="text-gray-400 text-sm mb-2">Responding to:</p>
          <h2 className="text-xl md:text-2xl font-bold text-white leading-relaxed">
            {question.text}
          </h2>
        </div>

        {/* Waveform visualization */}
        <div className="w-full max-w-md h-24 mb-8 flex items-center justify-center gap-1">
          <AnimatePresence mode="wait">
            {state.isRecording && !state.isPaused ? (
              // Live waveform
              state.waveformData.map((value, index) => (
                <motion.div
                  key={index}
                  className="w-1 bg-red-500 rounded-full"
                  initial={{ height: 4 }}
                  animate={{ height: Math.max(4, value * 80) }}
                  transition={{ type: 'spring', stiffness: 300, damping: 15 }}
                />
              ))
            ) : state.audioBlob ? (
              // Completed waveform (static)
              <motion.div
                className="flex items-center justify-center gap-1"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {Array.from({ length: 50 }).map((_, index) => (
                  <div
                    key={index}
                    className="w-1 bg-green-500 rounded-full"
                    style={{
                      height: `${Math.random() * 60 + 10}px`,
                    }}
                  />
                ))}
              </motion.div>
            ) : (
              // Waiting/paused state
              <motion.div
                className="flex items-center justify-center gap-1"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {Array.from({ length: 50 }).map((_, index) => (
                  <div key={index} className="w-1 h-1 bg-gray-600 rounded-full" />
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Duration */}
        <div className="text-4xl font-mono text-white mb-8">
          {formatDuration(state.duration)}
        </div>

        {/* Recording indicator */}
        <AnimatePresence>
          {state.isRecording && !state.isPaused && (
            <motion.div
              className="flex items-center gap-2 text-red-500 mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className="w-3 h-3 bg-red-500 rounded-full"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 1 }}
              />
              <span className="text-sm font-medium">Recording...</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Controls */}
      <div className="p-6 pb-10 safe-area-inset-bottom">
        {!state.audioBlob ? (
          // Recording controls
          <div className="flex items-center justify-center gap-6">
            {/* Pause/Resume */}
            {state.isRecording && (
              <button
                onClick={state.isPaused ? resumeRecording : pauseRecording}
                className="w-14 h-14 flex items-center justify-center bg-gray-700 rounded-full text-white hover:bg-gray-600 transition-colors"
              >
                {state.isPaused ? (
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                ) : (
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
                  </svg>
                )}
              </button>
            )}

            {/* Stop button */}
            <button
              onClick={stopRecording}
              className="w-20 h-20 flex items-center justify-center bg-red-500 rounded-full hover:bg-red-600 transition-colors"
              disabled={!state.isRecording}
            >
              <div className="w-8 h-8 bg-white rounded-sm" />
            </button>
          </div>
        ) : (
          // Review controls
          <div className="flex items-center justify-center gap-4">
            {/* Re-record */}
            <button
              onClick={handleReRecord}
              className="flex-1 py-4 px-6 bg-gray-700 rounded-full text-white font-medium hover:bg-gray-600 transition-colors"
            >
              Re-record
            </button>

            {/* Submit */}
            <button
              onClick={handleSubmit}
              className="flex-1 py-4 px-6 bg-green-500 rounded-full text-white font-medium hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
              Submit
            </button>
          </div>
        )}

        {/* Audio preview */}
        {state.audioUrl && (
          <div className="mt-4">
            <audio src={state.audioUrl} controls className="w-full" />
          </div>
        )}
      </div>
    </motion.div>
  );
}
