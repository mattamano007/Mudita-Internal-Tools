'use client';

import { motion } from 'framer-motion';

interface EmptyStateProps {
  answeredCount: number;
  onReset?: () => void;
}

export function EmptyState({ answeredCount, onReset }: EmptyStateProps) {
  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[60vh] px-6 text-center"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <motion.div
        className="w-24 h-24 mb-6 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', delay: 0.2 }}
      >
        <svg
          className="w-12 h-12 text-white"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M5 13l4 4L19 7"
          />
        </svg>
      </motion.div>

      <h2 className="text-2xl font-bold text-gray-900 mb-2">All caught up!</h2>

      <p className="text-gray-600 mb-2">
        You&apos;ve answered {answeredCount} question{answeredCount !== 1 ? 's' : ''}.
      </p>

      <p className="text-gray-500 text-sm mb-8">
        Check back later for new questions.
      </p>

      {onReset && (
        <button
          onClick={onReset}
          className="px-6 py-3 bg-gray-100 text-gray-700 rounded-full font-medium hover:bg-gray-200 transition-colors"
        >
          Start Over
        </button>
      )}
    </motion.div>
  );
}
