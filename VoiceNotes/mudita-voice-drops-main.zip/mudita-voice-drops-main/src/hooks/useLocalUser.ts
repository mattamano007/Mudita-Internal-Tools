'use client';

import { useState, useEffect, useCallback } from 'react';
import { User } from '@/types';

const LOCAL_STORAGE_KEY = 'mudita-voice-drops-user';

interface UseLocalUserReturn {
  user: User | null;
  isLoading: boolean;
  setUserName: (name: string) => void;
  addAnsweredQuestion: (questionId: string) => void;
  clearUser: () => void;
}

function generateUserId(): string {
  return `user_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

export function useLocalUser(): UseLocalUserReturn {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user from localStorage on mount
  useEffect(() => {
    if (typeof window === 'undefined') return;

    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (stored) {
        const parsedUser = JSON.parse(stored) as User;
        setUser(parsedUser);
      }
    } catch (error) {
      console.error('Error loading user from localStorage:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Save user to localStorage whenever it changes
  useEffect(() => {
    if (typeof window === 'undefined' || user === null) return;

    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(user));
    } catch (error) {
      console.error('Error saving user to localStorage:', error);
    }
  }, [user]);

  const setUserName = useCallback((name: string) => {
    const newUser: User = {
      id: generateUserId(),
      name: name.trim(),
      answeredQuestionIds: [],
      createdAt: new Date().toISOString(),
    };
    setUser(newUser);
  }, []);

  const addAnsweredQuestion = useCallback((questionId: string) => {
    setUser((prev) => {
      if (!prev) return prev;
      if (prev.answeredQuestionIds.includes(questionId)) return prev;

      return {
        ...prev,
        answeredQuestionIds: [...prev.answeredQuestionIds, questionId],
      };
    });
  }, []);

  const clearUser = useCallback(() => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
    setUser(null);
  }, []);

  return {
    user,
    isLoading,
    setUserName,
    addAnsweredQuestion,
    clearUser,
  };
}
