# Mudita VC Sourcing Platform

## Overview
A comprehensive Product Hunt VC Sourcing & Scoring Platform with AI-powered research and scoring capabilities. The platform scrapes Product Hunt launches, automatically researches startups using AI (Anthropic Claude), and scores them using the Mudita 13-Criteria Scoring System across 7 sections: Market Environment, Competition, Cost/Difficulty, Product Need, Financial Return, Founder/Team, and Traction.

## Recent Changes
- **Jan 20, 2026**: Steve Jobs-style UI simplification - "Less is More"
  - Reduced from 7 pages to 2 essential pages (Dashboard + StartupDetail)
  - Dashboard: one timeframe dropdown, one scoring mode toggle (Quick/Deep), one Fetch button
  - Startup rows show: rank, name, tagline, stage badge, score
  - StartupDetail: single clean page with overview, score breakdown, research, notes
  - Removed: Analytics page, Pipeline page, Scoring Config page, Settings page
  - Removed: Complex scoring selector cards, business model filter, min score slider
  - Removed: Multi-step processing UI, tabs navigation, accordions

- **Jan 8, 2026**: Mudita 13-Criteria Scoring System implementation
  - Database schema updated with rawScores, sectionScores, normalizedScores, weightedScores JSONB fields
  - Added scoringConfig and scoringProfiles tables for customizable weight profiles
  - AI scoring prompt includes all 13 criteria with 1-10 scale definitions
  - 6-step scoring calculation: raw scores -> section averages -> normalization -> weighting -> final 0-100 score

- **Jan 7, 2026**: Initial build with complete frontend and backend
  - Dark purple/navy glassmorphism theme with particle background
  - Product Hunt API integration with OAuth2
  - AI-powered research and scoring via Anthropic Claude

## Project Architecture

### Frontend (`client/src/`)
- **React + TypeScript** with Vite bundler
- **Routing**: wouter (lightweight router)
- **State Management**: TanStack Query for server state
- **UI Components**: Shadcn/ui with Radix primitives
- **Styling**: Tailwind CSS with glassmorphism effects
- **Charts**: Recharts for data visualization

### Backend (`server/`)
- **Express.js** with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **AI Integration**: Anthropic Claude via Replit AI Integrations

### Key Files
- `shared/schema.ts` - Database models (startups, users, scoring_criteria, interactions)
- `server/routes.ts` - API endpoints
- `server/storage.ts` - Database storage class
- `client/src/App.tsx` - Main app with routing
- `client/src/index.css` - Theme colors and glassmorphism styles

### Database Schema
- **users**: Team members (id, name, email, role)
- **startups**: Product Hunt launches (name, tagline, scores, pipeline stage, research data)
- **scoring_criteria**: Configurable scoring categories and weights
- **interactions**: Notes and activity log per startup
- **research_findings**: AI research results

### API Endpoints
- `GET/POST /api/startups` - List/create startups
- `GET/PATCH/DELETE /api/startups/:id` - Single startup CRUD
- `POST /api/startups/:id/research` - AI research
- `POST /api/startups/:id/score` - AI scoring
- `POST /api/startups/:id/memo` - Generate investment memo
- `GET/POST /api/startups/:id/interactions` - Notes/activity
- `GET/PUT /api/scoring-criteria` - Scoring config
- `POST /api/scrape` - Mock Product Hunt scrape

## Design Decisions
- **Theme**: Dark purple/navy gradient with glassmorphism cards
- **Score Colors**: Green (80+), Yellow (60-79), Gray (<60)
- **Pipeline Stages**: discovered, high_potential, outreach, conversation, due_diligence, portfolio, declined
- **AI Integration**: Using Replit AI Integrations (no API key needed)

## Running the Project
The workflow `Start application` runs `npm run dev` which starts:
- Express backend on port 5000
- Vite dev server for frontend

## Database
Using PostgreSQL via Replit's built-in database. Run `npm run db:push` to sync schema changes.
