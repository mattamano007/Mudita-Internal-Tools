import {
  type User,
  type InsertUser,
  type Startup,
  type InsertStartup,
  type ScoringCriteria,
  type InsertScoringCriteria,
  type Interaction,
  type InsertInteraction,
  type ResearchFinding,
  type InsertResearchFinding,
  type ScoringConfigRecord,
  type InsertScoringConfig,
  type ScoringProfile,
  type InsertScoringProfile,
  users,
  startups,
  scoringCriteria,
  scoringConfig,
  scoringProfiles,
  interactions,
  researchFindings,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Startups
  getAllStartups(): Promise<Startup[]>;
  getStartup(id: number): Promise<Startup | undefined>;
  getStartupByProductHuntId(phId: string): Promise<Startup | undefined>;
  createStartup(startup: InsertStartup): Promise<Startup>;
  updateStartup(id: number, updates: Partial<InsertStartup>): Promise<Startup | undefined>;
  deleteStartup(id: number): Promise<void>;

  // Scoring Criteria
  getAllScoringCriteria(): Promise<ScoringCriteria[]>;
  getScoringCriteria(id: number): Promise<ScoringCriteria | undefined>;
  createScoringCriteria(criteria: InsertScoringCriteria): Promise<ScoringCriteria>;
  updateScoringCriteria(id: number, updates: Partial<InsertScoringCriteria>): Promise<ScoringCriteria | undefined>;
  deleteScoringCriteria(id: number): Promise<void>;
  replaceScoringCriteria(criteria: InsertScoringCriteria[]): Promise<ScoringCriteria[]>;

  // Interactions
  getInteractionsByStartup(startupId: number): Promise<Interaction[]>;
  createInteraction(interaction: InsertInteraction): Promise<Interaction>;

  // Research Findings
  getResearchFindingsByStartup(startupId: number): Promise<ResearchFinding[]>;
  createResearchFinding(finding: InsertResearchFinding): Promise<ResearchFinding>;

  // Scoring Config (new 13-criteria system)
  getAllScoringConfig(): Promise<ScoringConfigRecord[]>;
  getScoringConfigBySection(sectionCode: string): Promise<ScoringConfigRecord | undefined>;
  upsertScoringConfig(config: InsertScoringConfig): Promise<ScoringConfigRecord>;
  updateScoringConfigWeight(sectionCode: string, weight: number): Promise<ScoringConfigRecord | undefined>;

  // Scoring Profiles
  getAllScoringProfiles(): Promise<ScoringProfile[]>;
  getScoringProfile(id: number): Promise<ScoringProfile | undefined>;
  getDefaultScoringProfile(): Promise<ScoringProfile | undefined>;
  createScoringProfile(profile: InsertScoringProfile): Promise<ScoringProfile>;
  updateScoringProfile(id: number, updates: Partial<InsertScoringProfile>): Promise<ScoringProfile | undefined>;
  deleteScoringProfile(id: number): Promise<void>;
  setDefaultScoringProfile(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Startups
  async getAllStartups(): Promise<Startup[]> {
    return db.select().from(startups).orderBy(desc(startups.createdAt));
  }

  async getStartup(id: number): Promise<Startup | undefined> {
    const [startup] = await db.select().from(startups).where(eq(startups.id, id));
    return startup || undefined;
  }

  async getStartupByProductHuntId(phId: string): Promise<Startup | undefined> {
    const [startup] = await db.select().from(startups).where(eq(startups.productHuntId, phId));
    return startup || undefined;
  }

  async createStartup(startup: InsertStartup): Promise<Startup> {
    const [created] = await db.insert(startups).values(startup).returning();
    return created;
  }

  async updateStartup(id: number, updates: Partial<InsertStartup>): Promise<Startup | undefined> {
    const [updated] = await db
      .update(startups)
      .set({ ...updates, updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(eq(startups.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteStartup(id: number): Promise<void> {
    await db.delete(startups).where(eq(startups.id, id));
  }

  // Scoring Criteria
  async getAllScoringCriteria(): Promise<ScoringCriteria[]> {
    return db.select().from(scoringCriteria);
  }

  async getScoringCriteria(id: number): Promise<ScoringCriteria | undefined> {
    const [criteria] = await db.select().from(scoringCriteria).where(eq(scoringCriteria.id, id));
    return criteria || undefined;
  }

  async createScoringCriteria(criteria: InsertScoringCriteria): Promise<ScoringCriteria> {
    const [created] = await db.insert(scoringCriteria).values(criteria).returning();
    return created;
  }

  async updateScoringCriteria(id: number, updates: Partial<InsertScoringCriteria>): Promise<ScoringCriteria | undefined> {
    const [updated] = await db
      .update(scoringCriteria)
      .set(updates)
      .where(eq(scoringCriteria.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteScoringCriteria(id: number): Promise<void> {
    await db.delete(scoringCriteria).where(eq(scoringCriteria.id, id));
  }

  async replaceScoringCriteria(criteria: InsertScoringCriteria[]): Promise<ScoringCriteria[]> {
    await db.delete(scoringCriteria);
    if (criteria.length === 0) return [];
    const created = await db.insert(scoringCriteria).values(criteria).returning();
    return created;
  }

  // Interactions
  async getInteractionsByStartup(startupId: number): Promise<Interaction[]> {
    return db
      .select()
      .from(interactions)
      .where(eq(interactions.startupId, startupId))
      .orderBy(desc(interactions.createdAt));
  }

  async createInteraction(interaction: InsertInteraction): Promise<Interaction> {
    const [created] = await db.insert(interactions).values(interaction).returning();
    return created;
  }

  // Research Findings
  async getResearchFindingsByStartup(startupId: number): Promise<ResearchFinding[]> {
    return db
      .select()
      .from(researchFindings)
      .where(eq(researchFindings.startupId, startupId))
      .orderBy(desc(researchFindings.scrapedAt));
  }

  async createResearchFinding(finding: InsertResearchFinding): Promise<ResearchFinding> {
    const [created] = await db.insert(researchFindings).values(finding).returning();
    return created;
  }

  // Scoring Config (new 13-criteria system)
  async getAllScoringConfig(): Promise<ScoringConfigRecord[]> {
    return db.select().from(scoringConfig).orderBy(scoringConfig.sectionCode);
  }

  async getScoringConfigBySection(sectionCode: string): Promise<ScoringConfigRecord | undefined> {
    const [config] = await db.select().from(scoringConfig).where(eq(scoringConfig.sectionCode, sectionCode));
    return config || undefined;
  }

  async upsertScoringConfig(config: InsertScoringConfig): Promise<ScoringConfigRecord> {
    const existing = await this.getScoringConfigBySection(config.sectionCode);
    if (existing) {
      const [updated] = await db
        .update(scoringConfig)
        .set({ ...config, updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(scoringConfig.sectionCode, config.sectionCode))
        .returning();
      return updated;
    }
    const [created] = await db.insert(scoringConfig).values(config).returning();
    return created;
  }

  async updateScoringConfigWeight(sectionCode: string, weight: number): Promise<ScoringConfigRecord | undefined> {
    const [updated] = await db
      .update(scoringConfig)
      .set({ weight, updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(eq(scoringConfig.sectionCode, sectionCode))
      .returning();
    return updated || undefined;
  }

  // Scoring Profiles
  async getAllScoringProfiles(): Promise<ScoringProfile[]> {
    return db.select().from(scoringProfiles).orderBy(desc(scoringProfiles.createdAt));
  }

  async getScoringProfile(id: number): Promise<ScoringProfile | undefined> {
    const [profile] = await db.select().from(scoringProfiles).where(eq(scoringProfiles.id, id));
    return profile || undefined;
  }

  async getDefaultScoringProfile(): Promise<ScoringProfile | undefined> {
    const [profile] = await db.select().from(scoringProfiles).where(eq(scoringProfiles.isDefault, true));
    return profile || undefined;
  }

  async createScoringProfile(profile: InsertScoringProfile): Promise<ScoringProfile> {
    if (profile.isDefault) {
      await db.update(scoringProfiles).set({ isDefault: false });
    }
    const [created] = await db.insert(scoringProfiles).values(profile).returning();
    return created;
  }

  async updateScoringProfile(id: number, updates: Partial<InsertScoringProfile>): Promise<ScoringProfile | undefined> {
    if (updates.isDefault) {
      await db.update(scoringProfiles).set({ isDefault: false });
    }
    const [updated] = await db
      .update(scoringProfiles)
      .set(updates)
      .where(eq(scoringProfiles.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteScoringProfile(id: number): Promise<void> {
    await db.delete(scoringProfiles).where(eq(scoringProfiles.id, id));
  }

  async setDefaultScoringProfile(id: number): Promise<void> {
    await db.update(scoringProfiles).set({ isDefault: false });
    await db.update(scoringProfiles).set({ isDefault: true }).where(eq(scoringProfiles.id, id));
  }
}

export const storage = new DatabaseStorage();
