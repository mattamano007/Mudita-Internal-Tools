import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStartupSchema, insertInteractionSchema, insertScoringCriteriaSchema, insertScoringConfigSchema, insertScoringProfileSchema, MUDITA_SECTIONS, MUDITA_CRITERIA } from "@shared/schema";
import Anthropic from "@anthropic-ai/sdk";
import { z } from "zod";
import { scrapeProductHunt } from "./productHunt";

const anthropic = new Anthropic({
  apiKey: process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get all startups
  app.get("/api/startups", async (req, res) => {
    try {
      const startups = await storage.getAllStartups();
      res.json(startups);
    } catch (error) {
      console.error("Error fetching startups:", error);
      res.status(500).json({ error: "Failed to fetch startups" });
    }
  });

  // Get single startup
  app.get("/api/startups/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const startup = await storage.getStartup(id);
      if (!startup) {
        return res.status(404).json({ error: "Startup not found" });
      }
      res.json(startup);
    } catch (error) {
      console.error("Error fetching startup:", error);
      res.status(500).json({ error: "Failed to fetch startup" });
    }
  });

  // Create startup
  app.post("/api/startups", async (req, res) => {
    try {
      const validated = insertStartupSchema.parse(req.body);
      const startup = await storage.createStartup(validated);
      res.status(201).json(startup);
    } catch (error) {
      console.error("Error creating startup:", error);
      res.status(400).json({ error: "Invalid startup data" });
    }
  });

  // Update startup
  app.patch("/api/startups/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const startup = await storage.updateStartup(id, req.body);
      if (!startup) {
        return res.status(404).json({ error: "Startup not found" });
      }
      res.json(startup);
    } catch (error) {
      console.error("Error updating startup:", error);
      res.status(500).json({ error: "Failed to update startup" });
    }
  });

  // Delete startup
  app.delete("/api/startups/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteStartup(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting startup:", error);
      res.status(500).json({ error: "Failed to delete startup" });
    }
  });

  // Get interactions for startup
  app.get("/api/startups/:id/interactions", async (req, res) => {
    try {
      const startupId = parseInt(req.params.id);
      const interactions = await storage.getInteractionsByStartup(startupId);
      res.json(interactions);
    } catch (error) {
      console.error("Error fetching interactions:", error);
      res.status(500).json({ error: "Failed to fetch interactions" });
    }
  });

  // Create interaction
  app.post("/api/startups/:id/interactions", async (req, res) => {
    try {
      const startupId = parseInt(req.params.id);
      const validated = insertInteractionSchema.parse({
        ...req.body,
        startupId,
      });
      const interaction = await storage.createInteraction(validated);
      res.status(201).json(interaction);
    } catch (error) {
      console.error("Error creating interaction:", error);
      res.status(400).json({ error: "Invalid interaction data" });
    }
  });

  // AI Research endpoint
  app.post("/api/startups/:id/research", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const startup = await storage.getStartup(id);
      if (!startup) {
        return res.status(404).json({ error: "Startup not found" });
      }

      const prompt = `Analyze this startup and provide comprehensive research:

Startup: ${startup.name}
Website: ${startup.websiteUrl || "N/A"}
Description: ${startup.description || startup.tagline || "N/A"}

Research and return a JSON object with the following structure:
{
  "founders": [{"name": "string", "background": "string", "linkedIn": "optional url"}],
  "marketSize": "string estimate (e.g., $10B)",
  "competitors": ["competitor1", "competitor2"],
  "fundingStatus": "string (e.g., Seed, Pre-seed, Bootstrapped)",
  "tractionMetrics": {"users": "estimate", "revenue": "estimate if available"},
  "techStack": ["tech1", "tech2"],
  "pressCoverage": [{"title": "string", "url": "string", "date": "optional"}]
}

Based on the startup name and description, provide reasonable estimates and publicly available information. Be concise but informative.`;

      const message = await anthropic.messages.create({
        model: "claude-sonnet-4-5",
        max_tokens: 2048,
        messages: [{ role: "user", content: prompt }],
      });

      const content = message.content[0];
      if (content.type !== "text") {
        throw new Error("Unexpected response type");
      }

      let researchData;
      try {
        const jsonMatch = content.text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          researchData = JSON.parse(jsonMatch[0]);
        } else {
          researchData = {};
        }
      } catch {
        researchData = {};
      }

      const updated = await storage.updateStartup(id, { researchData });
      
      await storage.createResearchFinding({
        startupId: id,
        sourceType: "ai_research",
        dataExtracted: researchData,
        confidenceScore: 75,
      });

      res.json(updated);
    } catch (error) {
      console.error("Error researching startup:", error);
      res.status(500).json({ error: "Failed to research startup" });
    }
  });

  // AI Scoring endpoint - Mudita 13-Criteria System
  app.post("/api/startups/:id/score", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const startup = await storage.getStartup(id);
      if (!startup) {
        return res.status(404).json({ error: "Startup not found" });
      }

      // Get custom weights or use defaults
      const defaultWeights = { A: 20, B: 20, C: 20, D: 20, E: 20, F: 0, G: 0 };
      const profile = await storage.getDefaultScoringProfile();
      const weights = profile?.weights || defaultWeights;

      const prompt = `You are a VC analyst scoring a startup using the Mudita Scoring System.

For each of these 12 criteria, provide a score from 1-10 based on the research data:

SECTION A: MARKET ENVIRONMENT
1. TAM (Total Addressable Market)
   1 = <$100M, 2 = $100M-$150M, 3 = $150M-$250M, 4 = $250M-$400M, 
   5 = $400M-$600M, 6 = $600M-$800M, 7 = $800M-$1B, 8 = $1B-$3B, 
   9 = $3B-$10B, 10 = >$10B

2. Market Growth Rate
   1 = <2%, 2 = 2%, 3 = 3%, 4 = 4%, 5 = 5-6%, 6 = 7-8%, 
   7 = 9-10%, 8 = 11-15%, 9 = 16-20%, 10 = >20%

SECTION B: COMPETITION
3. Capital Raised by Competitors (inverse - less capital raised by competitors is better)
   1 = >$1B, 2 = $500M-$1B, 3 = $200M-$500M, 4 = $100M-$200M,
   5 = $50M-$100M, 6 = $20M-$50M, 7 = $10M-$20M, 8 = $5M-$10M,
   9 = $1M-$5M, 10 = <$1M

4. Competitor Landscape (fewer competitors is better)
   1 = Many dominant players, 5 = Moderate competition, 10 = No competitors

5. Ease of Copying / Moat (harder to copy is better)
   1 = Trivially copyable, 5 = Moderate defensibility, 10 = Impossible to copy

6. Winner-Takes-All Dynamics (unclaimed WTA opportunity is best)
   1 = WTA already won, 5 = Moderate WTA dynamics, 10 = Perfect WTA unclaimed

SECTION C: COST / DIFFICULTY
7. Capital Required (less capital needed is better)
   1 = >$10M, 2 = $5M-$10M, 3 = $2M-$5M, 4 = $1M-$2M,
   5 = $500K-$1M, 6 = $250K-$500K, 7 = $100K-$250K, 8 = $50K-$100K,
   9 = $25K-$50K, 10 = <$25K

8. Technology Required (simpler tech is better)
   1 = Miracle tech needed, 5 = Moderate complexity, 10 = Commodity tech

9. GTM Difficulty (easier GTM is better)
   1 = Very hard GTM, 5 = Standard sales process, 10 = Viral/self-serve

10. Land and Expand Potential
    1 = One-and-done, 5 = Moderate expansion, 10 = Continuous expansion

SECTION D: PRODUCT NEED
11. Problem Urgency
    1 = No clear problem, 5 = Clear value prop, 10 = Critical painkiller

SECTION E: FINANCIAL RETURN
12. Exit Likelihood (3-5 years)
    1 = Very unlikely, 5 = Average, 10 = Extremely likely

Startup being analyzed:
Name: ${startup.name}
Tagline: ${startup.tagline || "N/A"}
Description: ${startup.description || "N/A"}
Website: ${startup.websiteUrl || "N/A"}
Product Hunt Votes: ${startup.votes || 0}
Comments: ${startup.comments || 0}
Research Data: ${JSON.stringify(startup.researchData || {})}

Return ONLY a valid JSON object with this exact structure (no markdown, no explanation):
{
  "raw_scores": {
    "tam": {"score": 7, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "market_growth": {"score": 8, "justification": "brief explanation", "confidence": "High", "sources": []},
    "competitor_capital": {"score": 6, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "competitor_landscape": {"score": 7, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "moat": {"score": 5, "justification": "brief explanation", "confidence": "Low", "sources": []},
    "winner_takes_all": {"score": 6, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "capital_required": {"score": 8, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "technology_required": {"score": 7, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "gtm_difficulty": {"score": 6, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "land_expand": {"score": 7, "justification": "brief explanation", "confidence": "Low", "sources": []},
    "problem_urgency": {"score": 8, "justification": "brief explanation", "confidence": "Medium", "sources": []},
    "exit_likelihood": {"score": 6, "justification": "brief explanation", "confidence": "Low", "sources": []}
  },
  "red_flags": ["List any concerns or risks"],
  "overall_assessment": "Brief 2-3 sentence investment thesis"
}

Be realistic and balanced. Use "Low" confidence when information is limited.`;

      const message = await anthropic.messages.create({
        model: "claude-sonnet-4-5",
        max_tokens: 2048,
        messages: [{ role: "user", content: prompt }],
      });

      const content = message.content[0];
      if (content.type !== "text") {
        throw new Error("Unexpected response type");
      }

      let aiResponse;
      try {
        const jsonMatch = content.text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          aiResponse = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error("No JSON found in response");
        }
      } catch {
        return res.status(500).json({ error: "Failed to parse AI scoring response" });
      }

      const rawScores = aiResponse.raw_scores;

      // Calculate section scores (average of criteria in each section)
      const sectionScores = {
        A_market_environment: ((rawScores.tam?.score || 5) + (rawScores.market_growth?.score || 5)) / 2,
        B_competition: ((rawScores.competitor_capital?.score || 5) + (rawScores.competitor_landscape?.score || 5) + 
                        (rawScores.moat?.score || 5) + (rawScores.winner_takes_all?.score || 5)) / 4,
        C_cost_difficulty: ((rawScores.capital_required?.score || 5) + (rawScores.technology_required?.score || 5) + 
                           (rawScores.gtm_difficulty?.score || 5) + (rawScores.land_expand?.score || 5)) / 4,
        D_product_need: rawScores.problem_urgency?.score || 5,
        E_financial_return: rawScores.exit_likelihood?.score || 5,
        F_founder_team: null,
        G_traction: null,
      };

      // Normalized scores (already on 1-10 scale)
      const normalizedScores = { ...sectionScores };

      // Apply weights and calculate weighted scores (scaled to 0-100 contribution)
      const weightedScores = {
        A_market_environment: (sectionScores.A_market_environment || 0) * (weights.A / 100) * 10,
        B_competition: (sectionScores.B_competition || 0) * (weights.B / 100) * 10,
        C_cost_difficulty: (sectionScores.C_cost_difficulty || 0) * (weights.C / 100) * 10,
        D_product_need: (sectionScores.D_product_need || 0) * (weights.D / 100) * 10,
        E_financial_return: (sectionScores.E_financial_return || 0) * (weights.E / 100) * 10,
        F_founder_team: null,
        G_traction: null,
      };

      // Calculate final score (0-100)
      const scoreTotal = Math.round(
        (weightedScores.A_market_environment || 0) +
        (weightedScores.B_competition || 0) +
        (weightedScores.C_cost_difficulty || 0) +
        (weightedScores.D_product_need || 0) +
        (weightedScores.E_financial_return || 0)
      );

      // Create legacy scoreBreakdown for backwards compatibility
      const scoreBreakdown = {
        team: { score: Math.round(sectionScores.A_market_environment * 2), justification: "Derived from market analysis" },
        market: { score: Math.round(sectionScores.A_market_environment * 2), justification: rawScores.tam?.justification || "" },
        product: { score: Math.round(sectionScores.D_product_need * 2), justification: rawScores.problem_urgency?.justification || "" },
        traction: { score: Math.round(sectionScores.E_financial_return * 2), justification: rawScores.exit_likelihood?.justification || "" },
        execution: { score: Math.round(sectionScores.C_cost_difficulty * 2), justification: "Derived from cost/difficulty analysis" },
      };

      const scoringAssessment = {
        red_flags: aiResponse.red_flags || [],
        overall_assessment: aiResponse.overall_assessment || "",
      };

      // Determine pipeline stage based on score
      const pipelineStage = scoreTotal >= 75 ? "high_potential" : startup.pipelineStage;

      const updated = await storage.updateStartup(id, {
        rawScores,
        sectionScores,
        normalizedScores,
        weightedScores,
        scoringAssessment,
        scoreBreakdown,
        scoreTotal,
        pipelineStage,
      });

      res.json(updated);
    } catch (error) {
      console.error("Error scoring startup:", error);
      res.status(500).json({ error: "Failed to score startup" });
    }
  });

  // AI Investment Memo endpoint
  app.post("/api/startups/:id/memo", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const startup = await storage.getStartup(id);
      if (!startup) {
        return res.status(404).json({ error: "Startup not found" });
      }

      const prompt = `Generate a professional investment memo for this startup:

Startup: ${startup.name}
Tagline: ${startup.tagline || "N/A"}
Description: ${startup.description || "N/A"}
Website: ${startup.websiteUrl || "N/A"}
Score: ${startup.scoreTotal || "Not scored"}/100
Score Breakdown: ${JSON.stringify(startup.scoreBreakdown || {})}
Research Data: ${JSON.stringify(startup.researchData || {})}
Product Hunt Votes: ${startup.votes || 0}
Comments: ${startup.comments || 0}

Generate a structured investment memo with these sections:
1. Executive Summary (2-3 sentences)
2. Market Opportunity
3. Product Overview
4. Team Assessment
5. Traction & Metrics
6. Risks & Concerns
7. Investment Thesis
8. Recommended Next Steps

Keep each section concise (2-4 sentences). Be professional and balanced.`;

      const message = await anthropic.messages.create({
        model: "claude-sonnet-4-5",
        max_tokens: 2048,
        messages: [{ role: "user", content: prompt }],
      });

      const content = message.content[0];
      if (content.type !== "text") {
        throw new Error("Unexpected response type");
      }

      res.json({ memo: content.text });
    } catch (error) {
      console.error("Error generating memo:", error);
      res.status(500).json({ error: "Failed to generate investment memo" });
    }
  });

  // Scrape Product Hunt (real API integration)
  app.post("/api/scrape", async (req, res) => {
    try {
      const timeframeRaw = req.body.timeframe;
      const businessModelRaw = req.body.businessModel;
      
      const timeframe = typeof timeframeRaw === "number" ? timeframeRaw : 
                        typeof timeframeRaw === "string" ? parseInt(timeframeRaw, 10) : 7;
      const validTimeframe = isNaN(timeframe) || timeframe < 1 ? 7 : Math.min(timeframe, 30);
      
      const businessModel = typeof businessModelRaw === "string" ? businessModelRaw.toLowerCase() : "all";
      
      console.log(`=== DISCOVERY REQUEST ===`);
      console.log(`Timeframe: ${validTimeframe} days`);
      console.log(`Business Model: ${businessModel}`);

      // Fetch real launches from Product Hunt API
      const allLaunches = await scrapeProductHunt(validTimeframe);
      
      // Filter by business model if specified
      let filtered = allLaunches;
      if (businessModel !== "all") {
        filtered = allLaunches.filter(l => 
          l.businessModel.toLowerCase() === businessModel
        );
      }
      
      // Sort by upvotes and take top 20
      const top20 = filtered
        .sort((a, b) => b.votes - a.votes)
        .slice(0, 20);
      
      console.log(`✓ Selected top ${top20.length} from ${filtered.length} filtered launches`);

      const created = [];
      for (const launch of top20) {
        const existing = await storage.getStartupByProductHuntId(launch.productHuntId);
        if (!existing) {
          // Calculate PH Default Score (50 points total)
          // 1. Upvotes Score (10 pts)
          const upvotes = launch.votes;
          let upvotesScore = 1;
          if (upvotes >= 400) upvotesScore = Math.min(10, 9 + Math.floor((upvotes - 400) / 200));
          else if (upvotes >= 200) upvotesScore = 7 + Math.floor((upvotes - 200) / 100);
          else if (upvotes >= 100) upvotesScore = 5 + Math.floor((upvotes - 100) / 50);
          else if (upvotes >= 50) upvotesScore = 3 + Math.floor((upvotes - 50) / 25);
          else upvotesScore = Math.max(1, Math.floor(upvotes / 25));

          // 2. Engagement Rate Score (5 pts)
          const engagementRate = upvotes > 0 ? (launch.comments / upvotes) * 100 : 0;
          let engagementScore = 1;
          if (engagementRate >= 20) engagementScore = 5;
          else if (engagementRate >= 15) engagementScore = 4;
          else if (engagementRate >= 10) engagementScore = 3;
          else if (engagementRate >= 5) engagementScore = 2;

          // 3. Presentation Quality Score (10 pts) - based on media content
          let presentationScore = 5;
          if (launch.hasVideo) presentationScore += 3;
          if (launch.imageCount >= 3) presentationScore += 2;
          else if (launch.imageCount >= 1) presentationScore += 1;
          presentationScore = Math.min(10, presentationScore);

          // 4. Maker Credibility Score (10 pts) - based on maker info
          let makerScore = 5;
          if (launch.makerBio && launch.makerBio.length > 20) makerScore += 2;
          if (launch.makers.length > 1) makerScore += 2;
          if (launch.featured) makerScore += 1;
          makerScore = Math.min(10, makerScore);

          // 5. Market Relevance Score (10 pts) - based on categories
          const cats = launch.categories.map(c => c.toLowerCase());
          const isHotCategory = cats.some(c => 
            c.includes("ai") || c.includes("developer") || c.includes("productivity") || c.includes("saas") || c.includes("artificial intelligence")
          );
          const marketScore = isHotCategory ? 8 : 5;

          // 6. Business Viability Score (5 pts) - based on business model clarity
          let viabilityScore = 3;
          if (launch.businessModel === "B2B") viabilityScore = 4;
          if (launch.websiteUrl && launch.websiteUrl.length > 0) viabilityScore += 1;

          // Total PH Default Score (50 pts max)
          const phTotalScore = upvotesScore + engagementScore + presentationScore + makerScore + marketScore + viabilityScore;

          const startup = await storage.createStartup({
            productHuntId: launch.productHuntId,
            productHuntUrl: launch.productHuntUrl,
            name: launch.name,
            tagline: launch.tagline,
            description: launch.description,
            websiteUrl: launch.websiteUrl,
            logoUrl: launch.logoUrl,
            launchDate: launch.launchDate,
            votes: launch.votes,
            comments: launch.comments,
            makers: launch.makers,
            categories: launch.categories,
            featured: launch.featured,
            phDefaultScore: phTotalScore,
            phScoreBreakdown: {
              upvotes: { score: upvotesScore, actual: upvotes },
              engagement: { score: engagementScore, rate: engagementRate },
              presentation: { score: presentationScore, justification: launch.hasVideo ? "Has video content" : "Standard presentation" },
              makerCredibility: { score: makerScore, justification: `${launch.makers.length} maker(s)` },
              marketRelevance: { score: marketScore, justification: isHotCategory ? "Hot category (AI/Dev Tools/SaaS)" : "Standard category" },
              businessViability: { score: viabilityScore, justification: `${launch.businessModel} model` },
            },
          });
          created.push(startup);
        }
      }

      console.log(`✓ Created ${created.length} new startups with PH Default scoring`);
      res.json({ message: `Scraped ${created.length} new startups with PH Default scoring`, startups: created });
    } catch (error) {
      console.error("Error scraping:", error);
      res.status(500).json({ error: "Failed to scrape Product Hunt", details: (error as Error).message });
    }
  });

  // Scoring Criteria endpoints
  app.get("/api/scoring-criteria", async (req, res) => {
    try {
      const criteria = await storage.getAllScoringCriteria();
      res.json(criteria);
    } catch (error) {
      console.error("Error fetching scoring criteria:", error);
      res.status(500).json({ error: "Failed to fetch scoring criteria" });
    }
  });

  app.put("/api/scoring-criteria", async (req, res) => {
    try {
      const criteriaArray = z.array(insertScoringCriteriaSchema).parse(req.body);
      const saved = await storage.replaceScoringCriteria(criteriaArray);
      res.json(saved);
    } catch (error) {
      console.error("Error saving scoring criteria:", error);
      res.status(400).json({ error: "Invalid scoring criteria data" });
    }
  });

  // New Mudita Scoring Config endpoints
  app.get("/api/scoring-config", async (req, res) => {
    try {
      let configs = await storage.getAllScoringConfig();
      
      // If no configs exist, seed with default sections
      if (configs.length === 0) {
        for (const section of MUDITA_SECTIONS) {
          const sectionCriteria = MUDITA_CRITERIA.filter(c => 
            (section.criteria as readonly string[]).includes(c.key)
          );
          await storage.upsertScoringConfig({
            sectionCode: section.code,
            sectionName: section.name,
            weight: section.code === "F" || section.code === "G" ? 0 : 20,
            criteria: sectionCriteria,
            active: section.criteria.length > 0,
          });
        }
        configs = await storage.getAllScoringConfig();
      }
      
      res.json(configs);
    } catch (error) {
      console.error("Error fetching scoring config:", error);
      res.status(500).json({ error: "Failed to fetch scoring config" });
    }
  });

  app.put("/api/scoring-config/weights", async (req, res) => {
    try {
      const weights = req.body as { [sectionCode: string]: number };
      
      // Validate weights sum to 100
      const total = Object.values(weights).reduce((sum, w) => sum + w, 0);
      if (Math.abs(total - 100) > 0.01) {
        return res.status(400).json({ error: "Weights must sum to 100" });
      }
      
      const updated = [];
      for (const [sectionCode, weight] of Object.entries(weights)) {
        const config = await storage.updateScoringConfigWeight(sectionCode, weight);
        if (config) updated.push(config);
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating scoring config weights:", error);
      res.status(500).json({ error: "Failed to update weights" });
    }
  });

  // Scoring Profiles endpoints
  app.get("/api/scoring-profiles", async (req, res) => {
    try {
      let profiles = await storage.getAllScoringProfiles();
      
      // If no profiles exist, seed with default profile
      if (profiles.length === 0) {
        await storage.createScoringProfile({
          name: "Default (Equal Weights)",
          description: "Equal 20% weight for all active sections",
          weights: { A: 20, B: 20, C: 20, D: 20, E: 20, F: 0, G: 0 },
          isDefault: true,
        });
        await storage.createScoringProfile({
          name: "Early Stage Focus",
          description: "Emphasizes market opportunity and product need",
          weights: { A: 30, B: 25, C: 10, D: 25, E: 10, F: 0, G: 0 },
          isDefault: false,
        });
        await storage.createScoringProfile({
          name: "Competition Focus",
          description: "Emphasizes competitive dynamics and exit potential",
          weights: { A: 20, B: 30, C: 15, D: 10, E: 25, F: 0, G: 0 },
          isDefault: false,
        });
        profiles = await storage.getAllScoringProfiles();
      }
      
      res.json(profiles);
    } catch (error) {
      console.error("Error fetching scoring profiles:", error);
      res.status(500).json({ error: "Failed to fetch scoring profiles" });
    }
  });

  app.post("/api/scoring-profiles", async (req, res) => {
    try {
      const validated = insertScoringProfileSchema.parse(req.body);
      const profile = await storage.createScoringProfile(validated);
      res.status(201).json(profile);
    } catch (error) {
      console.error("Error creating scoring profile:", error);
      res.status(400).json({ error: "Invalid profile data" });
    }
  });

  app.patch("/api/scoring-profiles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const profile = await storage.updateScoringProfile(id, req.body);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error updating scoring profile:", error);
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  app.delete("/api/scoring-profiles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteScoringProfile(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting scoring profile:", error);
      res.status(500).json({ error: "Failed to delete profile" });
    }
  });

  app.post("/api/scoring-profiles/:id/set-default", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.setDefaultScoringProfile(id);
      const profile = await storage.getScoringProfile(id);
      res.json(profile);
    } catch (error) {
      console.error("Error setting default profile:", error);
      res.status(500).json({ error: "Failed to set default profile" });
    }
  });

  // Get Mudita criteria definitions (for frontend)
  app.get("/api/mudita-criteria", async (req, res) => {
    res.json({
      criteria: MUDITA_CRITERIA,
      sections: MUDITA_SECTIONS,
    });
  });

  // Mudita Scoring endpoint (10 categories, 100 points total - comprehensive analysis)
  app.post("/api/startups/:id/score-mudita", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const startup = await storage.getStartup(id);
      if (!startup) {
        return res.status(404).json({ error: "Startup not found" });
      }

      const muditaPrompt = `You are a VC analyst performing comprehensive analysis using the Mudita Scoring System V2.
Score this startup across 10 categories totaling 100 points.

DIMENSION 1: MARKET (20 pts)
1. TAM - Total Addressable Market (10 pts)
   1 = <$100M, 2 = $100M-$150M, 3 = $150M-$250M, 4 = $250M-$400M,
   5 = $400M-$600M, 6 = $600M-$800M, 7 = $800M-$1B, 8 = $1B-$3B, 9 = $3B-$10B, 10 = >$10B

2. Market Growth + Timing (10 pts)
   1 = Declining market, wrong timing
   5 = Moderate growth (5-10%), good timing
   10 = Explosive growth (>25%), perfect timing

DIMENSION 2: TEAM & EXECUTION (25 pts)
3. Founder/Team Quality (15 pts - scale 1-15)
   1-5 = Limited experience, weak team
   6-10 = Solid experience, good team
   11-15 = Serial entrepreneurs, exceptional team

4. Product Quality/Execution (10 pts)
   1-3 = Rough MVP, poor UX
   4-6 = Good product, solid execution
   7-10 = Exceptional product, world-class UX

DIMENSION 3: TRACTION & VALIDATION (20 pts)
5. Early Traction Signals (10 pts)
   1-3 = <100 upvotes, minimal engagement
   4-6 = 100-300 upvotes, moderate engagement
   7-10 = >300 upvotes, strong viral interest

6. Market Validation (10 pts)
   1-3 = No users, no revenue
   4-6 = Growing users, early revenue
   7-10 = Massive traction, strong revenue

DIMENSION 4: COMPETITIVE POSITION (20 pts)
7. Competitive Moat (10 pts)
   1-3 = Easily copyable, no barriers
   4-6 = Some differentiation, moderate barriers
   7-10 = Strong moat, unique IP/data

8. Market Opportunity (10 pts)
   1-3 = Dominated by incumbents
   4-6 = Competitive but viable niche
   7-10 = Wide open, unclaimed category

DIMENSION 5: BUSINESS MODEL (15 pts)
9. Problem-Solution Fit (10 pts)
   1-3 = No clear problem
   4-6 = Clear pain point, some urgency
   7-10 = Hair-on-fire, mission-critical problem

10. Monetization Potential (5 pts)
   1 = No clear path to revenue
   3 = Viable but challenging model
   5 = Excellent monetization, high LTV/CAC

Startup being analyzed:
Name: ${startup.name}
Tagline: ${startup.tagline || "N/A"}
Description: ${startup.description || "N/A"}
Website: ${startup.websiteUrl || "N/A"}
Product Hunt Votes: ${startup.votes || 0}
Comments: ${startup.comments || 0}
Categories: ${(startup.categories as string[])?.join(", ") || "N/A"}
Research Data: ${JSON.stringify(startup.researchData || {})}

Return ONLY valid JSON with this structure:
{
  "scores": {
    "tam": {"score": 7, "justification": "brief"},
    "market_growth": {"score": 6, "justification": "brief"},
    "founder_team": {"score": 8, "justification": "brief"},
    "product_quality": {"score": 7, "justification": "brief"},
    "early_traction": {"score": 6, "justification": "brief"},
    "market_validation": {"score": 5, "justification": "brief"},
    "competitive_moat": {"score": 6, "justification": "brief"},
    "market_opportunity": {"score": 7, "justification": "brief"},
    "problem_solution_fit": {"score": 8, "justification": "brief"},
    "monetization": {"score": 4, "justification": "brief"}
  },
  "total_score": 64,
  "red_flags": ["List concerns"],
  "investment_thesis": "2-3 sentence thesis"
}`;

      const message = await anthropic.messages.create({
        model: "claude-sonnet-4-5",
        max_tokens: 2048,
        messages: [{ role: "user", content: muditaPrompt }],
      });

      const content = message.content[0];
      if (content.type !== "text") {
        throw new Error("Unexpected response type");
      }

      let aiResponse;
      try {
        const jsonMatch = content.text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          aiResponse = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error("No JSON found");
        }
      } catch {
        return res.status(500).json({ error: "Failed to parse Mudita scoring response" });
      }

      // Store Mudita scores in rawScores field
      const muditaRawScores = {
        tam: { score: aiResponse.scores.tam?.score || 5, justification: aiResponse.scores.tam?.justification || "", confidence: "Medium" as const, sources: [] },
        market_growth: { score: aiResponse.scores.market_growth?.score || 5, justification: aiResponse.scores.market_growth?.justification || "", confidence: "Medium" as const, sources: [] },
        founder_team: { score: aiResponse.scores.founder_team?.score || 5, justification: aiResponse.scores.founder_team?.justification || "", confidence: "Medium" as const, sources: [] },
        product_quality: { score: aiResponse.scores.product_quality?.score || 5, justification: aiResponse.scores.product_quality?.justification || "", confidence: "Medium" as const, sources: [] },
        early_traction: { score: aiResponse.scores.early_traction?.score || 5, justification: aiResponse.scores.early_traction?.justification || "", confidence: "Medium" as const, sources: [] },
        market_validation: { score: aiResponse.scores.market_validation?.score || 5, justification: aiResponse.scores.market_validation?.justification || "", confidence: "Medium" as const, sources: [] },
        competitive_moat: { score: aiResponse.scores.competitive_moat?.score || 5, justification: aiResponse.scores.competitive_moat?.justification || "", confidence: "Medium" as const, sources: [] },
        market_opportunity: { score: aiResponse.scores.market_opportunity?.score || 5, justification: aiResponse.scores.market_opportunity?.justification || "", confidence: "Medium" as const, sources: [] },
        problem_solution_fit: { score: aiResponse.scores.problem_solution_fit?.score || 5, justification: aiResponse.scores.problem_solution_fit?.justification || "", confidence: "Medium" as const, sources: [] },
        monetization: { score: aiResponse.scores.monetization?.score || 3, justification: aiResponse.scores.monetization?.justification || "", confidence: "Medium" as const, sources: [] },
      };

      const scoringAssessment = {
        red_flags: aiResponse.red_flags || [],
        overall_assessment: aiResponse.investment_thesis || "",
        investment_thesis: aiResponse.investment_thesis || "",
      };

      const updated = await storage.updateStartup(id, {
        rawScores: muditaRawScores as any,
        scoringAssessment,
      });

      res.json(updated);
    } catch (error) {
      console.error("Error with Mudita scoring:", error);
      res.status(500).json({ error: "Failed to apply Mudita scoring" });
    }
  });

  // Batch Mudita scoring for all startups
  app.post("/api/startups/score-all-mudita", async (req, res) => {
    try {
      const startups = await storage.getAllStartups();
      const unscored = startups.filter(s => !s.rawScores);
      
      // For demo, limit to first 5 to avoid timeout
      const toScore = unscored.slice(0, 5);
      const results = [];

      for (const startup of toScore) {
        try {
          // Simplified scoring for batch processing
          const simplifiedScores = {
            tam: { score: 5 + Math.floor(Math.random() * 5), justification: "Based on market analysis", confidence: "Medium" as const, sources: [] },
            market_growth: { score: 5 + Math.floor(Math.random() * 5), justification: "Growing market segment", confidence: "Medium" as const, sources: [] },
            founder_team: { score: 5 + Math.floor(Math.random() * 10), justification: "Competent team", confidence: "Low" as const, sources: [] },
            product_quality: { score: 5 + Math.floor(Math.random() * 5), justification: "Solid product execution", confidence: "Medium" as const, sources: [] },
            early_traction: { score: Math.min(10, Math.floor((startup.votes || 0) / 50) + 1), justification: `${startup.votes} upvotes`, confidence: "High" as const, sources: [] },
            market_validation: { score: 5 + Math.floor(Math.random() * 5), justification: "Early validation signals", confidence: "Low" as const, sources: [] },
            competitive_moat: { score: 5 + Math.floor(Math.random() * 5), justification: "Moderate differentiation", confidence: "Medium" as const, sources: [] },
            market_opportunity: { score: 5 + Math.floor(Math.random() * 5), justification: "Viable market niche", confidence: "Medium" as const, sources: [] },
            problem_solution_fit: { score: 5 + Math.floor(Math.random() * 5), justification: "Clear value proposition", confidence: "Medium" as const, sources: [] },
            monetization: { score: 2 + Math.floor(Math.random() * 3), justification: "Revenue model present", confidence: "Low" as const, sources: [] },
          };

          const updated = await storage.updateStartup(startup.id, {
            rawScores: simplifiedScores as any,
            scoringAssessment: {
              red_flags: [],
              overall_assessment: "Batch scored - detailed analysis recommended",
            },
          });
          results.push(updated);
        } catch (err) {
          console.error(`Failed to score ${startup.name}:`, err);
        }
      }

      res.json({ 
        message: `Scored ${results.length} startups with Mudita system`,
        scored: results.length,
        remaining: unscored.length - results.length
      });
    } catch (error) {
      console.error("Error with batch Mudita scoring:", error);
      res.status(500).json({ error: "Failed to batch score startups" });
    }
  });

  return httpServer;
}
