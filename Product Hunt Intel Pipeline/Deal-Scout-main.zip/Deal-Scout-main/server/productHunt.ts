import pRetry from "p-retry";

interface ProductHuntPost {
  id: string;
  name: string;
  tagline: string;
  description: string;
  slug: string;
  votesCount: number;
  commentsCount: number;
  createdAt: string;
  website: string;
  url: string;
  featuredAt: string | null;
  thumbnail: { url: string } | null;
  user: {
    name: string;
    username: string;
    headline: string;
  };
  makers: Array<{
    name: string;
    username: string;
    headline: string;
  }>;
  topics: {
    edges: Array<{
      node: {
        name: string;
      };
    }>;
  };
}

interface ProductHuntLaunch {
  productHuntId: string;
  productHuntUrl: string;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  websiteUrl: string;
  categories: string[];
  launchDate: Date;
  featuredAt: Date | null;
  votes: number;
  comments: number;
  makers: string[];
  makerUsername: string;
  makerBio: string;
  hasVideo: boolean;
  imageCount: number;
  logoUrl: string;
  businessModel: "B2B" | "B2C" | "Hybrid";
  featured: boolean;
}

let cachedAccessToken: string | null = null;

async function getProductHuntAccessToken(): Promise<string> {
  if (cachedAccessToken) {
    return cachedAccessToken;
  }

  const clientId = process.env.PRODUCT_HUNT_API_KEY;
  const clientSecret = process.env.PRODUCT_HUNT_API_SECRET;

  if (!clientId || !clientSecret) {
    throw new Error("Product Hunt API credentials not configured");
  }

  const response = await fetch("https://api.producthunt.com/v2/oauth/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: "client_credentials",
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Product Hunt OAuth failed: ${error}`);
  }

  const data = await response.json();
  cachedAccessToken = data.access_token;

  console.log("✓ Product Hunt access token obtained");
  return cachedAccessToken as string;
}

const POSTS_QUERY = `
  query GetPosts($postedAfter: DateTime!) {
    posts(first: 20, order: VOTES, postedAfter: $postedAfter) {
      edges {
        node {
          id
          name
          tagline
          description
          slug
          votesCount
          commentsCount
          createdAt
          website
          url
          featuredAt
          thumbnail {
            url
          }
          user {
            name
            username
            headline
          }
          makers {
            name
            username
            headline
          }
          topics {
            edges {
              node {
                name
              }
            }
          }
        }
      }
    }
  }
`;

async function fetchProductHuntPosts(timeframeDays: number): Promise<ProductHuntLaunch[]> {
  const accessToken = await getProductHuntAccessToken();

  const now = new Date();
  const startDate = new Date(now);
  startDate.setDate(now.getDate() - timeframeDays);

  console.log(`Fetching Product Hunt posts from ${startDate.toISOString()}...`);

  const response = await fetch("https://api.producthunt.com/v2/api/graphql", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      query: POSTS_QUERY,
      variables: {
        postedAfter: startDate.toISOString(),
      },
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error("Product Hunt API error:", errorText);
    throw new Error(`Product Hunt API request failed: ${response.status}`);
  }

  const data = await response.json();

  if (data.errors) {
    console.error("Product Hunt GraphQL errors:", data.errors);
    throw new Error(`Product Hunt GraphQL errors: ${JSON.stringify(data.errors)}`);
  }

  if (!data.data || !data.data.posts) {
    throw new Error("Invalid response from Product Hunt API");
  }

  console.log(`✓ Fetched ${data.data.posts.edges.length} posts from Product Hunt`);

  const launches: ProductHuntLaunch[] = data.data.posts.edges.map((edge: { node: ProductHuntPost }) => {
    const post = edge.node;

    const topics = post.topics.edges.map((t) => t.node.name);
    const topicsLower = topics.map((t) => t.toLowerCase());

    const hasB2BSignals = topicsLower.some(
      (t) =>
        t.includes("saas") ||
        t.includes("b2b") ||
        t.includes("enterprise") ||
        t.includes("developer") ||
        t.includes("productivity") ||
        t.includes("analytics")
    );
    const hasB2CSignals = topicsLower.some(
      (t) =>
        t.includes("consumer") ||
        t.includes("b2c") ||
        t.includes("social") ||
        t.includes("lifestyle") ||
        t.includes("entertainment")
    );

    let businessModel: "B2B" | "B2C" | "Hybrid" = "B2B";
    if (hasB2BSignals && hasB2CSignals) {
      businessModel = "Hybrid";
    } else if (hasB2CSignals) {
      businessModel = "B2C";
    }

    const makers = post.makers.length > 0 ? post.makers : [post.user];
    const makerNames = makers.map((m) => m.name);

    const hasVideo = false;
    const imageCount = post.thumbnail?.url ? 1 : 0;

    const productHuntUrl = post.url.startsWith("http") 
      ? post.url 
      : `https://www.producthunt.com${post.url}`;

    return {
      productHuntId: post.id,
      productHuntUrl,
      name: post.name,
      slug: post.slug,
      tagline: post.tagline || "",
      description: post.description || post.tagline || "",
      websiteUrl: post.website || "",
      categories: topics,
      launchDate: new Date(post.createdAt),
      featuredAt: post.featuredAt ? new Date(post.featuredAt) : null,
      votes: post.votesCount,
      comments: post.commentsCount,
      makers: makerNames,
      makerUsername: makers[0]?.username || "",
      makerBio: makers[0]?.headline || "",
      hasVideo,
      imageCount,
      logoUrl: post.thumbnail?.url || "",
      businessModel,
      featured: !!post.featuredAt,
    };
  });

  console.log(`✓ Transformed ${launches.length} launches`);
  return launches;
}

export async function scrapeProductHunt(timeframeDays: number): Promise<ProductHuntLaunch[]> {
  return pRetry(
    async () => {
      const launches = await fetchProductHuntPosts(timeframeDays);

      if (launches.length === 0) {
        throw new Error("No launches returned from Product Hunt");
      }

      return launches;
    },
    {
      retries: 3,
      onFailedAttempt: (error) => {
        console.log(
          `Product Hunt API attempt ${error.attemptNumber} failed. ${error.retriesLeft} retries left.`
        );
      },
    }
  );
}

export function clearTokenCache(): void {
  cachedAccessToken = null;
}
