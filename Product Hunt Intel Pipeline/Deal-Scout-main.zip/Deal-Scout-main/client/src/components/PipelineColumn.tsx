import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StartupCard } from "./StartupCard";
import { 
  Search, Star, Mail, MessageSquare, ClipboardCheck, CheckCircle, XCircle,
  LucideIcon 
} from "lucide-react";
import type { Startup } from "@shared/schema";
import { cn } from "@/lib/utils";

interface PipelineColumnProps {
  stage: {
    id: string;
    label: string;
    icon: string;
  };
  startups: Startup[];
  onStartupClick: (startup: Startup) => void;
  onStageChange: (startupId: number, newStage: string) => void;
  onDragStart?: (e: React.DragEvent, startup: Startup) => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: (e: React.DragEvent, stage: string) => void;
}

const iconMap: Record<string, LucideIcon> = {
  Search,
  Star,
  Mail,
  MessageSquare,
  ClipboardCheck,
  CheckCircle,
  XCircle,
};

const stageColors: Record<string, string> = {
  discovered: "from-blue-500/20 to-blue-600/10 border-blue-500/30",
  high_potential: "from-yellow-500/20 to-yellow-600/10 border-yellow-500/30",
  outreach: "from-purple-500/20 to-purple-600/10 border-purple-500/30",
  conversation: "from-cyan-500/20 to-cyan-600/10 border-cyan-500/30",
  due_diligence: "from-orange-500/20 to-orange-600/10 border-orange-500/30",
  portfolio: "from-green-500/20 to-green-600/10 border-green-500/30",
  declined: "from-red-500/20 to-red-600/10 border-red-500/30",
};

export function PipelineColumn({
  stage,
  startups,
  onStartupClick,
  onStageChange,
  onDragStart,
  onDragOver,
  onDrop,
}: PipelineColumnProps) {
  const Icon = iconMap[stage.icon] || Search;

  return (
    <div
      className="flex-shrink-0 w-72"
      onDragOver={(e) => {
        e.preventDefault();
        onDragOver?.(e);
      }}
      onDrop={(e) => onDrop?.(e, stage.id)}
      data-testid={`pipeline-column-${stage.id}`}
    >
      <Card className={cn(
        "h-full flex flex-col bg-gradient-to-b border",
        stageColors[stage.id] || stageColors.discovered
      )}>
        <div className="p-4 border-b border-border/50">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-white/5">
                <Icon className="w-4 h-4 text-purple-400" />
              </div>
              <h3 className="font-semibold text-sm text-foreground">{stage.label}</h3>
            </div>
            <Badge variant="secondary" className="text-xs">
              {startups.length}
            </Badge>
          </div>
        </div>

        <ScrollArea className="flex-1 p-2">
          <div className="space-y-2">
            {startups.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground text-sm">
                No startups in this stage
              </div>
            ) : (
              startups.map((startup) => (
                <div
                  key={startup.id}
                  draggable
                  onDragStart={(e) => onDragStart?.(e, startup)}
                  className="cursor-move"
                >
                  <StartupCard
                    startup={startup}
                    onClick={() => onStartupClick(startup)}
                    onStageChange={(newStage) => onStageChange(startup.id, newStage)}
                    compact
                  />
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );
}
