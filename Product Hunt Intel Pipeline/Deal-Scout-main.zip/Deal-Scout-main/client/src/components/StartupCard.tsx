import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScoreBadge } from "./ScoreBadge";
import { ExternalLink, MessageSquare, ThumbsUp, Calendar, MoreVertical, Download, Plus, Target, TrendingUp, Shield, DollarSign, Zap, Flame } from "lucide-react";
import { format } from "date-fns";
import type { Startup, PIPELINE_STAGES } from "@shared/schema";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const SECTION_LABELS: Record<string, string> = {
  A: "Market",
  B: "Competition",
  C: "Cost/Difficulty",
  D: "Product Need",
  E: "Financial Return",
};

const SECTION_COLORS: Record<string, string> = {
  A: "#3b82f6",
  B: "#f59e0b",
  C: "#ef4444",
  D: "#22c55e",
  E: "#a855f7",
};

interface StartupCardProps {
  startup: Startup;
  onClick?: () => void;
  onStageChange?: (stage: string) => void;
  onAddToPipeline?: () => void;
  onExport?: () => void;
  compact?: boolean;
}

const stageColors: Record<string, string> = {
  discovered: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  high_potential: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
  outreach: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  conversation: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  due_diligence: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  portfolio: "bg-green-500/20 text-green-300 border-green-500/30",
  declined: "bg-red-500/20 text-red-300 border-red-500/30",
};

const stageLabels: Record<string, string> = {
  discovered: "Discovered",
  high_potential: "High Potential",
  outreach: "Outreach",
  conversation: "In Conversation",
  due_diligence: "Due Diligence",
  portfolio: "Portfolio",
  declined: "Declined",
};

export function StartupCard({ startup, onClick, onStageChange, onAddToPipeline, onExport, compact = false }: StartupCardProps) {
  const categories = (startup.categories as string[]) || [];
  const tags = (startup.tags as string[]) || [];
  const sectionScores = startup.sectionScores as unknown as Record<string, number | null> | null;
  const rawScores = startup.rawScores as unknown as Record<string, { score: number }> | null;
  
  const getSectionScore = (code: string): number | null => {
    if (!sectionScores) return null;
    const key = Object.keys(sectionScores).find(k => k.startsWith(code));
    return key ? sectionScores[key] : null;
  };

  const getQuickScores = () => {
    if (!rawScores) return null;
    return [
      { key: "tam", label: "TAM", icon: Target, score: rawScores.tam?.score },
      { key: "market_growth", label: "Growth", icon: TrendingUp, score: rawScores.market_growth?.score },
      { key: "moat", label: "Moat", icon: Shield, score: rawScores.moat?.score },
      { key: "capital_required", label: "Capital", icon: DollarSign, score: rawScores.capital_required?.score },
      { key: "gtm_difficulty", label: "GTM", icon: Zap, score: rawScores.gtm_difficulty?.score },
      { key: "problem_urgency", label: "Urgency", icon: Flame, score: rawScores.problem_urgency?.score },
    ].filter(s => s.score !== undefined);
  };

  const quickScores = getQuickScores();

  return (
    <Card
      className={cn(
        "glass transition-smooth cursor-pointer group",
        "hover:purple-glow hover:border-purple-500/30",
        compact ? "p-3" : "p-4"
      )}
      onClick={onClick}
      data-testid={`startup-card-${startup.id}`}
    >
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0">
          {startup.logoUrl ? (
            <img
              src={startup.logoUrl}
              alt={startup.name}
              className="w-12 h-12 rounded-lg object-cover border border-purple-500/20"
            />
          ) : (
            <div className="w-12 h-12 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold text-lg">
              {startup.name.charAt(0).toUpperCase()}
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h3 className="font-semibold text-foreground truncate group-hover:text-purple-300 transition-colors">
                {startup.name}
              </h3>
              {startup.tagline && (
                <p className="text-sm text-muted-foreground line-clamp-2 mt-0.5">
                  {startup.tagline}
                </p>
              )}
            </div>
            <ScoreBadge score={startup.scoreTotal} size="sm" />
          </div>

          {!compact && (
            <>
              <div className="flex flex-wrap items-center gap-2 mt-3">
                <Badge
                  variant="outline"
                  className={cn("text-xs border", stageColors[startup.pipelineStage] || stageColors.discovered)}
                >
                  {stageLabels[startup.pipelineStage] || "Discovered"}
                </Badge>
                {categories.slice(0, 2).map((cat) => (
                  <Badge key={cat} variant="secondary" className="text-xs">
                    {cat}
                  </Badge>
                ))}
                {tags.slice(0, 2).map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs border-purple-500/20 text-purple-300">
                    {tag}
                  </Badge>
                ))}
              </div>

              {quickScores && quickScores.length > 0 && (
                <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-muted-foreground">
                  {quickScores.slice(0, 6).map((qs) => (
                    <span key={qs.key} className="flex items-center gap-1">
                      <qs.icon className="w-3 h-3" />
                      {qs.label}: {qs.score}/10
                    </span>
                  ))}
                </div>
              )}

              {sectionScores && (
                <div className="flex items-center gap-1 mt-3">
                  {["A", "B", "C", "D", "E"].map((code) => {
                    const score = getSectionScore(code);
                    if (score === null) return null;
                    return (
                      <Tooltip key={code}>
                        <TooltipTrigger asChild>
                          <div className="flex-1">
                            <div
                              className="h-1.5 rounded-full"
                              style={{
                                backgroundColor: SECTION_COLORS[code],
                                opacity: 0.3 + (score / 10) * 0.7,
                              }}
                            />
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs">{SECTION_LABELS[code]}: {score.toFixed(1)}/10</p>
                        </TooltipContent>
                      </Tooltip>
                    );
                  })}
                </div>
              )}

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
                <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                  {startup.websiteUrl && (
                    <span className="flex items-center gap-1">
                      <ExternalLink className="w-3.5 h-3.5" />
                      <a
                        href={startup.websiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-foreground transition-colors"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {new URL(startup.websiteUrl).hostname.replace("www.", "")}
                      </a>
                    </span>
                  )}
                  <span className="flex items-center gap-1">
                    <ThumbsUp className="w-3.5 h-3.5" />
                    {startup.votes || 0} upvotes
                  </span>
                  {startup.launchDate && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {format(new Date(startup.launchDate), "MMM d")}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 mt-3">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    onExport?.();
                  }}
                  data-testid={`export-report-${startup.id}`}
                >
                  <Download className="w-3.5 h-3.5 mr-1.5" />
                  Export Report
                </Button>
                <Button
                  size="sm"
                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddToPipeline?.();
                  }}
                  data-testid={`add-to-pipeline-${startup.id}`}
                >
                  <Plus className="w-3.5 h-3.5 mr-1.5" />
                  Add to Pipeline
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </Card>
  );
}
