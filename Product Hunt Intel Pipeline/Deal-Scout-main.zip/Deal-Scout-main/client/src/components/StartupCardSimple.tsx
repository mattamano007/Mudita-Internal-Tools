import { ExternalLink, ThumbsUp, MessageSquare, Calendar, ArrowRight, AlertTriangle, TrendingUp, Rocket } from "lucide-react";
import { format } from "date-fns";
import type { Startup } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type ScoringSystem = "ph-default" | "mudita";

interface StartupCardSimpleProps {
  startup: Startup;
  onClick?: () => void;
  onScoreMudita?: () => void;
  minScoreThreshold?: number;
  activeScoringSystem?: ScoringSystem;
}

function getBusinessModel(categories: string[]): "B2B" | "B2C" | "Hybrid" {
  const cats = categories.map(c => c.toLowerCase());
  const hasB2B = cats.some(c => c.includes("saas") || c.includes("b2b") || c.includes("enterprise") || c.includes("developer") || c.includes("analytics"));
  const hasB2C = cats.some(c => c.includes("consumer") || c.includes("b2c") || c.includes("social") || c.includes("lifestyle") || c.includes("entertainment"));
  
  if (hasB2B && hasB2C) return "Hybrid";
  if (hasB2B) return "B2B";
  if (hasB2C) return "B2C";
  return "B2B";
}

function getBusinessModelStyles(model: string): string {
  switch (model) {
    case "B2B":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    case "B2C":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    case "Hybrid":
      return "bg-purple-500/20 text-purple-400 border-purple-500/30";
    default:
      return "bg-slate-500/20 text-slate-400 border-slate-500/30";
  }
}

function calculateEngagementRate(comments: number, upvotes: number): number {
  if (upvotes === 0) return 0;
  return Math.round((comments / upvotes) * 100);
}

export function StartupCardSimple({ startup, onClick, onScoreMudita, minScoreThreshold = 25, activeScoringSystem = "ph-default" }: StartupCardSimpleProps) {
  const categories = (startup.categories as string[]) || [];
  const businessModel = getBusinessModel(categories);
  const phScore = startup.phDefaultScore || 0;
  const muditaScore = startup.rawScores ? 
    (Object.values(startup.rawScores as unknown as Record<string, { score: number }>).reduce((sum, v) => sum + (v?.score || 0), 0)) : 
    null;
  
  const isPHDefault = activeScoringSystem === "ph-default";
  const activeScore = isPHDefault ? phScore : (muditaScore || 0);
  const maxScore = isPHDefault ? 50 : 100;
  const needsManualReview = activeScore < minScoreThreshold || (isPHDefault ? !startup.phDefaultScore : !startup.rawScores);
  const engagementRate = calculateEngagementRate(startup.comments || 0, startup.votes || 0);

  const getHostname = (url: string) => {
    try {
      return new URL(url).hostname.replace("www.", "");
    } catch {
      return url;
    }
  };

  return (
    <div
      className={cn(
        "bg-slate-800 border rounded-xl p-6 cursor-pointer transition-all duration-300 relative",
        "hover:-translate-y-0.5",
        needsManualReview 
          ? "border-amber-500/50 hover:border-amber-400 hover:shadow-lg hover:shadow-amber-500/20 bg-gradient-to-br from-slate-800 to-amber-950/10" 
          : muditaScore ? "border-emerald-500/30 hover:border-emerald-400 hover:shadow-lg hover:shadow-emerald-500/20" : "border-slate-700 hover:border-purple-500 hover:shadow-lg hover:shadow-purple-500/20",
        !muditaScore && !needsManualReview && "border-l-4 border-l-purple-500",
        "group"
      )}
      onClick={onClick}
      data-testid={`startup-card-${startup.id}`}
    >
      {needsManualReview && (
        <div className="absolute -top-3 left-6 bg-amber-500 text-black px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide shadow-lg shadow-amber-500/40 flex items-center gap-1.5 z-10">
          <AlertTriangle className="w-3.5 h-3.5" />
          Manual Review
        </div>
      )}

      <div className="absolute top-6 right-6 flex flex-col items-end gap-2.5">
        <div className={cn(
          "px-5 py-3 rounded-xl text-center shadow-lg min-w-[100px]",
          needsManualReview 
            ? "bg-gradient-to-br from-slate-500 to-slate-600" 
            : isPHDefault 
              ? "bg-gradient-to-br from-blue-500 to-blue-600"
              : "bg-gradient-to-br from-emerald-500 to-emerald-600"
        )}>
          <div className="text-2xl font-bold text-white">{activeScore || "N/A"}/{maxScore}</div>
          <div className="text-[11px] font-medium uppercase tracking-wide text-white/80 mt-1">
            {isPHDefault ? "PH Score" : "Mudita"}
          </div>
        </div>
        
        {isPHDefault && !muditaScore && (
          <Button
            size="sm"
            variant="outline"
            className="bg-purple-500/20 border-purple-500/40 text-purple-400 hover:bg-purple-500/30 hover:text-purple-300 min-w-[100px]"
            onClick={(e) => {
              e.stopPropagation();
              onScoreMudita?.();
            }}
            data-testid={`score-mudita-${startup.id}`}
          >
            <TrendingUp className="w-3.5 h-3.5 mr-1" />
            Score Mudita
          </Button>
        )}
        
        {isPHDefault && muditaScore && (
          <div className="px-4 py-2 rounded-xl text-center min-w-[100px] bg-emerald-500/20 border border-emerald-500/30">
            <div className="text-lg font-bold text-emerald-400">{muditaScore}/100</div>
            <div className="text-[10px] font-medium uppercase tracking-wide text-emerald-400/80">Mudita</div>
          </div>
        )}
        
        <span className={cn(
          "px-3 py-1.5 rounded-full text-xs font-semibold uppercase border text-center min-w-[60px]",
          getBusinessModelStyles(businessModel)
        )}>
          {businessModel}
        </span>
      </div>

      <div className="pr-36 mb-4">
        <h3 className="text-xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
          {startup.name}
        </h3>
        {startup.tagline && (
          <p className="text-slate-300 text-sm leading-relaxed line-clamp-2">
            {startup.tagline}
          </p>
        )}
      </div>

      <div className="flex flex-wrap gap-4 text-sm text-slate-400 py-3 border-y border-slate-700 mb-3">
        <span className="flex items-center gap-1.5 font-medium">
          <ThumbsUp className="w-4 h-4" />
          {startup.votes || 0} upvotes
        </span>
        <span className="flex items-center gap-1.5">
          <MessageSquare className="w-4 h-4" />
          {startup.comments || 0} comments
        </span>
        <span className="flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4" />
          {engagementRate}% engagement
        </span>
      </div>

      <div className="flex flex-wrap gap-5 text-sm text-slate-400 mb-3">
        {startup.productHuntUrl && (
          <a
            href={startup.productHuntUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-orange-400 hover:text-orange-300 font-semibold transition-colors"
            onClick={(e) => e.stopPropagation()}
            data-testid={`link-ph-${startup.id}`}
          >
            <Rocket className="w-4 h-4" />
            View on Product Hunt
          </a>
        )}
        {startup.websiteUrl && (
          <a
            href={startup.websiteUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 hover:text-slate-300 transition-colors"
            onClick={(e) => e.stopPropagation()}
            data-testid={`link-website-${startup.id}`}
          >
            <ExternalLink className="w-4 h-4" />
            {getHostname(startup.websiteUrl)}
          </a>
        )}
        {startup.launchDate && (
          <span className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4" />
            {format(new Date(startup.launchDate), "MMM d, yyyy")}
          </span>
        )}
      </div>

      <div className={cn(
        "text-right text-sm italic flex items-center justify-end gap-1 transition-colors",
        needsManualReview ? "text-amber-500/70 group-hover:text-amber-400" : "text-slate-500 group-hover:text-purple-400"
      )}>
        Click to view {muditaScore ? "full breakdown" : "PH Default breakdown"}
        <ArrowRight className="w-4 h-4" />
      </div>
    </div>
  );
}
