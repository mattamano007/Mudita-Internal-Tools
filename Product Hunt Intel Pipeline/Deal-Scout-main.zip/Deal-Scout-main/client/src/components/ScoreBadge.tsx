import { cn } from "@/lib/utils";

interface ScoreBadgeProps {
  score: number | null | undefined;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
  className?: string;
}

export function ScoreBadge({ score, size = "md", showLabel = false, className }: ScoreBadgeProps) {
  const displayScore = score ?? 0;
  
  const getScoreClass = () => {
    if (displayScore >= 80) return "score-excellent";
    if (displayScore >= 60) return "score-good";
    return "score-average";
  };

  const getScoreLabel = () => {
    if (displayScore >= 80) return "Excellent";
    if (displayScore >= 60) return "Good";
    return "Average";
  };

  const sizeClasses = {
    sm: "w-10 h-10 text-sm",
    md: "w-14 h-14 text-lg",
    lg: "w-24 h-24 text-3xl",
  };

  if (score === null || score === undefined) {
    return (
      <div
        className={cn(
          "flex flex-col items-center justify-center rounded-full bg-muted text-muted-foreground font-semibold",
          sizeClasses[size],
          className
        )}
        data-testid="score-badge-pending"
      >
        <span>--</span>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col items-center gap-1", className)}>
      <div
        className={cn(
          "flex items-center justify-center rounded-full font-bold text-white shadow-lg",
          getScoreClass(),
          sizeClasses[size]
        )}
        data-testid={`score-badge-${displayScore}`}
      >
        {displayScore}
      </div>
      {showLabel && (
        <span className="text-xs text-muted-foreground font-medium">
          {getScoreLabel()}
        </span>
      )}
    </div>
  );
}
