import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { StartupCard } from "@/components/StartupCard";
import {
  Search,
  Filter,
  ArrowUpDown,
  Sparkles,
  RefreshCw,
  Loader2,
} from "lucide-react";
import type { Startup } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Launches() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("recent");
  const [filterStage, setFilterStage] = useState("all");
  const [filterScore, setFilterScore] = useState("all");

  const { data: startups = [], isLoading } = useQuery<Startup[]>({
    queryKey: ["/api/startups"],
  });

  const scrapeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/scrape");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups"] });
      toast({
        title: "Scraping complete",
        description: "New startups have been added to the database.",
      });
    },
    onError: () => {
      toast({
        title: "Scraping failed",
        description: "Could not fetch new startups. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateStageMutation = useMutation({
    mutationFn: async ({ id, stage }: { id: number; stage: string }) => {
      return apiRequest("PATCH", `/api/startups/${id}`, { pipelineStage: stage });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups"] });
    },
  });

  const filteredStartups = startups
    .filter((startup) => {
      const matchesSearch =
        startup.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        startup.tagline?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        startup.description?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesStage =
        filterStage === "all" || startup.pipelineStage === filterStage;

      const matchesScore =
        filterScore === "all" ||
        (filterScore === "excellent" && (startup.scoreTotal || 0) >= 80) ||
        (filterScore === "good" && (startup.scoreTotal || 0) >= 60 && (startup.scoreTotal || 0) < 80) ||
        (filterScore === "average" && (startup.scoreTotal || 0) < 60) ||
        (filterScore === "unscored" && startup.scoreTotal === null);

      return matchesSearch && matchesStage && matchesScore;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "score":
          return (b.scoreTotal || 0) - (a.scoreTotal || 0);
        case "votes":
          return (b.votes || 0) - (a.votes || 0);
        case "comments":
          return (b.comments || 0) - (a.comments || 0);
        case "recent":
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Product Hunt Launches</h1>
          <p className="text-muted-foreground mt-1">
            {startups.length} startups discovered
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            className="gap-2"
            onClick={() => scrapeMutation.mutate()}
            disabled={scrapeMutation.isPending}
            data-testid="button-refresh-launches"
          >
            {scrapeMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4" />
            )}
            Refresh
          </Button>
          <Button className="gap-2" data-testid="button-scrape-launches">
            <Sparkles className="w-4 h-4" />
            Scrape New
          </Button>
        </div>
      </div>

      <Card className="glass p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search startups..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-background/50"
              data-testid="input-search-startups"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <Select value={filterStage} onValueChange={setFilterStage}>
              <SelectTrigger className="w-40 bg-background/50" data-testid="select-filter-stage">
                <SelectValue placeholder="Stage" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stages</SelectItem>
                <SelectItem value="discovered">Discovered</SelectItem>
                <SelectItem value="high_potential">High Potential</SelectItem>
                <SelectItem value="outreach">Outreach</SelectItem>
                <SelectItem value="conversation">Conversation</SelectItem>
                <SelectItem value="due_diligence">Due Diligence</SelectItem>
                <SelectItem value="portfolio">Portfolio</SelectItem>
                <SelectItem value="declined">Declined</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterScore} onValueChange={setFilterScore}>
              <SelectTrigger className="w-40 bg-background/50" data-testid="select-filter-score">
                <SelectValue placeholder="Score" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Scores</SelectItem>
                <SelectItem value="excellent">Excellent (80+)</SelectItem>
                <SelectItem value="good">Good (60-79)</SelectItem>
                <SelectItem value="average">Average (&lt;60)</SelectItem>
                <SelectItem value="unscored">Not Scored</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4 text-muted-foreground" />
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-36 bg-background/50" data-testid="select-sort-by">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="score">Highest Score</SelectItem>
                <SelectItem value="votes">Most Votes</SelectItem>
                <SelectItem value="comments">Most Comments</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <div className="flex flex-wrap gap-2">
        {filterStage !== "all" && (
          <Badge variant="secondary" className="gap-1">
            Stage: {filterStage}
            <button
              className="ml-1 hover:text-foreground"
              onClick={() => setFilterStage("all")}
            >
              x
            </button>
          </Badge>
        )}
        {filterScore !== "all" && (
          <Badge variant="secondary" className="gap-1">
            Score: {filterScore}
            <button
              className="ml-1 hover:text-foreground"
              onClick={() => setFilterScore("all")}
            >
              x
            </button>
          </Badge>
        )}
        {searchQuery && (
          <Badge variant="secondary" className="gap-1">
            Search: {searchQuery}
            <button
              className="ml-1 hover:text-foreground"
              onClick={() => setSearchQuery("")}
            >
              x
            </button>
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {isLoading ? (
          Array(6).fill(0).map((_, i) => (
            <Card key={i} className="glass p-4">
              <div className="flex items-start gap-4">
                <Skeleton className="w-12 h-12 rounded-lg" />
                <div className="flex-1">
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-4 w-full mb-3" />
                  <div className="flex gap-2">
                    <Skeleton className="h-5 w-20 rounded-full" />
                    <Skeleton className="h-5 w-16 rounded-full" />
                  </div>
                </div>
                <Skeleton className="w-10 h-10 rounded-full" />
              </div>
            </Card>
          ))
        ) : filteredStartups.length === 0 ? (
          <div className="col-span-full">
            <Card className="glass p-12 text-center">
              <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">
                No startups found
              </h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                {searchQuery || filterStage !== "all" || filterScore !== "all"
                  ? "Try adjusting your filters or search query"
                  : "Click 'Scrape New' to fetch the latest Product Hunt launches"}
              </p>
            </Card>
          </div>
        ) : (
          filteredStartups.map((startup) => (
            <StartupCard
              key={startup.id}
              startup={startup}
              onClick={() => navigate(`/startup/${startup.id}`)}
              onStageChange={(stage) =>
                updateStageMutation.mutate({ id: startup.id, stage })
              }
            />
          ))
        )}
      </div>
    </div>
  );
}
