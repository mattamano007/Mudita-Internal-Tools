import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLocation } from "wouter";
import { Rocket, Loader2, Download, Sparkles } from "lucide-react";
import type { Startup } from "@shared/schema";
import { PIPELINE_STAGES } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type ScoringMode = "ph" | "mudita";

const stageColors: Record<string, string> = {
  discovered: "bg-blue-500/20 text-blue-300",
  high_potential: "bg-yellow-500/20 text-yellow-300",
  outreach: "bg-purple-500/20 text-purple-300",
  conversation: "bg-cyan-500/20 text-cyan-300",
  due_diligence: "bg-orange-500/20 text-orange-300",
  portfolio: "bg-green-500/20 text-green-300",
  declined: "bg-red-500/20 text-red-300",
};

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [timeframe, setTimeframe] = useState("7");
  const [scoringMode, setScoringMode] = useState<ScoringMode>("ph");
  const [isProcessing, setIsProcessing] = useState(false);

  const { data: startups = [] } = useQuery<Startup[]>({
    queryKey: ["/api/startups"],
  });

  const scrapeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/scrape", {
        timeframe: parseInt(timeframe),
        scoringSystem: "ph-default",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups"] });
    },
  });

  const scoreAllMuditaMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/startups/score-all-mudita");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups"] });
      toast({ title: "Mudita scoring complete" });
    },
  });

  const getScore = (s: Startup) => {
    if (scoringMode === "mudita" && s.rawScores) {
      return Object.values(s.rawScores as unknown as Record<string, { score: number }>)
        .reduce((sum, v) => sum + (v?.score || 0), 0);
    }
    return s.phDefaultScore || 0;
  };

  const sortedStartups = [...startups]
    .sort((a, b) => getScore(b) - getScore(a))
    .slice(0, 20);

  const handleFetch = async () => {
    setIsProcessing(true);
    try {
      await scrapeMutation.mutateAsync();
      if (scoringMode === "mudita") {
        await scoreAllMuditaMutation.mutateAsync();
      }
      toast({
        title: "Done",
        description: `Found ${sortedStartups.length} startups`,
      });
    } catch {
      toast({
        title: "Failed",
        description: "Could not fetch startups",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const exportCSV = () => {
    const headers = ["Name", "Score", "Stage", "Website"];
    const rows = sortedStartups.map(s => [
      s.name,
      getScore(s),
      s.pipelineStage,
      s.websiteUrl || "",
    ]);
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `startups-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  if (isProcessing) {
    return (
      <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
          <p className="text-white text-lg">
            {scoringMode === "mudita" ? "Running deep analysis..." : "Fetching startups..."}
          </p>
          <p className="text-slate-400 text-sm mt-2">
            {scoringMode === "mudita" ? "This may take 10-15 minutes" : "About 1 minute"}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-32 bg-slate-800 border-slate-700" data-testid="select-timeframe">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">7 days</SelectItem>
            <SelectItem value="14">14 days</SelectItem>
            <SelectItem value="30">30 days</SelectItem>
          </SelectContent>
        </Select>

        <Select value={scoringMode} onValueChange={(v) => setScoringMode(v as ScoringMode)}>
          <SelectTrigger className="w-32 bg-slate-800 border-slate-700" data-testid="select-scoring">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ph">Quick (PH)</SelectItem>
            <SelectItem value="mudita">Deep (Mudita)</SelectItem>
          </SelectContent>
        </Select>

        <Button
          onClick={handleFetch}
          disabled={isProcessing}
          className="bg-purple-600 hover:bg-purple-700 flex-1"
          data-testid="button-fetch"
        >
          <Rocket className="w-4 h-4 mr-2" />
          Fetch & Score
        </Button>

        {sortedStartups.length > 0 && (
          <Button
            variant="outline"
            onClick={exportCSV}
            className="border-slate-600"
            data-testid="button-export"
          >
            <Download className="w-4 h-4" />
          </Button>
        )}
      </div>

      {sortedStartups.length === 0 ? (
        <div className="text-center py-20 text-slate-400">
          <Rocket className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p>No startups yet. Click "Fetch & Score" to get started.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {sortedStartups.map((startup, index) => {
            const stage = PIPELINE_STAGES.find(s => s.id === startup.pipelineStage);
            const hasMuditaScore = startup.rawScores !== null;
            
            return (
              <div
                key={startup.id}
                onClick={() => navigate(`/startup/${startup.id}`)}
                className="flex items-center gap-4 p-4 bg-slate-800/50 border border-slate-700 rounded-lg cursor-pointer hover:border-purple-500 hover:bg-slate-800 transition-all group"
                data-testid={`startup-row-${startup.id}`}
              >
                <span className="text-slate-500 w-5 text-right text-sm">
                  {index + 1}
                </span>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-white group-hover:text-purple-300 transition-colors truncate">
                      {startup.name}
                    </h3>
                    {hasMuditaScore && (
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    )}
                  </div>
                  <p className="text-sm text-slate-400 truncate">
                    {startup.tagline}
                  </p>
                </div>

                <Badge className={`${stageColors[startup.pipelineStage]} text-xs`}>
                  {stage?.label || startup.pipelineStage}
                </Badge>

                <div className="w-11 h-11 rounded-lg bg-purple-600 flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-sm">
                    {getScore(startup)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
