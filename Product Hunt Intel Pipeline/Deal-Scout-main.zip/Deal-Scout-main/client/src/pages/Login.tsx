import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Lock, Mail } from "lucide-react";
import muditaLogo from "@assets/mudita-logo-Dc1-cjiV_1768343087044.jpeg";

const APP_TITLE_PART_1 = "Mudita";
const APP_TITLE_PART_2 = "VC Sourcing";
const APP_DESCRIPTION = "Track and discover promising startups from Product Hunt";

export default function Login() {
  const [, navigate] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!email.includes("@")) {
      setError("Please enter a valid email address");
      return;
    }

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    const success = login(email, password);
    
    if (success) {
      toast({
        title: "Welcome back!",
        description: "Successfully logged in to Mudita VC Sourcing",
      });
      navigate("/dashboard");
    } else {
      setError("Invalid email or password");
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
      <div className="flex flex-col items-center mb-12">
        <img
          src={muditaLogo}
          alt="Mudita Studios"
          className="w-20 h-20 border-2 border-white rounded object-cover mb-6"
        />
        
        <h1 className="text-4xl font-bold tracking-tight mb-3">
          <span className="text-white">{APP_TITLE_PART_1} </span>
          <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
            {APP_TITLE_PART_2}
          </span>
        </h1>
        
        <p className="text-zinc-400 text-base text-center max-w-md">
          {APP_DESCRIPTION}
        </p>
      </div>

      <div
        className={`w-full max-w-md bg-slate-800 rounded-2xl p-12 shadow-2xl ${
          shake ? "animate-shake" : ""
        }`}
        style={{ boxShadow: "0 20px 60px rgba(0, 0, 0, 0.5)" }}
      >
        <h2 className="text-2xl font-semibold text-white mb-2">Welcome back</h2>
        <p className="text-slate-400 text-sm mb-8">
          Enter your credentials to access your account
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-slate-200 text-sm font-medium mb-2">
              Email
            </label>
            <div className="flex items-center gap-3 bg-slate-900 border border-slate-700 rounded-lg px-4 py-3.5 focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-500/20 transition-all">
              <Mail className="w-5 h-5 text-slate-500 flex-shrink-0" />
              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-transparent text-white text-sm outline-none placeholder:text-slate-500"
                aria-label="Email address"
                required
                data-testid="input-email"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-200 text-sm font-medium mb-2">
              Password
            </label>
            <div className="flex items-center gap-3 bg-slate-900 border border-slate-700 rounded-lg px-4 py-3.5 focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-500/20 transition-all">
              <Lock className="w-5 h-5 text-slate-500 flex-shrink-0" />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="flex-1 bg-transparent text-white text-sm outline-none placeholder:text-slate-500"
                aria-label="Password"
                required
                data-testid="input-password"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-13 py-3.5 mt-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold rounded-lg transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-purple-500/40 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Sign in to your account"
            data-testid="button-login"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <Loader2 className="w-5 h-5 animate-spin" />
                Signing in...
              </span>
            ) : (
              "Sign In"
            )}
          </button>

          {error && (
            <p className="text-red-500 text-sm text-center animate-in fade-in duration-300">
              {error}
            </p>
          )}
        </form>

        <p className="text-center text-sm mt-5 text-slate-400">
          Don't have an account?{" "}
          <span className="text-blue-400 opacity-50 cursor-not-allowed">
            Sign up
          </span>
        </p>
      </div>
    </div>
  );
}
