import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Key,
  Bell,
  Clock,
  Database,
  Users,
  Download,
  Trash2,
  Save,
} from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState({
    highScore: true,
    newLaunches: true,
    followupReminders: true,
    weeklyDigest: true,
  });
  const [scrapeSchedule, setScrapeSchedule] = useState("daily");
  const [researchDepth, setResearchDepth] = useState("standard");

  const handleSave = () => {
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated.",
    });
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Configure your VC sourcing platform preferences
        </p>
      </div>

      <Card className="glass p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <Key className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">API Configuration</h3>
            <p className="text-sm text-muted-foreground">
              Configure external API keys and integrations
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="ph-api-key">Product Hunt API Key</Label>
            <Input
              id="ph-api-key"
              type="password"
              placeholder="Enter your Product Hunt API key"
              className="bg-background/50"
              data-testid="input-ph-api-key"
            />
            <p className="text-xs text-muted-foreground">
              Get your API key from{" "}
              <a href="https://www.producthunt.com/v2/oauth/applications" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">
                Product Hunt Developer Portal
              </a>
            </p>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="anthropic-api-key">Anthropic API Key</Label>
            <Input
              id="anthropic-api-key"
              type="password"
              placeholder="Using Replit AI Integrations"
              disabled
              className="bg-background/50"
              data-testid="input-anthropic-api-key"
            />
            <p className="text-xs text-muted-foreground">
              Powered by Replit AI Integrations - no additional API key required
            </p>
          </div>
        </div>
      </Card>

      <Card className="glass p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <Clock className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Scraping Schedule</h3>
            <p className="text-sm text-muted-foreground">
              Configure automatic Product Hunt scraping
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="grid gap-2">
            <Label>Scrape Frequency</Label>
            <Select value={scrapeSchedule} onValueChange={setScrapeSchedule}>
              <SelectTrigger className="bg-background/50" data-testid="select-scrape-frequency">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hourly">Every Hour</SelectItem>
                <SelectItem value="daily">Daily (Midnight UTC)</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="manual">Manual Only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label>Research Depth</Label>
            <Select value={researchDepth} onValueChange={setResearchDepth}>
              <SelectTrigger className="bg-background/50" data-testid="select-research-depth">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="quick">Quick (Faster, less detailed)</SelectItem>
                <SelectItem value="standard">Standard (Balanced)</SelectItem>
                <SelectItem value="deep">Deep (Comprehensive analysis)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <Card className="glass p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <Bell className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Notifications</h3>
            <p className="text-sm text-muted-foreground">
              Configure when you want to be notified
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>High Score Alerts</Label>
              <p className="text-sm text-muted-foreground">
                Notify when a startup scores 80+ points
              </p>
            </div>
            <Switch
              checked={notifications.highScore}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, highScore: checked })
              }
              data-testid="toggle-high-score-alerts"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <Label>New Launches</Label>
              <p className="text-sm text-muted-foreground">
                Notify when new startups are scraped
              </p>
            </div>
            <Switch
              checked={notifications.newLaunches}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, newLaunches: checked })
              }
              data-testid="toggle-new-launches"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <Label>Follow-up Reminders</Label>
              <p className="text-sm text-muted-foreground">
                Remind about scheduled follow-ups
              </p>
            </div>
            <Switch
              checked={notifications.followupReminders}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, followupReminders: checked })
              }
              data-testid="toggle-followup-reminders"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <Label>Weekly Digest</Label>
              <p className="text-sm text-muted-foreground">
                Send a summary of top startups each week
              </p>
            </div>
            <Switch
              checked={notifications.weeklyDigest}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, weeklyDigest: checked })
              }
              data-testid="toggle-weekly-digest"
            />
          </div>
        </div>
      </Card>

      <Card className="glass p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <Database className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Data Management</h3>
            <p className="text-sm text-muted-foreground">
              Export or manage your data
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          <Button variant="outline" className="gap-2" data-testid="button-export-startups">
            <Download className="w-4 h-4" />
            Export Startups (CSV)
          </Button>
          <Button variant="outline" className="gap-2" data-testid="button-export-pipeline">
            <Download className="w-4 h-4" />
            Export Pipeline
          </Button>
          <Button variant="outline" className="gap-2 text-destructive hover:text-destructive" data-testid="button-clear-data">
            <Trash2 className="w-4 h-4" />
            Clear All Data
          </Button>
        </div>
      </Card>

      <Card className="glass p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <Users className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Team Management</h3>
            <p className="text-sm text-muted-foreground">
              Manage team members and roles
            </p>
          </div>
        </div>

        <div className="p-8 text-center text-muted-foreground border border-dashed border-border rounded-lg">
          <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Team management coming soon</p>
          <p className="text-sm mt-1">
            Invite team members and assign roles for collaborative deal flow management
          </p>
        </div>
      </Card>

      <div className="flex justify-end">
        <Button className="gap-2" onClick={handleSave} data-testid="button-save-settings">
          <Save className="w-4 h-4" />
          Save Settings
        </Button>
      </div>
    </div>
  );
}
