import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Sparkles, Plus, Save, Loader2, Check, Star, Info, Copy, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";
import type { ScoringConfigRecord, ScoringProfile } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MuditaCriteria {
  key: string;
  name: string;
  description: string;
  scaleDescriptions: Record<string, string>;
}

interface MuditaSection {
  code: string;
  name: string;
  criteria: readonly string[];
}

interface MuditaDefinitions {
  criteria: MuditaCriteria[];
  sections: MuditaSection[];
}

export default function ScoringConfigPage() {
  const { toast } = useToast();
  const [weights, setWeights] = useState<{ [key: string]: number }>({});
  const [newProfileName, setNewProfileName] = useState("");
  const [newProfileDescription, setNewProfileDescription] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: configs = [], isLoading: configsLoading } = useQuery<ScoringConfigRecord[]>({
    queryKey: ["/api/scoring-config"],
  });

  const { data: profiles = [], isLoading: profilesLoading } = useQuery<ScoringProfile[]>({
    queryKey: ["/api/scoring-profiles"],
  });

  const { data: definitions } = useQuery<MuditaDefinitions>({
    queryKey: ["/api/mudita-criteria"],
  });

  useEffect(() => {
    if (configs.length > 0) {
      const initialWeights: { [key: string]: number } = {};
      configs.forEach((c) => {
        initialWeights[c.sectionCode] = c.weight;
      });
      setWeights(initialWeights);
    }
  }, [configs]);

  const saveWeightsMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PUT", "/api/scoring-config/weights", weights);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scoring-config"] });
      toast({ title: "Weights saved successfully" });
    },
    onError: () => {
      toast({ title: "Failed to save weights", variant: "destructive" });
    },
  });

  const createProfileMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/scoring-profiles", {
        name: newProfileName,
        description: newProfileDescription,
        weights: weights,
        isDefault: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scoring-profiles"] });
      toast({ title: "Profile created" });
      setNewProfileName("");
      setNewProfileDescription("");
      setDialogOpen(false);
    },
    onError: () => {
      toast({ title: "Failed to create profile", variant: "destructive" });
    },
  });

  const setDefaultMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("POST", `/api/scoring-profiles/${id}/set-default`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scoring-profiles"] });
      toast({ title: "Default profile updated" });
    },
  });

  const deleteProfileMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/scoring-profiles/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scoring-profiles"] });
      toast({ title: "Profile deleted" });
    },
  });

  const applyProfile = (profile: ScoringProfile) => {
    const profileWeights = profile.weights as unknown as { [key: string]: number };
    setWeights(profileWeights);
    toast({ title: `Applied "${profile.name}" weights` });
  };

  const totalWeight = Object.values(weights).reduce((sum, w) => sum + (w || 0), 0);
  const activeWeight = Object.entries(weights)
    .filter(([code]) => code !== "F" && code !== "G")
    .reduce((sum, [, w]) => sum + (w || 0), 0);

  const updateWeight = (sectionCode: string, value: number) => {
    setWeights((prev) => ({ ...prev, [sectionCode]: value }));
  };

  const getCriteriaForSection = (sectionCode: string): MuditaCriteria[] => {
    if (!definitions) return [];
    const section = definitions.sections.find((s) => s.code === sectionCode);
    if (!section) return [];
    return definitions.criteria.filter((c) => section.criteria.includes(c.key));
  };

  const getSectionColor = (code: string) => {
    const colors: { [key: string]: string } = {
      A: "text-blue-400",
      B: "text-orange-400",
      C: "text-yellow-400",
      D: "text-green-400",
      E: "text-purple-400",
      F: "text-cyan-400",
      G: "text-pink-400",
    };
    return colors[code] || "text-foreground";
  };

  const isLoading = configsLoading || profilesLoading;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Mudita Scoring System</h1>
          <p className="text-muted-foreground mt-1">
            Configure weights across 7 sections with 13 investment criteria
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2" data-testid="button-save-as-profile">
                <Plus className="w-4 h-4" />
                Save as Profile
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Save Weight Profile</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div>
                  <Label>Profile Name</Label>
                  <Input
                    value={newProfileName}
                    onChange={(e) => setNewProfileName(e.target.value)}
                    placeholder="e.g., Early Stage Focus"
                    data-testid="input-profile-name"
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Input
                    value={newProfileDescription}
                    onChange={(e) => setNewProfileDescription(e.target.value)}
                    placeholder="Brief description of this weight configuration"
                    data-testid="input-profile-description"
                  />
                </div>
                <Button
                  className="w-full gap-2"
                  onClick={() => createProfileMutation.mutate()}
                  disabled={!newProfileName || createProfileMutation.isPending}
                  data-testid="button-create-profile"
                >
                  {createProfileMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  Create Profile
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <Button
            className="gap-2"
            onClick={() => saveWeightsMutation.mutate()}
            disabled={saveWeightsMutation.isPending || Math.abs(totalWeight - 100) > 0.01}
            data-testid="button-save-weights"
          >
            {saveWeightsMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            Save Weights
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="glass p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
              <Sparkles className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Total Weight</h3>
              <p className="text-xs text-muted-foreground">Must equal 100%</p>
            </div>
          </div>
          <div className={`text-4xl font-bold ${Math.abs(totalWeight - 100) < 0.01 ? "text-green-400" : "text-yellow-400"}`}>
            {totalWeight}%
          </div>
          {Math.abs(totalWeight - 100) > 0.01 && (
            <p className="text-xs text-yellow-400 mt-2">
              Adjust weights to equal 100%
            </p>
          )}
        </Card>

        <Card className="glass p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <Info className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Active Sections</h3>
              <p className="text-xs text-muted-foreground">A through E (F, G are placeholders)</p>
            </div>
          </div>
          <div className="text-4xl font-bold text-foreground">
            {activeWeight}%
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            5 sections with 11 criteria
          </p>
        </Card>

        <Card className="glass p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/20">
              <Star className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Score Range</h3>
              <p className="text-xs text-muted-foreground">Final score calculation</p>
            </div>
          </div>
          <div className="text-4xl font-bold text-foreground">0-100</div>
          <p className="text-xs text-muted-foreground mt-2">
            Normalized from 1-10 criteria scores
          </p>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-4">
        <div className="lg:col-span-3 space-y-4">
          <h2 className="text-xl font-semibold text-foreground">Section Weights</h2>
          
          {isLoading ? (
            <div className="grid gap-4">
              {Array(7).fill(0).map((_, i) => (
                <Card key={i} className="glass p-6">
                  <Skeleton className="h-6 w-48 mb-4" />
                  <Skeleton className="h-4 w-full" />
                </Card>
              ))}
            </div>
          ) : (
            <Accordion type="multiple" className="space-y-3" defaultValue={["A", "B", "C", "D", "E"]}>
              {configs.map((config) => {
                const sectionCriteria = getCriteriaForSection(config.sectionCode);
                const isPlaceholder = config.sectionCode === "F" || config.sectionCode === "G";
                
                return (
                  <AccordionItem
                    key={config.sectionCode}
                    value={config.sectionCode}
                    className={`border-none ${isPlaceholder ? "opacity-50" : ""}`}
                  >
                    <Card className="glass overflow-visible">
                      <AccordionTrigger className="px-6 py-4 hover:no-underline">
                        <div className="flex items-center justify-between w-full pr-4 gap-4">
                          <div className="flex items-center gap-3">
                            <span className={`text-lg font-bold ${getSectionColor(config.sectionCode)}`}>
                              {config.sectionCode}.
                            </span>
                            <div className="text-left">
                              <div className="font-semibold text-foreground">{config.sectionName}</div>
                              <div className="text-xs text-muted-foreground">
                                {sectionCriteria.length} criteria
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="w-40 flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
                              <Slider
                                value={[weights[config.sectionCode] || 0]}
                                onValueChange={([value]) => updateWeight(config.sectionCode, value)}
                                max={50}
                                step={1}
                                disabled={isPlaceholder}
                                className="flex-1"
                                data-testid={`slider-${config.sectionCode}`}
                              />
                              <span className="text-sm font-medium w-10 text-right">
                                {weights[config.sectionCode] || 0}%
                              </span>
                            </div>
                            {isPlaceholder && (
                              <Badge variant="outline" className="text-xs">
                                Placeholder
                              </Badge>
                            )}
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-6 pb-4">
                        <div className="space-y-4 pt-2">
                          {sectionCriteria.length === 0 ? (
                            <p className="text-sm text-muted-foreground italic">
                              This section is a placeholder for future criteria (Founder/Team or Traction data).
                            </p>
                          ) : (
                            sectionCriteria.map((criterion) => (
                              <div
                                key={criterion.key}
                                className="p-4 rounded-lg bg-background/40 border border-border/50"
                              >
                                <div className="flex items-start justify-between gap-4 mb-3">
                                  <div>
                                    <h4 className="font-medium text-foreground">{criterion.name}</h4>
                                    <p className="text-sm text-muted-foreground">{criterion.description}</p>
                                  </div>
                                  <Badge variant="secondary" className="text-xs shrink-0">
                                    1-10 scale
                                  </Badge>
                                </div>
                                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                                  {Object.entries(criterion.scaleDescriptions).map(([score, desc]) => (
                                    <div
                                      key={score}
                                      className="text-xs p-2 rounded bg-background/50 border border-border/30"
                                    >
                                      <span className="font-semibold text-foreground">{score}:</span>{" "}
                                      <span className="text-muted-foreground">{desc}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </AccordionContent>
                    </Card>
                  </AccordionItem>
                );
              })}
            </Accordion>
          )}
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-foreground">Weight Profiles</h2>
          
          {profilesLoading ? (
            <div className="space-y-3">
              {Array(3).fill(0).map((_, i) => (
                <Card key={i} className="glass p-4">
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-3 w-full" />
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {profiles.map((profile) => (
                <Card
                  key={profile.id}
                  className="glass p-4 hover-elevate cursor-pointer"
                  onClick={() => applyProfile(profile)}
                  data-testid={`profile-${profile.id}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-medium text-foreground truncate">{profile.name}</h4>
                        {profile.isDefault && (
                          <Badge variant="secondary" className="text-xs gap-1 shrink-0">
                            <Check className="w-3 h-3" />
                            Default
                          </Badge>
                        )}
                      </div>
                      {profile.description && (
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {profile.description}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          applyProfile(profile);
                        }}
                        title="Apply weights"
                        data-testid={`button-apply-profile-${profile.id}`}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      {!profile.isDefault && (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDefaultMutation.mutate(profile.id);
                            }}
                            title="Set as default"
                            data-testid={`button-set-default-${profile.id}`}
                          >
                            <Star className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteProfileMutation.mutate(profile.id);
                            }}
                            className="text-destructive hover:text-destructive"
                            title="Delete profile"
                            data-testid={`button-delete-profile-${profile.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-3">
                    {Object.entries(profile.weights as unknown as { [key: string]: number })
                      .filter(([, w]) => w > 0)
                      .map(([code, weight]) => (
                        <Badge
                          key={code}
                          variant="outline"
                          className={`text-xs ${getSectionColor(code)}`}
                        >
                          {code}: {weight}%
                        </Badge>
                      ))}
                  </div>
                </Card>
              ))}
            </div>
          )}

          <Card className="glass p-4">
            <h4 className="font-medium text-foreground mb-2">Score Interpretation</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-green-400">80-100</span>
                <span className="text-muted-foreground">Strong Investment</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-yellow-400">60-79</span>
                <span className="text-muted-foreground">Worth Exploring</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">40-59</span>
                <span className="text-muted-foreground">Needs Review</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-red-400">0-39</span>
                <span className="text-muted-foreground">Pass</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
