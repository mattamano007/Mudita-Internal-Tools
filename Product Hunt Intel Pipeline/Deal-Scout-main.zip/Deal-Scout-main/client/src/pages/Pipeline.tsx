import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { PipelineColumn } from "@/components/PipelineColumn";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Kanban, Filter, Download } from "lucide-react";
import type { Startup } from "@shared/schema";
import { PIPELINE_STAGES } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Pipeline() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [draggedStartup, setDraggedStartup] = useState<Startup | null>(null);

  const { data: startups = [], isLoading } = useQuery<Startup[]>({
    queryKey: ["/api/startups"],
  });

  const updateStageMutation = useMutation({
    mutationFn: async ({ id, stage }: { id: number; stage: string }) => {
      return apiRequest("PATCH", `/api/startups/${id}`, { pipelineStage: stage });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups"] });
      toast({
        title: "Stage updated",
        description: "Startup moved to new pipeline stage.",
      });
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Could not update startup stage.",
        variant: "destructive",
      });
    },
  });

  const handleDragStart = (e: React.DragEvent, startup: Startup) => {
    setDraggedStartup(startup);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, stage: string) => {
    e.preventDefault();
    if (draggedStartup && draggedStartup.pipelineStage !== stage) {
      updateStageMutation.mutate({ id: draggedStartup.id, stage });
    }
    setDraggedStartup(null);
  };

  const getStartupsByStage = (stageId: string) => {
    return startups.filter((s) => s.pipelineStage === stageId);
  };

  const totalInPipeline = startups.filter(
    (s) => !["discovered", "declined", "portfolio"].includes(s.pipelineStage)
  ).length;

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Pipeline</h1>
          <p className="text-muted-foreground mt-1">
            {totalInPipeline} active prospects across {PIPELINE_STAGES.length} stages
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2" data-testid="button-filter-pipeline">
            <Filter className="w-4 h-4" />
            Filter
          </Button>
          <Button variant="outline" className="gap-2" data-testid="button-export-pipeline">
            <Download className="w-4 h-4" />
            Export
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex gap-4 overflow-hidden">
          {Array(5).fill(0).map((_, i) => (
            <Card key={i} className="w-72 flex-shrink-0 glass p-4">
              <Skeleton className="h-6 w-32 mb-4" />
              <div className="space-y-3">
                {Array(3).fill(0).map((_, j) => (
                  <Card key={j} className="glass p-3">
                    <div className="flex items-center gap-3">
                      <Skeleton className="w-10 h-10 rounded-lg" />
                      <div className="flex-1">
                        <Skeleton className="h-4 w-24 mb-1" />
                        <Skeleton className="h-3 w-32" />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>
          ))}
        </div>
      ) : startups.length === 0 ? (
        <Card className="glass p-12 text-center flex-1 flex flex-col items-center justify-center">
          <Kanban className="w-16 h-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">
            No startups in pipeline
          </h3>
          <p className="text-muted-foreground max-w-md">
            Discover startups from Product Hunt and add them to your pipeline to track investment opportunities.
          </p>
          <Button className="mt-6" onClick={() => navigate("/launches")} data-testid="button-go-to-launches">
            Go to Launches
          </Button>
        </Card>
      ) : (
        <ScrollArea className="flex-1 -mx-6 px-6">
          <div className="flex gap-4 pb-4 min-h-[calc(100vh-200px)]">
            {PIPELINE_STAGES.map((stage) => (
              <PipelineColumn
                key={stage.id}
                stage={stage}
                startups={getStartupsByStage(stage.id)}
                onStartupClick={(startup) => navigate(`/startup/${startup.id}`)}
                onStageChange={(startupId, newStage) =>
                  updateStageMutation.mutate({ id: startupId, stage: newStage })
                }
                onDragStart={handleDragStart}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
              />
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      )}
    </div>
  );
}
