import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  ExternalLink,
  ThumbsUp,
  MessageSquare,
  Globe,
  Sparkles,
  Loader2,
  Send,
  Rocket,
  TrendingUp,
} from "lucide-react";
import { format } from "date-fns";
import { useState } from "react";
import type { Startup, Interaction, ScoreBreakdown, ResearchData } from "@shared/schema";
import { PIPELINE_STAGES } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function StartupDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [newNote, setNewNote] = useState("");

  const { data: startup, isLoading } = useQuery<Startup>({
    queryKey: ["/api/startups", id],
  });

  const { data: interactions = [] } = useQuery<Interaction[]>({
    queryKey: ["/api/startups", id, "interactions"],
    enabled: !!id,
  });

  const updateStageMutation = useMutation({
    mutationFn: async (stage: string) => {
      return apiRequest("PATCH", `/api/startups/${id}`, { pipelineStage: stage });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/startups"] });
      toast({ title: "Stage updated" });
    },
  });

  const researchMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/startups/${id}/research`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups", id] });
      toast({ title: "Research completed" });
    },
    onError: () => {
      toast({ title: "Research failed", variant: "destructive" });
    },
  });

  const scoreMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/startups/${id}/score`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups", id] });
      toast({ title: "Scoring completed" });
    },
    onError: () => {
      toast({ title: "Scoring failed", variant: "destructive" });
    },
  });

  const addNoteMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/startups/${id}/interactions`, {
        interactionType: "note",
        content: newNote,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/startups", id, "interactions"] });
      setNewNote("");
      toast({ title: "Note added" });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
      </div>
    );
  }

  if (!startup) {
    return (
      <div className="text-center py-20">
        <p className="text-slate-400 mb-4">Startup not found</p>
        <Button onClick={() => navigate("/dashboard")} data-testid="button-back-to-dashboard">
          Back
        </Button>
      </div>
    );
  }

  const scoreBreakdown = startup.scoreBreakdown as ScoreBreakdown | null;
  const researchData = startup.researchData as ResearchData | null;

  return (
    <div className="max-w-3xl mx-auto px-6 py-8">
      <button
        onClick={() => navigate("/dashboard")}
        className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        data-testid="button-back"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      <div className="mb-8">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">{startup.name}</h1>
            <p className="text-slate-400">{startup.tagline}</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 rounded-xl bg-purple-600 flex items-center justify-center mb-2">
              <span className="text-2xl font-bold text-white">
                {startup.phDefaultScore || startup.scoreTotal || "--"}
              </span>
            </div>
            <span className="text-xs text-slate-500">Score</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-sm text-slate-400 mb-6">
          <span className="flex items-center gap-1">
            <ThumbsUp className="w-4 h-4" />
            {startup.votes || 0}
          </span>
          <span className="flex items-center gap-1">
            <MessageSquare className="w-4 h-4" />
            {startup.comments || 0}
          </span>
          {startup.launchDate && (
            <span>{format(new Date(startup.launchDate), "MMM d, yyyy")}</span>
          )}
          {startup.websiteUrl && (
            <a
              href={startup.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-purple-400 hover:text-purple-300"
              data-testid="link-website"
            >
              <Globe className="w-4 h-4" />
              Website
              <ExternalLink className="w-3 h-3" />
            </a>
          )}
          {startup.productHuntUrl && (
            <a
              href={startup.productHuntUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-orange-400 hover:text-orange-300"
              data-testid="link-ph"
            >
              <Rocket className="w-4 h-4" />
              Product Hunt
              <ExternalLink className="w-3 h-3" />
            </a>
          )}
        </div>

        <div className="flex items-center gap-3">
          <Select
            value={startup.pipelineStage}
            onValueChange={(value) => updateStageMutation.mutate(value)}
          >
            <SelectTrigger className="w-44 bg-slate-800 border-slate-700" data-testid="select-stage">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PIPELINE_STAGES.map((stage) => (
                <SelectItem key={stage.id} value={stage.id}>
                  {stage.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            size="sm"
            onClick={() => researchMutation.mutate()}
            disabled={researchMutation.isPending}
            className="border-slate-700"
            data-testid="button-research"
          >
            {researchMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => scoreMutation.mutate()}
            disabled={scoreMutation.isPending}
            className="border-slate-700"
            data-testid="button-score"
          >
            {scoreMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <TrendingUp className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>

      {startup.description && (
        <div className="mb-8">
          <h2 className="text-sm font-medium text-slate-500 uppercase tracking-wide mb-2">About</h2>
          <p className="text-slate-300">{startup.description}</p>
        </div>
      )}

      {scoreBreakdown && (
        <div className="mb-8">
          <h2 className="text-sm font-medium text-slate-500 uppercase tracking-wide mb-3">Score Breakdown</h2>
          <div className="grid grid-cols-2 gap-3">
            {Object.entries(scoreBreakdown).map(([key, val]) => (
              <div key={key} className="bg-slate-800/50 border border-slate-700 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-white capitalize">{key}</span>
                  <span className="text-purple-400 font-bold">{val?.score || 0}</span>
                </div>
                {val?.justification && (
                  <p className="text-xs text-slate-500 line-clamp-2">{val.justification}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {researchData && (
        <div className="mb-8">
          <h2 className="text-sm font-medium text-slate-500 uppercase tracking-wide mb-3">Research</h2>
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 space-y-3 text-sm">
            {researchData.marketSize && (
              <div>
                <span className="text-slate-500">Market Size: </span>
                <span className="text-slate-300">{researchData.marketSize}</span>
              </div>
            )}
            {researchData.fundingStatus && (
              <div>
                <span className="text-slate-500">Funding: </span>
                <span className="text-slate-300">{researchData.fundingStatus}</span>
              </div>
            )}
            {researchData.competitors && researchData.competitors.length > 0 && (
              <div>
                <span className="text-slate-500">Competitors: </span>
                <span className="text-slate-300">{researchData.competitors.slice(0, 5).join(", ")}</span>
              </div>
            )}
          </div>
        </div>
      )}

      <div>
        <h2 className="text-sm font-medium text-slate-500 uppercase tracking-wide mb-3">Notes</h2>
        <div className="flex gap-2 mb-4">
          <Textarea
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder="Add a note..."
            className="bg-slate-800 border-slate-700 min-h-[60px]"
            data-testid="input-note"
          />
          <Button
            onClick={() => addNoteMutation.mutate()}
            disabled={!newNote.trim() || addNoteMutation.isPending}
            className="bg-purple-600 hover:bg-purple-700"
            data-testid="button-add-note"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {interactions.length > 0 && (
          <div className="space-y-2">
            {interactions.map((interaction) => (
              <div
                key={interaction.id}
                className="bg-slate-800/50 border border-slate-700 rounded-lg p-3"
              >
                <p className="text-slate-300 text-sm">{interaction.content}</p>
                <p className="text-xs text-slate-500 mt-1">
                  {format(new Date(interaction.createdAt), "MMM d, h:mm a")}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
