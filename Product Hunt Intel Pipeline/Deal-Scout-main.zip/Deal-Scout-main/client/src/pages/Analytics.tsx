import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts";
import type { Startup } from "@shared/schema";

const COLORS = ["#a855f7", "#3b82f6", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4", "#8b5cf6"];

const SECTION_CONFIG = {
  A: { name: "Market Environment", color: "#3b82f6" },
  B: { name: "Competition", color: "#f59e0b" },
  C: { name: "Cost/Difficulty", color: "#ef4444" },
  D: { name: "Product Need", color: "#22c55e" },
  E: { name: "Financial Return", color: "#a855f7" },
};

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("7d");

  const { data: startups = [], isLoading } = useQuery<Startup[]>({
    queryKey: ["/api/startups"],
  });

  const scoreDistribution = [
    { range: "90-100", count: startups.filter((s) => (s.scoreTotal || 0) >= 90).length },
    { range: "80-89", count: startups.filter((s) => (s.scoreTotal || 0) >= 80 && (s.scoreTotal || 0) < 90).length },
    { range: "70-79", count: startups.filter((s) => (s.scoreTotal || 0) >= 70 && (s.scoreTotal || 0) < 80).length },
    { range: "60-69", count: startups.filter((s) => (s.scoreTotal || 0) >= 60 && (s.scoreTotal || 0) < 70).length },
    { range: "50-59", count: startups.filter((s) => (s.scoreTotal || 0) >= 50 && (s.scoreTotal || 0) < 60).length },
    { range: "<50", count: startups.filter((s) => (s.scoreTotal || 0) < 50 && s.scoreTotal !== null).length },
    { range: "Unscored", count: startups.filter((s) => s.scoreTotal === null).length },
  ];

  const pipelineDistribution = [
    { name: "Discovered", value: startups.filter((s) => s.pipelineStage === "discovered").length },
    { name: "High Potential", value: startups.filter((s) => s.pipelineStage === "high_potential").length },
    { name: "Outreach", value: startups.filter((s) => s.pipelineStage === "outreach").length },
    { name: "Conversation", value: startups.filter((s) => s.pipelineStage === "conversation").length },
    { name: "Due Diligence", value: startups.filter((s) => s.pipelineStage === "due_diligence").length },
    { name: "Portfolio", value: startups.filter((s) => s.pipelineStage === "portfolio").length },
    { name: "Declined", value: startups.filter((s) => s.pipelineStage === "declined").length },
  ].filter((d) => d.value > 0);

  const categoryData = startups.reduce((acc, startup) => {
    const categories = (startup.categories as string[]) || [];
    categories.forEach((cat) => {
      acc[cat] = (acc[cat] || 0) + 1;
    });
    return acc;
  }, {} as Record<string, number>);

  const topCategories = Object.entries(categoryData)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name, count }));

  const sectionAverages = Object.entries(SECTION_CONFIG).map(([code, config]) => {
    const startupsWithSection = startups.filter((s) => {
      const sectionScores = s.sectionScores as unknown as Record<string, number | null> | null;
      if (!sectionScores) return false;
      const key = Object.keys(sectionScores).find((k) => k.startsWith(code));
      return key && sectionScores[key] !== null;
    });
    
    const avgScore = startupsWithSection.length > 0
      ? startupsWithSection.reduce((sum, s) => {
          const sectionScores = s.sectionScores as unknown as Record<string, number | null>;
          const key = Object.keys(sectionScores).find((k) => k.startsWith(code))!;
          return sum + (sectionScores[key] || 0);
        }, 0) / startupsWithSection.length
      : 0;
    
    return {
      section: config.name,
      avgScore: Math.round(avgScore * 10) / 10,
      count: startupsWithSection.length,
      color: config.color,
    };
  });

  const weeklyData = [
    { day: "Mon", launches: 12, scored: 8, highPotential: 3 },
    { day: "Tue", launches: 19, scored: 14, highPotential: 5 },
    { day: "Wed", launches: 15, scored: 11, highPotential: 4 },
    { day: "Thu", launches: 22, scored: 18, highPotential: 7 },
    { day: "Fri", launches: 28, scored: 22, highPotential: 9 },
    { day: "Sat", launches: 18, scored: 12, highPotential: 4 },
    { day: "Sun", launches: 25, scored: 20, highPotential: 8 },
  ];

  const avgScore = startups.length > 0
    ? Math.round(startups.filter((s) => s.scoreTotal).reduce((sum, s) => sum + (s.scoreTotal || 0), 0) / startups.filter((s) => s.scoreTotal).length)
    : 0;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-strong rounded-lg p-3 text-sm">
          <p className="font-medium text-foreground">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {entry.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Insights and trends from your startup pipeline
          </p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-36 bg-background/50" data-testid="select-time-range">
            <SelectValue placeholder="Time range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
            <SelectItem value="all">All time</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading ? (
          Array(4).fill(0).map((_, i) => (
            <Card key={i} className="glass p-6">
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-8 w-16" />
            </Card>
          ))
        ) : (
          <>
            <Card className="glass p-6">
              <p className="text-sm text-muted-foreground">Total Startups</p>
              <p className="text-3xl font-bold text-foreground mt-1">{startups.length}</p>
            </Card>
            <Card className="glass p-6">
              <p className="text-sm text-muted-foreground">Average Score</p>
              <p className="text-3xl font-bold text-foreground mt-1">{avgScore || "--"}</p>
            </Card>
            <Card className="glass p-6">
              <p className="text-sm text-muted-foreground">High Potential</p>
              <p className="text-3xl font-bold text-green-400 mt-1">
                {startups.filter((s) => (s.scoreTotal || 0) >= 70).length}
              </p>
            </Card>
            <Card className="glass p-6">
              <p className="text-sm text-muted-foreground">Conversion Rate</p>
              <p className="text-3xl font-bold text-purple-400 mt-1">
                {startups.length > 0 
                  ? Math.round((startups.filter((s) => s.pipelineStage === "portfolio").length / startups.length) * 100)
                  : 0}%
              </p>
            </Card>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass p-6">
          <h3 className="text-lg font-semibold text-foreground mb-6">Weekly Activity</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weeklyData}>
                <defs>
                  <linearGradient id="launchGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="scoredGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="launches" stroke="#a855f7" strokeWidth={2} fill="url(#launchGrad)" name="Launches" />
                <Area type="monotone" dataKey="scored" stroke="#3b82f6" strokeWidth={2} fill="url(#scoredGrad)" name="Scored" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="glass p-6">
          <h3 className="text-lg font-semibold text-foreground mb-6">Pipeline Distribution</h3>
          <div className="h-72">
            {pipelineDistribution.length === 0 ? (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                No data available
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pipelineDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {pipelineDistribution.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="glass p-6">
          <h3 className="text-lg font-semibold text-foreground mb-6">Score Distribution</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scoreDistribution} layout="vertical">
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 12 }} />
                <YAxis type="category" dataKey="range" axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 12 }} width={70} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="count" fill="#a855f7" radius={[0, 4, 4, 0]} name="Startups" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="glass p-6">
          <h3 className="text-lg font-semibold text-foreground mb-6">Top Categories</h3>
          <div className="h-72">
            {topCategories.length === 0 ? (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                No category data available
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topCategories}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 10 }} angle={-45} textAnchor="end" height={60} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 12 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Startups" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>
      </div>

      <Card className="glass p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6">Section Score Averages (Mudita Criteria)</h3>
        <div className="h-72">
          {sectionAverages.every((s) => s.count === 0) ? (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              No section score data available. Score some startups to see analytics.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sectionAverages} layout="vertical">
                <XAxis type="number" domain={[0, 10]} axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 12 }} />
                <YAxis type="category" dataKey="section" axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 12 }} width={120} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="avgScore" radius={[0, 4, 4, 0]} name="Average Score">
                  {sectionAverages.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
        <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
          {sectionAverages.map((section) => (
            <div key={section.section} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: section.color }} />
              <span>{section.section}: {section.avgScore}/10 ({section.count} scored)</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
