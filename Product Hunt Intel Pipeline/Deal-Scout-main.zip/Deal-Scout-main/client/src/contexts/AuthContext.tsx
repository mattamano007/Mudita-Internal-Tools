import { createContext, useContext, useState, useEffect } from "react";

interface AuthContextType {
  isAuthenticated: boolean;
  userEmail: string | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const VALID_EMAIL = "gtm@muditastudios.com";
const VALID_PASSWORD = "Mudita";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    const storedAuth = localStorage.getItem("mudita_auth");
    if (storedAuth) {
      const { email, timestamp } = JSON.parse(storedAuth);
      const now = Date.now();
      const oneDay = 24 * 60 * 60 * 1000;
      if (now - timestamp < oneDay) {
        setIsAuthenticated(true);
        setUserEmail(email);
      } else {
        localStorage.removeItem("mudita_auth");
      }
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    if (email === VALID_EMAIL && password === VALID_PASSWORD) {
      setIsAuthenticated(true);
      setUserEmail(email);
      localStorage.setItem("mudita_auth", JSON.stringify({
        email,
        timestamp: Date.now()
      }));
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUserEmail(null);
    localStorage.removeItem("mudita_auth");
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, userEmail, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
