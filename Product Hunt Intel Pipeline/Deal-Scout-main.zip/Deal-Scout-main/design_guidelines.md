# Design Guidelines: VC Sourcing & Scoring Platform

## Design Approach
**System Selected:** Custom Dark Theme with Material Design principles
**Rationale:** Data-heavy enterprise application requiring clear hierarchy and efficient scanning for investment professionals. Premium aesthetic balances sophistication with functional density.

## Core Visual Identity

### Color Palette
- **Background:** Dark gradient navy (#0a0e27) to dark purple (#1a0b2e)
- **Primary Accent:** Bright purple (#a855f7)
- **Text:** White (#ffffff) headings, gray (#9ca3af) body
- **Score Badges:** Green (>80), Yellow (60-79), Gray (<60)
- **Visualizations:** Purple/blue gradient scheme

### Typography
**Font Family:** Inter (primary) via Google Fonts
- H1: 2.5rem, font-bold, white
- H2: 2rem, font-semibold, white  
- H3: 1.5rem, font-semibold, white
- Body: 1rem, font-normal, gray
- Small: 0.875rem, font-normal, gray

### Layout System
**Spacing Units:** Tailwind 2, 4, 6, 8, 12, 16
- Container: max-w-7xl with px-6
- Card padding: p-6 to p-8
- Grid gaps: gap-4 (tight), gap-6 (standard), gap-8 (spacious)

## Component Library

### Glassmorphism Cards
- backdrop-blur-lg with bg-white/5
- Border: 1px border-purple-500/20
- Corners: rounded-xl
- Hover: Purple glow (box-shadow: 0 0 20px rgba(168, 85, 247, 0.3))

### Startup Cards
**List View:** Horizontal glassmorphism card with:
- Left: Logo (64x64 circular, purple border)
- Center: Name (H3), tagline, tag pills
- Right: Score badge (60px diameter), quick metrics, pipeline stage
- Hover: Intensified glow, subtle lift transform

### Score Badges
**Large (Detail):** 120px diameter, bold score, radial category breakdown
**Small (Cards):** 60px diameter, score only
**Styling:** Circular gradient with subtle outer glow matching color tier

### Navigation
**Top Bar:** Sticky glassmorphism header (h-16)
- Logo: Left with purple glow
- Main nav: Center, purple underline on active
- User menu: Right with avatar dropdown

### Data Tables
- Header: Purple gradient background, white bold text
- Rows: Alternating bg-white/5, hover purple/10
- Borders: border-purple-500/10
- Cell spacing: py-4 px-6

### Pipeline Kanban
- Vertical glassmorphism columns with equal widths
- Stage headers: Purple gradient with count badges
- Draggable cards: Compact startup cards with purple drag handles
- Layout: Horizontal scroll when needed

### Form Elements
- Input: bg-white/5, border-purple-500/20, white text
- Focus: border-purple-500 ring-2 ring-purple-500/20
- Spacing: py-3 px-4

### Buttons
- Primary: bg-purple-600 hover:bg-purple-700, px-6 py-3, rounded-lg
- Secondary: border-2 border-purple-500, text-purple-400, hover:bg-purple-500/10
- On images: backdrop-blur-md bg-purple-600/80

### Icons
**Library:** Lucide React exclusively
- Color: Purple (#a855f7) with glow
- Sizes: w-5 h-5 (inline), w-6 h-6 (standalone), w-8 h-8 (features)
- Feature icons: Dark circular containers (bg-purple-900/30)

## Page Layouts

### Dashboard
- Hero stats: 4-column grid with large numbers and trend indicators
- Today's launches: 2-column startup card grid
- Pipeline overview: Horizontal stage cards
- Charts: Full-width Recharts with purple/blue gradients

### Startup Detail
- Header: Full-width, logo left, name center, score right
- Tab navigation: Horizontal with purple active indicator
- Content: 2-column (8-4) - main content left, metrics sidebar right
- Research: Accordion glassmorphism cards with source icons

### Pipeline Board
- 5-7 equal-width columns based on investment stages
- Height: min-h-screen minus header
- Card width: 280px, compact vertical layout

### Analytics
- 2-column grid for chart pairs
- Full-width for complex visualizations
- Sticky filter bar: date range, category, score filters

## Special Effects
- **Background:** Animated particle network (subtle purple dots and connecting lines)
- **Transitions:** transition-all duration-300 for all interactions
- **Loading:** Purple spinner or skeleton with shimmer effect
- **Data Viz:** Recharts with dark theme, purple/blue color palette, gridlines at purple/10 opacity, glassmorphism tooltips

## Images
No hero images. This is a data-centric application where visual hierarchy is achieved through glassmorphism, gradients, particle animations, and structured data presentation. Focus remains on information density and premium aesthetic through effects rather than imagery.