import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, boolean, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table for team members
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("analyst"),
});

export const usersRelations = relations(users, ({ many }) => ({
  startups: many(startups),
  interactions: many(interactions),
}));

// Startups discovered from Product Hunt
export const startups = pgTable("startups", {
  id: serial("id").primaryKey(),
  productHuntId: text("product_hunt_id").unique(),
  productHuntUrl: text("product_hunt_url"),
  name: text("name").notNull(),
  tagline: text("tagline"),
  description: text("description"),
  websiteUrl: text("website_url"),
  logoUrl: text("logo_url"),
  launchDate: timestamp("launch_date"),
  votes: integer("votes").default(0),
  comments: integer("comments").default(0),
  makers: jsonb("makers").$type<string[]>().default([]),
  categories: jsonb("categories").$type<string[]>().default([]),
  featured: boolean("featured").default(false),
  // PH Default Scoring (50 points total - Tier 1, fast)
  phDefaultScore: integer("ph_default_score"),
  phScoreBreakdown: jsonb("ph_score_breakdown").$type<PHScoreBreakdown>(),
  // Legacy score fields (for backwards compatibility)
  scoreTotal: integer("score_total"),
  scoreBreakdown: jsonb("score_breakdown").$type<ScoreBreakdown>(),
  // Mudita Scoring System (100 points - Tier 2, deep analysis)
  rawScores: jsonb("raw_scores").$type<RawScores>(),
  sectionScores: jsonb("section_scores").$type<SectionScores>(),
  normalizedScores: jsonb("normalized_scores").$type<SectionScores>(),
  weightedScores: jsonb("weighted_scores").$type<SectionScores>(),
  scoringAssessment: jsonb("scoring_assessment").$type<ScoringAssessment>(),
  // Research and pipeline
  researchData: jsonb("research_data").$type<ResearchData>(),
  pipelineStage: text("pipeline_stage").notNull().default("discovered"),
  assignedTo: integer("assigned_to").references(() => users.id),
  notes: text("notes"),
  tags: jsonb("tags").$type<string[]>().default([]),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const startupsRelations = relations(startups, ({ one, many }) => ({
  assignee: one(users, {
    fields: [startups.assignedTo],
    references: [users.id],
  }),
  researchFindings: many(researchFindings),
  interactions: many(interactions),
}));

// Research findings from various sources
export const researchFindings = pgTable("research_findings", {
  id: serial("id").primaryKey(),
  startupId: integer("startup_id").notNull().references(() => startups.id, { onDelete: "cascade" }),
  sourceType: text("source_type").notNull(),
  sourceUrl: text("source_url"),
  dataExtracted: jsonb("data_extracted"),
  confidenceScore: integer("confidence_score"),
  scrapedAt: timestamp("scraped_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const researchFindingsRelations = relations(researchFindings, ({ one }) => ({
  startup: one(startups, {
    fields: [researchFindings.startupId],
    references: [startups.id],
  }),
}));

// Scoring configuration - stores section weights and criteria definitions
export const scoringConfig = pgTable("scoring_config", {
  id: serial("id").primaryKey(),
  sectionCode: text("section_code").notNull().unique(), // A, B, C, D, E, F, G
  sectionName: text("section_name").notNull(),
  weight: integer("weight").notNull().default(20), // Percentage weight
  criteria: jsonb("criteria").$type<CriteriaDefinition[]>().default([]),
  active: boolean("active").default(true),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

// Weight profiles for different investment stages
export const scoringProfiles = pgTable("scoring_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  weights: jsonb("weights").$type<SectionWeights>().notNull(),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

// Legacy scoring criteria (for backwards compatibility)
export const scoringCriteria = pgTable("scoring_criteria", {
  id: serial("id").primaryKey(),
  categoryName: text("category_name").notNull(),
  weight: integer("weight").notNull().default(20),
  subcriteria: jsonb("subcriteria").$type<Subcriteria[]>().default([]),
  scoringRules: text("scoring_rules"),
  active: boolean("active").default(true),
});

// Interactions/notes with startups
export const interactions = pgTable("interactions", {
  id: serial("id").primaryKey(),
  startupId: integer("startup_id").notNull().references(() => startups.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id),
  interactionType: text("interaction_type").notNull(),
  content: text("content"),
  scheduledFollowup: timestamp("scheduled_followup"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const interactionsRelations = relations(interactions, ({ one }) => ({
  startup: one(startups, {
    fields: [interactions.startupId],
    references: [startups.id],
  }),
  user: one(users, {
    fields: [interactions.userId],
    references: [users.id],
  }),
}));

// Types for JSON columns - Mudita 13-Criteria Scoring System

// Individual criterion score with metadata
export interface CriterionScore {
  score: number; // 1-10
  justification: string;
  confidence: "High" | "Medium" | "Low";
  sources: string[];
}

// Raw criterion score with key for array storage
export interface RawCriterionScore {
  criterionKey: string;
  score: number;
  justification?: string;
  confidence?: string;
  sources?: string[];
}

// Section score item for array storage
export interface SectionScoreItem {
  sectionCode: string;
  sectionName: string;
  averageScore: number;
  normalizedScore?: number;
  weightedScore?: number;
}

// Raw scores for all 13 criteria
export interface RawScores {
  tam: CriterionScore;
  market_growth: CriterionScore;
  competitor_capital: CriterionScore;
  competitor_landscape: CriterionScore;
  moat: CriterionScore;
  winner_takes_all: CriterionScore;
  capital_required: CriterionScore;
  technology_required: CriterionScore;
  gtm_difficulty: CriterionScore;
  land_expand: CriterionScore;
  problem_urgency: CriterionScore;
  exit_likelihood: CriterionScore;
  // Placeholders for future
  founder_team?: CriterionScore;
  traction_execution?: CriterionScore;
}

// Section scores (average of criteria in each section)
export interface SectionScores {
  A_market_environment: number | null;
  B_competition: number | null;
  C_cost_difficulty: number | null;
  D_product_need: number | null;
  E_financial_return: number | null;
  F_founder_team: number | null;
  G_traction: number | null;
}

// Section weights configuration
export interface SectionWeights {
  A: number;
  B: number;
  C: number;
  D: number;
  E: number;
  F: number;
  G: number;
}

// Red flags and assessment from AI
export interface ScoringAssessment {
  red_flags: string[];
  overall_assessment: string;
  investment_thesis?: string;
  overallConfidence?: string;
  summary?: string;
  keyStrengths?: string[];
  keyRisks?: string[];
}

// PH Default Score Breakdown (50 points total, 5 categories)
export interface PHScoreBreakdown {
  upvotes: { score: number; actual: number };          // 10 pts max
  engagement: { score: number; rate: number };         // 5 pts max
  presentation: { score: number; justification: string };  // 10 pts max
  makerCredibility: { score: number; justification: string };  // 10 pts max
  marketRelevance: { score: number; justification: string };   // 10 pts max
  businessViability: { score: number; justification: string }; // 5 pts max
}

// Legacy score breakdown (for backwards compatibility)
export interface ScoreBreakdown {
  team?: { score: number; justification: string };
  market?: { score: number; justification: string };
  product?: { score: number; justification: string };
  traction?: { score: number; justification: string };
  execution?: { score: number; justification: string };
}

export interface ResearchData {
  founders?: { name: string; background: string; linkedIn?: string }[];
  marketSize?: string;
  competitors?: string[];
  fundingStatus?: string;
  tractionMetrics?: Record<string, string>;
  techStack?: string[];
  pressCoverage?: { title: string; url: string; date?: string }[];
}

export interface Subcriteria {
  name: string;
  points: number;
}

// Criteria definition with scale descriptions
export interface CriteriaDefinition {
  key: string; // e.g., "tam", "market_growth"
  name: string; // e.g., "TAM (Total Addressable Market)"
  description: string;
  scaleDescriptions: { [key: number]: string }; // 1-10 descriptions
}

// Mudita scoring criteria definitions
export const MUDITA_CRITERIA: CriteriaDefinition[] = [
  // Section A: Market Environment
  {
    key: "tam",
    name: "TAM (Total Addressable Market)",
    description: "Total market size opportunity",
    scaleDescriptions: {
      1: "<$100M", 2: "$100M-$150M", 3: "$150M-$250M", 4: "$250M-$400M",
      5: "$400M-$600M", 6: "$600M-$800M", 7: "$800M-$1B", 8: "$1B-$3B",
      9: "$3B-$10B", 10: ">$10B"
    }
  },
  {
    key: "market_growth",
    name: "Market Growth Rate",
    description: "Annual market growth rate",
    scaleDescriptions: {
      1: "<2%", 2: "2%", 3: "3%", 4: "4%", 5: "5-6%", 6: "7-8%",
      7: "9-10%", 8: "11-15%", 9: "16-20%", 10: ">20%"
    }
  },
  // Section B: Competition
  {
    key: "competitor_capital",
    name: "Capital Raised by Competitors",
    description: "How much capital competitors have raised (inverse - less is better)",
    scaleDescriptions: {
      1: ">$1B", 2: "$500M-$1B", 3: "$200M-$500M", 4: "$100M-$200M",
      5: "$50M-$100M", 6: "$20M-$50M", 7: "$10M-$20M", 8: "$5M-$10M",
      9: "$1M-$5M", 10: "<$1M"
    }
  },
  {
    key: "competitor_landscape",
    name: "Competitor Landscape",
    description: "Number and strength of competitors (fewer is better)",
    scaleDescriptions: {
      1: "Many dominant players", 2: "Several strong players", 3: "Multiple established players",
      4: "Few established players", 5: "Moderate competition", 6: "Light competition",
      7: "Few early startups", 8: "Very few competitors", 9: "1-2 small players", 10: "No competitors"
    }
  },
  {
    key: "moat",
    name: "Ease of Copying / Moat",
    description: "How defensible is the business (harder to copy is better)",
    scaleDescriptions: {
      1: "Trivially copyable", 2: "Very easy to copy", 3: "Easy to copy",
      4: "Somewhat copyable", 5: "Moderate defensibility", 6: "Reasonably defensible",
      7: "Strong moat", 8: "Very strong moat", 9: "Nearly impossible to copy", 10: "Impossible to copy"
    }
  },
  {
    key: "winner_takes_all",
    name: "Winner-Takes-All Dynamics",
    description: "Market dynamics favoring one winner (unclaimed WTA is best)",
    scaleDescriptions: {
      1: "WTA already won", 2: "WTA nearly captured", 3: "Strong leader emerging",
      4: "Leaders consolidating", 5: "Moderate WTA dynamics", 6: "Some WTA potential",
      7: "Clear WTA opportunity", 8: "Strong WTA unclaimed", 9: "Very strong WTA unclaimed", 10: "Perfect WTA unclaimed"
    }
  },
  // Section C: Cost / Difficulty
  {
    key: "capital_required",
    name: "Capital Required",
    description: "How much capital needed to build (less is better)",
    scaleDescriptions: {
      1: ">$10M", 2: "$5M-$10M", 3: "$2M-$5M", 4: "$1M-$2M",
      5: "$500K-$1M", 6: "$250K-$500K", 7: "$100K-$250K", 8: "$50K-$100K",
      9: "$25K-$50K", 10: "<$25K"
    }
  },
  {
    key: "technology_required",
    name: "Technology Required",
    description: "Technical difficulty to build (easier is better)",
    scaleDescriptions: {
      1: "Miracle tech needed", 2: "Breakthrough required", 3: "Very advanced tech",
      4: "Advanced tech", 5: "Moderate complexity", 6: "Standard tech",
      7: "Common frameworks", 8: "Simple tech stack", 9: "Very simple", 10: "Commodity tech"
    }
  },
  {
    key: "gtm_difficulty",
    name: "GTM Difficulty",
    description: "Go-to-market complexity (easier is better)",
    scaleDescriptions: {
      1: "Very hard GTM", 2: "Hard enterprise sales", 3: "Complex sales cycle",
      4: "Moderate sales effort", 5: "Standard sales process", 6: "Light touch sales",
      7: "Self-serve friendly", 8: "Mostly self-serve", 9: "Viral potential", 10: "Viral/self-serve"
    }
  },
  {
    key: "land_expand",
    name: "Land and Expand Potential",
    description: "Ability to grow within accounts over time",
    scaleDescriptions: {
      1: "One-and-done", 2: "Very limited expansion", 3: "Limited expansion",
      4: "Some expansion possible", 5: "Moderate expansion", 6: "Good expansion potential",
      7: "Strong expansion", 8: "Very strong expansion", 9: "Excellent expansion", 10: "Continuous expansion"
    }
  },
  // Section D: Product Need
  {
    key: "problem_urgency",
    name: "Problem Urgency",
    description: "How urgent is the problem being solved",
    scaleDescriptions: {
      1: "No clear problem", 2: "Nice-to-have", 3: "Minor convenience",
      4: "Moderate value", 5: "Clear value prop", 6: "Important problem",
      7: "Significant pain point", 8: "Major pain point", 9: "Critical problem", 10: "Critical painkiller"
    }
  },
  // Section E: Financial Return
  {
    key: "exit_likelihood",
    name: "Exit Likelihood (3-5 years)",
    description: "Probability of successful exit in 3-5 years",
    scaleDescriptions: {
      1: "Very unlikely", 2: "Unlikely", 3: "Low probability",
      4: "Below average", 5: "Average", 6: "Above average",
      7: "Good probability", 8: "High probability", 9: "Very high probability", 10: "Extremely likely"
    }
  }
];

// Section definitions
export const MUDITA_SECTIONS = [
  { code: "A", name: "Market Environment", criteria: ["tam", "market_growth"] },
  { code: "B", name: "Competition", criteria: ["competitor_capital", "competitor_landscape", "moat", "winner_takes_all"] },
  { code: "C", name: "Cost / Difficulty", criteria: ["capital_required", "technology_required", "gtm_difficulty", "land_expand"] },
  { code: "D", name: "Product Need", criteria: ["problem_urgency"] },
  { code: "E", name: "Financial Return", criteria: ["exit_likelihood"] },
  { code: "F", name: "Founder & Team", criteria: [] },
  { code: "G", name: "Traction & Execution", criteria: [] },
] as const;

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertStartupSchema = createInsertSchema(startups).omit({ id: true, createdAt: true, updatedAt: true });
export const insertScoringConfigSchema = createInsertSchema(scoringConfig).omit({ id: true, updatedAt: true });
export const insertScoringProfileSchema = createInsertSchema(scoringProfiles).omit({ id: true, createdAt: true });
export const insertResearchFindingSchema = createInsertSchema(researchFindings).omit({ id: true, scrapedAt: true });
export const insertScoringCriteriaSchema = createInsertSchema(scoringCriteria).omit({ id: true });
export const insertInteractionSchema = createInsertSchema(interactions).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Startup = typeof startups.$inferSelect;
export type InsertStartup = z.infer<typeof insertStartupSchema>;
export type ResearchFinding = typeof researchFindings.$inferSelect;
export type InsertResearchFinding = z.infer<typeof insertResearchFindingSchema>;
export type ScoringCriteria = typeof scoringCriteria.$inferSelect;
export type InsertScoringCriteria = z.infer<typeof insertScoringCriteriaSchema>;
export type Interaction = typeof interactions.$inferSelect;
export type InsertInteraction = z.infer<typeof insertInteractionSchema>;
export type ScoringConfigRecord = typeof scoringConfig.$inferSelect;
export type InsertScoringConfig = z.infer<typeof insertScoringConfigSchema>;
export type ScoringProfile = typeof scoringProfiles.$inferSelect;
export type InsertScoringProfile = z.infer<typeof insertScoringProfileSchema>;

// Pipeline stages enum
export const PIPELINE_STAGES = [
  { id: "discovered", label: "Discovered", icon: "Search" },
  { id: "high_potential", label: "High Potential", icon: "Star" },
  { id: "outreach", label: "Outreach Initiated", icon: "Mail" },
  { id: "conversation", label: "In Conversation", icon: "MessageSquare" },
  { id: "due_diligence", label: "Due Diligence", icon: "ClipboardCheck" },
  { id: "portfolio", label: "Portfolio/Passed", icon: "CheckCircle" },
  { id: "declined", label: "Declined", icon: "XCircle" },
] as const;

export type PipelineStage = typeof PIPELINE_STAGES[number]["id"];
