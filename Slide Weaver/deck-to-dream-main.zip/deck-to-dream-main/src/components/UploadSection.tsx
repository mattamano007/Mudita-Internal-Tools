import { useState, useCallback } from "react";
import { Upload, FileText, CheckCircle, Loader2, Globe, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

type SearchMode = "web" | "network";

interface UploadSectionProps {
  onUploadComplete: (mode: SearchMode) => void;
}

const UploadSection = ({ onUploadComplete }: UploadSectionProps) => {
  const [mode, setMode] = useState<SearchMode>("web");
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [networkCsv, setNetworkCsv] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && (file.type === "application/pdf" || file.name.endsWith('.pptx') || file.name.endsWith('.ppt'))) {
      setUploadedFile(file);
    }
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  }, []);

  const handleCsvInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.name.endsWith('.csv')) {
      setNetworkCsv(file);
    }
  }, []);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsAnalyzing(false);
    onUploadComplete(mode);
  };

  const canAnalyze = mode === "web" ? uploadedFile : (uploadedFile && networkCsv);

  return (
    <section className="py-12">
      <div className="container px-4">
        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-semibold mb-2">
              Upload Pitch Deck
            </h1>
            <p className="text-muted-foreground">
              Upload a pitch deck to find matching investors
            </p>
          </div>

          <Tabs value={mode} onValueChange={(v) => setMode(v as SearchMode)} className="mb-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="web" className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                Web Search
              </TabsTrigger>
              <TabsTrigger value="network" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Own Network
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <Card className="p-2">
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`
                relative rounded-lg border-2 border-dashed p-10 text-center transition-all duration-200
                ${isDragging ? 'border-primary bg-secondary' : 'border-border hover:border-primary/50'}
                ${uploadedFile ? 'bg-secondary' : ''}
              `}
            >
              {uploadedFile ? (
                <div className="space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{uploadedFile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  <div className="flex items-center justify-center gap-2 text-sm text-primary">
                    <CheckCircle className="w-4 h-4" />
                    Ready for analysis
                  </div>
                </div>
              ) : (
                <>
                  <div className="w-12 h-12 mx-auto rounded-full bg-muted flex items-center justify-center mb-3">
                    <Upload className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <p className="font-medium mb-1">
                    Drag and drop your pitch deck
                  </p>
                  <p className="text-sm text-muted-foreground mb-4">
                    PDF or PowerPoint, up to 50MB
                  </p>
                  <label>
                    <input
                      type="file"
                      accept=".pdf,.ppt,.pptx"
                      onChange={handleFileInput}
                      className="hidden"
                    />
                    <span className="inline-flex items-center px-4 py-2 rounded-md bg-secondary text-secondary-foreground text-sm font-medium cursor-pointer hover:bg-secondary/80 transition-colors">
                      Browse Files
                    </span>
                  </label>
                </>
              )}
            </div>
          </Card>

          {mode === "network" && (
            <Card className="p-2 mt-4">
              <div className="rounded-lg border-2 border-dashed p-6 text-center">
                {networkCsv ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <FileText className="w-5 h-5 text-primary" />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-sm">{networkCsv.name}</p>
                        <p className="text-xs text-muted-foreground">Investor network CSV</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => setNetworkCsv(null)}>
                      Remove
                    </Button>
                  </div>
                ) : (
                  <>
                    <Users className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm font-medium mb-1">Upload investor network CSV</p>
                    <p className="text-xs text-muted-foreground mb-3">
                      CSV with columns: name, email, focus, check_size
                    </p>
                    <label>
                      <input
                        type="file"
                        accept=".csv"
                        onChange={handleCsvInput}
                        className="hidden"
                      />
                      <span className="inline-flex items-center px-3 py-1.5 rounded-md bg-secondary text-secondary-foreground text-xs font-medium cursor-pointer hover:bg-secondary/80 transition-colors">
                        Upload CSV
                      </span>
                    </label>
                  </>
                )}
              </div>
            </Card>
          )}

          {uploadedFile && (
            <div className="mt-4 flex gap-3">
              <Button
                className="gradient-primary text-primary-foreground hover:opacity-90"
                onClick={handleAnalyze}
                disabled={isAnalyzing || !canAnalyze}
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  'Find Matches'
                )}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setUploadedFile(null);
                  setNetworkCsv(null);
                }}
                disabled={isAnalyzing}
              >
                Clear
              </Button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default UploadSection;
