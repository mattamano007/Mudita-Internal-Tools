import { ExternalLink, MapPin, DollarSign, Target } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const mockInvestors = [
  {
    id: 1,
    name: "Andreessen Horowitz",
    logo: "a16z",
    matchScore: 94,
    location: "Menlo Park, CA",
    checkSize: "$5M - $100M",
    focus: ["SaaS", "AI/ML", "Enterprise"],
    reason: "Strong alignment with your AI-first approach and enterprise focus.",
  },
  {
    id: 2,
    name: "Sequoia Capital",
    logo: "SQ",
    matchScore: 89,
    location: "Menlo Park, CA",
    checkSize: "$1M - $50M",
    focus: ["Consumer", "Enterprise", "Fintech"],
    reason: "Your growth metrics align with their typical Series A investments.",
  },
  {
    id: 3,
    name: "First Round Capital",
    logo: "FR",
    matchScore: 87,
    location: "San Francisco, CA",
    checkSize: "$500K - $5M",
    focus: ["B2B", "Developer Tools", "Marketplaces"],
    reason: "Perfect stage fit for your current traction and funding needs.",
  },
  {
    id: 4,
    name: "Y Combinator",
    logo: "YC",
    matchScore: 85,
    location: "Mountain View, CA",
    checkSize: "$500K",
    focus: ["All Sectors", "Early Stage"],
    reason: "Ideal for founders looking for mentorship alongside capital.",
  },
];

interface InvestorResultsProps {
  mode: "web" | "network";
}

const InvestorResults = ({ mode }: InvestorResultsProps) => {
  return (
    <section className="py-8 border-t border-border">
      <div className="container px-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold">Matched Investors</h2>
              <p className="text-sm text-muted-foreground">
                {mockInvestors.length} investors found via {mode === "web" ? "web search" : "your network"}
              </p>
            </div>
            <Button variant="outline" size="sm">
              Export CSV
            </Button>
          </div>

          <div className="space-y-3">
            {mockInvestors.map((investor) => (
              <Card key={investor.id} className="p-4">
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-lg bg-foreground text-background font-semibold text-xs flex items-center justify-center flex-shrink-0">
                    {investor.logo}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-medium">{investor.name}</h3>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {investor.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            {investor.checkSize}
                          </span>
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="text-lg font-semibold text-primary">{investor.matchScore}%</div>
                        <div className="text-xs text-muted-foreground">match</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 mt-2">
                      <Target className="w-3 h-3 text-muted-foreground" />
                      <div className="flex gap-1 flex-wrap">
                        {investor.focus.map(f => (
                          <Badge key={f} variant="secondary" className="text-xs px-1.5 py-0">
                            {f}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <p className="text-xs text-muted-foreground mt-2">
                      {investor.reason}
                    </p>

                    <div className="flex gap-2 mt-3">
                      <Button size="sm" variant="outline" className="h-7 text-xs">
                        View Profile
                        <ExternalLink className="ml-1 w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default InvestorResults;
