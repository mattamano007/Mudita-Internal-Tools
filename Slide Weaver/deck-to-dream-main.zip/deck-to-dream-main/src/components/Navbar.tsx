import muditaLogo from "@/assets/mudita-logo.jpeg";

const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container px-4">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <img 
              src={muditaLogo} 
              alt="Mudita Venture Studios" 
              className="h-8 w-auto"
            />
            <span className="text-sm font-medium text-muted-foreground">
              Investor Match
            </span>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
