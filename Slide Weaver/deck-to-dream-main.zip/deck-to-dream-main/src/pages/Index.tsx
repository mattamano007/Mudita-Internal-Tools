import { useState } from "react";
import Navbar from "@/components/Navbar";
import UploadSection from "@/components/UploadSection";
import InvestorResults from "@/components/InvestorResults";

type SearchMode = "web" | "network";

const Index = () => {
  const [showResults, setShowResults] = useState(false);
  const [searchMode, setSearchMode] = useState<SearchMode>("web");

  const handleUploadComplete = (mode: SearchMode) => {
    setSearchMode(mode);
    setShowResults(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-14">
        <UploadSection onUploadComplete={handleUploadComplete} />
        {showResults && <InvestorResults mode={searchMode} />}
      </main>
    </div>
  );
};

export default Index;