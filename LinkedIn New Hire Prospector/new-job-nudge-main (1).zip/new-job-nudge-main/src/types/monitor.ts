export interface MonitorTemplate {
  id: string;
  title: string;
  description: string;
  category: "new-hires" | "job-changes" | "company-news" | "executive-moves";
  icon: string;
  defaultConfig: Partial<MonitorConfig>;
  usageCount: number;
}

export interface MonitorConfig {
  companies: string[];
  jobTitles: string[];
  seniorityLevels: string[];
  locations: string[];
  sources: ("job-boards" | "news" | "company-pages")[];
  frequency: "realtime" | "daily" | "weekly";
}

export interface Monitor {
  id: string;
  name: string;
  description: string;
  config: MonitorConfig;
  status: "active" | "paused";
  createdAt: string;
  lastChecked?: string;
  matchCount: number;
  templateId?: string;
}

export interface Alert {
  id: string;
  monitorId: string;
  monitorName: string;
  type: "new-hire" | "promotion" | "departure" | "news";
  title: string;
  description: string;
  company: string;
  personName?: string;
  personTitle?: string;
  previousTitle?: string;
  previousCompany?: string;
  source: string;
  sourceUrl?: string;
  timestamp: string;
  isRead: boolean;
}

export interface EmailDigestSettings {
  enabled: boolean;
  frequency: "daily" | "weekly";
  email: string;
  time: string;
}
