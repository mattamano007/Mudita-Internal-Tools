export interface Prospect {
  id: string;
  name: string;
  title: string;
  company: string;
  companyLogo?: string;
  previousTitle?: string;
  previousCompany?: string;
  startDate: string;
  daysInRole: number;
  location: string;
  profileUrl: string;
  avatarUrl?: string;
  email?: string;
  connectionDegree: 1 | 2 | 3;
}

export interface SearchFilters {
  company: string;
  jobTitle: string;
  location: string;
  daysRange: number;
}
