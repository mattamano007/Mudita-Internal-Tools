import { supabase } from '@/integrations/supabase/client';

export interface JobResult {
  url: string;
  title: string;
  description: string;
  markdown?: string;
}

export interface SearchResponse {
  success: boolean;
  results?: JobResult[];
  error?: string;
}

export const jobsApi = {
  async searchFinanceRoles(customQuery?: string): Promise<SearchResponse> {
    const { data, error } = await supabase.functions.invoke('search-jobs', {
      body: { 
        query: customQuery,
        limit: 15 
      },
    });

    if (error) {
      return { success: false, error: error.message };
    }
    
    return data;
  },
};
