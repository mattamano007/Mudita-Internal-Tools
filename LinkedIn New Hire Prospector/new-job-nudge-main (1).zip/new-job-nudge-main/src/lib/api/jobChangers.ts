import { supabase } from '@/integrations/supabase/client';

export interface TargetCompany {
  id: string;
  name: string;
  domain: string | null;
  industry: string | null;
  created_at: string;
}

export interface JobChanger {
  id: string;
  linkedin_url: string | null;
  full_name: string;
  current_title: string | null;
  current_company: string | null;
  previous_title: string | null;
  previous_company: string | null;
  profile_image_url: string | null;
  headline: string | null;
  location: string | null;
  target_company_id: string | null;
  status: 'pending' | 'approved' | 'skipped' | 'sent';
  outreach_message: string | null;
  sent_at: string | null;
  found_at: string;
  created_at: string;
}

export interface PhantomBusterConfig {
  id: string;
  agent_id: string;
  name: string;
  last_run_at: string | null;
  is_active: boolean;
  auto_approve: boolean;
  created_at: string;
}

export interface MessageTemplate {
  id: string;
  name: string;
  content: string;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface DashboardStats {
  totalLeads: number;
  pendingLeads: number;
  approvedLeads: number;
  sentLeads: number;
  targetCompanies: number;
}

export const jobChangersApi = {
  // Target Companies
  async getTargetCompanies(): Promise<TargetCompany[]> {
    const { data, error } = await supabase
      .from('target_companies')
      .select('*')
      .order('name', { ascending: true });

    if (error) throw error;
    return data as TargetCompany[];
  },

  async addTargetCompany(name: string, domain?: string, industry?: string): Promise<TargetCompany> {
    const { data, error } = await supabase
      .from('target_companies')
      .insert({ name, domain, industry })
      .select()
      .single();

    if (error) throw error;
    return data as TargetCompany;
  },

  async deleteTargetCompany(id: string): Promise<void> {
    const { error } = await supabase
      .from('target_companies')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async bulkAddTargetCompanies(companies: Array<{ name: string; domain?: string; industry?: string }>): Promise<number> {
    const { data, error } = await supabase
      .from('target_companies')
      .insert(companies)
      .select();

    if (error) throw error;
    return data?.length || 0;
  },

  async clearAllTargetCompanies(): Promise<void> {
    const { error } = await supabase
      .from('target_companies')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all

    if (error) throw error;
  },

  // Job Changers
  async getJobChangers(status?: string): Promise<JobChanger[]> {
    let query = supabase
      .from('job_changers')
      .select('*')
      .order('found_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data as JobChanger[];
  },

  async getAllJobChangers(): Promise<JobChanger[]> {
    const { data, error } = await supabase
      .from('job_changers')
      .select('*')
      .order('found_at', { ascending: false });

    if (error) throw error;
    return data as JobChanger[];
  },

  async updateJobChangerStatus(id: string, status: JobChanger['status'], message?: string): Promise<void> {
    const updates: Record<string, unknown> = { status };
    
    if (status === 'approved' && message) {
      updates.outreach_message = message;
    } else if (status === 'sent') {
      updates.sent_at = new Date().toISOString();
    }

    const { error } = await supabase
      .from('job_changers')
      .update(updates)
      .eq('id', id);

    if (error) throw error;
  },

  async bulkUpdateStatus(ids: string[], status: JobChanger['status']): Promise<void> {
    const updates: Record<string, unknown> = { status };
    
    if (status === 'sent') {
      updates.sent_at = new Date().toISOString();
    }

    const { error } = await supabase
      .from('job_changers')
      .update(updates)
      .in('id', ids);

    if (error) throw error;
  },

  async updateJobChangerMessage(id: string, message: string): Promise<void> {
    const { error } = await supabase
      .from('job_changers')
      .update({ outreach_message: message })
      .eq('id', id);

    if (error) throw error;
  },

  // Dashboard Stats
  async getDashboardStats(): Promise<DashboardStats> {
    const [jobChangers, companies] = await Promise.all([
      supabase.from('job_changers').select('status'),
      supabase.from('target_companies').select('id'),
    ]);

    const allChangers = (jobChangers.data || []) as { status: string }[];
    
    return {
      totalLeads: allChangers.length,
      pendingLeads: allChangers.filter(c => c.status === 'pending').length,
      approvedLeads: allChangers.filter(c => c.status === 'approved').length,
      sentLeads: allChangers.filter(c => c.status === 'sent').length,
      targetCompanies: companies.data?.length || 0,
    };
  },

  // PhantomBuster Config
  async getPhantomBusterConfigs(): Promise<PhantomBusterConfig[]> {
    const { data, error } = await supabase
      .from('phantombuster_config')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as PhantomBusterConfig[];
  },

  async addPhantomBusterConfig(agentId: string, name: string): Promise<PhantomBusterConfig> {
    const { data, error } = await supabase
      .from('phantombuster_config')
      .insert({ agent_id: agentId, name })
      .select()
      .single();

    if (error) throw error;
    return data as PhantomBusterConfig;
  },

  async deletePhantomBusterConfig(id: string): Promise<void> {
    const { error } = await supabase
      .from('phantombuster_config')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async toggleAutoApprove(id: string, autoApprove: boolean): Promise<void> {
    const { error } = await supabase
      .from('phantombuster_config')
      .update({ auto_approve: autoApprove })
      .eq('id', id);

    if (error) throw error;
  },

  // Message Templates
  async getMessageTemplates(): Promise<MessageTemplate[]> {
    const { data, error } = await supabase
      .from('message_templates')
      .select('*')
      .order('is_default', { ascending: false });

    if (error) throw error;
    return data as MessageTemplate[];
  },

  async createMessageTemplate(name: string, content: string, isDefault: boolean = false): Promise<MessageTemplate> {
    // If setting as default, unset other defaults first
    if (isDefault) {
      await supabase.from('message_templates').update({ is_default: false }).eq('is_default', true);
    }

    const { data, error } = await supabase
      .from('message_templates')
      .insert({ name, content, is_default: isDefault })
      .select()
      .single();

    if (error) throw error;
    return data as MessageTemplate;
  },

  async updateMessageTemplate(id: string, updates: { name?: string; content?: string; is_default?: boolean }): Promise<void> {
    if (updates.is_default) {
      await supabase.from('message_templates').update({ is_default: false }).eq('is_default', true);
    }

    const { error } = await supabase
      .from('message_templates')
      .update(updates)
      .eq('id', id);

    if (error) throw error;
  },

  async deleteMessageTemplate(id: string): Promise<void> {
    const { error } = await supabase
      .from('message_templates')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async getDefaultTemplate(): Promise<MessageTemplate | null> {
    const { data, error } = await supabase
      .from('message_templates')
      .select('*')
      .eq('is_default', true)
      .single();

    if (error) return null;
    return data as MessageTemplate;
  },

  // Edge function calls
  async runPhantomBusterScrape(agentId: string): Promise<{ success: boolean; newProfiles?: number; error?: string }> {
    const { data, error } = await supabase.functions.invoke('run-phantombuster-scrape', {
      body: { agentId },
    });
    if (error) return { success: false, error: error.message };
    return data;
  },

  async generateOutreachMessage(jobChanger: JobChanger, template?: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const { data, error } = await supabase.functions.invoke('generate-job-changer-message', {
      body: { 
        fullName: jobChanger.full_name,
        currentTitle: jobChanger.current_title,
        currentCompany: jobChanger.current_company,
        previousTitle: jobChanger.previous_title,
        previousCompany: jobChanger.previous_company,
        template,
      },
    });
    if (error) return { success: false, error: error.message };
    return data;
  },

  async matchProfilesToTargets(): Promise<{ success: boolean; matched?: number; error?: string }> {
    const { data, error } = await supabase.functions.invoke('match-job-changers', {});
    if (error) return { success: false, error: error.message };
    return data;
  },

  // Parse natural language search query
  async parseSearchQuery(query: string): Promise<{ roles: string[]; companies: string[] }> {
    // Simple regex-based parsing for now
    // Example: "Track CFO hires at Stripe, Airbnb, Plaid"
    const result = { roles: [] as string[], companies: [] as string[] };
    
    // Extract roles (before "at" or "hires")
    const rolePatterns = [
      /track\s+(.+?)\s+(?:hires|at)/i,
      /find\s+(.+?)\s+(?:hires|at)/i,
      /(.+?)\s+hires\s+at/i,
    ];
    
    for (const pattern of rolePatterns) {
      const match = query.match(pattern);
      if (match) {
        const roles = match[1].split(/,\s*|and\s+/).map(r => r.trim()).filter(Boolean);
        result.roles.push(...roles);
        break;
      }
    }

    // Extract companies (after "at")
    const companyMatch = query.match(/at\s+(.+?)$/i);
    if (companyMatch) {
      const companies = companyMatch[1].split(/,\s*|and\s+/).map(c => c.trim()).filter(Boolean);
      result.companies.push(...companies);
    }

    return result;
  },
};
