import { supabase } from '@/integrations/supabase/client';

export interface SavedSearch {
  id: string;
  name: string;
  query: string;
  is_active: boolean;
  last_run_at: string | null;
  created_at: string;
}

export interface Prospect {
  id: string;
  search_id: string | null;
  title: string;
  description: string | null;
  url: string;
  company_name: string | null;
  person_name: string | null;
  person_email: string | null;
  status: 'pending' | 'approved' | 'rejected' | 'sent';
  found_at: string;
  approved_at: string | null;
  sent_at: string | null;
  outreach_message: string | null;
  founder_name: string | null;
  founder_email: string | null;
  founder_linkedin: string | null;
  founder_lookup_status: 'pending' | 'found' | 'not_found' | 'manual' | null;
}

export const prospectsApi = {
  // Saved Searches
  async getSavedSearches(): Promise<SavedSearch[]> {
    const { data, error } = await supabase
      .from('saved_searches')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as SavedSearch[];
  },

  async createSavedSearch(name: string, query: string): Promise<SavedSearch> {
    const { data, error } = await supabase
      .from('saved_searches')
      .insert({ name, query })
      .select()
      .single();

    if (error) throw error;
    return data as SavedSearch;
  },

  async deleteSavedSearch(id: string): Promise<void> {
    const { error } = await supabase
      .from('saved_searches')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async toggleSearchActive(id: string, isActive: boolean): Promise<void> {
    const { error } = await supabase
      .from('saved_searches')
      .update({ is_active: isActive })
      .eq('id', id);

    if (error) throw error;
  },

  // Prospects
  async getProspects(status?: string): Promise<Prospect[]> {
    let query = supabase
      .from('prospects')
      .select('*')
      .order('found_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data as Prospect[];
  },

  async getProspectsBySearch(searchId: string): Promise<Prospect[]> {
    const { data, error } = await supabase
      .from('prospects')
      .select('*')
      .eq('search_id', searchId)
      .order('found_at', { ascending: false });

    if (error) throw error;
    return data as Prospect[];
  },

  async updateProspectStatus(id: string, status: Prospect['status'], message?: string): Promise<void> {
    const updates: any = { status };
    
    if (status === 'approved') {
      updates.approved_at = new Date().toISOString();
      if (message) updates.outreach_message = message;
    } else if (status === 'sent') {
      updates.sent_at = new Date().toISOString();
    }

    const { error } = await supabase
      .from('prospects')
      .update(updates)
      .eq('id', id);

    if (error) throw error;
  },

  async updateProspectEmail(id: string, email: string): Promise<void> {
    const { error } = await supabase
      .from('prospects')
      .update({ person_email: email })
      .eq('id', id);

    if (error) throw error;
  },

  // Run scrape
  async runWeeklyScrape(): Promise<{ success: boolean; newProspects?: number; error?: string }> {
    const { data, error } = await supabase.functions.invoke('run-weekly-scrape');
    if (error) return { success: false, error: error.message };
    return data;
  },

  // Send outreach email
  async sendOutreach(to: string, subject: string, message: string, recipientName?: string): Promise<{ success: boolean; error?: string }> {
    const { data, error } = await supabase.functions.invoke('send-outreach', {
      body: { to, subject, message, recipientName },
    });
    if (error) return { success: false, error: error.message };
    return data;
  },

  // Lookup founder
  async lookupFounder(prospectId: string, companyName: string): Promise<{ success: boolean; founder?: { name: string | null; email: string | null; linkedin: string | null }; error?: string }> {
    const { data, error } = await supabase.functions.invoke('lookup-founder', {
      body: { prospectId, companyName },
    });
    if (error) return { success: false, error: error.message };
    return data;
  },

  // Update founder info manually
  async updateFounderInfo(id: string, founderName: string, founderEmail: string): Promise<void> {
    const { error } = await supabase
      .from('prospects')
      .update({ 
        founder_name: founderName, 
        founder_email: founderEmail,
        founder_lookup_status: 'manual'
      })
      .eq('id', id);

    if (error) throw error;
  },
};
