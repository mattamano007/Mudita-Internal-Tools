import { useState, useEffect } from "react";
import { X, Copy, Check, Sparkles, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { Alert } from "@/types/monitor";

interface AlertMessageGeneratorProps {
  alert: Alert;
  onClose: () => void;
}

const messageTemplates = [
  {
    id: "congratulate",
    label: "Congratulations",
    template: (alert: Alert) =>
      `Hi ${alert.personName?.split(" ")[0]},\n\nCongratulations on your new role as ${alert.personTitle} at ${alert.company}! ${alert.previousCompany && alert.previousCompany !== alert.company ? `I noticed you made the move from ${alert.previousCompany} — ` : ""}I'm sure you'll make a big impact in this position.\n\nI'd love to connect and share some insights that might be valuable as you settle into your new role. Would you be open to a quick chat?\n\nBest,\n[Your name]`,
  },
  {
    id: "intro",
    label: "Introduction",
    template: (alert: Alert) =>
      `Hi ${alert.personName?.split(" ")[0]},\n\nI saw the news about your move to ${alert.company} as ${alert.personTitle} — exciting times!\n\nI work with several ${alert.personTitle?.includes("VP") || alert.personTitle?.includes("Head") ? "executive" : "leadership"} teams in the ${alert.company} space and thought there might be some natural synergies worth exploring.\n\nWould you be open to a brief intro call?\n\nBest,\n[Your name]`,
  },
  {
    id: "value",
    label: "Value-First",
    template: (alert: Alert) =>
      `Hi ${alert.personName?.split(" ")[0]},\n\nWelcome to ${alert.company}! As you're ramping up in your new ${alert.personTitle} role, I wanted to share a resource that has helped other leaders in similar transitions.\n\n[Insert relevant resource/insight here]\n\nNo strings attached — just thought it might be useful. Happy to discuss further if you find it valuable.\n\nCheers,\n[Your name]`,
  },
];

export const AlertMessageGenerator = ({ alert, onClose }: AlertMessageGeneratorProps) => {
  const [selectedTemplate, setSelectedTemplate] = useState(messageTemplates[0]);
  const [message, setMessage] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    generateMessage();
  }, [selectedTemplate, alert]);

  const generateMessage = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setMessage(selectedTemplate.template(alert));
      setIsGenerating(false);
    }, 500);
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(message);
    setCopied(true);
    toast({
      title: "Copied to clipboard",
      description: "Message ready to paste",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl mx-4 rounded-xl border border-border bg-card p-6 shadow-xl animate-slide-up">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-1 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="mb-6 space-y-2">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-bold text-foreground">Generate Outreach</h2>
          </div>
          <p className="text-sm text-muted-foreground">
            Reaching out to <span className="text-foreground font-medium">{alert.personName}</span> at{" "}
            <span className="text-foreground font-medium">{alert.company}</span>
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-foreground">
              Message Style
            </label>
            <div className="flex flex-wrap gap-2">
              {messageTemplates.map((template) => (
                <Badge
                  key={template.id}
                  variant={selectedTemplate.id === template.id ? "default" : "outline"}
                  className="cursor-pointer px-3 py-1.5 transition-colors"
                  onClick={() => setSelectedTemplate(template)}
                >
                  {template.label}
                </Badge>
              ))}
            </div>
          </div>

          <div className="relative">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-[280px] resize-none bg-muted/50 font-mono text-sm"
              placeholder="Your personalized message will appear here..."
            />
            {isGenerating && (
              <div className="absolute inset-0 flex items-center justify-center bg-card/50 backdrop-blur-sm rounded-lg">
                <div className="flex items-center gap-2 text-primary">
                  <Sparkles className="h-5 w-5 animate-pulse" />
                  <span className="text-sm font-medium">Generating message...</span>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between gap-3">
            <Button
              variant="outline"
              onClick={generateMessage}
              disabled={isGenerating}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isGenerating ? "animate-spin" : ""}`} />
              Regenerate
            </Button>
            <Button
              onClick={handleCopy}
              disabled={!message || isGenerating}
              className="gap-2 btn-glow"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  Copy Message
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
