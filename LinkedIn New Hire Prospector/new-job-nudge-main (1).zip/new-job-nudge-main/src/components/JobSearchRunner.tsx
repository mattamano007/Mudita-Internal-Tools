import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, ExternalLink, Mail, Sparkles } from "lucide-react";
import { jobsApi, JobResult } from "@/lib/api/jobs";
import { useToast } from "@/hooks/use-toast";

interface JobSearchRunnerProps {
  onGenerateMessage: (job: JobResult) => void;
}

export function JobSearchRunner({ onGenerateMessage }: JobSearchRunnerProps) {
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<JobResult[]>([]);
  const [customQuery, setCustomQuery] = useState("");
  const { toast } = useToast();

  const handleSearch = async () => {
    setIsSearching(true);
    setResults([]);

    try {
      const response = await jobsApi.searchFinanceRoles(customQuery || undefined);

      if (response.success && response.results) {
        setResults(response.results);
        toast({
          title: "Search complete",
          description: `Found ${response.results.length} potential opportunities`,
        });
      } else {
        toast({
          title: "Search failed",
          description: response.error || "Unable to search. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Search error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Make sure Firecrawl is connected.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Controls */}
      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5 text-primary" />
            Find Finance Hires at Startups
          </CardTitle>
          <CardDescription>
            Scrape the web for recent finance leadership hires and job postings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder="Custom search query (optional)"
              value={customQuery}
              onChange={(e) => setCustomQuery(e.target.value)}
              className="flex-1"
            />
            <Button 
              onClick={handleSearch} 
              disabled={isSearching}
              className="min-w-[120px]"
            >
              {isSearching ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Scraping...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Run Search
                </>
              )}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Default: Searches for VP Finance, CFO, Finance Director roles at startups from the past week
          </p>
        </CardContent>
      </Card>

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Badge variant="secondary" className="text-sm">
              {results.length} results
            </Badge>
            Recent Finance Opportunities
          </h3>
          
          <div className="grid gap-4">
            {results.map((job, index) => (
              <Card key={index} className="border-border/50 hover:border-primary/50 transition-colors">
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground truncate">
                        {job.title || "Untitled"}
                      </h4>
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                        {job.description || "No description available"}
                      </p>
                      <a 
                        href={job.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-xs text-primary hover:underline flex items-center gap-1 mt-2"
                      >
                        <ExternalLink className="h-3 w-3" />
                        {new URL(job.url).hostname}
                      </a>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => onGenerateMessage(job)}
                      className="shrink-0"
                    >
                      <Mail className="mr-2 h-4 w-4" />
                      Generate Message
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {!isSearching && results.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>Run a search to find finance leadership opportunities</p>
        </div>
      )}
    </div>
  );
}
