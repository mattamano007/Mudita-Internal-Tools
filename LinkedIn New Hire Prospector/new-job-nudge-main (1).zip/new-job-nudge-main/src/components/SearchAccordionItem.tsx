import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  ChevronRight, 
  Trash2, 
  Loader2, 
  Mail, 
  Linkedin, 
  ExternalLink, 
  User, 
  Check, 
  X, 
  Clock,
  CheckCircle2
} from "lucide-react";
import { prospectsApi, Prospect, SavedSearch } from "@/lib/api/prospects";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface SearchAccordionItemProps {
  search: SavedSearch;
  onToggle: (id: string, current: boolean) => void;
  onDelete: (id: string) => void;
  onUpdate?: () => void;
}

export function SearchAccordionItem({ search, onToggle, onDelete, onUpdate }: SearchAccordionItemProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loadedOnce, setLoadedOnce] = useState(false);
  const [sendingId, setSendingId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && !loadedOnce) {
      loadProspects();
    }
  }, [isOpen, loadedOnce]);

  const loadProspects = async () => {
    setIsLoading(true);
    try {
      const data = await prospectsApi.getProspectsBySearch(search.id);
      setProspects(data);
      setLoadedOnce(true);
    } catch (error) {
      console.error('Error loading prospects:', error);
      toast({ title: "Failed to load leads", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickEmail = async (prospect: Prospect) => {
    if (!prospect.founder_email) {
      toast({ 
        title: "No email available", 
        description: "Find the founder first or add email manually",
        variant: "destructive" 
      });
      return;
    }

    setSendingId(prospect.id);
    try {
      const role = extractRole(prospect.title);
      const firstName = prospect.founder_name ? prospect.founder_name.split(' ')[0] : '';
      
      const message = `Hi${firstName ? ` ${firstName}` : ''},

I saw you're hiring a ${role} — sounds like finance is top of mind right now.

We built an AI-powered finance solution that's helped similar startups get CFO-level insights without the full-time hire. Would love to share how it might help.

Open to a quick chat?`;

      const result = await prospectsApi.sendOutreach(
        prospect.founder_email,
        `Quick note about your ${role} search`,
        message,
        prospect.founder_name || undefined
      );

      if (result.success) {
        await prospectsApi.updateProspectStatus(prospect.id, 'sent', message);
        loadProspects();
        onUpdate?.();
        toast({ title: "Email sent!" });
      } else {
        toast({ title: result.error || "Failed to send", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Failed to send email", variant: "destructive" });
    } finally {
      setSendingId(null);
    }
  };

  const handleLinkedInOutreach = (prospect: Prospect) => {
    const linkedinUrl = prospect.founder_linkedin;
    if (linkedinUrl) {
      window.open(linkedinUrl, '_blank');
      prospectsApi.updateProspectStatus(prospect.id, 'approved').then(() => {
        loadProspects();
        onUpdate?.();
      });
    } else {
      toast({ 
        title: "No LinkedIn available", 
        description: "Find the founder first",
        variant: "destructive" 
      });
    }
  };

  const handleApprove = async (id: string) => {
    try {
      await prospectsApi.updateProspectStatus(id, 'approved');
      loadProspects();
      onUpdate?.();
      toast({ title: "Approved!" });
    } catch {
      toast({ title: "Failed to approve", variant: "destructive" });
    }
  };

  const handleReject = async (id: string) => {
    try {
      await prospectsApi.updateProspectStatus(id, 'rejected');
      loadProspects();
      onUpdate?.();
      toast({ title: "Rejected" });
    } catch {
      toast({ title: "Failed to reject", variant: "destructive" });
    }
  };

  const handleLookupFounder = async (prospect: Prospect) => {
    const companyName = prospect.company_name || extractCompanyName(prospect.title);
    if (!companyName) {
      toast({ title: "Could not determine company name", variant: "destructive" });
      return;
    }

    setSendingId(prospect.id);
    try {
      const result = await prospectsApi.lookupFounder(prospect.id, companyName);
      if (result.success && result.founder?.name) {
        toast({ title: `Found: ${result.founder.name}` });
        loadProspects();
      } else {
        toast({ title: "Founder not found automatically" });
        loadProspects();
      }
    } catch {
      toast({ title: "Lookup failed", variant: "destructive" });
    } finally {
      setSendingId(null);
    }
  };

  const extractRole = (title: string): string => {
    const match = title.match(/(CFO|VP.*Finance|Finance Director|Head of Finance|Controller|FP&A)/i);
    return match ? match[1] : "key hire";
  };

  const extractCompanyName = (title: string): string => {
    const patterns = [
      /at\s+([A-Z][A-Za-z0-9\s]+?)(?:\s*[-–—]|\s*$)/i,
      /([A-Z][A-Za-z0-9]+)\s+(?:is\s+)?hiring/i,
    ];
    for (const pattern of patterns) {
      const match = title.match(pattern);
      if (match) return match[1].trim();
    }
    return "";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20"><Check className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'sent':
        return <Badge variant="outline" className="bg-success/10 text-success border-success/20"><CheckCircle2 className="h-3 w-3 mr-1" />Sent</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20"><X className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const pendingCount = prospects.filter(p => p.status === 'pending').length;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="rounded-xl border border-border/40 bg-muted/20 overflow-hidden transition-all hover:border-border/60">
        {/* Toggle Header - Notion-style */}
        <CollapsibleTrigger asChild>
          <div className="flex items-center gap-3 p-4 cursor-pointer select-none group">
            <ChevronRight 
              className={cn(
                "h-4 w-4 text-muted-foreground transition-transform duration-200",
                isOpen && "rotate-90"
              )} 
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2.5">
                <h3 className="font-semibold text-base group-hover:text-primary transition-colors">
                  {search.name}
                </h3>
                {search.is_active && (
                  <Badge className="bg-success/10 text-success border-success/20 gap-1 text-xs">
                    <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
                    Live
                  </Badge>
                )}
                {pendingCount > 0 && loadedOnce && (
                  <Badge variant="secondary" className="text-xs">
                    {pendingCount} pending
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground truncate mt-0.5">
                {search.query}
              </p>
            </div>
            <div className="flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
              <Switch
                checked={search.is_active}
                onCheckedChange={() => onToggle(search.id, search.is_active)}
              />
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                onClick={() => onDelete(search.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CollapsibleTrigger>

        {/* Expanded Content - Leads List */}
        <CollapsibleContent>
          <div className="border-t border-border/40 bg-background/40 p-4">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : prospects.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p className="text-sm">No job postings found yet</p>
                <p className="text-xs mt-1">Check back after the daily search runs</p>
              </div>
            ) : (
              <div className="space-y-2">
                {prospects.map((prospect) => (
                  <div
                    key={prospect.id}
                    className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border/30 hover:border-border/50 transition-colors"
                  >
                    {/* Avatar */}
                    <div className="shrink-0 h-9 w-9 rounded-lg bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center border border-primary/10">
                      <span className="text-xs font-bold text-primary">
                        {(prospect.company_name || prospect.title)?.[0]?.toUpperCase() || '?'}
                      </span>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium text-sm text-foreground truncate">
                          {prospect.title}
                        </h4>
                        {getStatusBadge(prospect.status)}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                        {prospect.company_name && (
                          <span className="text-xs text-primary font-medium">
                            {prospect.company_name}
                          </span>
                        )}
                        {prospect.founder_name && (
                          <Badge variant="outline" className="text-xs gap-1 py-0 h-5 bg-success/5 border-success/20 text-success">
                            <User className="h-2.5 w-2.5" />
                            {prospect.founder_name}
                          </Badge>
                        )}
                        {!prospect.founder_name && prospect.founder_lookup_status === 'pending' && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-5 text-xs gap-1 px-2"
                            onClick={() => handleLookupFounder(prospect)}
                            disabled={sendingId === prospect.id}
                          >
                            {sendingId === prospect.id ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <User className="h-3 w-3" />
                            )}
                            Find Founder
                          </Button>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {prospect.status === 'pending' && (
                        <>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                            onClick={() => handleReject(prospect.id)}
                          >
                            <X className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-success hover:bg-success/10"
                            onClick={() => handleApprove(prospect.id)}
                          >
                            <Check className="h-3.5 w-3.5" />
                          </Button>
                        </>
                      )}

                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 gap-1 text-xs px-2"
                        onClick={() => handleQuickEmail(prospect)}
                        disabled={sendingId === prospect.id || !prospect.founder_email || prospect.status === 'sent'}
                      >
                        {sendingId === prospect.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <Mail className="h-3 w-3" />
                        )}
                        Email
                      </Button>

                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 gap-1 text-xs px-2"
                        onClick={() => handleLinkedInOutreach(prospect)}
                        disabled={!prospect.founder_linkedin}
                      >
                        <Linkedin className="h-3 w-3" />
                        LI
                      </Button>

                      <a
                        href={prospect.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="h-7 w-7 flex items-center justify-center rounded-md border border-input hover:bg-accent transition-colors"
                      >
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}
