import { Settings, Bell, LogOut, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/useAuth";
import muditaLogo from "@/assets/mudita-logo.jpeg";

interface HeaderProps {
  alertCount?: number;
  onResetOnboarding?: () => void;
}

export const Header = ({ alertCount = 0, onResetOnboarding }: HeaderProps) => {
  const { user, signOut } = useAuth();
  
  const userInitials = user?.email
    ? user.email.substring(0, 2).toUpperCase()
    : 'U';

  return (
    <header className="border-b border-border bg-card sticky top-0 z-40">
      <div className="h-1 w-full gradient-bg" />
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <img 
            src={muditaLogo} 
            alt="Mudita Venture Studios" 
            className="h-10 w-auto"
          />
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="relative" id="alerts-button">
            <Bell className="h-5 w-5" />
            {alertCount > 0 && (
              <Badge className="absolute -right-1 -top-1 h-5 min-w-[20px] px-1 text-xs bg-primary text-primary-foreground">
                {alertCount}
              </Badge>
            )}
          </Button>
          <Button variant="ghost" size="icon" id="settings-button">
            <Settings className="h-5 w-5" />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="ml-2 flex h-9 w-9 items-center justify-center rounded-full gradient-bg hover:opacity-90 transition-opacity">
                <span className="text-sm font-semibold text-white">{userInitials}</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <div className="px-2 py-1.5 text-sm text-muted-foreground truncate">
                {user?.email}
              </div>
              <DropdownMenuSeparator />
              {onResetOnboarding && (
                <DropdownMenuItem onClick={onResetOnboarding}>
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Show Tutorial
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={signOut} className="text-destructive focus:text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
};
