import { useState } from "react";
import { X, Copy, Check, RefreshCw, Send, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Prospect } from "@/types/prospect";
import { useToast } from "@/hooks/use-toast";

interface MessageGeneratorProps {
  prospect: Prospect;
  onClose: () => void;
}

const generateMessage = (prospect: Prospect): string => {
  const templates = [
    `Hi ${prospect.name.split(" ")[0]},

Congratulations on your new role as ${prospect.title} at ${prospect.company}! Starting a leadership position at such an innovative company is exciting.

I noticed you previously led ${prospect.previousTitle ? `the team as ${prospect.previousTitle}` : "initiatives"} at ${prospect.previousCompany || "your previous company"}, and I imagine you're bringing valuable experience to your new role.

I'd love to share some insights that have helped other ${prospect.title.includes("VP") || prospect.title.includes("Director") || prospect.title.includes("Head") ? "executives" : "leaders"} during their first 90 days. Would you be open to a quick chat?

Best,`,
    `${prospect.name.split(" ")[0]},

Just saw you joined ${prospect.company} as ${prospect.title} — congrats! That's a great move.

Curious: what's the biggest challenge you're tackling first? I work with a lot of folks in similar roles and might have some relevant insights to share.

Happy to connect if useful.

Cheers,`,
    `Hi ${prospect.name.split(" ")[0]},

Exciting news about your move to ${prospect.company}! The transition from ${prospect.previousCompany || "your previous role"} to leading ${prospect.title.toLowerCase().includes("engineering") ? "engineering" : prospect.title.toLowerCase().includes("sales") ? "sales" : prospect.title.toLowerCase().includes("product") ? "product" : "the team"} at ${prospect.company} sounds like a great opportunity.

I help ${prospect.title.includes("VP") || prospect.title.includes("Director") || prospect.title.includes("Head") || prospect.title.includes("Chief") ? "executives" : "leaders"} navigate transitions like this and would love to share a few ideas that might be useful in your first 90 days.

Open to a brief call this week?

Best,`,
  ];

  return templates[Math.floor(Math.random() * templates.length)];
};

export const MessageGenerator = ({ prospect, onClose }: MessageGeneratorProps) => {
  const [message, setMessage] = useState(generateMessage(prospect));
  const [copied, setCopied] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const { toast } = useToast();

  const handleCopy = async () => {
    await navigator.clipboard.writeText(message);
    setCopied(true);
    toast({
      title: "Copied to clipboard",
      description: "Message is ready to paste into LinkedIn",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRegenerate = () => {
    setIsRegenerating(true);
    setTimeout(() => {
      setMessage(generateMessage(prospect));
      setIsRegenerating(false);
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm animate-fade-in">
      <div className="card-glow mx-4 w-full max-w-2xl rounded-xl border border-border bg-card shadow-2xl animate-slide-up">
        <div className="flex items-center justify-between border-b border-border p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Personalized Message</h2>
              <p className="text-sm text-muted-foreground">
                For {prospect.name} at {prospect.company}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-4">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="min-h-[280px] w-full resize-none rounded-lg border border-border bg-background/50 p-4 text-sm leading-relaxed text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>

        <div className="flex items-center justify-between border-t border-border p-4">
          <Button
            variant="outline"
            onClick={handleRegenerate}
            disabled={isRegenerating}
          >
            <RefreshCw className={`h-4 w-4 ${isRegenerating ? "animate-spin" : ""}`} />
            Regenerate
          </Button>

          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={handleCopy}>
              {copied ? (
                <>
                  <Check className="h-4 w-4" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  Copy
                </>
              )}
            </Button>
            
            <Button variant="glow">
              <Send className="h-4 w-4" />
              Open LinkedIn
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
