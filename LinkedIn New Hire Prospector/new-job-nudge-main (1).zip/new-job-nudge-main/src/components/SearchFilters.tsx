import { Search, Building2, Briefcase, MapPin, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SearchFilters as SearchFiltersType } from "@/types/prospect";

interface SearchFiltersProps {
  filters: SearchFiltersType;
  onFiltersChange: (filters: SearchFiltersType) => void;
  onSearch: () => void;
  isLoading?: boolean;
}

export const SearchFilters = ({
  filters,
  onFiltersChange,
  onSearch,
  isLoading,
}: SearchFiltersProps) => {
  const updateFilter = (key: keyof SearchFiltersType, value: string | number) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <div className="card-glow rounded-xl border border-border bg-card p-6">
      <div className="mb-4 flex items-center gap-2">
        <Search className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold text-foreground">Search Prospects</h2>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Building2 className="h-4 w-4" />
            Company
          </label>
          <Input
            placeholder="e.g., Stripe, Figma..."
            value={filters.company}
            onChange={(e) => updateFilter("company", e.target.value)}
            className="input-glow bg-background/50"
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Briefcase className="h-4 w-4" />
            Job Title
          </label>
          <Input
            placeholder="e.g., VP, Director..."
            value={filters.jobTitle}
            onChange={(e) => updateFilter("jobTitle", e.target.value)}
            className="input-glow bg-background/50"
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <MapPin className="h-4 w-4" />
            Location
          </label>
          <Input
            placeholder="e.g., San Francisco..."
            value={filters.location}
            onChange={(e) => updateFilter("location", e.target.value)}
            className="input-glow bg-background/50"
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Calendar className="h-4 w-4" />
            Started within
          </label>
          <select
            value={filters.daysRange}
            onChange={(e) => updateFilter("daysRange", parseInt(e.target.value))}
            className="flex h-10 w-full rounded-lg border border-input bg-background/50 px-3 py-2 text-sm ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <option value={30}>Last 30 days</option>
            <option value={60}>Last 60 days</option>
            <option value={90}>Last 90 days</option>
          </select>
        </div>
      </div>

      <div className="mt-6 flex justify-end">
        <Button
          onClick={onSearch}
          disabled={isLoading}
          variant="glow"
          size="lg"
          className="min-w-[140px]"
        >
          {isLoading ? (
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
              Searching...
            </span>
          ) : (
            <>
              <Search className="h-4 w-4" />
              Search
            </>
          )}
        </Button>
      </div>
    </div>
  );
};
