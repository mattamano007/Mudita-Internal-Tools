import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Loader2, Clock } from "lucide-react";
import { prospectsApi, SavedSearch } from "@/lib/api/prospects";
import { useToast } from "@/hooks/use-toast";
import { SearchAccordionItem } from "./SearchAccordionItem";

export function SavedSearches() {
  const [searches, setSearches] = useState<SavedSearch[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const loadSearches = async () => {
    try {
      const data = await prospectsApi.getSavedSearches();
      setSearches(data);
    } catch (error) {
      console.error('Error loading searches:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSearches();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      await prospectsApi.deleteSavedSearch(id);
      loadSearches();
      toast({ title: "Search deleted" });
    } catch (error) {
      toast({ title: "Failed to delete", variant: "destructive" });
    }
  };

  const handleToggle = async (id: string, current: boolean) => {
    try {
      await prospectsApi.toggleSearchActive(id, !current);
      loadSearches();
      toast({ 
        title: !current ? "Monitoring enabled" : "Monitoring paused",
      });
    } catch (error) {
      toast({ title: "Failed to update", variant: "destructive" });
    }
  };

  return (
    <Card className="border-border/40 bg-card/60 backdrop-blur-sm shadow-xl shadow-black/5">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2.5 text-lg">
          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Search className="h-4 w-4 text-primary" />
          </div>
          Hiring Signals
        </CardTitle>
        <CardDescription className="flex items-center gap-2">
          <Clock className="h-3 w-3" />
          Job postings = pain points. Click to expand and pitch.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : searches.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-sm">No searches yet</p>
            <p className="text-xs mt-1">Search for roles above to find warm leads</p>
          </div>
        ) : (
          <div className="space-y-3">
            {searches.map((search) => (
              <SearchAccordionItem
                key={search.id}
                search={search}
                onToggle={handleToggle}
                onDelete={handleDelete}
                onUpdate={loadSearches}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
