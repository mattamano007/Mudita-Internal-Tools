import { useState } from "react";
import { Sparkles, ArrowRight } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface MonitorPromptProps {
  onSubmit: (prompt: string) => void;
  isLoading?: boolean;
}

const quickPrompts = [
  { label: "New VPs", prompt: "Watch for new VP hires at Stripe, Figma, and Linear" },
  { label: "Competitor Moves", prompt: "Alert me when employees leave Salesforce for competitors" },
  { label: "Executive News", prompt: "Track executive announcements at Series B+ startups" },
  { label: "Sales Leaders", prompt: "Find new sales leadership at enterprise SaaS companies" },
];

export const MonitorPrompt = ({ onSubmit, isLoading }: MonitorPromptProps) => {
  const [prompt, setPrompt] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onSubmit(prompt);
    }
  };

  const handleQuickPrompt = (quickPrompt: string) => {
    setPrompt(quickPrompt);
  };

  return (
    <div className="mx-auto w-full max-w-2xl space-y-6">
      <div className="text-center space-y-3">
        <h1 className="text-4xl font-bold text-foreground md:text-5xl">
          What do you want to{" "}
          <span className="gradient-text">watch for?</span>
        </h1>
        <p className="text-lg text-muted-foreground">
          Create monitors that track new hires for you.
          <br />
          Get notified when someone important joins a target company.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe what you want to monitor..."
            className="min-h-[120px] resize-none bg-card border-border text-base placeholder:text-muted-foreground focus:border-primary"
          />
          <Button
            type="submit"
            size="icon"
            disabled={!prompt.trim() || isLoading}
            className="absolute bottom-3 right-3 h-8 w-8 rounded-full btn-glow"
          >
            {isLoading ? (
              <Sparkles className="h-4 w-4 animate-pulse" />
            ) : (
              <ArrowRight className="h-4 w-4" />
            )}
          </Button>
        </div>
      </form>

      <div className="flex flex-wrap items-center justify-center gap-2">
        {quickPrompts.map((qp) => (
          <Badge
            key={qp.label}
            variant="outline"
            className="cursor-pointer px-3 py-1.5 text-sm transition-colors hover:bg-primary/10 hover:border-primary"
            onClick={() => handleQuickPrompt(qp.prompt)}
          >
            {qp.label}
          </Badge>
        ))}
      </div>
    </div>
  );
};
