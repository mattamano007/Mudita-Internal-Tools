import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi, JobChanger } from "@/lib/api/jobChangers";
import { 
  Linkedin, 
  MapPin, 
  ArrowRight, 
  Sparkles, 
  Copy, 
  Check,
  User,
  Building2,
  SkipForward
} from "lucide-react";

export function JobChangerQueue() {
  const [jobChangers, setJobChangers] = useState<JobChanger[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedChanger, setSelectedChanger] = useState<JobChanger | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const loadJobChangers = async () => {
    try {
      const data = await jobChangersApi.getJobChangers('pending');
      // Only show matched profiles (those linked to target companies)
      setJobChangers(data.filter(c => c.target_company_id));
    } catch (error) {
      console.error('Error loading job changers:', error);
      toast({
        title: "Error",
        description: "Failed to load job changers",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadJobChangers();
  }, []);

  const handleSkip = async (id: string) => {
    try {
      await jobChangersApi.updateJobChangerStatus(id, 'skipped');
      setJobChangers(prev => prev.filter(c => c.id !== id));
      toast({
        title: "Skipped",
        description: "Profile skipped",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to skip profile",
        variant: "destructive",
      });
    }
  };

  const handleOpenOutreach = async (changer: JobChanger) => {
    setSelectedChanger(changer);
    setDialogOpen(true);
    setMessage("");
    setCopied(false);
    
    // Auto-generate message
    setIsGenerating(true);
    try {
      const result = await jobChangersApi.generateOutreachMessage(changer);
      if (result.success && result.message) {
        setMessage(result.message);
      } else {
        toast({
          title: "Generation failed",
          description: result.error || "Could not generate message",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate message",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRegenerate = async () => {
    if (!selectedChanger) return;
    
    setIsGenerating(true);
    try {
      const result = await jobChangersApi.generateOutreachMessage(selectedChanger);
      if (result.success && result.message) {
        setMessage(result.message);
      } else {
        toast({
          title: "Generation failed",
          description: result.error || "Could not generate message",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate message",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyAndMarkSent = async () => {
    if (!selectedChanger || !message) return;

    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      
      await jobChangersApi.updateJobChangerStatus(selectedChanger.id, 'sent', message);
      
      toast({
        title: "Copied!",
        description: "Message copied. Go paste it on LinkedIn!",
      });
      
      setTimeout(() => {
        setDialogOpen(false);
        setJobChangers(prev => prev.filter(c => c.id !== selectedChanger.id));
      }, 1000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy message",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => (
          <Card key={i} className="card-glow">
            <CardContent className="p-6">
              <div className="flex gap-4">
                <Skeleton className="h-14 w-14 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-5 w-48" />
                  <Skeleton className="h-4 w-64" />
                  <Skeleton className="h-4 w-40" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (jobChangers.length === 0) {
    return (
      <Card className="card-glow">
        <CardContent className="py-12 text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <User className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="font-medium text-foreground mb-1">No Matches Yet</h3>
          <p className="text-sm text-muted-foreground max-w-sm mx-auto">
            Upload target companies and run a PhantomBuster scrape to find job changers at your target accounts.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-4">
        {jobChangers.map(changer => (
          <Card key={changer.id} className="card-glow hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className="flex gap-4">
                {/* Avatar */}
                <div className="flex-shrink-0">
                  {changer.profile_image_url ? (
                    <img 
                      src={changer.profile_image_url} 
                      alt={changer.full_name}
                      className="h-14 w-14 rounded-full object-cover ring-2 ring-primary/20"
                    />
                  ) : (
                    <div className="h-14 w-14 rounded-full gradient-bg flex items-center justify-center">
                      <span className="text-lg font-semibold text-white">
                        {changer.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </span>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-foreground">{changer.full_name}</h3>
                      <p className="text-sm text-muted-foreground">{changer.headline}</p>
                    </div>
                    {changer.linkedin_url && (
                      <a 
                        href={changer.linkedin_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary hover:text-primary/80 transition-colors"
                      >
                        <Linkedin className="h-5 w-5" />
                      </a>
                    )}
                  </div>

                  {/* Job transition */}
                  <div className="mt-3 flex items-center gap-2 text-sm">
                    {changer.previous_title && changer.previous_company && (
                      <>
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <Building2 className="h-3.5 w-3.5" />
                          <span>{changer.previous_title}</span>
                          <span className="text-muted-foreground/60">at</span>
                          <span>{changer.previous_company}</span>
                        </div>
                        <ArrowRight className="h-4 w-4 text-primary" />
                      </>
                    )}
                    <div className="flex items-center gap-1.5">
                      <Badge variant="secondary" className="font-medium">
                        {changer.current_title}
                      </Badge>
                      <span className="text-muted-foreground/60">at</span>
                      <span className="font-medium text-foreground">{changer.current_company}</span>
                    </div>
                  </div>

                  {changer.location && (
                    <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      {changer.location}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="mt-4 flex gap-2">
                    <Button 
                      variant="muted" 
                      size="sm"
                      onClick={() => handleSkip(changer.id)}
                    >
                      <SkipForward className="h-4 w-4 mr-1" />
                      Skip
                    </Button>
                    <Button 
                      variant="glow" 
                      size="sm"
                      onClick={() => handleOpenOutreach(changer)}
                    >
                      <Sparkles className="h-4 w-4 mr-1" />
                      Write Message
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Outreach Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Message for {selectedChanger?.full_name}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {selectedChanger && (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <div className="text-sm">
                  <span className="font-medium">{selectedChanger.current_title}</span>
                  <span className="text-muted-foreground"> at </span>
                  <span className="font-medium">{selectedChanger.current_company}</span>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">LinkedIn Message</label>
                <span className={`text-xs ${message.length > 280 ? 'text-destructive' : 'text-muted-foreground'}`}>
                  {message.length}/280
                </span>
              </div>
              
              {isGenerating ? (
                <div className="space-y-2 p-4 rounded-lg border bg-muted/30">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-4/5" />
                  <Skeleton className="h-4 w-3/5" />
                </div>
              ) : (
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Your personalized message..."
                  className="min-h-[120px] resize-none"
                />
              )}
            </div>

            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleRegenerate}
              disabled={isGenerating}
              className="w-full"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Regenerate
            </Button>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="glow"
              onClick={handleCopyAndMarkSent}
              disabled={!message || isGenerating}
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy & Mark Sent
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
