import { UserPlus, ArrowRightLeft, Newspaper, TrendingUp, Code, Megaphone, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MonitorTemplate } from "@/types/monitor";

interface TemplateCardProps {
  template: MonitorTemplate;
  onClick: (template: MonitorTemplate) => void;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  UserPlus,
  ArrowRightLeft,
  Newspaper,
  TrendingUp,
  Code,
  Megaphone,
  Users,
};

const categoryColors: Record<string, string> = {
  "new-hires": "bg-success/10 text-success border-success/20",
  "job-changes": "bg-warning/10 text-warning border-warning/20",
  "company-news": "bg-primary/10 text-primary border-primary/20",
  "executive-moves": "bg-accent/10 text-accent border-accent/20",
};

export const TemplateCard = ({ template, onClick }: TemplateCardProps) => {
  const IconComponent = iconMap[template.icon] || Users;

  return (
    <Card
      className="group cursor-pointer border-border bg-card transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5 card-glow"
      onClick={() => onClick(template)}
    >
      <CardContent className="p-5">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-accent/10 transition-transform group-hover:scale-105">
            <IconComponent className="h-6 w-6 text-primary" />
          </div>
          <div className="min-w-0 flex-1 space-y-2">
            <h3 className="font-semibold text-foreground leading-tight group-hover:text-primary transition-colors">
              {template.title}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {template.description}
            </p>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={categoryColors[template.category]}>
                {template.category.replace("-", " ")}
              </Badge>
              <span className="text-xs text-muted-foreground">
                {template.usageCount.toLocaleString()} using
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
