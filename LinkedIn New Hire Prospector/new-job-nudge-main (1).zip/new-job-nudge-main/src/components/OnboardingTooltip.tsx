import { useEffect, useState, ReactNode } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export interface OnboardingStep {
  target: string; // CSS selector for the target element
  title: string;
  description: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

interface OnboardingTooltipProps {
  steps: OnboardingStep[];
  currentStep: number;
  onNext: () => void;
  onPrev: () => void;
  onComplete: () => void;
  isVisible: boolean;
}

export function OnboardingTooltip({
  steps,
  currentStep,
  onNext,
  onPrev,
  onComplete,
  isVisible,
}: OnboardingTooltipProps) {
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const [isPositioned, setIsPositioned] = useState(false);

  const step = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;
  const isFirstStep = currentStep === 0;

  useEffect(() => {
    if (!isVisible || !step) return;

    const positionTooltip = () => {
      const target = document.querySelector(step.target);
      if (!target) {
        setIsPositioned(false);
        return;
      }

      const rect = target.getBoundingClientRect();
      const tooltipWidth = 320;
      const tooltipHeight = 180;
      const gap = 12;

      let top = 0;
      let left = 0;

      switch (step.position || 'bottom') {
        case 'top':
          top = rect.top - tooltipHeight - gap + window.scrollY;
          left = rect.left + (rect.width - tooltipWidth) / 2;
          break;
        case 'bottom':
          top = rect.bottom + gap + window.scrollY;
          left = rect.left + (rect.width - tooltipWidth) / 2;
          break;
        case 'left':
          top = rect.top + (rect.height - tooltipHeight) / 2 + window.scrollY;
          left = rect.left - tooltipWidth - gap;
          break;
        case 'right':
          top = rect.top + (rect.height - tooltipHeight) / 2 + window.scrollY;
          left = rect.right + gap;
          break;
      }

      // Keep within viewport
      left = Math.max(16, Math.min(left, window.innerWidth - tooltipWidth - 16));
      top = Math.max(16, top);

      setPosition({ top, left });
      setIsPositioned(true);

      // Add highlight to target element
      target.classList.add('onboarding-highlight');
    };

    positionTooltip();
    window.addEventListener('resize', positionTooltip);
    window.addEventListener('scroll', positionTooltip);

    return () => {
      window.removeEventListener('resize', positionTooltip);
      window.removeEventListener('scroll', positionTooltip);
      const target = document.querySelector(step.target);
      if (target) {
        target.classList.remove('onboarding-highlight');
      }
    };
  }, [step, isVisible, currentStep]);

  if (!isVisible || !step || !isPositioned) return null;

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-foreground/20 z-40 pointer-events-none" />
      
      {/* Tooltip */}
      <div
        className={cn(
          "fixed z-50 w-80 bg-card rounded-xl shadow-lg border border-border p-4 animate-fade-in",
          "pointer-events-auto"
        )}
        style={{ top: position.top, left: position.left }}
      >
        {/* Close button */}
        <button
          onClick={onComplete}
          className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Content */}
        <div className="pr-6">
          <h3 className="font-semibold text-foreground mb-1">{step.title}</h3>
          <p className="text-sm text-muted-foreground mb-4">{step.description}</p>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <div className="flex gap-1">
            {steps.map((_, i) => (
              <div
                key={i}
                className={cn(
                  "w-2 h-2 rounded-full transition-colors",
                  i === currentStep ? "bg-primary" : "bg-muted"
                )}
              />
            ))}
          </div>
          
          <div className="flex gap-2">
            {!isFirstStep && (
              <Button variant="ghost" size="sm" onClick={onPrev}>
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back
              </Button>
            )}
            <Button size="sm" onClick={isLastStep ? onComplete : onNext}>
              {isLastStep ? 'Get Started' : 'Next'}
              {!isLastStep && <ChevronRight className="h-4 w-4 ml-1" />}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
