import { ExternalLink, User, Building2, ArrowRight, Newspaper, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert } from "@/types/monitor";

interface AlertFeedProps {
  alerts: Alert[];
  onMarkRead: (id: string) => void;
  onGenerateMessage: (alert: Alert) => void;
}

const typeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  "new-hire": User,
  "promotion": TrendingUp,
  "departure": ArrowRight,
  "news": Newspaper,
};

const typeColors: Record<string, string> = {
  "new-hire": "bg-success/10 text-success border-success/20",
  "promotion": "bg-primary/10 text-primary border-primary/20",
  "departure": "bg-warning/10 text-warning border-warning/20",
  "news": "bg-accent/10 text-accent border-accent/20",
};

export const AlertFeed = ({ alerts, onMarkRead, onGenerateMessage }: AlertFeedProps) => {
  if (alerts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-12 text-center">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
          <Newspaper className="h-6 w-6 text-muted-foreground" />
        </div>
        <h3 className="font-semibold text-foreground">No alerts yet</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Your monitors will surface new hires here
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {alerts.map((alert, index) => {
        const IconComponent = typeIcons[alert.type] || User;
        
        return (
          <Card
            key={alert.id}
            className={`animate-slide-up border-border bg-card transition-all duration-300 hover:border-primary/30 ${
              !alert.isRead ? "ring-1 ring-primary/20" : ""
            }`}
            style={{ animationDelay: `${index * 50}ms` }}
            onClick={() => !alert.isRead && onMarkRead(alert.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${typeColors[alert.type].split(" ")[0]}`}>
                  <IconComponent className="h-5 w-5 text-primary" />
                </div>

                <div className="min-w-0 flex-1 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-semibold text-foreground leading-tight">
                        {alert.title}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-0.5">
                        {alert.description}
                      </p>
                    </div>
                    {!alert.isRead && (
                      <div className="h-2 w-2 shrink-0 rounded-full bg-primary mt-2" />
                    )}
                  </div>

                  {alert.personName && (
                    <div className="flex items-center gap-4 text-sm">
                      <span className="flex items-center gap-1.5 text-foreground">
                        <User className="h-3.5 w-3.5 text-muted-foreground" />
                        {alert.personName}
                      </span>
                      {alert.previousCompany && alert.previousCompany !== alert.company && (
                        <span className="flex items-center gap-1.5 text-muted-foreground">
                          <Building2 className="h-3.5 w-3.5" />
                          {alert.previousCompany}
                          <ArrowRight className="h-3 w-3" />
                          {alert.company}
                        </span>
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={typeColors[alert.type]}>
                        {alert.type.replace("-", " ")}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        via {alert.source}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        · {alert.timestamp}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {alert.sourceUrl && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 text-xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            window.open(alert.sourceUrl, "_blank");
                          }}
                        >
                          <ExternalLink className="mr-1 h-3 w-3" />
                          Source
                        </Button>
                      )}
                      <Button
                        size="sm"
                        className="h-7 text-xs btn-glow"
                        onClick={(e) => {
                          e.stopPropagation();
                          onGenerateMessage(alert);
                        }}
                      >
                        Generate Message
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};
