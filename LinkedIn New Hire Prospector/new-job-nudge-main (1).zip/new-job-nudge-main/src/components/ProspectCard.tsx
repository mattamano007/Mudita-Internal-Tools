import { User, Building2, ArrowRight, MapPin, ExternalLink, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Prospect } from "@/types/prospect";

interface ProspectCardProps {
  prospect: Prospect;
  onGenerateMessage: (prospect: Prospect) => void;
  isSelected?: boolean;
}

export const ProspectCard = ({
  prospect,
  onGenerateMessage,
  isSelected,
}: ProspectCardProps) => {
  const getConnectionBadge = (degree: number) => {
    if (degree === 1) return <Badge variant="success">1st</Badge>;
    if (degree === 2) return <Badge variant="glow">2nd</Badge>;
    return <Badge variant="muted">3rd</Badge>;
  };

  const getDaysLabel = (days: number) => {
    if (days <= 7) return "This week";
    if (days <= 14) return "2 weeks ago";
    if (days <= 30) return `${Math.floor(days / 7)} weeks ago`;
    return `${Math.floor(days / 30)} months ago`;
  };

  return (
    <Card
      className={`card-glow group cursor-pointer overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:border-primary/30 ${
        isSelected ? "border-primary ring-2 ring-primary/20" : ""
      }`}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-accent/20 ring-2 ring-primary/10">
              <User className="h-6 w-6 text-primary" />
            </div>
            
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                  {prospect.name}
                </h3>
                {getConnectionBadge(prospect.connectionDegree)}
              </div>
              
              <p className="text-sm font-medium text-primary">{prospect.title}</p>
              
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Building2 className="h-3.5 w-3.5" />
                {prospect.company}
              </div>
              
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                {prospect.location}
              </div>
            </div>
          </div>

          <Badge variant="warning" className="whitespace-nowrap">
            {getDaysLabel(prospect.daysInRole)}
          </Badge>
        </div>

        {prospect.previousCompany && (
          <div className="mt-4 flex items-center gap-2 rounded-lg bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
            <span className="font-medium">{prospect.previousTitle}</span>
            <span>at</span>
            <span>{prospect.previousCompany}</span>
            <ArrowRight className="h-3 w-3 text-primary" />
            <span className="font-medium text-foreground">{prospect.company}</span>
          </div>
        )}

        <div className="mt-4 flex items-center gap-2">
          <Button
            onClick={() => onGenerateMessage(prospect)}
            variant="glow"
            size="sm"
            className="flex-1"
          >
            <Sparkles className="h-4 w-4" />
            Generate Message
          </Button>
          
          <Button variant="outline" size="sm" className="px-3">
            <ExternalLink className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
