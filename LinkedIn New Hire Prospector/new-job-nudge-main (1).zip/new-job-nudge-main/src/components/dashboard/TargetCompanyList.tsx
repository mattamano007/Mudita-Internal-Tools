import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi, TargetCompany } from "@/lib/api/jobChangers";
import { Building2, Plus, X, Trash2 } from "lucide-react";

interface TargetCompanyListProps {
  refreshKey: number;
  onCompaniesChange: () => void;
}

export function TargetCompanyList({ refreshKey, onCompaniesChange }: TargetCompanyListProps) {
  const [companies, setCompanies] = useState<TargetCompany[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCompany, setNewCompany] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const { toast } = useToast();

  const loadCompanies = async () => {
    try {
      const data = await jobChangersApi.getTargetCompanies();
      setCompanies(data);
    } catch (error) {
      console.error('Error loading companies:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCompanies();
  }, [refreshKey]);

  const handleAddCompany = async () => {
    if (!newCompany.trim()) return;
    
    setIsAdding(true);
    try {
      const company = await jobChangersApi.addTargetCompany(newCompany.trim());
      setCompanies(prev => [...prev, company].sort((a, b) => a.name.localeCompare(b.name)));
      setNewCompany("");
      onCompaniesChange();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add company",
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  const handleDeleteCompany = async (id: string) => {
    try {
      await jobChangersApi.deleteTargetCompany(id);
      setCompanies(prev => prev.filter(c => c.id !== id));
      onCompaniesChange();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove company",
        variant: "destructive",
      });
    }
  };

  const handleClearAll = async () => {
    if (companies.length === 0) return;
    
    try {
      await jobChangersApi.clearAllTargetCompanies();
      setCompanies([]);
      onCompaniesChange();
      toast({
        title: "Cleared",
        description: "All target companies removed",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to clear companies",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Building2 className="h-5 w-5 text-primary" />
            Target Companies
            <Badge variant="secondary">{companies.length}</Badge>
          </CardTitle>
          {companies.length > 0 && (
            <Button variant="ghost" size="sm" onClick={handleClearAll} className="text-muted-foreground hover:text-destructive">
              <Trash2 className="h-4 w-4 mr-1" />
              Clear All
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add company form */}
        <div className="flex gap-2">
          <Input
            placeholder="Add company..."
            value={newCompany}
            onChange={(e) => setNewCompany(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddCompany()}
            className="flex-1"
          />
          <Button 
            onClick={handleAddCompany}
            disabled={!newCompany.trim() || isAdding}
            size="icon"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {/* Companies list */}
        {loading ? (
          <div className="text-center py-4 text-muted-foreground text-sm">Loading...</div>
        ) : companies.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-muted-foreground text-sm">
              No target companies. Use the search bar above or add manually.
            </p>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2 max-h-[200px] overflow-y-auto">
            {companies.map(company => (
              <Badge 
                key={company.id} 
                variant="outline"
                className="py-1.5 px-3 flex items-center gap-2 hover:bg-muted/50 transition-colors group"
              >
                <span>{company.name}</span>
                <button
                  onClick={() => handleDeleteCompany(company.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
