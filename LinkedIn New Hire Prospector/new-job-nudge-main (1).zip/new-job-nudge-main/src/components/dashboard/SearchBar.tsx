import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi } from "@/lib/api/jobChangers";
import { Search, Upload, Sparkles, Loader2 } from "lucide-react";

interface SearchBarProps {
  onSearchComplete: () => void;
}

export function SearchBar({ onSearchComplete }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [csvDialogOpen, setCsvDialogOpen] = useState(false);
  const [csvText, setCsvText] = useState("");
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!query.trim()) return;
    
    setIsSearching(true);
    try {
      const parsed = await jobChangersApi.parseSearchQuery(query);
      
      if (parsed.companies.length === 0) {
        toast({
          title: "Couldn't parse query",
          description: "Try: 'CFO roles at Series A startups'",
          variant: "destructive",
        });
        return;
      }

      // Add companies to target list
      const companies = parsed.companies.map(name => ({ name }));
      const count = await jobChangersApi.bulkAddTargetCompanies(companies);
      
      toast({
        title: "Companies added",
        description: `Added ${count} companies to your target list. Configure PhantomBuster to run the search.`,
      });
      
      setQuery("");
      onSearchComplete();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process search query",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setCsvText(text);
      setCsvDialogOpen(true);
    };
    reader.readAsText(file);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleImportCsv = async () => {
    if (!csvText.trim()) return;

    setIsImporting(true);
    try {
      const lines = csvText.split('\n').map(line => line.trim()).filter(line => line);
      const companies: Array<{ name: string; domain?: string; industry?: string }> = [];
      
      const startIndex = lines[0]?.toLowerCase().includes('company') || 
                         lines[0]?.toLowerCase().includes('name') ? 1 : 0;

      for (let i = startIndex; i < lines.length; i++) {
        const parts = lines[i].split(',').map(p => p.trim().replace(/^["']|["']$/g, ''));
        if (parts[0]) {
          companies.push({
            name: parts[0],
            domain: parts[1] || undefined,
            industry: parts[2] || undefined,
          });
        }
      }

      if (companies.length === 0) {
        toast({
          title: "No companies found",
          description: "Could not parse any company names from the CSV",
          variant: "destructive",
        });
        return;
      }

      const count = await jobChangersApi.bulkAddTargetCompanies(companies);
      toast({
        title: "Import complete",
        description: `Added ${count} companies to target list`,
      });
      
      setCsvDialogOpen(false);
      setCsvText("");
      onSearchComplete();
    } catch (error) {
      toast({
        title: "Import failed",
        description: "Failed to import companies",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <>
      <Card className="card-glow">
        <CardContent className="p-4">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Sparkles className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder='Try: "CFO roles at fintech startups" or "VP Finance openings"'
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="pl-10 h-11"
              />
            </div>
            <Button 
              onClick={handleSearch}
              disabled={!query.trim() || isSearching}
              className="gradient-bg btn-glow h-11 px-6"
            >
              {isSearching ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </>
              )}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.txt"
              onChange={handleFileUpload}
              className="hidden"
            />
            <Button 
              variant="outline" 
              onClick={() => fileInputRef.current?.click()}
              className="h-11"
            >
              <Upload className="h-4 w-4 mr-2" />
              CSV
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Find companies hiring for roles you can help with — each posting is a warm lead
          </p>
        </CardContent>
      </Card>

      {/* CSV Import Dialog */}
      <Dialog open={csvDialogOpen} onOpenChange={setCsvDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Import Companies from CSV</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Format: company name, domain (optional), industry (optional)
            </p>
            <Textarea
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="Company Name, Domain, Industry&#10;Acme Inc, acme.com, SaaS&#10;Example Corp, example.io, Fintech"
              className="min-h-[200px] font-mono text-sm"
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setCsvDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleImportCsv} disabled={!csvText.trim() || isImporting}>
              {isImporting ? "Importing..." : "Import"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
