import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi, JobChanger, MessageTemplate } from "@/lib/api/jobChangers";
import { 
  Linkedin, 
  MapPin, 
  ArrowRight, 
  Sparkles, 
  Copy, 
  Check,
  User,
  Building2,
  CheckCircle2,
  X,
  Users
} from "lucide-react";

interface LeadQueueProps {
  refreshKey: number;
  onStatsChange: () => void;
}

export function LeadQueue({ refreshKey, onStatsChange }: LeadQueueProps) {
  const [jobChangers, setJobChangers] = useState<JobChanger[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [autoApprove, setAutoApprove] = useState(false);
  const [selectedChanger, setSelectedChanger] = useState<JobChanger | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string | null>(null);
  const { toast } = useToast();

  const loadJobChangers = async () => {
    try {
      const [data, templateData] = await Promise.all([
        jobChangersApi.getJobChangers('pending'),
        jobChangersApi.getMessageTemplates(),
      ]);
      setJobChangers(data.filter(c => c.target_company_id));
      setTemplates(templateData);
      setSelectedTemplateId(templateData.find(t => t.is_default)?.id || null);
    } catch (error) {
      console.error('Error loading job changers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadJobChangers();
  }, [refreshKey]);

  const handleToggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    if (selectedIds.size === jobChangers.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(jobChangers.map(c => c.id)));
    }
  };

  const handleBatchApprove = async () => {
    if (selectedIds.size === 0) return;
    
    try {
      await jobChangersApi.bulkUpdateStatus(Array.from(selectedIds), 'approved');
      setJobChangers(prev => prev.filter(c => !selectedIds.has(c.id)));
      setSelectedIds(new Set());
      toast({
        title: "Approved",
        description: `${selectedIds.size} leads approved`,
      });
      onStatsChange();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve leads",
        variant: "destructive",
      });
    }
  };

  const handleSkip = async (id: string) => {
    try {
      await jobChangersApi.updateJobChangerStatus(id, 'skipped');
      setJobChangers(prev => prev.filter(c => c.id !== id));
      onStatsChange();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to skip profile",
        variant: "destructive",
      });
    }
  };

  const handleOpenOutreach = async (changer: JobChanger) => {
    setSelectedChanger(changer);
    setDialogOpen(true);
    setMessage("");
    setCopied(false);
    
    setIsGenerating(true);
    try {
      const template = templates.find(t => t.id === selectedTemplateId);
      const result = await jobChangersApi.generateOutreachMessage(changer, template?.content);
      if (result.success && result.message) {
        setMessage(result.message);
      }
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRegenerate = async () => {
    if (!selectedChanger) return;
    
    setIsGenerating(true);
    try {
      const template = templates.find(t => t.id === selectedTemplateId);
      const result = await jobChangersApi.generateOutreachMessage(selectedChanger, template?.content);
      if (result.success && result.message) {
        setMessage(result.message);
      }
    } catch (error) {
      console.error('Regeneration failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyAndMarkSent = async () => {
    if (!selectedChanger || !message) return;

    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      
      await jobChangersApi.updateJobChangerStatus(selectedChanger.id, 'sent', message);
      
      toast({
        title: "Copied!",
        description: "Message copied. Go paste it on LinkedIn!",
      });
      
      setTimeout(() => {
        setDialogOpen(false);
        setJobChangers(prev => prev.filter(c => c.id !== selectedChanger.id));
        onStatsChange();
      }, 1000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy message",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex gap-4 py-4 border-b last:border-0">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-3 w-64" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Lead Queue
              <Badge variant="secondary">{jobChangers.length}</Badge>
            </CardTitle>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch 
                  id="auto-approve" 
                  checked={autoApprove}
                  onCheckedChange={setAutoApprove}
                />
                <label htmlFor="auto-approve" className="text-sm text-muted-foreground cursor-pointer">
                  Auto-approve new leads
                </label>
              </div>
            </div>
          </div>
        </CardHeader>
        
        {jobChangers.length > 0 && (
          <div className="px-6 pb-3 flex items-center justify-between border-b">
            <div className="flex items-center gap-3">
              <Checkbox
                checked={selectedIds.size === jobChangers.length && jobChangers.length > 0}
                onCheckedChange={handleSelectAll}
              />
              <span className="text-sm text-muted-foreground">
                {selectedIds.size > 0 ? `${selectedIds.size} selected` : 'Select all'}
              </span>
            </div>
            {selectedIds.size > 0 && (
              <Button size="sm" onClick={handleBatchApprove} className="gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Approve Selected
              </Button>
            )}
          </div>
        )}

        <CardContent className="p-0">
          {jobChangers.length === 0 ? (
            <div className="py-12 text-center">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <User className="h-6 w-6 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-foreground mb-1">No Leads Yet</h3>
              <p className="text-sm text-muted-foreground max-w-sm mx-auto">
                Add target companies and run a search to find job changers.
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[400px]">
              <div className="divide-y">
                {jobChangers.map(changer => (
                  <div 
                    key={changer.id} 
                    className="flex items-center gap-4 p-4 hover:bg-muted/30 transition-colors"
                  >
                    <Checkbox
                      checked={selectedIds.has(changer.id)}
                      onCheckedChange={() => handleToggleSelect(changer.id)}
                    />
                    
                    {/* Avatar */}
                    <div className="flex-shrink-0">
                      {changer.profile_image_url ? (
                        <img 
                          src={changer.profile_image_url} 
                          alt={changer.full_name}
                          className="h-10 w-10 rounded-full object-cover ring-1 ring-border"
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-full gradient-bg flex items-center justify-center">
                          <span className="text-xs font-semibold text-white">
                            {changer.full_name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm truncate">{changer.full_name}</span>
                        {changer.linkedin_url && (
                          <a 
                            href={changer.linkedin_url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary hover:text-primary/80"
                          >
                            <Linkedin className="h-3.5 w-3.5" />
                          </a>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
                        {changer.previous_company && (
                          <>
                            <span>{changer.previous_company}</span>
                            <ArrowRight className="h-3 w-3" />
                          </>
                        )}
                        <span className="font-medium text-foreground">{changer.current_company}</span>
                        {changer.current_title && (
                          <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                            {changer.current_title}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleSkip(changer.id)}
                        className="h-8 w-8 p-0"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => handleOpenOutreach(changer)}
                        className="h-8"
                      >
                        <Sparkles className="h-3.5 w-3.5 mr-1.5" />
                        Message
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Outreach Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Message for {selectedChanger?.full_name}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {selectedChanger && (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <div className="text-sm">
                  <span className="font-medium">{selectedChanger.current_title}</span>
                  <span className="text-muted-foreground"> at </span>
                  <span className="font-medium">{selectedChanger.current_company}</span>
                </div>
              </div>
            )}

            {templates.length > 1 && (
              <div className="flex gap-2 flex-wrap">
                {templates.map(t => (
                  <Button
                    key={t.id}
                    variant={selectedTemplateId === t.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedTemplateId(t.id)}
                  >
                    {t.name}
                  </Button>
                ))}
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">LinkedIn Message</label>
                <span className={`text-xs ${message.length > 280 ? 'text-destructive' : 'text-muted-foreground'}`}>
                  {message.length}/280
                </span>
              </div>
              
              {isGenerating ? (
                <div className="space-y-2 p-4 rounded-lg border bg-muted/30">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-4/5" />
                  <Skeleton className="h-4 w-3/5" />
                </div>
              ) : (
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Your personalized message..."
                  className="min-h-[120px] resize-none"
                />
              )}
            </div>

            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleRegenerate}
              disabled={isGenerating}
              className="w-full"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Regenerate
            </Button>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCopyAndMarkSent}
              disabled={!message || isGenerating}
              className="gradient-bg"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy & Mark Sent
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
