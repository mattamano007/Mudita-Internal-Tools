import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi, PhantomBusterConfig } from "@/lib/api/jobChangers";
import { Ghost, Plus, Play, Loader2, Trash2, Zap } from "lucide-react";

interface PhantomBusterPanelProps {
  onScrapeComplete: () => void;
}

export function PhantomBusterPanel({ onScrapeComplete }: PhantomBusterPanelProps) {
  const [configs, setConfigs] = useState<PhantomBusterConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [runningId, setRunningId] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newAgentId, setNewAgentId] = useState("");
  const [newName, setNewName] = useState("");
  const { toast } = useToast();

  const loadConfigs = async () => {
    try {
      const data = await jobChangersApi.getPhantomBusterConfigs();
      setConfigs(data);
    } catch (error) {
      console.error('Error loading configs:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadConfigs();
  }, []);

  const handleAddConfig = async () => {
    if (!newAgentId.trim() || !newName.trim()) return;

    try {
      const config = await jobChangersApi.addPhantomBusterConfig(newAgentId.trim(), newName.trim());
      setConfigs(prev => [config, ...prev]);
      setDialogOpen(false);
      setNewAgentId("");
      setNewName("");
      toast({
        title: "Added",
        description: "PhantomBuster agent configured",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add config",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await jobChangersApi.deletePhantomBusterConfig(id);
      setConfigs(prev => prev.filter(c => c.id !== id));
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete config",
        variant: "destructive",
      });
    }
  };

  const handleToggleAutoApprove = async (id: string, autoApprove: boolean) => {
    try {
      await jobChangersApi.toggleAutoApprove(id, autoApprove);
      setConfigs(prev => prev.map(c => c.id === id ? { ...c, auto_approve: autoApprove } : c));
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update setting",
        variant: "destructive",
      });
    }
  };

  const handleRunScrape = async (agentId: string, configId: string) => {
    setRunningId(configId);
    
    try {
      const result = await jobChangersApi.runPhantomBusterScrape(agentId);
      
      if (result.success) {
        // Run matching
        await jobChangersApi.matchProfilesToTargets();
        
        toast({
          title: "Search complete",
          description: `Found ${result.newProfiles || 0} new profiles`,
        });
        onScrapeComplete();
      } else {
        toast({
          title: "Search failed",
          description: result.error || "Something went wrong",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to run search",
        variant: "destructive",
      });
    } finally {
      setRunningId(null);
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Ghost className="h-5 w-5 text-primary" />
              PhantomBuster
            </CardTitle>
            <Button size="sm" onClick={() => setDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-1" />
              Add Agent
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-4 text-muted-foreground text-sm">Loading...</div>
          ) : configs.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-muted-foreground text-sm">
                Add a PhantomBuster agent to start searching for job changers.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {configs.map(config => (
                <div 
                  key={config.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-muted/30"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{config.name}</span>
                      {config.auto_approve && (
                        <Badge variant="secondary" className="text-[10px]">
                          <Zap className="h-3 w-3 mr-0.5" />
                          Auto
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Agent ID: {config.agent_id.slice(0, 8)}...
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5 mr-2">
                      <Switch
                        checked={config.auto_approve}
                        onCheckedChange={(checked) => handleToggleAutoApprove(config.id, checked)}
                        className="scale-75"
                      />
                      <span className="text-xs text-muted-foreground">Auto</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(config.id)}
                      className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleRunScrape(config.agent_id, config.id)}
                      disabled={runningId !== null}
                      className="gradient-bg"
                    >
                      {runningId === config.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <Play className="h-4 w-4 mr-1" />
                          Run
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Agent Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add PhantomBuster Agent</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Agent Name</label>
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g., Sales Nav Job Changers"
                className="mt-1.5"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Agent ID</label>
              <Input
                value={newAgentId}
                onChange={(e) => setNewAgentId(e.target.value)}
                placeholder="Your PhantomBuster Agent ID"
                className="mt-1.5"
              />
              <p className="text-xs text-muted-foreground mt-1.5">
                Find this in your PhantomBuster dashboard URL
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddConfig}
              disabled={!newAgentId.trim() || !newName.trim()}
            >
              Add Agent
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
