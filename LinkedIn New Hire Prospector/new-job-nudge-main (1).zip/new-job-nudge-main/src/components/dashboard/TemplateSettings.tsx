import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi, MessageTemplate } from "@/lib/api/jobChangers";
import { FileText, Plus, Trash2, Edit2, Star } from "lucide-react";

export function TemplateSettings() {
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<MessageTemplate | null>(null);
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [isDefault, setIsDefault] = useState(false);
  const { toast } = useToast();

  const loadTemplates = async () => {
    try {
      const data = await jobChangersApi.getMessageTemplates();
      setTemplates(data);
    } catch (error) {
      console.error('Error loading templates:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTemplates();
  }, []);

  const handleOpenDialog = (template?: MessageTemplate) => {
    if (template) {
      setEditingTemplate(template);
      setName(template.name);
      setContent(template.content);
      setIsDefault(template.is_default);
    } else {
      setEditingTemplate(null);
      setName("");
      setContent("");
      setIsDefault(false);
    }
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!name.trim() || !content.trim()) return;

    try {
      if (editingTemplate) {
        await jobChangersApi.updateMessageTemplate(editingTemplate.id, {
          name: name.trim(),
          content: content.trim(),
          is_default: isDefault,
        });
        toast({ title: "Updated", description: "Template updated" });
      } else {
        await jobChangersApi.createMessageTemplate(name.trim(), content.trim(), isDefault);
        toast({ title: "Created", description: "Template created" });
      }
      
      setDialogOpen(false);
      loadTemplates();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save template",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await jobChangersApi.deleteMessageTemplate(id);
      setTemplates(prev => prev.filter(t => t.id !== id));
      toast({ title: "Deleted", description: "Template deleted" });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete template",
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Message Templates
            </CardTitle>
            <Button size="sm" onClick={() => handleOpenDialog()}>
              <Plus className="h-4 w-4 mr-1" />
              New Template
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-4 text-muted-foreground text-sm">Loading...</div>
          ) : templates.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-muted-foreground text-sm">
                No templates yet. Create one to personalize your outreach.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {templates.map(template => (
                <div 
                  key={template.id}
                  className="p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{template.name}</span>
                        {template.is_default && (
                          <Badge variant="secondary" className="text-[10px]">
                            <Star className="h-3 w-3 mr-0.5 fill-current" />
                            Default
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {template.content}
                      </p>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleOpenDialog(template)}
                        className="h-8 w-8 p-0"
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(template.id)}
                        className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Template Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingTemplate ? 'Edit Template' : 'New Template'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Template Name</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Warm Intro"
                className="mt-1.5"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Message Content</label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Hey {{first_name}}! Congrats on the new role..."
                className="mt-1.5 min-h-[150px]"
              />
              <p className="text-xs text-muted-foreground mt-1.5">
                Variables: {'{{first_name}}'}, {'{{current_title}}'}, {'{{current_company}}'}, {'{{previous_company}}'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={isDefault}
                onCheckedChange={setIsDefault}
              />
              <label className="text-sm">Set as default template</label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              disabled={!name.trim() || !content.trim()}
            >
              {editingTemplate ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
