import { MoreVertical, Pause, Play, Trash2, Bell, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Monitor } from "@/types/monitor";

interface MonitorCardProps {
  monitor: Monitor;
  onToggleStatus: (id: string) => void;
  onDelete: (id: string) => void;
  onClick: (monitor: Monitor) => void;
}

export const MonitorCard = ({ monitor, onToggleStatus, onDelete, onClick }: MonitorCardProps) => {
  return (
    <Card
      className="group cursor-pointer border-border bg-card transition-all duration-300 hover:border-primary/50 card-glow"
      onClick={() => onClick(monitor)}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1 space-y-3">
            <div className="flex items-center gap-2">
              <Badge
                variant={monitor.status === "active" ? "default" : "secondary"}
                className={monitor.status === "active" ? "bg-success/20 text-success border-success/30" : ""}
              >
                {monitor.status === "active" ? (
                  <span className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
                    Active
                  </span>
                ) : (
                  "Paused"
                )}
              </Badge>
              <Badge variant="outline" className="text-muted-foreground">
                {monitor.config.frequency}
              </Badge>
            </div>
            
            <div>
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                {monitor.name}
              </h3>
              <p className="text-sm text-muted-foreground line-clamp-1 mt-0.5">
                {monitor.description}
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Bell className="h-3.5 w-3.5" />
                {monitor.matchCount} matches
              </span>
              {monitor.lastChecked && (
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  {monitor.lastChecked}
                </span>
              )}
            </div>

            {monitor.config.companies.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {monitor.config.companies.slice(0, 3).map((company) => (
                  <Badge key={company} variant="outline" className="text-xs">
                    {company}
                  </Badge>
                ))}
                {monitor.config.companies.length > 3 && (
                  <Badge variant="outline" className="text-xs text-muted-foreground">
                    +{monitor.config.companies.length - 3} more
                  </Badge>
                )}
              </div>
            )}
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onToggleStatus(monitor.id); }}>
                {monitor.status === "active" ? (
                  <>
                    <Pause className="mr-2 h-4 w-4" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Resume
                  </>
                )}
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-destructive"
                onClick={(e) => { e.stopPropagation(); onDelete(monitor.id); }}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
};
