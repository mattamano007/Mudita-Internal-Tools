import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi, PhantomBusterConfig } from "@/lib/api/jobChangers";
import { 
  Ghost, 
  Play, 
  Loader2, 
  Plus,
  Trash2,
  Clock,
  Zap
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface PhantomBusterSetupProps {
  onScrapeComplete: () => void;
}

export function PhantomBusterSetup({ onScrapeComplete }: PhantomBusterSetupProps) {
  const [configs, setConfigs] = useState<PhantomBusterConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [newAgentId, setNewAgentId] = useState("");
  const [newAgentName, setNewAgentName] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [runningAgents, setRunningAgents] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const loadConfigs = async () => {
    try {
      const data = await jobChangersApi.getPhantomBusterConfigs();
      setConfigs(data);
    } catch (error) {
      console.error('Error loading configs:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadConfigs();
  }, []);

  const handleAddConfig = async () => {
    if (!newAgentId.trim() || !newAgentName.trim()) return;
    
    setIsAdding(true);
    try {
      const config = await jobChangersApi.addPhantomBusterConfig(
        newAgentId.trim(), 
        newAgentName.trim()
      );
      setConfigs(prev => [config, ...prev]);
      setNewAgentId("");
      setNewAgentName("");
      toast({
        title: "Agent added",
        description: `${config.name} is ready to run`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add agent",
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  const handleDeleteConfig = async (id: string) => {
    try {
      await jobChangersApi.deletePhantomBusterConfig(id);
      setConfigs(prev => prev.filter(c => c.id !== id));
      toast({
        title: "Removed",
        description: "Agent configuration removed",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove agent",
        variant: "destructive",
      });
    }
  };

  const handleRunScrape = async (config: PhantomBusterConfig) => {
    setRunningAgents(prev => new Set(prev).add(config.agent_id));
    
    toast({
      title: "Scrape started",
      description: `Running ${config.name}... This may take a few minutes.`,
    });

    try {
      const result = await jobChangersApi.runPhantomBusterScrape(config.agent_id);
      
      if (result.success) {
        toast({
          title: "Scrape complete",
          description: `Found ${result.newProfiles || 0} new profiles`,
        });
        
        // Now run matching
        const matchResult = await jobChangersApi.matchProfilesToTargets();
        if (matchResult.success && matchResult.matched && matchResult.matched > 0) {
          toast({
            title: "Matching complete",
            description: `${matchResult.matched} profiles matched to target companies`,
          });
        }
        
        loadConfigs();
        onScrapeComplete();
      } else {
        toast({
          title: "Scrape failed",
          description: result.error || "Unknown error",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to run scrape",
        variant: "destructive",
      });
    } finally {
      setRunningAgents(prev => {
        const next = new Set(prev);
        next.delete(config.agent_id);
        return next;
      });
    }
  };

  return (
    <Card className="card-glow">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          <Ghost className="h-5 w-5 text-primary" />
          PhantomBuster Agents
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add agent form */}
        <div className="space-y-2 p-4 rounded-lg border border-dashed">
          <p className="text-sm text-muted-foreground mb-3">
            Add your Sales Navigator Search Export phantom ID
          </p>
          <div className="grid grid-cols-2 gap-2">
            <Input
              placeholder="Agent Name (e.g., 'Q1 Finance Leads')"
              value={newAgentName}
              onChange={(e) => setNewAgentName(e.target.value)}
            />
            <Input
              placeholder="Agent ID from PhantomBuster"
              value={newAgentId}
              onChange={(e) => setNewAgentId(e.target.value)}
            />
          </div>
          <Button 
            onClick={handleAddConfig}
            disabled={!newAgentId.trim() || !newAgentName.trim() || isAdding}
            className="w-full mt-2"
            variant="outline"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Agent
          </Button>
        </div>

        {/* Agent list */}
        {loading ? (
          <div className="text-center py-4 text-muted-foreground">Loading...</div>
        ) : configs.length === 0 ? (
          <div className="text-center py-4 text-muted-foreground text-sm">
            No agents configured yet
          </div>
        ) : (
          <div className="space-y-2">
            {configs.map(config => (
              <div 
                key={config.id}
                className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Zap className="h-4 w-4 text-primary" />
                  <div>
                    <p className="font-medium text-sm">{config.name}</p>
                    <p className="text-xs text-muted-foreground font-mono">
                      {config.agent_id.slice(0, 16)}...
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {config.last_run_at && (
                    <Badge variant="outline" className="text-xs">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatDistanceToNow(new Date(config.last_run_at), { addSuffix: true })}
                    </Badge>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteConfig(config.id)}
                  >
                    <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleRunScrape(config)}
                    disabled={runningAgents.has(config.agent_id)}
                  >
                    {runningAgents.has(config.agent_id) ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                        Running...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-1" />
                        Run
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
