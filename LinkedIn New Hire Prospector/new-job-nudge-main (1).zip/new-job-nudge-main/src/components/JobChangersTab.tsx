import { useState, useCallback } from "react";
import { JobChangerQueue } from "./JobChangerQueue";
import { TargetCompanies } from "./TargetCompanies";
import { PhantomBusterSetup } from "./PhantomBusterSetup";

export function JobChangersTab() {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleScrapeComplete = useCallback(() => {
    setRefreshKey(prev => prev + 1);
  }, []);

  return (
    <div className="space-y-6">
      {/* Setup Section */}
      <div className="grid gap-6 md:grid-cols-2">
        <TargetCompanies />
        <PhantomBusterSetup onScrapeComplete={handleScrapeComplete} />
      </div>

      {/* Queue Section */}
      <div>
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <span className="gradient-text">Matched Profiles</span>
          <span className="text-muted-foreground font-normal text-sm">
            — Ready for outreach
          </span>
        </h2>
        <JobChangerQueue key={refreshKey} />
      </div>
    </div>
  );
}
