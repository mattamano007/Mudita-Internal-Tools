import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { jobChangersApi, TargetCompany } from "@/lib/api/jobChangers";
import { 
  Building2, 
  Plus, 
  Trash2, 
  Upload, 
  Globe,
  X
} from "lucide-react";

export function TargetCompanies() {
  const [companies, setCompanies] = useState<TargetCompany[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCompany, setNewCompany] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [csvDialogOpen, setCsvDialogOpen] = useState(false);
  const [csvText, setCsvText] = useState("");
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const loadCompanies = async () => {
    try {
      const data = await jobChangersApi.getTargetCompanies();
      setCompanies(data);
    } catch (error) {
      console.error('Error loading companies:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCompanies();
  }, []);

  const handleAddCompany = async () => {
    if (!newCompany.trim()) return;
    
    setIsAdding(true);
    try {
      const company = await jobChangersApi.addTargetCompany(newCompany.trim());
      setCompanies(prev => [...prev, company].sort((a, b) => a.name.localeCompare(b.name)));
      setNewCompany("");
      toast({
        title: "Added",
        description: `${company.name} added to target list`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add company",
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  const handleDeleteCompany = async (id: string, name: string) => {
    try {
      await jobChangersApi.deleteTargetCompany(id);
      setCompanies(prev => prev.filter(c => c.id !== id));
      toast({
        title: "Removed",
        description: `${name} removed from target list`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove company",
        variant: "destructive",
      });
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setCsvText(text);
      setCsvDialogOpen(true);
    };
    reader.readAsText(file);

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleImportCsv = async () => {
    if (!csvText.trim()) return;

    setIsImporting(true);
    try {
      // Parse CSV - assume first column is company name
      const lines = csvText.split('\n').map(line => line.trim()).filter(line => line);
      const companies: Array<{ name: string; domain?: string; industry?: string }> = [];
      
      // Skip header if it looks like one
      const startIndex = lines[0]?.toLowerCase().includes('company') || 
                         lines[0]?.toLowerCase().includes('name') ? 1 : 0;

      for (let i = startIndex; i < lines.length; i++) {
        const parts = lines[i].split(',').map(p => p.trim().replace(/^["']|["']$/g, ''));
        if (parts[0]) {
          companies.push({
            name: parts[0],
            domain: parts[1] || undefined,
            industry: parts[2] || undefined,
          });
        }
      }

      if (companies.length === 0) {
        toast({
          title: "No companies found",
          description: "Could not parse any company names from the CSV",
          variant: "destructive",
        });
        return;
      }

      const count = await jobChangersApi.bulkAddTargetCompanies(companies);
      toast({
        title: "Import complete",
        description: `Added ${count} companies to target list`,
      });
      
      setCsvDialogOpen(false);
      setCsvText("");
      loadCompanies();
    } catch (error) {
      toast({
        title: "Import failed",
        description: "Failed to import companies",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <>
      <Card className="card-glow">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Target Companies
              <Badge variant="secondary" className="ml-2">{companies.length}</Badge>
            </CardTitle>
            <div className="flex gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-4 w-4 mr-1" />
                Import CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Add company form */}
          <div className="flex gap-2">
            <Input
              placeholder="Add company name..."
              value={newCompany}
              onChange={(e) => setNewCompany(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddCompany()}
              className="flex-1"
            />
            <Button 
              onClick={handleAddCompany}
              disabled={!newCompany.trim() || isAdding}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Companies list */}
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">Loading...</div>
          ) : companies.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground text-sm">
                No target companies yet. Add companies manually or import a CSV.
              </p>
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {companies.map(company => (
                <Badge 
                  key={company.id} 
                  variant="outline"
                  className="py-1.5 px-3 flex items-center gap-2 hover:bg-muted/50 transition-colors group"
                >
                  {company.domain && (
                    <Globe className="h-3 w-3 text-muted-foreground" />
                  )}
                  <span>{company.name}</span>
                  <button
                    onClick={() => handleDeleteCompany(company.id, company.name)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* CSV Import Dialog */}
      <Dialog open={csvDialogOpen} onOpenChange={setCsvDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Import Companies from CSV</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Paste or edit your CSV data below. Format: company name, domain (optional), industry (optional)
            </p>
            <Textarea
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="Company Name, Domain, Industry&#10;Acme Inc, acme.com, SaaS&#10;Example Corp, example.io, Fintech"
              className="min-h-[200px] font-mono text-sm"
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setCsvDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleImportCsv} disabled={!csvText.trim() || isImporting}>
              {isImporting ? "Importing..." : "Import"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
