import { useState } from "react";
import { X, Plus, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { MonitorTemplate, MonitorConfig, Monitor } from "@/types/monitor";

interface CreateMonitorDialogProps {
  open: boolean;
  onClose: () => void;
  template?: MonitorTemplate | null;
  initialPrompt?: string;
  onCreateMonitor: (monitor: Omit<Monitor, "id" | "createdAt" | "matchCount">) => void;
}

export const CreateMonitorDialog = ({
  open,
  onClose,
  template,
  initialPrompt,
  onCreateMonitor,
}: CreateMonitorDialogProps) => {
  const [name, setName] = useState(template?.title || "");
  const [description, setDescription] = useState(template?.description || initialPrompt || "");
  const [companies, setCompanies] = useState<string[]>([]);
  const [companyInput, setCompanyInput] = useState("");
  const [jobTitles, setJobTitles] = useState<string[]>(template?.defaultConfig.jobTitles || []);
  const [titleInput, setTitleInput] = useState("");
  const [frequency, setFrequency] = useState<"realtime" | "daily" | "weekly">(
    template?.defaultConfig.frequency || "daily"
  );
  const [sources, setSources] = useState<("job-boards" | "news" | "company-pages")[]>(
    template?.defaultConfig.sources || ["job-boards", "news"]
  );

  const handleAddCompany = () => {
    if (companyInput.trim() && !companies.includes(companyInput.trim())) {
      setCompanies([...companies, companyInput.trim()]);
      setCompanyInput("");
    }
  };

  const handleAddTitle = () => {
    if (titleInput.trim() && !jobTitles.includes(titleInput.trim())) {
      setJobTitles([...jobTitles, titleInput.trim()]);
      setTitleInput("");
    }
  };

  const toggleSource = (source: "job-boards" | "news" | "company-pages") => {
    if (sources.includes(source)) {
      setSources(sources.filter((s) => s !== source));
    } else {
      setSources([...sources, source]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const config: MonitorConfig = {
      companies,
      jobTitles,
      seniorityLevels: template?.defaultConfig.seniorityLevels || [],
      locations: [],
      sources,
      frequency,
    };

    onCreateMonitor({
      name: name || "Untitled Monitor",
      description,
      config,
      status: "active",
      templateId: template?.id,
    });

    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-foreground">
            Create Monitor
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="name">Monitor Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., VP+ Hires at Target Accounts"
              className="bg-muted/50"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What are you tracking?"
              className="bg-muted/50 min-h-[80px] resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label>Companies to Watch</Label>
            <div className="flex gap-2">
              <Input
                value={companyInput}
                onChange={(e) => setCompanyInput(e.target.value)}
                placeholder="Add a company"
                className="bg-muted/50"
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleAddCompany())}
              />
              <Button type="button" variant="secondary" onClick={handleAddCompany}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {companies.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {companies.map((company) => (
                  <Badge key={company} variant="secondary" className="pr-1">
                    {company}
                    <button
                      type="button"
                      onClick={() => setCompanies(companies.filter((c) => c !== company))}
                      className="ml-1 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Job Titles (optional)</Label>
            <div className="flex gap-2">
              <Input
                value={titleInput}
                onChange={(e) => setTitleInput(e.target.value)}
                placeholder="e.g., VP of Sales"
                className="bg-muted/50"
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleAddTitle())}
              />
              <Button type="button" variant="secondary" onClick={handleAddTitle}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {jobTitles.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {jobTitles.map((title) => (
                  <Badge key={title} variant="secondary" className="pr-1">
                    {title}
                    <button
                      type="button"
                      onClick={() => setJobTitles(jobTitles.filter((t) => t !== title))}
                      className="ml-1 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Data Sources</Label>
            <div className="flex flex-col gap-2">
              {[
                { id: "job-boards", label: "Job Boards & LinkedIn" },
                { id: "news", label: "News & Press Releases" },
                { id: "company-pages", label: "Company Career Pages" },
              ].map((source) => (
                <div key={source.id} className="flex items-center gap-2">
                  <Checkbox
                    id={source.id}
                    checked={sources.includes(source.id as any)}
                    onCheckedChange={() => toggleSource(source.id as any)}
                  />
                  <Label htmlFor={source.id} className="text-sm font-normal cursor-pointer">
                    {source.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="frequency">Check Frequency</Label>
            <Select value={frequency} onValueChange={(v) => setFrequency(v as any)}>
              <SelectTrigger className="bg-muted/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="realtime">Real-time</SelectItem>
                <SelectItem value="daily">Daily digest</SelectItem>
                <SelectItem value="weekly">Weekly digest</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="btn-glow">
              Create Monitor
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
