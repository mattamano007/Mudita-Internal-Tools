import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Copy, Check, Send, Sparkles } from "lucide-react";
import { JobResult } from "@/lib/api/jobs";
import { useToast } from "@/hooks/use-toast";

interface OutreachGeneratorProps {
  job: JobResult | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const MESSAGE_TEMPLATES = [
  {
    id: "congratulatory",
    label: "Congratulatory",
    generate: (job: JobResult) => `Hi there,

Congratulations on the new finance leadership opportunity! I noticed the recent posting and wanted to reach out.

Starting a new finance role at a growing company is both exciting and challenging. As someone who works with finance leaders during transitions, I'd love to connect and share some insights that might be helpful as you build out your team and processes.

Would you be open to a brief conversation?

Best regards`,
  },
  {
    id: "value-add",
    label: "Value-Add",
    generate: (job: JobResult) => `Hi,

I came across the finance leadership position and it caught my attention. Companies at this stage often face unique challenges around scaling financial operations, implementing new systems, and building out their finance function.

I've helped several finance leaders navigate these exact challenges during their first 90 days. Would it be valuable to share some of those learnings?

Looking forward to connecting.

Best`,
  },
  {
    id: "direct",
    label: "Direct",
    generate: (job: JobResult) => `Hi,

I noticed your company is looking to strengthen the finance team. I work with finance leaders at growing companies and thought it might be worth connecting.

Are you the right person to speak with about this, or could you point me in the right direction?

Thanks!`,
  },
];

export function OutreachGenerator({ job, open, onOpenChange }: OutreachGeneratorProps) {
  const [selectedTemplate, setSelectedTemplate] = useState("congratulatory");
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
    const template = MESSAGE_TEMPLATES.find((t) => t.id === templateId);
    if (template && job) {
      setMessage(template.generate(job));
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(message);
    setCopied(true);
    toast({ title: "Copied to clipboard" });
    setTimeout(() => setCopied(false), 2000);
  };

  // Generate initial message when job changes
  useState(() => {
    if (job) {
      const template = MESSAGE_TEMPLATES.find((t) => t.id === selectedTemplate);
      if (template) {
        setMessage(template.generate(job));
      }
    }
  });

  if (!job) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Generate Outreach Message
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Job Context */}
          <div className="p-3 rounded-lg bg-muted/50 border border-border/50">
            <p className="text-sm font-medium">{job.title || "Finance Role"}</p>
            <p className="text-xs text-muted-foreground truncate">{job.url}</p>
          </div>

          {/* Template Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Message Style</label>
            <div className="flex gap-2">
              {MESSAGE_TEMPLATES.map((template) => (
                <Badge
                  key={template.id}
                  variant={selectedTemplate === template.id ? "default" : "outline"}
                  className="cursor-pointer hover:bg-primary/20"
                  onClick={() => handleTemplateSelect(template.id)}
                >
                  {template.label}
                </Badge>
              ))}
            </div>
          </div>

          {/* Message Editor */}
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="min-h-[250px] font-mono text-sm"
            placeholder="Your personalized message..."
          />

          {/* Actions */}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={handleCopy}>
              {copied ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </>
              )}
            </Button>
            <Button onClick={() => onOpenChange(false)}>
              <Send className="mr-2 h-4 w-4" />
              Done
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
