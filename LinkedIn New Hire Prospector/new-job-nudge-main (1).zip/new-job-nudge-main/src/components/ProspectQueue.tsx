import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Check, X, Mail, Send, ExternalLink, Loader2, Search, User, Linkedin } from "lucide-react";
import { prospectsApi, Prospect } from "@/lib/api/prospects";
import { useToast } from "@/hooks/use-toast";

const MESSAGE_TEMPLATES = [
  {
    id: "congratulatory",
    label: "Congratulatory",
    generate: (founderName: string, role: string) => `Hi ${founderName || 'there'},

I noticed you're building out your finance team — congrats on the growth!

Hiring a ${role || 'finance leader'} is a big milestone. I work with founders during these transitions and have some insights that might be helpful as you scale your finance function.

Would you be open to a quick chat?

Best regards`,
  },
  {
    id: "value-add",
    label: "Value-Add",
    generate: (founderName: string, role: string) => `Hi ${founderName || 'there'},

Saw you're hiring for a ${role || 'finance role'} — exciting times!

I've helped several founders navigate building out their finance teams at this stage. The right hire can be transformational, and I'd love to share some learnings.

Worth a quick conversation?

Best`,
  },
  {
    id: "direct",
    label: "Direct",
    generate: (founderName: string, role: string) => `Hi ${founderName || 'there'},

I see you're hiring a ${role || 'finance leader'}. I work with growing companies on finance team strategy.

Would it be helpful to connect?

Thanks`,
  },
];

export function ProspectQueue() {
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProspect, setSelectedProspect] = useState<Prospect | null>(null);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [founderEmail, setFounderEmail] = useState("");
  const [founderName, setFounderName] = useState("");
  const [message, setMessage] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("congratulatory");
  const [isSending, setIsSending] = useState(false);
  const [lookingUpFounder, setLookingUpFounder] = useState<string | null>(null);
  const { toast } = useToast();

  const loadProspects = async () => {
    try {
      const data = await prospectsApi.getProspects('pending');
      setProspects(data);
    } catch (error) {
      console.error('Error loading prospects:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProspects();
  }, []);

  const handleReject = async (id: string) => {
    try {
      await prospectsApi.updateProspectStatus(id, 'rejected');
      setProspects(prospects.filter(p => p.id !== id));
      toast({ title: "Prospect rejected" });
    } catch (error) {
      toast({ title: "Failed to reject", variant: "destructive" });
    }
  };

  const handleLookupFounder = async (prospect: Prospect) => {
    // Extract company name from title or use placeholder
    const companyName = prospect.company_name || extractCompanyName(prospect.title);
    
    if (!companyName) {
      toast({ title: "Could not determine company name", variant: "destructive" });
      return;
    }

    setLookingUpFounder(prospect.id);

    try {
      const result = await prospectsApi.lookupFounder(prospect.id, companyName);
      
      if (result.success && result.founder?.name) {
        toast({ title: `Found founder: ${result.founder.name}` });
        loadProspects();
      } else {
        toast({ title: "Could not find founder info automatically", description: "You can enter it manually" });
        loadProspects();
      }
    } catch (error) {
      toast({ title: "Lookup failed", variant: "destructive" });
    } finally {
      setLookingUpFounder(null);
    }
  };

  const extractCompanyName = (title: string): string => {
    // Try to extract company name from job title patterns
    const patterns = [
      /at\s+([A-Z][A-Za-z0-9\s]+?)(?:\s*[-–—]|\s*$)/i,
      /([A-Z][A-Za-z0-9]+)\s+(?:is\s+)?hiring/i,
      /^([A-Z][A-Za-z0-9\s]+?)\s*[-–—]/,
    ];
    
    for (const pattern of patterns) {
      const match = title.match(pattern);
      if (match) return match[1].trim();
    }
    
    return "";
  };

  const handleApproveClick = (prospect: Prospect) => {
    setSelectedProspect(prospect);
    setFounderEmail(prospect.founder_email || "");
    setFounderName(prospect.founder_name || "");
    
    const role = extractRoleFromTitle(prospect.title);
    const template = MESSAGE_TEMPLATES.find(t => t.id === selectedTemplate);
    setMessage(template?.generate(prospect.founder_name || "", role) || "");
    setShowApproveDialog(true);
  };

  const extractRoleFromTitle = (title: string): string => {
    const rolePatterns = [
      /(CFO|VP Finance|Finance Director|Head of Finance|Controller|Finance Manager)/i,
    ];
    
    for (const pattern of rolePatterns) {
      const match = title.match(pattern);
      if (match) return match[1];
    }
    return "finance leader";
  };

  const handleTemplateChange = (templateId: string) => {
    setSelectedTemplate(templateId);
    const template = MESSAGE_TEMPLATES.find(t => t.id === templateId);
    if (template && selectedProspect) {
      const role = extractRoleFromTitle(selectedProspect.title);
      setMessage(template.generate(founderName || "", role));
    }
  };

  const handleSendOutreach = async () => {
    if (!selectedProspect || !founderEmail || !message) {
      toast({ title: "Please fill in founder email and message", variant: "destructive" });
      return;
    }

    setIsSending(true);

    try {
      // Update founder info if changed
      if (founderName !== selectedProspect.founder_name || founderEmail !== selectedProspect.founder_email) {
        await prospectsApi.updateFounderInfo(selectedProspect.id, founderName, founderEmail);
      }

      // Send the email to founder
      const result = await prospectsApi.sendOutreach(
        founderEmail,
        "Quick question about your finance team",
        message,
        founderName || undefined
      );

      if (result.success) {
        await prospectsApi.updateProspectStatus(selectedProspect.id, 'sent', message);
        setProspects(prospects.filter(p => p.id !== selectedProspect.id));
        setShowApproveDialog(false);
        setSelectedProspect(null);
        toast({ title: "Outreach sent to founder!" });
      } else {
        toast({ title: result.error || "Failed to send email", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Failed to send outreach", variant: "destructive" });
    } finally {
      setIsSending(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (prospects.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <div className="h-16 w-16 rounded-2xl bg-muted/50 flex items-center justify-center mx-auto mb-4">
          <Mail className="h-8 w-8 text-muted-foreground/50" />
        </div>
        <h3 className="font-semibold text-lg text-foreground mb-1">Queue Empty</h3>
        <p className="text-sm text-muted-foreground max-w-sm mx-auto">
          No prospects waiting for review. Run your saved searches to discover new opportunities.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            <h3 className="font-semibold text-lg">Review Queue</h3>
          </div>
          <Badge className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
            {prospects.length} pending
          </Badge>
        </div>

        <div className="space-y-3">
          {prospects.map((prospect, index) => (
            <Card 
              key={prospect.id} 
              className="group border-border/40 bg-card/60 backdrop-blur-sm hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  {/* Company Avatar */}
                  <div className="shrink-0 h-12 w-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center border border-primary/10">
                    <span className="text-lg font-bold text-primary">
                      {(prospect.company_name || prospect.title)?.[0]?.toUpperCase() || '?'}
                    </span>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    {/* Title & Company */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <h4 className="font-semibold text-foreground truncate leading-tight">
                          {prospect.title}
                        </h4>
                        {prospect.company_name && (
                          <p className="text-sm text-primary font-medium mt-0.5">
                            {prospect.company_name}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-2 leading-relaxed">
                      {prospect.description || "No description available"}
                    </p>
                    
                    {/* Founder Info Row */}
                    <div className="mt-3 flex items-center gap-2 flex-wrap">
                      {prospect.founder_name && (
                        <Badge variant="outline" className="gap-1.5 bg-success/5 border-success/20 text-success">
                          <User className="h-3 w-3" />
                          {prospect.founder_name}
                        </Badge>
                      )}
                      
                      {prospect.founder_email && (
                        <Badge variant="outline" className="gap-1.5 bg-primary/5 border-primary/20 text-primary">
                          <Mail className="h-3 w-3" />
                          {prospect.founder_email}
                        </Badge>
                      )}
                      
                      {prospect.founder_linkedin && (
                        <a href={prospect.founder_linkedin} target="_blank" rel="noopener noreferrer">
                          <Badge variant="outline" className="gap-1.5 hover:bg-primary/10 transition-colors">
                            <Linkedin className="h-3 w-3" />
                            LinkedIn
                          </Badge>
                        </a>
                      )}
                      
                      {prospect.founder_lookup_status === 'pending' && !prospect.founder_name && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-primary"
                          onClick={() => handleLookupFounder(prospect)}
                          disabled={lookingUpFounder === prospect.id}
                        >
                          {lookingUpFounder === prospect.id ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <Search className="h-3 w-3" />
                          )}
                          Find Founder
                        </Button>
                      )}
                      
                      {prospect.founder_lookup_status === 'not_found' && (
                        <Badge variant="secondary" className="text-xs text-muted-foreground">
                          No founder found
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Row */}
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/30">
                  <a
                    href={prospect.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1.5 transition-colors"
                  >
                    <ExternalLink className="h-3 w-3" />
                    View job posting
                  </a>
                  
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-9 px-3 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                      onClick={() => handleReject(prospect.id)}
                    >
                      <X className="h-4 w-4 mr-1.5" />
                      Skip
                    </Button>
                    <Button
                      size="sm"
                      className="h-9 px-4 bg-primary hover:bg-primary/90 shadow-md shadow-primary/20"
                      onClick={() => handleApproveClick(prospect)}
                    >
                      <Send className="h-4 w-4 mr-1.5" />
                      Contact
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Approve & Send Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Send Outreach to Founder</DialogTitle>
            <DialogDescription>
              Reach out to the founder about their finance hiring
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Prospect Context */}
            <div className="p-3 rounded-lg bg-muted/50 border border-border/50">
              <p className="text-sm font-medium">{selectedProspect?.title}</p>
              <p className="text-xs text-muted-foreground truncate">{selectedProspect?.url}</p>
            </div>

            {/* Founder Info */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-sm font-medium">Founder Name</label>
                <Input
                  placeholder="John Smith"
                  value={founderName}
                  onChange={(e) => {
                    setFounderName(e.target.value);
                    // Regenerate message with new name
                    const template = MESSAGE_TEMPLATES.find(t => t.id === selectedTemplate);
                    if (template && selectedProspect) {
                      const role = extractRoleFromTitle(selectedProspect.title);
                      setMessage(template.generate(e.target.value, role));
                    }
                  }}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Founder Email</label>
                <Input
                  type="email"
                  placeholder="founder@startup.com"
                  value={founderEmail}
                  onChange={(e) => setFounderEmail(e.target.value)}
                />
              </div>
            </div>

            {/* Template Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Message Template</label>
              <div className="flex gap-2">
                {MESSAGE_TEMPLATES.map((template) => (
                  <Badge
                    key={template.id}
                    variant={selectedTemplate === template.id ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary/20"
                    onClick={() => handleTemplateChange(template.id)}
                  >
                    {template.label}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Message Editor */}
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-[200px] font-mono text-sm"
              placeholder="Your personalized message to the founder..."
            />

            {/* Actions */}
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowApproveDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSendOutreach} disabled={isSending || !founderEmail}>
                {isSending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Send to Founder
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
