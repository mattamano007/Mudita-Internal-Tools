import { Users, TrendingUp, MessageSquare, Target } from "lucide-react";

interface StatsBarProps {
  totalProspects: number;
  filteredCount: number;
  messagesGenerated: number;
}

export const StatsBar = ({
  totalProspects,
  filteredCount,
  messagesGenerated,
}: StatsBarProps) => {
  const stats = [
    {
      label: "Total Prospects",
      value: totalProspects,
      icon: Users,
      color: "text-primary",
    },
    {
      label: "Matching Filters",
      value: filteredCount,
      icon: Target,
      color: "text-success",
    },
    {
      label: "Messages Generated",
      value: messagesGenerated,
      icon: MessageSquare,
      color: "text-warning",
    },
    {
      label: "Response Rate",
      value: "24%",
      icon: TrendingUp,
      color: "text-primary",
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="card-glow flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/20"
        >
          <div className={`flex h-10 w-10 items-center justify-center rounded-lg bg-muted ${stat.color}`}>
            <stat.icon className="h-5 w-5" />
          </div>
          <div>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </div>
        </div>
      ))}
    </div>
  );
};
