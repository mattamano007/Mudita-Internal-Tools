import { useState, useCallback } from "react";
import { Header } from "@/components/Header";
import { StatsCards } from "@/components/dashboard/StatsCards";
import { SearchBar } from "@/components/dashboard/SearchBar";
import { SavedSearches } from "@/components/SavedSearches";
import { TargetCompanyList } from "@/components/dashboard/TargetCompanyList";
import { PhantomBusterPanel } from "@/components/dashboard/PhantomBusterPanel";
import { TemplateSettings } from "@/components/dashboard/TemplateSettings";
import { OnboardingTooltip, OnboardingStep } from "@/components/OnboardingTooltip";
import { useOnboarding } from "@/hooks/useOnboarding";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LayoutDashboard, Settings } from "lucide-react";

const onboardingSteps: OnboardingStep[] = [
  {
    target: '[data-onboarding="search-bar"]',
    title: "Find Hiring Signals",
    description: "Search for job postings that signal pain points you can solve — e.g., 'CFO roles at fintech startups'.",
    position: "bottom",
  },
  {
    target: '[data-onboarding="lead-queue"]',
    title: "Warm Leads",
    description: "Each job posting = a company with a pain point. Reach out to founders with your solution.",
    position: "top",
  },
  {
    target: '[data-onboarding="settings-tab"]',
    title: "Settings",
    description: "Configure integrations and message templates for personalized outreach.",
    position: "bottom",
  },
];

const Index = () => {
  const [refreshKey, setRefreshKey] = useState(0);
  const [statsKey, setStatsKey] = useState(0);
  const [activeTab, setActiveTab] = useState("dashboard");
  const {
    showOnboarding,
    currentStep,
    nextStep,
    prevStep,
    completeOnboarding,
    resetOnboarding,
  } = useOnboarding();

  const handleRefresh = useCallback(() => {
    setRefreshKey(prev => prev + 1);
    setStatsKey(prev => prev + 1);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header alertCount={0} onResetOnboarding={resetOnboarding} />

      <main className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <section className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground tracking-tight">
            Hiring <span className="gradient-text">Signals</span>
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Find companies hiring for roles you can solve — then pitch your AI CFO.
          </p>
        </section>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="h-10 p-1 bg-muted/50 rounded-lg w-fit">
            <TabsTrigger 
              value="dashboard" 
              className="gap-2 px-4 data-[state=active]:bg-background data-[state=active]:shadow-sm"
              data-onboarding="dashboard-tab"
            >
              <LayoutDashboard className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger 
              value="settings" 
              className="gap-2 px-4 data-[state=active]:bg-background data-[state=active]:shadow-sm"
              data-onboarding="settings-tab"
            >
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6 animate-fade-in">
            {/* Stats */}
            <StatsCards key={statsKey} />

            {/* Search Bar */}
            <div data-onboarding="search-bar">
              <SearchBar onSearchComplete={handleRefresh} />
            </div>

            {/* Main Content Grid */}
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Saved Searches - 2/3 width */}
              <div className="lg:col-span-2" data-onboarding="lead-queue">
                <SavedSearches />
              </div>

              {/* Sidebar - 1/3 width */}
              <div className="space-y-6">
                <TargetCompanyList refreshKey={refreshKey} onCompaniesChange={handleRefresh} />
                <PhantomBusterPanel onScrapeComplete={handleRefresh} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6 animate-fade-in">
            <div className="grid gap-6 md:grid-cols-2">
              <TemplateSettings />
              <PhantomBusterPanel onScrapeComplete={handleRefresh} />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Onboarding */}
      <OnboardingTooltip
        steps={onboardingSteps}
        currentStep={currentStep}
        onNext={nextStep}
        onPrev={prevStep}
        onComplete={completeOnboarding}
        isVisible={showOnboarding}
      />
    </div>
  );
};

export default Index;
