-- Create table for target companies (the accounts we want to reach)
CREATE TABLE public.target_companies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  domain TEXT,
  industry TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for job changers (people who recently changed jobs at target companies)
CREATE TABLE public.job_changers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  linkedin_url TEXT UNIQUE,
  full_name TEXT NOT NULL,
  current_title TEXT,
  current_company TEXT,
  previous_title TEXT,
  previous_company TEXT,
  profile_image_url TEXT,
  headline TEXT,
  location TEXT,
  target_company_id UUID REFERENCES public.target_companies(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'skipped', 'sent')),
  outreach_message TEXT,
  sent_at TIMESTAMP WITH TIME ZONE,
  found_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for PhantomBuster agent configuration
CREATE TABLE public.phantombuster_config (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  agent_id TEXT NOT NULL,
  name TEXT NOT NULL,
  last_run_at TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.target_companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_changers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.phantombuster_config ENABLE ROW LEVEL SECURITY;

-- Create public access policies (single-user workflow)
CREATE POLICY "Public access for target_companies" ON public.target_companies FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public access for job_changers" ON public.job_changers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public access for phantombuster_config" ON public.phantombuster_config FOR ALL USING (true) WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX idx_job_changers_status ON public.job_changers(status);
CREATE INDEX idx_job_changers_current_company ON public.job_changers(current_company);
CREATE INDEX idx_target_companies_name ON public.target_companies(name);