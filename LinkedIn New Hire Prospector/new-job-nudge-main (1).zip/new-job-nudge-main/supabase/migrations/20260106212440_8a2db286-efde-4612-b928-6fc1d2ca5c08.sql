-- Add founder fields to prospects table
ALTER TABLE public.prospects 
ADD COLUMN founder_name TEXT,
ADD COLUMN founder_email TEXT,
ADD COLUMN founder_linkedin TEXT,
ADD COLUMN founder_lookup_status TEXT DEFAULT 'pending' CHECK (founder_lookup_status IN ('pending', 'found', 'not_found', 'manual'));