-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
NEW.updated_at = now();
RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create message_templates table for storing multiple templates
CREATE TABLE public.message_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  content TEXT NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;

-- Create public access policy (single-user workflow)
CREATE POLICY "Public access for message_templates" ON public.message_templates FOR ALL USING (true) WITH CHECK (true);

-- Create trigger for updated_at
CREATE TRIGGER update_message_templates_updated_at
BEFORE UPDATE ON public.message_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert a default template
INSERT INTO public.message_templates (name, content, is_default) VALUES 
(
  'Default Intro',
  'Hey {{first_name}}! Congrats on the new role as {{current_title}} at {{current_company}}. I help companies like yours find top finance talent. Would love to connect and share some insights that might be valuable as you settle in.',
  true
);

-- Add auto_approve column to track pre-approve setting
ALTER TABLE public.phantombuster_config ADD COLUMN IF NOT EXISTS auto_approve BOOLEAN NOT NULL DEFAULT false;