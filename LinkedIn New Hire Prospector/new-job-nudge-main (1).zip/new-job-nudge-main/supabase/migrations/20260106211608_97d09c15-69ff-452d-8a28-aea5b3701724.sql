-- Enable RLS on all tables
ALTER TABLE public.saved_searches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prospects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_settings ENABLE ROW LEVEL SECURITY;

-- Allow public access (single-user tool, no auth)
CREATE POLICY "Allow all access to saved_searches" ON public.saved_searches FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to prospects" ON public.prospects FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to email_settings" ON public.email_settings FOR ALL USING (true) WITH CHECK (true);