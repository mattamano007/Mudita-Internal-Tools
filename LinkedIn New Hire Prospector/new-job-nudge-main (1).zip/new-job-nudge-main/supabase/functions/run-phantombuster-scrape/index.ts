import { createClient } from "https://esm.sh/@supabase/supabase-js@2.89.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface PhantomBusterResult {
  name?: string;
  firstName?: string;
  lastName?: string;
  linkedInProfileUrl?: string;
  currentJobTitle?: string;
  currentCompanyName?: string;
  pastJobTitle?: string;
  pastCompanyName?: string;
  headline?: string;
  location?: string;
  profilePictureUrl?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { agentId } = await req.json();

    if (!agentId) {
      return new Response(
        JSON.stringify({ success: false, error: 'Agent ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const phantomBusterKey = Deno.env.get('PHANTOMBUSTER_API_KEY');
    if (!phantomBusterKey) {
      console.error('PHANTOMBUSTER_API_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'PhantomBuster API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Launching PhantomBuster agent:', agentId);

    // Launch the agent
    const launchResponse = await fetch(`https://api.phantombuster.com/api/v2/agents/launch`, {
      method: 'POST',
      headers: {
        'X-Phantombuster-Key': phantomBusterKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id: agentId }),
    });

    if (!launchResponse.ok) {
      const errorText = await launchResponse.text();
      console.error('PhantomBuster launch error:', errorText);
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to launch PhantomBuster agent' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Wait for agent to complete (poll every 10 seconds, max 5 minutes)
    let containerStatus = 'running';
    let attempts = 0;
    const maxAttempts = 30;

    while (containerStatus === 'running' && attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      
      const statusResponse = await fetch(`https://api.phantombuster.com/api/v2/agents/fetch?id=${agentId}`, {
        headers: {
          'X-Phantombuster-Key': phantomBusterKey,
        },
      });

      if (statusResponse.ok) {
        const statusData = await statusResponse.json();
        containerStatus = statusData.containerStatus || 'not running';
        console.log('Agent status:', containerStatus, 'attempt:', attempts + 1);
      }

      attempts++;
    }

    if (containerStatus === 'running') {
      return new Response(
        JSON.stringify({ success: false, error: 'Agent timed out' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch the results
    const outputResponse = await fetch(`https://api.phantombuster.com/api/v2/agents/fetch-output?id=${agentId}`, {
      headers: {
        'X-Phantombuster-Key': phantomBusterKey,
      },
    });

    if (!outputResponse.ok) {
      console.error('Failed to fetch agent output');
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to fetch agent results' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const outputData = await outputResponse.json();
    let profiles: PhantomBusterResult[] = [];

    // Try to parse the result
    if (outputData.resultObject) {
      try {
        profiles = typeof outputData.resultObject === 'string' 
          ? JSON.parse(outputData.resultObject) 
          : outputData.resultObject;
      } catch {
        console.log('Could not parse resultObject, trying output');
      }
    }

    if (outputData.output && Array.isArray(outputData.output)) {
      profiles = outputData.output;
    }

    if (!Array.isArray(profiles) || profiles.length === 0) {
      console.log('No profiles found in output');
      return new Response(
        JSON.stringify({ success: true, newProfiles: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Found', profiles.length, 'profiles');

    // Store in database
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const jobChangers = profiles.map((profile: PhantomBusterResult) => ({
      linkedin_url: profile.linkedInProfileUrl || null,
      full_name: profile.name || `${profile.firstName || ''} ${profile.lastName || ''}`.trim() || 'Unknown',
      current_title: profile.currentJobTitle || null,
      current_company: profile.currentCompanyName || null,
      previous_title: profile.pastJobTitle || null,
      previous_company: profile.pastCompanyName || null,
      profile_image_url: profile.profilePictureUrl || null,
      headline: profile.headline || null,
      location: profile.location || null,
      status: 'pending',
    }));

    const { data: insertedData, error: insertError } = await supabase
      .from('job_changers')
      .upsert(jobChangers, { 
        onConflict: 'linkedin_url',
        ignoreDuplicates: true 
      })
      .select();

    if (insertError) {
      console.error('Error inserting job changers:', insertError);
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to save profiles' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Update last run timestamp
    await supabase
      .from('phantombuster_config')
      .update({ last_run_at: new Date().toISOString() })
      .eq('agent_id', agentId);

    return new Response(
      JSON.stringify({ success: true, newProfiles: insertedData?.length || 0 }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in run-phantombuster-scrape:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
