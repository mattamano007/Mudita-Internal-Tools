const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fullName, currentTitle, currentCompany, previousTitle, previousCompany, template } = await req.json();

    if (!fullName || !currentTitle || !currentCompany) {
      return new Response(
        JSON.stringify({ success: false, error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const lovableApiKey = Deno.env.get('LOVABLE_API_KEY');
    if (!lovableApiKey) {
      console.error('LOVABLE_API_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'AI service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const firstName = fullName.split(' ')[0];
    
    const systemPrompt = `You are an expert at writing warm, personalized LinkedIn outreach messages. Your messages should:
- Be congratulatory about their new role without being over-the-top
- Sound human and conversational, not like a template
- Be concise - under 280 characters for LinkedIn connection requests
Never mention that you're an AI. Write as if you're a real person.`;

    let userPrompt: string;
    
    if (template) {
      // Use template with variable substitution
      userPrompt = `Use this template as inspiration and personalize it for this person. Fill in the variables and make it sound natural:

Template: ${template}

Person details:
- Name: ${fullName} (first name: ${firstName})
- New role: ${currentTitle} at ${currentCompany}
${previousTitle && previousCompany ? `- Previous role: ${previousTitle} at ${previousCompany}` : ''}

Keep it under 280 characters. Output only the final message, no explanations.`;
    } else {
      userPrompt = `Write a short LinkedIn connection request for:
- Name: ${fullName} (use "${firstName}")
- New role: ${currentTitle} at ${currentCompany}
${previousTitle && previousCompany ? `- Previous: ${previousTitle} at ${previousCompany}` : ''}

Keep under 280 characters.`;
    }

    console.log('Generating message for:', fullName);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-3-flash-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        max_tokens: 200,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ success: false, error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ success: false, error: 'AI credits depleted. Please add credits to continue.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      return new Response(
        JSON.stringify({ success: false, error: 'AI service error' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();
    const message = data.choices?.[0]?.message?.content?.trim();

    if (!message) {
      return new Response(
        JSON.stringify({ success: false, error: 'No message generated' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Generated message:', message);

    return new Response(
      JSON.stringify({ success: true, message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in generate-job-changer-message:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
