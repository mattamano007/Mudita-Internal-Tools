import { createClient } from "https://esm.sh/@supabase/supabase-js@2.89.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Fuzzy match helper - handles variations like Inc, LLC, Corp, etc.
function normalizeCompanyName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[,.]$/g, '')
    .replace(/\b(inc|incorporated|llc|ltd|limited|corp|corporation|co|company|group|holdings|technologies|tech|software|labs|solutions)\b/gi, '')
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

function fuzzyMatch(companyA: string, companyB: string): boolean {
  const normalizedA = normalizeCompanyName(companyA);
  const normalizedB = normalizeCompanyName(companyB);
  
  // Exact match after normalization
  if (normalizedA === normalizedB) return true;
  
  // One contains the other
  if (normalizedA.includes(normalizedB) || normalizedB.includes(normalizedA)) return true;
  
  // Levenshtein distance for close matches (threshold based on length)
  const distance = levenshteinDistance(normalizedA, normalizedB);
  const maxLength = Math.max(normalizedA.length, normalizedB.length);
  const threshold = Math.floor(maxLength * 0.2); // 20% tolerance
  
  return distance <= threshold;
}

function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];
  
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  
  return matrix[b.length][a.length];
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch all target companies
    const { data: targetCompanies, error: targetError } = await supabase
      .from('target_companies')
      .select('*');

    if (targetError) {
      console.error('Error fetching target companies:', targetError);
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to fetch target companies' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!targetCompanies || targetCompanies.length === 0) {
      return new Response(
        JSON.stringify({ success: true, matched: 0, message: 'No target companies configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch all unmatched job changers (no target_company_id yet)
    const { data: jobChangers, error: jobChangersError } = await supabase
      .from('job_changers')
      .select('*')
      .is('target_company_id', null);

    if (jobChangersError) {
      console.error('Error fetching job changers:', jobChangersError);
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to fetch job changers' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!jobChangers || jobChangers.length === 0) {
      return new Response(
        JSON.stringify({ success: true, matched: 0, message: 'No unmatched profiles' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Matching ${jobChangers.length} profiles against ${targetCompanies.length} target companies`);

    let matchedCount = 0;

    for (const changer of jobChangers) {
      if (!changer.current_company) continue;

      for (const target of targetCompanies) {
        if (fuzzyMatch(changer.current_company, target.name)) {
          const { error: updateError } = await supabase
            .from('job_changers')
            .update({ target_company_id: target.id })
            .eq('id', changer.id);

          if (!updateError) {
            matchedCount++;
            console.log(`Matched: ${changer.full_name} at ${changer.current_company} -> ${target.name}`);
          }
          break; // Found a match, move to next profile
        }
      }
    }

    console.log(`Matched ${matchedCount} profiles`);

    return new Response(
      JSON.stringify({ success: true, matched: matchedCount }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in match-job-changers:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
