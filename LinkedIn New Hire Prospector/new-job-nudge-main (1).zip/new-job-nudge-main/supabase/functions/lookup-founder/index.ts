import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Generate likely email patterns from name and domain
function generateEmailGuesses(firstName: string, lastName: string, domain: string): string[] {
  const f = firstName.toLowerCase();
  const l = lastName.toLowerCase();
  return [
    `${f}@${domain}`,
    `${f}.${l}@${domain}`,
    `${f}${l}@${domain}`,
    `${f[0]}${l}@${domain}`,
    `${f}_${l}@${domain}`,
    `${f}${l[0]}@${domain}`,
  ];
}

// Extract domain from company name (best guess)
function guessCompanyDomain(companyName: string): string {
  return companyName
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .substring(0, 20) + '.com';
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { prospectId, companyName } = await req.json();

    if (!prospectId || !companyName) {
      return new Response(
        JSON.stringify({ success: false, error: 'prospectId and companyName required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const firecrawlKey = Deno.env.get('FIRECRAWL_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    if (!firecrawlKey) {
      return new Response(
        JSON.stringify({ success: false, error: 'Firecrawl not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log(`Looking up founder for: ${companyName}`);

    // Search for founder info - multiple strategies
    const searchQueries = [
      `"${companyName}" founder CEO linkedin`,
      `"${companyName}" startup founder email`,
      `site:linkedin.com "${companyName}" founder CEO`,
    ];
    
    let founderName: string | null = null;
    let founderLinkedin: string | null = null;
    let founderEmail: string | null = null;
    let companyDomain: string | null = null;

    for (const searchQuery of searchQueries) {
      if (founderName && (founderEmail || founderLinkedin)) break;
      
      const response = await fetch('https://api.firecrawl.dev/v1/search', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${firecrawlKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: searchQuery,
          limit: 5,
          scrapeOptions: { formats: ['markdown'] },
        }),
      });

      const data = await response.json();
      if (!response.ok) continue;

      const results = data.data || [];
      
      for (const result of results) {
        const content = (result.markdown || result.description || result.title || '').toLowerCase();
        const originalContent = result.markdown || result.description || result.title || '';
        const url = result.url || '';
        
        // Try to extract company domain from any URL
        if (!companyDomain) {
          try {
            const urlObj = new URL(url);
            const hostname = urlObj.hostname.replace('www.', '');
            const jobBoards = ['linkedin', 'google', 'facebook', 'twitter', 'crunchbase', 'indeed'];
            if (!jobBoards.some(jb => hostname.includes(jb))) {
              companyDomain = hostname;
            }
          } catch {}
        }
        
        // Check if it's a LinkedIn profile
        if (url.includes('linkedin.com/in/') && !founderLinkedin) {
          founderLinkedin = url;
          
          // Extract name from LinkedIn title
          if (result.title) {
            const titleMatch = result.title.match(/^([^-|–—]+)/);
            if (titleMatch && !founderName) {
              const potentialName = titleMatch[1].trim();
              // Check it's a real name (has space, reasonable length)
              if (potentialName.includes(' ') && potentialName.length < 50) {
                founderName = potentialName;
              }
            }
          }
        }
        
        // Look for founder mentions in content with name extraction
        if (!founderName) {
          const founderPatterns = [
            // "CEO: John Smith" or "Founder, Jane Doe"
            /(?:founder|ceo|co-founder|chief executive)[,:\s]+([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)/g,
            // "John Smith, CEO" or "Jane Doe - Founder"
            /([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)[,\s\-–—]+(?:founder|ceo|co-founder|chief executive)/g,
          ];
          
          for (const pattern of founderPatterns) {
            const matches = originalContent.matchAll(pattern);
            for (const match of matches) {
              const potentialName = match[1].trim();
              // Validate it looks like a person's name
              const nameParts = potentialName.split(/\s+/);
              if (
                nameParts.length >= 2 && 
                nameParts.length <= 4 &&
                potentialName.length > 5 && 
                potentialName.length < 40 &&
                !potentialName.toLowerCase().includes('founder') &&
                !potentialName.toLowerCase().includes('company') &&
                !potentialName.toLowerCase().includes('inc') &&
                !/^\d/.test(potentialName) // Doesn't start with number
              ) {
                founderName = potentialName;
                break;
              }
            }
            if (founderName) break;
          }
        }
        
        // Look for email patterns
        if (!founderEmail) {
          const emailMatch = originalContent.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
          if (emailMatch) {
            const email = emailMatch[1];
            // Skip generic emails
            const genericPatterns = ['info@', 'contact@', 'hello@', 'support@', 'hr@', 'jobs@', 'careers@'];
            if (!genericPatterns.some(p => email.toLowerCase().startsWith(p))) {
              founderEmail = email;
            }
          }
        }
        
        if (founderName && founderEmail) break;
      }
    }

    // If we have founder name but no email, generate likely patterns
    let suggestedEmails: string[] = [];
    if (founderName && !founderEmail) {
      const nameParts = founderName.trim().split(' ');
      if (nameParts.length >= 2) {
        const firstName = nameParts[0];
        const lastName = nameParts[nameParts.length - 1];
        const domain = companyDomain || guessCompanyDomain(companyName);
        suggestedEmails = generateEmailGuesses(firstName, lastName, domain);
        // Use first pattern as best guess
        founderEmail = suggestedEmails[0];
      }
    }

    // Update prospect with founder info
    const updateData: any = {
      founder_lookup_status: founderName ? 'found' : 'not_found',
    };
    
    if (founderName) updateData.founder_name = founderName;
    if (founderLinkedin) updateData.founder_linkedin = founderLinkedin;
    if (founderEmail) updateData.founder_email = founderEmail;

    await supabase
      .from('prospects')
      .update(updateData)
      .eq('id', prospectId);

    console.log(`Founder lookup complete:`, { founderName, founderEmail, founderLinkedin });

    return new Response(
      JSON.stringify({ 
        success: true, 
        founder: {
          name: founderName,
          email: founderEmail,
          linkedin: founderLinkedin,
          suggestedEmails: suggestedEmails.length > 0 ? suggestedEmails : undefined,
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in founder lookup:', error);
    const errorMessage = error instanceof Error ? error.message : 'Lookup failed';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
