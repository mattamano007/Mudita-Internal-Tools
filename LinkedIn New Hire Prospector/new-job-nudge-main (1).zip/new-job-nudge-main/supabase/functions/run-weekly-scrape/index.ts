import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Extract company name from job title/description
function extractCompanyName(title: string, description: string, url: string): string | null {
  // Pattern 1: "Role at Company"
  let match = title.match(/(?:at|@)\s+([A-Z][A-Za-z0-9\s&.]+?)(?:\s*[-–—|]|$)/i);
  if (match) return match[1].trim();
  
  // Pattern 2: "Company - Role" or "Company | Role"
  match = title.match(/^([A-Z][A-Za-z0-9\s&.]+?)\s*[-–—|]\s*(?:.*(?:hiring|job|career|position|role|analyst|manager|director|vp|cfo|head))/i);
  if (match) return match[1].trim();
  
  // Pattern 3: From URL - extract domain name
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.replace('www.', '');
    // Skip job boards
    const jobBoards = ['indeed', 'linkedin', 'glassdoor', 'ziprecruiter', 'monster', 'lever', 'greenhouse', 'workday'];
    if (!jobBoards.some(jb => hostname.includes(jb))) {
      const domain = hostname.split('.')[0];
      if (domain.length > 2) {
        return domain.charAt(0).toUpperCase() + domain.slice(1);
      }
    }
  } catch {}
  
  // Pattern 4: "Careers at Company" from title
  match = title.match(/careers?\s*(?:at|:)\s*([A-Z][A-Za-z0-9\s&.]+)/i);
  if (match) return match[1].trim();
  
  return null;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const firecrawlKey = Deno.env.get('FIRECRAWL_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    if (!firecrawlKey) {
      return new Response(
        JSON.stringify({ success: false, error: 'Firecrawl not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get all active saved searches
    const { data: searches, error: searchError } = await supabase
      .from('saved_searches')
      .select('*')
      .eq('is_active', true);

    if (searchError) {
      console.error('Error fetching searches:', searchError);
      return new Response(
        JSON.stringify({ success: false, error: 'Failed to fetch saved searches' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!searches || searches.length === 0) {
      return new Response(
        JSON.stringify({ success: true, message: 'No active searches to run', results: [] }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const allResults = [];

    for (const search of searches) {
      console.log(`Running search: ${search.name}`);

      // Search using Firecrawl - use site: to target career pages
      const response = await fetch('https://api.firecrawl.dev/v1/search', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${firecrawlKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: search.query,
          limit: 15,
          tbs: 'qdr:w', // Last week
          scrapeOptions: { formats: ['markdown'] },
        }),
      });

      const data = await response.json();

      if (response.ok && data.data) {
        // Get existing URLs to avoid duplicates
        const { data: existingProspects } = await supabase
          .from('prospects')
          .select('url')
          .eq('search_id', search.id);

        const existingUrls = new Set(existingProspects?.map(p => p.url) || []);

          // Filter out duplicates and extract company names
        const newProspects = data.data
          .filter((result: any) => {
            if (existingUrls.has(result.url)) return false;
            
            const url = (result.url || '').toLowerCase();
            const title = (result.title || '').toLowerCase();
            
            // Aggressively filter out job board aggregator pages
            const jobBoardDomains = [
              'indeed.com', 'glassdoor.com', 'ziprecruiter.com', 'monster.com',
              'careerbuilder.com', 'simplyhired.com', 'dice.com', 'flexjobs.com',
              'wellfound.com/jobs', 'builtin.com/jobs', 'otta.com/jobs'
            ];
            if (jobBoardDomains.some(domain => url.includes(domain))) return false;
            
            // Filter out aggregator titles
            const aggregatorPatterns = [
              'best startup', 'top startup', 'top 10', 'best 10',
              'remote jobs', 'jobs in', 'openings from',
              'browse', 'job openings', 'career opportunities', 'jobs near',
              'job listings', 'search jobs', 'find jobs', 'explore jobs',
              'job board', 'job search', 'apply now', 'see all jobs'
            ];
            if (aggregatorPatterns.some(p => title.includes(p))) return false;
            
            return true;
          })
          .map((result: any) => {
            const companyName = extractCompanyName(
              result.title || '', 
              result.description || '',
              result.url || ''
            );
            
            return {
              search_id: search.id,
              title: result.title || 'Untitled',
              description: result.description || '',
              url: result.url,
              company_name: companyName,
              status: 'pending',
              founder_lookup_status: 'pending',
            };
          });

        if (newProspects.length > 0) {
          const { error: insertError } = await supabase
            .from('prospects')
            .insert(newProspects);

          if (insertError) {
            console.error('Error inserting prospects:', insertError);
          } else {
            allResults.push(...newProspects);
          }
        }
      }

      // Update last_run_at
      await supabase
        .from('saved_searches')
        .update({ last_run_at: new Date().toISOString() })
        .eq('id', search.id);
    }

    console.log(`Found ${allResults.length} new prospects`);

    return new Response(
      JSON.stringify({ success: true, newProspects: allResults.length, results: allResults }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in weekly scrape:', error);
    const errorMessage = error instanceof Error ? error.message : 'Scrape failed';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
