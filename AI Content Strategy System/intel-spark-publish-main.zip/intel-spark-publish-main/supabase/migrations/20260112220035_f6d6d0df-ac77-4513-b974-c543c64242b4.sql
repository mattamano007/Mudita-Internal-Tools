-- Create articles table to store fetched news
CREATE TABLE public.articles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  url TEXT NOT NULL UNIQUE,
  source_name TEXT,
  source_type TEXT NOT NULL DEFAULT 'rss', -- 'rss' or 'newsapi'
  published_at TIMESTAMP WITH TIME ZONE,
  fetched_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  relevance_score INTEGER, -- 1-10 from AI
  processed BOOLEAN NOT NULL DEFAULT false,
  archived BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create generated_content table to store AI-generated posts
CREATE TABLE public.generated_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  article_id UUID REFERENCES public.articles(id) ON DELETE CASCADE,
  tweet_content TEXT,
  linkedin_content TEXT,
  quality_score INTEGER, -- 1-10 from AI
  score_reasoning TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'published'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  published_at TIMESTAMP WITH TIME ZONE
);

-- Create news_sources table to store configured RSS feeds
CREATE TABLE public.news_sources (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  url TEXT NOT NULL UNIQUE,
  source_type TEXT NOT NULL DEFAULT 'rss', -- 'rss', 'newsapi_query'
  is_active BOOLEAN NOT NULL DEFAULT true,
  last_fetched_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generated_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.news_sources ENABLE ROW LEVEL SECURITY;

-- Public access policies (no auth for now - single user app)
CREATE POLICY "Allow public read on articles" ON public.articles FOR SELECT USING (true);
CREATE POLICY "Allow public insert on articles" ON public.articles FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on articles" ON public.articles FOR UPDATE USING (true);

CREATE POLICY "Allow public read on generated_content" ON public.generated_content FOR SELECT USING (true);
CREATE POLICY "Allow public insert on generated_content" ON public.generated_content FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on generated_content" ON public.generated_content FOR UPDATE USING (true);
CREATE POLICY "Allow public delete on generated_content" ON public.generated_content FOR DELETE USING (true);

CREATE POLICY "Allow public read on news_sources" ON public.news_sources FOR SELECT USING (true);
CREATE POLICY "Allow public insert on news_sources" ON public.news_sources FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on news_sources" ON public.news_sources FOR UPDATE USING (true);
CREATE POLICY "Allow public delete on news_sources" ON public.news_sources FOR DELETE USING (true);

-- Create index for faster lookups
CREATE INDEX idx_articles_url ON public.articles(url);
CREATE INDEX idx_articles_processed ON public.articles(processed);
CREATE INDEX idx_generated_content_status ON public.generated_content(status);