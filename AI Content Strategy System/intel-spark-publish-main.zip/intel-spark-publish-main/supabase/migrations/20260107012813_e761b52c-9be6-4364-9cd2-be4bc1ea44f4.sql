-- Create table to store social posting configurations
CREATE TABLE public.posting_configs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  platform TEXT NOT NULL CHECK (platform IN ('twitter', 'linkedin', 'zapier')),
  webhook_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table to store posted content history
CREATE TABLE public.posted_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  content TEXT NOT NULL,
  platform TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'posted', 'failed')),
  posted_at TIMESTAMP WITH TIME ZONE,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS (but allow public access for this demo - no auth required)
ALTER TABLE public.posting_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posted_content ENABLE ROW LEVEL SECURITY;

-- Public read/write policies (no auth for simplicity)
CREATE POLICY "Allow public read on posting_configs" ON public.posting_configs FOR SELECT USING (true);
CREATE POLICY "Allow public insert on posting_configs" ON public.posting_configs FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on posting_configs" ON public.posting_configs FOR UPDATE USING (true);
CREATE POLICY "Allow public delete on posting_configs" ON public.posting_configs FOR DELETE USING (true);

CREATE POLICY "Allow public read on posted_content" ON public.posted_content FOR SELECT USING (true);
CREATE POLICY "Allow public insert on posted_content" ON public.posted_content FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update on posted_content" ON public.posted_content FOR UPDATE USING (true);