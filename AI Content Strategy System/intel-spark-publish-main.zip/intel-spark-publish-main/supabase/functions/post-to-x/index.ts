import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

function generateNonce(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let nonce = ''
  for (let i = 0; i < 32; i++) {
    nonce += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return nonce
}

// RFC 3986 percent encoding - must match Twitter's requirements exactly
function percentEncode(str: string): string {
  return encodeURIComponent(str)
    .replace(/!/g, '%21')
    .replace(/\*/g, '%2A')
    .replace(/'/g, '%27')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29')
}

async function generateOAuthSignature(
  method: string,
  url: string,
  oauthParams: Record<string, string>,
  consumerSecret: string,
  tokenSecret: string
): Promise<string> {
  // Sort parameters alphabetically and encode
  const sortedParams = Object.keys(oauthParams)
    .sort()
    .map(key => `${percentEncode(key)}=${percentEncode(oauthParams[key])}`)
    .join('&')
  
  // Create signature base string: METHOD&URL&PARAMS
  const signatureBaseString = `${method.toUpperCase()}&${percentEncode(url)}&${percentEncode(sortedParams)}`
  
  console.log('Signature base string:', signatureBaseString)
  
  // Create signing key: consumer_secret&token_secret
  const signingKey = `${percentEncode(consumerSecret)}&${percentEncode(tokenSecret)}`
  
  // Generate HMAC-SHA1 signature
  const encoder = new TextEncoder()
  const keyData = encoder.encode(signingKey)
  const messageData = encoder.encode(signatureBaseString)
  
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-1' },
    false,
    ['sign']
  )
  
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData)
  const base64Signature = btoa(String.fromCharCode(...new Uint8Array(signature)))
  
  console.log('Generated signature:', base64Signature)
  
  return base64Signature
}

async function postToX(content: string): Promise<{ success: boolean; error?: string; tweetId?: string }> {
  const apiKey = Deno.env.get('X_API_KEY')
  const apiSecret = Deno.env.get('X_API_SECRET')
  const accessToken = Deno.env.get('X_ACCESS_TOKEN')
  const accessTokenSecret = Deno.env.get('X_ACCESS_TOKEN_SECRET')

  console.log('Checking credentials...')
  console.log('API Key exists:', !!apiKey, 'length:', apiKey?.length)
  console.log('API Secret exists:', !!apiSecret, 'length:', apiSecret?.length)
  console.log('Access Token exists:', !!accessToken, 'length:', accessToken?.length)
  console.log('Access Token Secret exists:', !!accessTokenSecret, 'length:', accessTokenSecret?.length)

  if (!apiKey || !apiSecret || !accessToken || !accessTokenSecret) {
    return { success: false, error: 'Missing X API credentials' }
  }

  // Trim any whitespace from credentials
  const cleanApiKey = apiKey.trim()
  const cleanApiSecret = apiSecret.trim()
  const cleanAccessToken = accessToken.trim()
  const cleanAccessTokenSecret = accessTokenSecret.trim()

  const url = 'https://api.twitter.com/2/tweets'
  const method = 'POST'
  const timestamp = Math.floor(Date.now() / 1000).toString()
  const nonce = generateNonce()

  console.log('OAuth timestamp:', timestamp)
  console.log('OAuth nonce:', nonce)

  // OAuth 1.0a parameters - for API v2 with JSON body, do NOT include body params
  const oauthParams: Record<string, string> = {
    oauth_consumer_key: cleanApiKey,
    oauth_nonce: nonce,
    oauth_signature_method: 'HMAC-SHA1',
    oauth_timestamp: timestamp,
    oauth_token: cleanAccessToken,
    oauth_version: '1.0',
  }

  // Generate signature
  const signature = await generateOAuthSignature(
    method, 
    url, 
    oauthParams, 
    cleanApiSecret, 
    cleanAccessTokenSecret
  )

  // Build Authorization header with signature
  const authHeaderParams: Record<string, string> = {
    ...oauthParams,
    oauth_signature: signature,
  }

  const authHeader = 'OAuth ' + Object.keys(authHeaderParams)
    .sort()
    .map(key => `${percentEncode(key)}="${percentEncode(authHeaderParams[key])}"`)
    .join(', ')

  console.log('Authorization header:', authHeader.substring(0, 100) + '...')
  console.log('Request body:', JSON.stringify({ text: content }))

  try {
    const response = await fetch(url, {
      method,
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text: content }),
    })

    const responseText = await response.text()
    console.log('X API response status:', response.status)
    console.log('X API response headers:', JSON.stringify(Object.fromEntries(response.headers.entries())))
    console.log('X API response body:', responseText)

    let data
    try {
      data = JSON.parse(responseText)
    } catch {
      return { success: false, error: `Invalid response: ${responseText}` }
    }

    if (!response.ok) {
      console.error('X API error:', data)
      const errorDetail = data.detail || data.errors?.[0]?.message || data.title || `X API returned ${response.status}`
      return { success: false, error: errorDetail }
    }

    return { success: true, tweetId: data.data?.id }
  } catch (error) {
    console.error('X API request failed:', error)
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' }
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { content } = await req.json()

    if (!content) {
      return new Response(
        JSON.stringify({ error: 'Missing content' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    const result = await postToX(content)

    // Log the post attempt
    await supabase.from('posted_content').insert({
      content,
      platform: 'x',
      status: result.success ? 'posted' : 'failed',
      posted_at: result.success ? new Date().toISOString() : null,
      error_message: result.error || null
    })

    if (!result.success) {
      return new Response(
        JSON.stringify({ error: result.error }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Posted to X',
        tweetId: result.tweetId,
        tweetUrl: `https://x.com/i/web/status/${result.tweetId}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    const message = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})