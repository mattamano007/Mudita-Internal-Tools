import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface Article {
  id: string
  title: string
  description: string | null
  url: string
  source_name: string
}

interface GeneratedContent {
  tweet_content: string
  linkedin_content: string
  quality_score: number
  score_reasoning: string
  is_relevant: boolean
}

async function generateContentForArticle(article: Article, topic: string, apiKey: string): Promise<GeneratedContent | null> {
  const systemPrompt = `You are a social media content strategist. Your job is to analyze news articles and create engaging social media posts.

You will receive an article and a topic/niche context. You need to:
1. Determine if the article is relevant to the topic (if not, mark as irrelevant)
2. If relevant, write a compelling tweet (max 280 chars) and LinkedIn post
3. Score the content quality from 1-10 based on:
   - Relevance to the topic (3 points)
   - Engagement potential (3 points)  
   - Uniqueness/novelty of the news (2 points)
   - Actionable insights (2 points)

Guidelines for tweets:
- Start with a hook or key insight
- Include relevant hashtags (1-2 max)
- Keep under 250 chars to leave room for links
- Use clear, direct language
- No emojis overload

Guidelines for LinkedIn:
- Professional tone
- 2-3 sentences max
- Include a question or call to action
- Focus on business implications`

  const userPrompt = `Topic/Niche: ${topic || 'general tech and business news'}

Article Title: ${article.title}
Article Description: ${article.description || 'No description available'}
Source: ${article.source_name}
URL: ${article.url}

Analyze this article and generate social media content. Respond with a JSON object containing:
{
  "is_relevant": boolean,
  "tweet_content": "your tweet here",
  "linkedin_content": "your LinkedIn post here",
  "quality_score": number (1-10),
  "score_reasoning": "brief explanation of the score"
}`

  try {
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-3-flash-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      if (response.status === 429) {
        console.error('Rate limited by AI gateway')
        return null
      }
      if (response.status === 402) {
        console.error('AI gateway payment required')
        return null
      }
      const errorText = await response.text()
      console.error('AI gateway error:', response.status, errorText)
      return null
    }

    const data = await response.json()
    const content = data.choices?.[0]?.message?.content

    if (!content) {
      console.error('No content in AI response')
      return null
    }

    // Parse JSON from response (handle markdown code blocks)
    let jsonStr = content
    if (content.includes('```json')) {
      jsonStr = content.split('```json')[1].split('```')[0].trim()
    } else if (content.includes('```')) {
      jsonStr = content.split('```')[1].split('```')[0].trim()
    }

    const parsed = JSON.parse(jsonStr)
    
    return {
      is_relevant: parsed.is_relevant ?? true,
      tweet_content: parsed.tweet_content || '',
      linkedin_content: parsed.linkedin_content || '',
      quality_score: Math.min(10, Math.max(1, parseInt(parsed.quality_score) || 5)),
      score_reasoning: parsed.score_reasoning || '',
    }
  } catch (error) {
    console.error('Error generating content:', error)
    return null
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )
    
    const lovableApiKey = Deno.env.get('LOVABLE_API_KEY')
    if (!lovableApiKey) {
      return new Response(
        JSON.stringify({ error: 'LOVABLE_API_KEY not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get request body for topic context
    let body: { topic?: string, limit?: number, article_id?: string } = {}
    try {
      body = await req.json()
    } catch {
      // No body provided
    }

    const topic = body.topic || 'technology, AI, startups, and business news'
    const limit = body.limit || 10

    // Get unprocessed articles
    let query = supabase
      .from('articles')
      .select('*')
      .eq('processed', false)
      .eq('archived', false)
      .order('fetched_at', { ascending: false })

    if (body.article_id) {
      query = supabase
        .from('articles')
        .select('*')
        .eq('id', body.article_id)
    } else {
      query = query.limit(limit)
    }

    const { data: articles, error: articlesError } = await query

    if (articlesError) {
      console.error('Error fetching articles:', articlesError)
      return new Response(
        JSON.stringify({ error: 'Failed to fetch articles' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    if (!articles || articles.length === 0) {
      return new Response(
        JSON.stringify({ success: true, message: 'No unprocessed articles found', processed: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log(`Processing ${articles.length} articles...`)

    const results = {
      processed: 0,
      auto_publish: 0,
      review_queue: 0,
      archived: 0,
      failed: 0,
    }

    for (const article of articles) {
      console.log(`Processing: ${article.title.substring(0, 50)}...`)
      
      const generated = await generateContentForArticle(article, topic, lovableApiKey)
      
      if (!generated) {
        results.failed++
        continue
      }

      // Mark as processed
      await supabase
        .from('articles')
        .update({ 
          processed: true,
          relevance_score: generated.quality_score,
          archived: !generated.is_relevant || generated.quality_score < 5,
        })
        .eq('id', article.id)

      // Skip if not relevant or very low quality
      if (!generated.is_relevant || generated.quality_score < 5) {
        results.archived++
        results.processed++
        continue
      }

      // Determine status based on score
      let status: 'pending' | 'approved'
      if (generated.quality_score >= 8) {
        status = 'approved' // Auto-publish queue
        results.auto_publish++
      } else {
        status = 'pending' // Review queue
        results.review_queue++
      }

      // Insert generated content
      const { error: insertError } = await supabase
        .from('generated_content')
        .insert({
          article_id: article.id,
          tweet_content: generated.tweet_content,
          linkedin_content: generated.linkedin_content,
          quality_score: generated.quality_score,
          score_reasoning: generated.score_reasoning,
          status,
        })

      if (insertError) {
        console.error('Error inserting generated content:', insertError)
        results.failed++
      } else {
        results.processed++
      }

      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 500))
    }

    console.log('Processing complete:', results)

    return new Response(
      JSON.stringify({
        success: true,
        ...results,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error in generate-content:', error)
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
