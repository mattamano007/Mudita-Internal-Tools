import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface Article {
  title: string
  description: string | null
  url: string
  source_name: string
  source_type: 'rss' | 'newsapi'
  published_at: string | null
}

// Parse RSS feed XML
function parseRSS(xml: string, sourceName: string): Article[] {
  const articles: Article[] = []
  
  // Simple regex-based RSS parsing for items
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi
  const titleRegex = /<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?<\/title>/i
  const linkRegex = /<link>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?<\/link>/i
  const descRegex = /<description>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/description>/i
  const pubDateRegex = /<pubDate>(.*?)<\/pubDate>/i
  
  let match
  while ((match = itemRegex.exec(xml)) !== null) {
    const item = match[1]
    
    const titleMatch = titleRegex.exec(item)
    const linkMatch = linkRegex.exec(item)
    const descMatch = descRegex.exec(item)
    const pubDateMatch = pubDateRegex.exec(item)
    
    if (titleMatch && linkMatch) {
      const title = titleMatch[1].trim()
      const url = linkMatch[1].trim()
      const description = descMatch ? descMatch[1].trim().replace(/<[^>]*>/g, '').substring(0, 500) : null
      const pubDate = pubDateMatch ? pubDateMatch[1].trim() : null
      
      // Skip if URL is empty or just whitespace
      if (!url || url.length < 10) continue
      
      articles.push({
        title,
        description,
        url,
        source_name: sourceName,
        source_type: 'rss',
        published_at: pubDate ? new Date(pubDate).toISOString() : null,
      })
    }
  }
  
  return articles
}

// Fetch RSS feed
async function fetchRSSFeed(feedUrl: string, sourceName: string): Promise<Article[]> {
  try {
    console.log(`Fetching RSS: ${feedUrl}`)
    const response = await fetch(feedUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; NewsBot/1.0)',
      },
    })
    
    if (!response.ok) {
      console.error(`RSS fetch failed for ${feedUrl}: ${response.status}`)
      return []
    }
    
    const xml = await response.text()
    return parseRSS(xml, sourceName)
  } catch (error) {
    console.error(`Error fetching RSS ${feedUrl}:`, error)
    return []
  }
}

// Fetch from NewsAPI
async function fetchNewsAPI(query: string, apiKey: string): Promise<Article[]> {
  try {
    console.log(`Fetching NewsAPI for query: ${query}`)
    
    const url = new URL('https://newsapi.org/v2/everything')
    url.searchParams.set('q', query)
    url.searchParams.set('sortBy', 'publishedAt')
    url.searchParams.set('pageSize', '20')
    url.searchParams.set('language', 'en')
    
    const response = await fetch(url.toString(), {
      headers: {
        'X-Api-Key': apiKey,
      },
    })
    
    if (!response.ok) {
      const errorText = await response.text()
      console.error(`NewsAPI error: ${response.status}`, errorText)
      return []
    }
    
    const data = await response.json()
    
    if (data.status !== 'ok' || !data.articles) {
      console.error('NewsAPI returned non-ok status:', data)
      return []
    }
    
    return data.articles.map((article: any) => ({
      title: article.title || '',
      description: article.description?.substring(0, 500) || null,
      url: article.url,
      source_name: article.source?.name || 'NewsAPI',
      source_type: 'newsapi' as const,
      published_at: article.publishedAt || null,
    })).filter((a: Article) => a.title && a.url)
  } catch (error) {
    console.error('Error fetching NewsAPI:', error)
    return []
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )
    
    const newsApiKey = Deno.env.get('NEWSAPI_KEY')
    
    // Get request body for manual triggers with specific sources
    let body: { topics?: string[], rss_feeds?: { url: string, name: string }[] } = {}
    try {
      body = await req.json()
    } catch {
      // No body provided, fetch from database sources
    }
    
    const allArticles: Article[] = []
    
    // Fetch from configured RSS sources in database
    const { data: sources, error: sourcesError } = await supabase
      .from('news_sources')
      .select('*')
      .eq('is_active', true)
    
    if (sourcesError) {
      console.error('Error fetching sources:', sourcesError)
    }
    
    // Fetch RSS feeds from database sources
    if (sources) {
      for (const source of sources.filter(s => s.source_type === 'rss')) {
        const articles = await fetchRSSFeed(source.url, source.name)
        allArticles.push(...articles)
        
        // Update last_fetched_at
        await supabase
          .from('news_sources')
          .update({ last_fetched_at: new Date().toISOString() })
          .eq('id', source.id)
      }
    }
    
    // Fetch from manually provided RSS feeds
    if (body.rss_feeds) {
      for (const feed of body.rss_feeds) {
        const articles = await fetchRSSFeed(feed.url, feed.name)
        allArticles.push(...articles)
      }
    }
    
    // Fetch from NewsAPI for topics
    if (newsApiKey) {
      // Get topics from database sources
      const newsApiQueries = sources?.filter(s => s.source_type === 'newsapi_query') || []
      
      for (const source of newsApiQueries) {
        const articles = await fetchNewsAPI(source.name, newsApiKey)
        allArticles.push(...articles)
      }
      
      // Fetch for manually provided topics
      if (body.topics) {
        for (const topic of body.topics) {
          const articles = await fetchNewsAPI(topic, newsApiKey)
          allArticles.push(...articles)
        }
      }
    } else {
      console.log('NEWSAPI_KEY not configured, skipping NewsAPI fetch')
    }
    
    console.log(`Total articles fetched: ${allArticles.length}`)
    
    // Insert articles, skipping duplicates (URL is unique)
    let inserted = 0
    let skipped = 0
    
    for (const article of allArticles) {
      const { error: insertError } = await supabase
        .from('articles')
        .insert({
          title: article.title,
          description: article.description,
          url: article.url,
          source_name: article.source_name,
          source_type: article.source_type,
          published_at: article.published_at,
        })
      
      if (insertError) {
        if (insertError.code === '23505') { // Unique violation
          skipped++
        } else {
          console.error('Insert error:', insertError)
        }
      } else {
        inserted++
      }
    }
    
    console.log(`Inserted: ${inserted}, Skipped (duplicates): ${skipped}`)
    
    return new Response(
      JSON.stringify({
        success: true,
        fetched: allArticles.length,
        inserted,
        skipped,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
    
  } catch (error) {
    console.error('Error in fetch-news:', error)
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
