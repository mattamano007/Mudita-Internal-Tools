import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { createHmac } from 'node:crypto'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-slack-signature, x-slack-request-timestamp',
}

async function verifySlackRequest(req: Request, body: string): Promise<boolean> {
  const signingSecret = Deno.env.get('SLACK_SIGNING_SECRET')
  if (!signingSecret) return false

  const timestamp = req.headers.get('x-slack-request-timestamp')
  const slackSignature = req.headers.get('x-slack-signature')
  
  if (!timestamp || !slackSignature) return false

  const currentTime = Math.floor(Date.now() / 1000)
  if (Math.abs(currentTime - parseInt(timestamp)) > 300) return false

  const sigBasestring = `v0:${timestamp}:${body}`
  const mySignature = 'v0=' + createHmac('sha256', signingSecret)
    .update(sigBasestring)
    .digest('hex')

  return mySignature === slackSignature
}

// OAuth 1.0a signing for X API
function generateOAuthSignature(
  method: string,
  url: string,
  params: Record<string, string>,
  consumerSecret: string,
  tokenSecret: string
): string {
  const sortedParams = Object.keys(params)
    .sort()
    .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
    .join('&')

  const signatureBase = `${method.toUpperCase()}&${encodeURIComponent(url)}&${encodeURIComponent(sortedParams)}`
  const signingKey = `${encodeURIComponent(consumerSecret)}&${encodeURIComponent(tokenSecret)}`

  const hmac = createHmac('sha1', signingKey)
  hmac.update(signatureBase)
  return hmac.digest('base64')
}

function generateNonce(): string {
  return Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2)
}

async function postToX(content: string): Promise<{ success: boolean; error?: string; tweetId?: string }> {
  const apiKey = Deno.env.get('X_API_KEY')
  const apiSecret = Deno.env.get('X_API_SECRET')
  const accessToken = Deno.env.get('X_ACCESS_TOKEN')
  const accessTokenSecret = Deno.env.get('X_ACCESS_TOKEN_SECRET')

  if (!apiKey || !apiSecret || !accessToken || !accessTokenSecret) {
    console.error('Missing X credentials:', { 
      hasApiKey: !!apiKey, 
      hasApiSecret: !!apiSecret, 
      hasAccessToken: !!accessToken, 
      hasAccessTokenSecret: !!accessTokenSecret 
    })
    return { success: false, error: 'X API credentials not configured' }
  }

  const url = 'https://api.twitter.com/2/tweets'
  const method = 'POST'
  const timestamp = Math.floor(Date.now() / 1000).toString()
  const nonce = generateNonce()

  // OAuth params - note: body params are NOT included in signature for OAuth 1.0a with JSON body
  const oauthParams: Record<string, string> = {
    oauth_consumer_key: apiKey,
    oauth_nonce: nonce,
    oauth_signature_method: 'HMAC-SHA1',
    oauth_timestamp: timestamp,
    oauth_token: accessToken,
    oauth_version: '1.0',
  }

  const signature = generateOAuthSignature(method, url, oauthParams, apiSecret, accessTokenSecret)

  // Build the Authorization header with signature
  const authHeader = 'OAuth ' + [
    `oauth_consumer_key="${encodeURIComponent(apiKey)}"`,
    `oauth_nonce="${encodeURIComponent(nonce)}"`,
    `oauth_signature="${encodeURIComponent(signature)}"`,
    `oauth_signature_method="HMAC-SHA1"`,
    `oauth_timestamp="${timestamp}"`,
    `oauth_token="${encodeURIComponent(accessToken)}"`,
    `oauth_version="1.0"`
  ].join(', ')

  console.log('Attempting X API post with auth header length:', authHeader.length)

  try {
    const response = await fetch(url, {
      method,
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text: content }),
    })

    const data = await response.json()

    if (!response.ok) {
      console.error('X API error:', JSON.stringify(data))
      return { success: false, error: data.detail || data.title || JSON.stringify(data) }
    }

    console.log('X API success:', JSON.stringify(data))
    return { success: true, tweetId: data.data?.id }
  } catch (err) {
    console.error('X API request failed:', err)
    return { success: false, error: err instanceof Error ? err.message : 'Request failed' }
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const body = await req.text()
    const payload = JSON.parse(body)

    if (payload.type === 'url_verification') {
      return new Response(
        JSON.stringify({ challenge: payload.challenge }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const isValid = await verifySlackRequest(req, body)
    if (!isValid) {
      console.error('Invalid Slack signature')
      return new Response(
        JSON.stringify({ error: 'Invalid signature' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    if (payload.type === 'event_callback') {
      const event = payload.event

      if (event.type === 'message' && event.channel_type === 'im' && !event.bot_id) {
        const rawContent = event.text
        const userId = event.user

        console.log(`Received DM from ${userId}: ${rawContent}`)

        // Check for @Mudita trigger
        const trigger = '@Mudita'
        const triggerLower = trigger.toLowerCase()
        
        if (!rawContent.toLowerCase().includes(triggerLower)) {
          console.log('Message does not contain trigger, ignoring')
          return new Response(
            JSON.stringify({ ok: true, ignored: true }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          )
        }

        // Remove the trigger from the content before posting
        const content = rawContent
          .replace(new RegExp(trigger, 'gi'), '')
          .trim()

        if (!content) {
          console.log('No content after removing trigger')
          const botToken = Deno.env.get('SLACK_BOT_TOKEN')
          if (botToken) {
            await fetch('https://slack.com/api/chat.postMessage', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${botToken}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                channel: event.channel,
                text: `⚠️ Please include content after @ContentCompass to post to X`
              })
            })
          }
          return new Response(
            JSON.stringify({ ok: true, empty: true }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          )
        }

        console.log(`Posting to X: ${content}`)

        const supabase = createClient(
          Deno.env.get('SUPABASE_URL')!,
          Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
        )

        // Post directly to X
        const result = await postToX(content)

        if (result.success) {
          await supabase.from('posted_content').insert({
            content,
            platform: 'X',
            status: 'posted',
            posted_at: new Date().toISOString()
          })

          const botToken = Deno.env.get('SLACK_BOT_TOKEN')
          if (botToken) {
            await fetch('https://slack.com/api/chat.postMessage', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${botToken}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                channel: event.channel,
                text: `✅ Posted to X: "${content.substring(0, 50)}${content.length > 50 ? '...' : ''}"`
              })
            })
          }
        } else {
          await supabase.from('posted_content').insert({
            content,
            platform: 'X',
            status: 'failed',
            error_message: result.error
          })

          const botToken = Deno.env.get('SLACK_BOT_TOKEN')
          if (botToken) {
            await fetch('https://slack.com/api/chat.postMessage', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${botToken}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                channel: event.channel,
                text: `❌ Failed to post to X: ${result.error}`
              })
            })
          }
        }
      }
    }

    return new Response(
      JSON.stringify({ ok: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
