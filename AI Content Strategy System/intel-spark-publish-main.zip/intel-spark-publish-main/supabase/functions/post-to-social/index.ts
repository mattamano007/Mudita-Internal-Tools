import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { content, webhookUrl, platform } = await req.json()

    if (!content || !webhookUrl) {
      return new Response(
        JSON.stringify({ error: 'Missing content or webhookUrl' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Trigger Zapier webhook
    const zapierResponse = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content,
        platform: platform || 'social',
        timestamp: new Date().toISOString(),
        source: 'mudita-content-system'
      })
    })

    // Log the post attempt
    const status = zapierResponse.ok ? 'posted' : 'failed'
    const errorMessage = zapierResponse.ok ? null : `Zapier returned ${zapierResponse.status}`

    await supabase.from('posted_content').insert({
      content,
      platform: platform || 'zapier',
      status,
      posted_at: status === 'posted' ? new Date().toISOString() : null,
      error_message: errorMessage
    })

    if (!zapierResponse.ok) {
      return new Response(
        JSON.stringify({ error: 'Zapier webhook failed', status: zapierResponse.status }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ success: true, message: 'Content sent to Zapier' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    const message = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
