import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface PostingConfig {
  id: string;
  platform: string;
  webhook_url: string | null;
  is_active: boolean;
}

export const useAutoPost = () => {
  const [configs, setConfigs] = useState<PostingConfig[]>([]);
  const [isPosting, setIsPosting] = useState(false);
  const { toast } = useToast();

  const fetchConfigs = async () => {
    const { data } = await supabase
      .from("posting_configs")
      .select("*")
      .eq("is_active", true);
    setConfigs(data || []);
  };

  useEffect(() => {
    fetchConfigs();
  }, []);

  const postContent = async (content: string): Promise<boolean> => {
    if (configs.length === 0) {
      toast({
        title: "No webhooks configured",
        description: "Add a Zapier webhook in settings first",
        variant: "destructive",
      });
      return false;
    }

    setIsPosting(true);
    let success = false;

    for (const config of configs) {
      if (!config.webhook_url) continue;

      try {
        const response = await supabase.functions.invoke("post-to-social", {
          body: {
            content,
            webhookUrl: config.webhook_url,
            platform: config.platform,
          },
        });

        if (response.error) {
          console.error("Post error:", response.error);
          toast({
            title: "Post failed",
            description: response.error.message,
            variant: "destructive",
          });
        } else {
          success = true;
          toast({
            title: "Sent to Zapier",
            description: "Your Zap will handle the posting",
          });
        }
      } catch (error) {
        console.error("Error posting:", error);
      }
    }

    setIsPosting(false);
    return success;
  };

  return {
    postContent,
    isPosting,
    hasWebhooks: configs.length > 0,
    refreshConfigs: fetchConfigs,
  };
};
