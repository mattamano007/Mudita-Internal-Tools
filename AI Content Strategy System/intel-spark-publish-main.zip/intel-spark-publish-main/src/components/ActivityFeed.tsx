interface Activity {
  id: string;
  message: string;
  time: string;
}

interface ActivityFeedProps {
  activities: Activity[];
}

export const ActivityFeed = ({ activities }: ActivityFeedProps) => {
  return (
    <div className="space-y-0">
      {activities.map((activity) => (
        <div key={activity.id} className="py-2 flex items-baseline justify-between gap-4">
          <p className="text-sm text-foreground/80">{activity.message}</p>
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {activity.time}
          </span>
        </div>
      ))}
    </div>
  );
};

export type { Activity };
