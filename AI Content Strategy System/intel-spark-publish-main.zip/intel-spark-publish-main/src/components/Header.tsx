import { Circle } from "lucide-react";
import muditaLogo from "@/assets/mudita-logo.jpeg";
import { SettingsDialog } from "./SettingsDialog";

export const Header = () => {
  return (
    <header className="border-b border-border bg-background sticky top-0 z-50">
      <div className="container mx-auto px-8 h-14 flex items-center justify-between">
        <img src={muditaLogo} alt="Mudita" className="h-6" />
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Circle className="w-1.5 h-1.5 fill-success text-success" />
            <span>Monitoring</span>
          </div>
          <SettingsDialog />
        </div>
      </div>
    </header>
  );
};
