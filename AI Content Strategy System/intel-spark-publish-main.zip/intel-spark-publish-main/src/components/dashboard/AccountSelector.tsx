import { ChevronDown, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Account } from "./MainDashboard";

interface AccountSelectorProps {
  accounts: Account[];
  selectedAccountId: string;
  onSelect: (id: string) => void;
}

export const AccountSelector = ({
  accounts,
  selectedAccountId,
  onSelect,
}: AccountSelectorProps) => {
  const selectedAccount = accounts.find((a) => a.id === selectedAccountId);

  if (!selectedAccount) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="gap-2 h-8 px-2">
          <div className="w-5 h-5 rounded-full bg-muted flex items-center justify-center text-[10px] font-medium">
            {selectedAccount.name.charAt(0)}
          </div>
          <span className="text-sm">{selectedAccount.handle}</span>
          <ChevronDown className="w-3 h-3 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-56 bg-popover">
        {accounts.map((account) => (
          <DropdownMenuItem
            key={account.id}
            onClick={() => onSelect(account.id)}
            className="flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs font-medium">
                {account.name.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-medium">{account.name}</p>
                <p className="text-xs text-muted-foreground">{account.handle}</p>
              </div>
            </div>
            {account.id === selectedAccountId && (
              <Check className="w-4 h-4" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
