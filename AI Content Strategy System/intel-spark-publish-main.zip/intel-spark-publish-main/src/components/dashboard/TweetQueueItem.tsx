import { useState } from "react";
import { Send, Clock, MoreHorizontal, Trash2, Edit3, Calendar, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tweet } from "./MainDashboard";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface TweetQueueItemProps {
  tweet: Tweet;
  onPublish: (id: string, tweetUrl?: string) => void;
  onDelete: (id: string) => void;
  onSchedule?: (id: string) => void;
}

export const TweetQueueItem = ({ 
  tweet, 
  onPublish, 
  onDelete, 
  onSchedule 
}: TweetQueueItemProps) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  // Score thresholds: 8-10 = high (green), 5-7 = medium (yellow), 1-4 = low (red)
  const getScoreColor = (score: number) => {
    if (score >= 8) return "bg-emerald-500";
    if (score >= 5) return "bg-amber-500";
    return "bg-red-500";
  };

  const handlePublishClick = () => {
    setShowConfirm(true);
  };

  const handleConfirmPublish = async () => {
    setIsPublishing(true);
    setShowConfirm(false);

    try {
      const response = await supabase.functions.invoke("post-to-x", {
        body: { content: tweet.content },
      });

      if (response.error) {
        console.error("Post error:", response.error);
        toast.error("Failed to post", {
          description: response.error.message,
        });
        setIsPublishing(false);
        return;
      }

      const tweetUrl = response.data?.tweetUrl;
      onPublish(tweet.id, tweetUrl);
    } catch (error) {
      console.error("Error posting:", error);
      toast.error("Failed to post", {
        description: error instanceof Error ? error.message : "Unknown error",
      });
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <>
      <div className="p-4 border border-border rounded-lg bg-card hover:border-muted-foreground/30 transition-colors group">
        <div className="flex gap-4">
          <div className="flex-1">
            <p className="text-sm leading-relaxed mb-3">{tweet.content}</p>
            
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${getScoreColor(tweet.score)}`} />
                <span className="font-medium">{tweet.score}/10</span>
              </span>
              <span>{tweet.source}</span>
              {tweet.scheduledFor && (
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {format(tweet.scheduledFor, "h:mm a")}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-start gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8"
              onClick={handlePublishClick}
              disabled={isPublishing}
            >
              {isPublishing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="w-8 h-8">
                  <MoreHorizontal className="w-3.5 h-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-popover">
                <DropdownMenuItem>
                  <Edit3 className="w-3.5 h-3.5 mr-2" />
                  Edit
                </DropdownMenuItem>
                {onSchedule && tweet.status === "queued" && (
                  <DropdownMenuItem onClick={() => onSchedule(tweet.id)}>
                    <Calendar className="w-3.5 h-3.5 mr-2" />
                    Schedule
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => onDelete(tweet.id)}
                  className="text-destructive"
                >
                  <Trash2 className="w-3.5 h-3.5 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Publish to X?</AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <span className="block">This will post the following content to X:</span>
              <span className="block text-foreground bg-muted p-3 rounded-md text-sm">
                {tweet.content}
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmPublish}>
              Publish Now
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
