import { useState } from "react";
import { Hash, Building2, Globe, AtSign, X, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface SourcesPanelProps {
  sources: {
    topics: string[];
    companies: string[];
    urls: string[];
    accounts: string[];
    polymarket: boolean;
  };
  onSourcesChange?: (sources: SourcesPanelProps["sources"]) => void;
}

export const SourcesPanel = ({ sources, onSourcesChange }: SourcesPanelProps) => {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [inputValues, setInputValues] = useState({
    topic: "",
    company: "",
    url: "",
    account: "",
  });

  const totalSources = 
    sources.topics.length + 
    sources.companies.length + 
    sources.urls.length + 
    sources.accounts.length;

  const addItem = (type: "topics" | "companies" | "urls" | "accounts") => {
    if (!onSourcesChange) return;
    const inputKey = type === "topics" ? "topic" : type === "companies" ? "company" : type === "urls" ? "url" : "account";
    const value = inputValues[inputKey].trim();
    if (value && !sources[type].includes(value)) {
      onSourcesChange({
        ...sources,
        [type]: [...sources[type], value],
      });
      setInputValues(prev => ({ ...prev, [inputKey]: "" }));
    }
  };

  const removeItem = (type: "topics" | "companies" | "urls" | "accounts", value: string) => {
    if (!onSourcesChange) return;
    onSourcesChange({
      ...sources,
      [type]: sources[type].filter(item => item !== value),
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent, type: "topics" | "companies" | "urls" | "accounts") => {
    if (e.key === "Enter") {
      e.preventDefault();
      addItem(type);
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const renderSourceSection = (
    type: "topics" | "companies" | "urls" | "accounts",
    icon: React.ReactNode,
    label: string,
    placeholder: string,
    inputKey: "topic" | "company" | "url" | "account"
  ) => {
    const items = sources[type];
    const isExpanded = expandedSection === type;

    return (
      <Collapsible open={isExpanded} onOpenChange={() => toggleSection(type)}>
        <CollapsibleTrigger asChild>
          <button className="w-full flex items-center justify-between py-2 text-xs hover:bg-muted/50 rounded px-2 -mx-2 transition-colors">
            <div className="flex items-center gap-2 text-muted-foreground">
              {icon}
              <span>{label}</span>
              {items.length > 0 && (
                <span className="text-foreground">({items.length})</span>
              )}
            </div>
            <Plus className={`w-3 h-3 text-muted-foreground transition-transform ${isExpanded ? "rotate-45" : ""}`} />
          </button>
        </CollapsibleTrigger>

        {items.length > 0 && !isExpanded && (
          <div className="flex flex-wrap gap-1.5 mt-1 mb-2">
            {items.slice(0, 3).map((item) => (
              <span
                key={item}
                className="px-2 py-1 text-xs bg-muted rounded truncate max-w-[120px]"
              >
                {type === "accounts" ? item.replace("@", "") : item}
              </span>
            ))}
            {items.length > 3 && (
              <span className="px-2 py-1 text-xs text-muted-foreground">
                +{items.length - 3} more
              </span>
            )}
          </div>
        )}

        <CollapsibleContent className="space-y-2 mt-2">
          <Input
            placeholder={placeholder}
            value={inputValues[inputKey]}
            onChange={(e) => setInputValues(prev => ({ ...prev, [inputKey]: e.target.value }))}
            onKeyDown={(e) => handleKeyDown(e, type)}
            className="h-8 text-xs"
          />
          <div className="flex flex-wrap gap-1.5">
            {items.map((item) => (
              <span
                key={item}
                className="flex items-center gap-1 px-2 py-1 text-xs bg-muted rounded group"
              >
                {type === "accounts" ? item.replace("@", "") : item}
                <button
                  onClick={() => removeItem(type, item)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
    );
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xs text-muted-foreground uppercase tracking-wider">
        Sources ({totalSources})
      </h2>

      <div className="space-y-1">
        {renderSourceSection(
          "topics",
          <Hash className="w-3 h-3" />,
          "Topics",
          "Add topic (Enter)",
          "topic"
        )}
        {renderSourceSection(
          "companies",
          <Building2 className="w-3 h-3" />,
          "Companies",
          "Add company (Enter)",
          "company"
        )}
        {renderSourceSection(
          "urls",
          <Globe className="w-3 h-3" />,
          "URLs",
          "Add URL (Enter)",
          "url"
        )}
        {renderSourceSection(
          "accounts",
          <AtSign className="w-3 h-3" />,
          "Accounts",
          "Add account (Enter)",
          "account"
        )}
      </div>

      {totalSources === 0 && (
        <p className="text-xs text-muted-foreground text-center py-4">
          Click a category above to add sources
        </p>
      )}
    </div>
  );
};
