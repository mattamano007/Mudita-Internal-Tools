import { useState } from "react";
import { Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface TweetComposerProps {
  onSuccess?: () => void;
}

export const TweetComposer = ({ onSuccess }: TweetComposerProps) => {
  const [content, setContent] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const charCount = content.length;
  const maxChars = 280;
  const isOverLimit = charCount > maxChars;

  const handlePublishClick = () => {
    if (content.trim() && !isOverLimit) {
      setShowConfirm(true);
    }
  };

  const handleConfirmPublish = async () => {
    setIsPublishing(true);
    setShowConfirm(false);

    try {
      const response = await supabase.functions.invoke("post-to-x", {
        body: { content: content.trim() },
      });

      if (response.error) {
        console.error("Post error:", response.error);
        toast.error("Failed to post", {
          description: response.error.message,
        });
        setIsPublishing(false);
        return;
      }

      const tweetUrl = response.data?.tweetUrl;
      
      toast.success("Published to X!", {
        action: tweetUrl ? {
          label: "View Tweet",
          onClick: () => window.open(tweetUrl, "_blank"),
        } : undefined,
      });

      setContent("");
      onSuccess?.();
    } catch (error) {
      console.error("Error posting:", error);
      toast.error("Failed to post", {
        description: error instanceof Error ? error.message : "Unknown error",
      });
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <>
      <div className="border border-border rounded-lg p-4 bg-card">
        <Textarea
          placeholder="What's happening?"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="min-h-[100px] resize-none border-0 p-0 focus-visible:ring-0 text-sm"
          disabled={isPublishing}
        />
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
          <span className={`text-xs ${isOverLimit ? "text-destructive" : "text-muted-foreground"}`}>
            {charCount}/{maxChars}
          </span>
          <Button
            size="sm"
            onClick={handlePublishClick}
            disabled={!content.trim() || isOverLimit || isPublishing}
          >
            {isPublishing ? (
              <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
            ) : (
              <Send className="w-4 h-4 mr-1.5" />
            )}
            Post to X
          </Button>
        </div>
      </div>

      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Publish to X?</AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <span className="block">This will post the following content to X:</span>
              <span className="block text-foreground bg-muted p-3 rounded-md text-sm whitespace-pre-wrap">
                {content}
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmPublish}>
              Publish Now
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
