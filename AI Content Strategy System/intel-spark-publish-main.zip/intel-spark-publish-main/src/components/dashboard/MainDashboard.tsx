import { useState, useEffect } from "react";
import { 
  Send, 
  Clock, 
  ChevronDown,
  Plus,
  Settings,
  Zap,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { OnboardingConfig } from "@/components/onboarding";
import { TweetQueueItem } from "./TweetQueueItem";
import { TweetComposer } from "./TweetComposer";
import { SourcesPanel } from "./SourcesPanel";
import { AccountSelector } from "./AccountSelector";
import { supabase } from "@/integrations/supabase/client";

interface MainDashboardProps {
  config: OnboardingConfig;
  onReset: () => void;
  onConfigChange: (config: OnboardingConfig) => void;
  onSignOut?: () => void;
}

export interface Tweet {
  id: string;
  content: string;
  scheduledFor?: Date;
  source: string;
  score: number;
  status: "queued" | "scheduled" | "posted" | "failed";
  views?: number;
}

export interface Account {
  id: string;
  name: string;
  handle: string;
  avatar?: string;
  isActive: boolean;
  stats: {
    totalPosts: number;
    avgViews: number;
  };
  frequency: "conservative" | "moderate" | "aggressive";
}

const initialAccounts: Account[] = [
  {
    id: "1",
    name: "My Account",
    handle: "@my_account",
    isActive: true,
    stats: { totalPosts: 0, avgViews: 0 },
    frequency: "moderate",
  },
];

export const MainDashboard = ({ config, onReset, onConfigChange, onSignOut }: MainDashboardProps) => {
  const [tweets, setTweets] = useState<Tweet[]>([]);
  const [accounts, setAccounts] = useState<Account[]>(initialAccounts);
  const [selectedAccountId, setSelectedAccountId] = useState(initialAccounts[0].id);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch generated content from database
  useEffect(() => {
    const fetchTweets = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from("generated_content")
        .select("*")
        .in("status", ["approved", "pending"])
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching tweets:", error);
        toast.error("Failed to load tweets");
      } else if (data) {
        const mappedTweets: Tweet[] = data.map((item) => ({
          id: item.id,
          content: item.tweet_content || "",
          source: "AI Generated",
          score: item.quality_score || 0,
          status: "queued" as const,
        }));
        setTweets(mappedTweets);
      }
      setIsLoading(false);
    };

    fetchTweets();
  }, []);

  const selectedAccount = accounts.find(a => a.id === selectedAccountId) || accounts[0];
  const queuedTweets = tweets.filter(t => t.status === "queued");
  const scheduledTweets = tweets.filter(t => t.status === "scheduled");

  const handlePublishNow = async (id: string, tweetUrl?: string) => {
    // Update status in database
    await supabase
      .from("generated_content")
      .update({ status: "published", published_at: new Date().toISOString() })
      .eq("id", id);

    setTweets(prev => prev.filter(t => t.id !== id));
    
    // Update account stats
    setAccounts(prev => prev.map(a => 
      a.id === selectedAccountId 
        ? { ...a, stats: { ...a.stats, totalPosts: a.stats.totalPosts + 1 } }
        : a
    ));

    if (tweetUrl) {
      toast.success("Published to X", {
        action: {
          label: "View Tweet",
          onClick: () => window.open(tweetUrl, "_blank"),
        },
      });
    } else {
      toast.success("Published to X");
    }
  };

  const handleDelete = async (id: string) => {
    // Update status in database to archived
    await supabase
      .from("generated_content")
      .update({ status: "archived" })
      .eq("id", id);

    setTweets(prev => prev.filter(t => t.id !== id));
    toast("Removed from queue");
  };

  const handleSchedule = (id: string) => {
    setTweets(prev => prev.map(t => 
      t.id === id 
        ? { ...t, status: "scheduled" as const, scheduledFor: new Date(Date.now() + 60 * 60 * 1000) }
        : t
    ));
    toast("Scheduled for 1 hour from now");
  };

  const updateFrequency = (frequency: Account["frequency"]) => {
    setAccounts(prev => prev.map(a => 
      a.id === selectedAccountId ? { ...a, frequency } : a
    ));
    toast(`Posting frequency set to ${frequency}`);
  };

  const totalPosts = selectedAccount.stats.totalPosts;
  const avgViews = selectedAccount.stats.avgViews;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 z-50 bg-background">
        <div className="container mx-auto px-8 h-14 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="text-sm font-medium tracking-tight">mudita</span>
            <div className="h-4 w-px bg-border" />
            <AccountSelector
              accounts={accounts}
              selectedAccountId={selectedAccountId}
              onSelect={setSelectedAccountId}
            />
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onReset}>
              <Plus className="w-4 h-4 mr-1.5" />
              New Account
            </Button>
            <Button variant="ghost" size="icon" className="w-8 h-8">
              <Settings className="w-4 h-4" />
            </Button>
            {onSignOut && (
              <Button variant="ghost" size="icon" className="w-8 h-8" onClick={onSignOut}>
                <LogOut className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-8 py-10 max-w-6xl">
        {/* Stats row */}
        <div className="flex items-center gap-12 mb-12">
          <div>
            <p className="text-4xl font-medium tracking-tight">{totalPosts}</p>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Total Posts</p>
          </div>
          <div>
            <p className="text-4xl font-medium tracking-tight">{avgViews.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Avg Views</p>
          </div>
          <div>
            <p className="text-4xl font-medium tracking-tight">{queuedTweets.length}</p>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">In Queue</p>
          </div>
          <div className="ml-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Zap className="w-3 h-3" />
                  {selectedAccount.frequency === "conservative" && "1-2 posts/day"}
                  {selectedAccount.frequency === "moderate" && "3-4 posts/day"}
                  {selectedAccount.frequency === "aggressive" && "5+ posts/day"}
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-popover">
                <DropdownMenuItem onClick={() => updateFrequency("conservative")}>
                  Conservative (1-2/day)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => updateFrequency("moderate")}>
                  Moderate (3-4/day)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => updateFrequency("aggressive")}>
                  Aggressive (5+/day)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-10">
          {/* Tweet Queue - Main focus */}
          <div className="col-span-2 space-y-8">
            {/* Compose */}
            <div>
              <h2 className="text-xs text-muted-foreground uppercase tracking-wider mb-4">
                Compose
              </h2>
              <TweetComposer 
                onSuccess={() => {
                  setAccounts(prev => prev.map(a => 
                    a.id === selectedAccountId 
                      ? { ...a, stats: { ...a.stats, totalPosts: a.stats.totalPosts + 1 } }
                      : a
                  ));
                }}
              />
            </div>

            {/* Queued */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xs text-muted-foreground uppercase tracking-wider">
                  Queue ({queuedTweets.length})
                </h2>
                {queuedTweets.length > 0 && (
                  <Button variant="ghost" size="sm" className="text-xs h-7">
                    <Send className="w-3 h-3 mr-1.5" />
                    Publish All
                  </Button>
                )}
              </div>
              <div className="space-y-3">
                {queuedTweets.map((tweet) => (
                  <TweetQueueItem
                    key={tweet.id}
                    tweet={tweet}
                    onPublish={handlePublishNow}
                    onDelete={handleDelete}
                    onSchedule={handleSchedule}
                  />
                ))}
                {queuedTweets.length === 0 && !isLoading && (
                  <p className="text-sm text-muted-foreground py-8 text-center border border-dashed border-border rounded-lg">
                    Queue is empty. Content will appear here once sources are scanned.
                  </p>
                )}
                {isLoading && (
                  <p className="text-sm text-muted-foreground py-8 text-center">
                    Loading tweets...
                  </p>
                )}
              </div>
            </div>

            {/* Scheduled */}
            {scheduledTweets.length > 0 && (
              <div>
                <h2 className="text-xs text-muted-foreground uppercase tracking-wider mb-4">
                  Scheduled ({scheduledTweets.length})
                </h2>
                <div className="space-y-3">
                  {scheduledTweets.map((tweet) => (
                    <TweetQueueItem
                      key={tweet.id}
                      tweet={tweet}
                      onPublish={handlePublishNow}
                      onDelete={handleDelete}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar - Sources */}
          <div>
            <SourcesPanel 
              sources={config.sources} 
              onSourcesChange={(newSources) => onConfigChange({ ...config, sources: newSources })}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
