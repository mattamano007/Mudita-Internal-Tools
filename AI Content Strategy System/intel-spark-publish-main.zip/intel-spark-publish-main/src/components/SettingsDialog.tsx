import { useState, useEffect } from "react";
import { Settings, X, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface PostingConfig {
  id: string;
  platform: string;
  webhook_url: string | null;
  is_active: boolean;
}

export const SettingsDialog = () => {
  const [open, setOpen] = useState(false);
  const [configs, setConfigs] = useState<PostingConfig[]>([]);
  const [newWebhookUrl, setNewWebhookUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchConfigs = async () => {
    const { data, error } = await supabase
      .from("posting_configs")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching configs:", error);
      return;
    }

    setConfigs(data || []);
  };

  useEffect(() => {
    if (open) {
      fetchConfigs();
    }
  }, [open]);

  const handleAddWebhook = async () => {
    if (!newWebhookUrl.trim()) {
      toast({
        title: "Error",
        description: "Please enter a webhook URL",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    const { error } = await supabase.from("posting_configs").insert({
      platform: "zapier",
      webhook_url: newWebhookUrl.trim(),
      is_active: true,
    });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to save webhook",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Success",
        description: "Webhook added",
      });
      setNewWebhookUrl("");
      fetchConfigs();
    }
    setIsLoading(false);
  };

  const handleDeleteWebhook = async (id: string) => {
    const { error } = await supabase
      .from("posting_configs")
      .delete()
      .eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to delete webhook",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Deleted",
        description: "Webhook removed",
      });
      fetchConfigs();
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-sm font-medium">Auto-Post Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="space-y-3">
            <Label className="text-xs text-muted-foreground">Zapier Webhook URL</Label>
            <p className="text-xs text-muted-foreground/60">
              Create a Zap with a "Webhooks by Zapier" trigger, then paste the URL here.
              The Zap can post to X, LinkedIn, or any platform.
            </p>
            <div className="flex gap-2">
              <Input
                placeholder="https://hooks.zapier.com/..."
                value={newWebhookUrl}
                onChange={(e) => setNewWebhookUrl(e.target.value)}
                className="text-sm"
              />
              <Button onClick={handleAddWebhook} disabled={isLoading} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {configs.length > 0 && (
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Active Webhooks</Label>
              {configs.map((config) => (
                <div
                  key={config.id}
                  className="flex items-center justify-between p-3 rounded-lg border border-border bg-card"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium capitalize">{config.platform}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {config.webhook_url}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    onClick={() => handleDeleteWebhook(config.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          <div className="pt-4 border-t border-border">
            <p className="text-xs text-muted-foreground">
              <strong>How it works:</strong> When you click "Publish" on a content card,
              it triggers your Zapier webhook with the content. Your Zap handles the actual posting.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
