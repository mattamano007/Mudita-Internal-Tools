import { useState } from "react";
import { RefreshCw } from "lucide-react";
import { MetricCard } from "./MetricCard";
import { ContentCard } from "./ContentCard";
import { NewsItem } from "./NewsItem";
import { ActivityFeed, Activity } from "./ActivityFeed";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { toast } from "sonner";
import { useAutoPost } from "@/hooks/useAutoPost";

const mockContent = [
  {
    id: "1",
    platform: "twitter" as const,
    content: "The AI landscape is shifting dramatically. Here's what you need to know about agentic AI and why it matters for your business.",
    score: 87,
    source: "TechCrunch",
    time: "2m",
  },
  {
    id: "2",
    platform: "linkedin" as const,
    content: "The future of content strategy isn't about creating more—it's about creating smarter. Companies using AI for content scoring see 3x higher engagement.",
    score: 72,
    source: "Forbes",
    time: "15m",
  },
  {
    id: "3",
    platform: "twitter" as const,
    content: "Major tech companies are investing heavily in AI safety research. Responsible AI development is becoming a competitive advantage.",
    score: 91,
    source: "Wired",
    time: "1h",
  },
  {
    id: "4",
    platform: "linkedin" as const,
    content: "Interesting pattern in how successful startups approach AI integration. It's not about replacing humans—it's about augmentation.",
    score: 45,
    source: "HBR",
    time: "2h",
  },
];

const mockNews = [
  { title: "OpenAI announces GPT-5 with reasoning capabilities", source: "TechCrunch", time: "5m", status: "processed" as const },
  { title: "European AI Act enters into force", source: "Reuters", time: "23m", status: "processed" as const },
  { title: "SPAM: Get rich quick with AI trading bots", source: "Unknown", time: "45m", status: "filtered" as const },
  { title: "Anthropic raises $2B in new funding round", source: "The Verge", time: "1h", status: "pending" as const },
  { title: "Microsoft integrates Copilot across product suite", source: "ZDNet", time: "2h", status: "processed" as const },
];

const mockActivities: Activity[] = [
  { id: "1", message: "Thread published to X", time: "now" },
  { id: "2", message: "3 posts generated", time: "2m" },
  { id: "3", message: "12 articles scanned", time: "5m" },
  { id: "4", message: "Post sent to review", time: "15m" },
  { id: "5", message: "Low-quality content archived", time: "1h" },
];

export const Dashboard = () => {
  const [content, setContent] = useState(mockContent);
  const [isScanning, setIsScanning] = useState(false);
  const { postContent, isPosting, hasWebhooks } = useAutoPost();

  const handlePublish = async (id: string) => {
    const item = content.find(c => c.id === id);
    if (!item) return;

    const success = await postContent(item.content);
    if (success) {
      setContent(prev => prev.filter(c => c.id !== id));
      toast.success("Published");
    }
  };

  const handleArchive = (id: string) => {
    setContent(prev => prev.filter(c => c.id !== id));
    toast("Archived");
  };

  const handleScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      toast.success("8 articles found");
    }, 1500);
  };

  const high = content.filter(c => c.score >= 80);
  const medium = content.filter(c => c.score >= 50 && c.score < 80);
  const low = content.filter(c => c.score < 50);

  return (
    <div className="container mx-auto px-8 py-12 max-w-6xl">
      {/* Hero */}
      <div className="mb-20">
        <h1 className="text-4xl font-medium tracking-tight mb-3">
          Content that writes itself.
        </h1>
        <p className="text-muted-foreground text-lg max-w-xl">
          Watch industry news. Generate posts. Publish automatically. 
          AI scores everything—high quality goes live, the rest waits for you.
        </p>
      </div>

      {/* Metrics */}
      <div className="flex gap-12 mb-16">
        <MetricCard label="Generated" value={24} sublabel="today" />
        <MetricCard label="Published" value={7} sublabel="29% rate" />
        <MetricCard label="Review" value={5} />
        <MetricCard label="Archived" value={12} />
      </div>

      <div className="grid grid-cols-3 gap-12">
        {/* Content */}
        <div className="col-span-2">
          <Tabs defaultValue="all">
            <TabsList className="bg-transparent border-b border-border rounded-none w-full justify-start h-auto p-0 mb-8">
              <TabsTrigger 
                value="all" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent px-0 mr-6 pb-3"
              >
                All
              </TabsTrigger>
              <TabsTrigger 
                value="publish" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent px-0 mr-6 pb-3"
              >
                Ready ({high.length})
              </TabsTrigger>
              <TabsTrigger 
                value="review"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent px-0 mr-6 pb-3"
              >
                Review ({medium.length})
              </TabsTrigger>
              <TabsTrigger 
                value="archived"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent px-0 pb-3"
              >
                Archived ({low.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-2 gap-4">
                {content.map((item) => (
                  <ContentCard
                    key={item.id}
                    {...item}
                    onPublish={handlePublish}
                    onArchive={handleArchive}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="publish" className="mt-0">
              <div className="grid grid-cols-2 gap-4">
                {high.map((item) => (
                  <ContentCard key={item.id} {...item} onPublish={handlePublish} onArchive={handleArchive} />
                ))}
                {high.length === 0 && (
                  <p className="text-sm text-muted-foreground col-span-2 py-8">No content ready</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="review" className="mt-0">
              <div className="grid grid-cols-2 gap-4">
                {medium.map((item) => (
                  <ContentCard key={item.id} {...item} onPublish={handlePublish} onArchive={handleArchive} onReview={() => toast.info("Opening editor...")} />
                ))}
                {medium.length === 0 && (
                  <p className="text-sm text-muted-foreground col-span-2 py-8">No content in review</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="archived" className="mt-0">
              <div className="grid grid-cols-2 gap-4">
                {low.map((item) => (
                  <ContentCard key={item.id} {...item} onArchive={handleArchive} />
                ))}
                {low.length === 0 && (
                  <p className="text-sm text-muted-foreground col-span-2 py-8">No archived content</p>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-12">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs text-muted-foreground uppercase tracking-wider">News</h3>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleScan}
                disabled={isScanning}
                className="text-xs h-6 px-2"
              >
                <RefreshCw className={`w-3 h-3 mr-1.5 ${isScanning ? "animate-spin" : ""}`} />
                Scan
              </Button>
            </div>
            <div className="divide-y divide-border">
              {mockNews.map((news, i) => (
                <NewsItem key={i} {...news} />
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xs text-muted-foreground uppercase tracking-wider mb-4">Activity</h3>
            <ActivityFeed activities={mockActivities} />
          </div>
        </div>
      </div>
    </div>
  );
};
