type QualityLevel = "high" | "medium" | "low";

interface QualityBadgeProps {
  score: number;
}

const getQualityLevel = (score: number): QualityLevel => {
  if (score >= 80) return "high";
  if (score >= 50) return "medium";
  return "low";
};

const qualityStyles = {
  high: "text-success",
  medium: "text-warning",
  low: "text-muted-foreground",
};

export const QualityBadge = ({ score }: QualityBadgeProps) => {
  const level = getQualityLevel(score);

  return (
    <span className={`text-xs tabular-nums font-medium ${qualityStyles[level]}`}>
      {score}
    </span>
  );
};

export { getQualityLevel };
export type { QualityLevel };
