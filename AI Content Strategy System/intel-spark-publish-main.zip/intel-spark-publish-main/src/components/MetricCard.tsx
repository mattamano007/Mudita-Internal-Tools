interface MetricCardProps {
  label: string;
  value: number;
  sublabel?: string;
}

export const MetricCard = ({ label, value, sublabel }: MetricCardProps) => {
  return (
    <div className="space-y-1">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-2xl font-medium tabular-nums">{value}</p>
      {sublabel && (
        <p className="text-xs text-muted-foreground">{sublabel}</p>
      )}
    </div>
  );
};
