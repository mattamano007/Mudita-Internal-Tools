import { Sparkles } from "lucide-react";
import { Input } from "@/components/ui/input";

interface LaunchStepProps {
  topic: string;
  onTopicChange: (topic: string) => void;
}

const topicSuggestions = [
  "AI & machine learning",
  "crypto & DeFi",
  "startups & venture",
  "climate tech",
  "fintech",
  "sports betting",
  "politics",
  "memes",
];

export const LaunchStep = ({
  topic,
  onTopicChange,
}: LaunchStepProps) => {
  return (
    <div>
      <h2 className="text-3xl font-medium tracking-tight mb-2">
        What's your account about?
      </h2>
      <p className="text-muted-foreground mb-10">
        Define the focus of your automated X account.
      </p>

      <div className="space-y-10">
        {/* Prompt builder */}
        <div className="p-8 bg-card border border-border rounded-lg">
          <div className="flex items-center gap-2 text-muted-foreground mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-xs uppercase tracking-wider">Your account</span>
          </div>
          
          <div className="flex flex-wrap items-center gap-3 text-2xl font-medium">
            <span className="text-muted-foreground">Launch an X account about</span>
            <Input
              value={topic}
              onChange={(e) => onTopicChange(e.target.value)}
              placeholder="AI & tech"
              className="w-64 text-2xl font-medium h-auto py-1 px-2 bg-transparent border-0 border-b-2 border-border rounded-none focus-visible:ring-0 focus-visible:border-foreground"
            />
          </div>
        </div>

        {/* Suggestions */}
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">
            Suggestions
          </p>
          <div className="flex flex-wrap gap-2">
            {topicSuggestions.map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => onTopicChange(suggestion)}
                className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${
                  topic === suggestion
                    ? "bg-foreground text-background border-foreground"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>

        {/* Preview */}
        {topic && (
          <div className="p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">
              Your AI will curate and generate content about <span className="text-foreground font-medium">{topic}</span>.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
