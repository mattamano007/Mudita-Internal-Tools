import { useState } from "react";
import { X, Globe, Building2, Hash, AtSign } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface SourcesStepProps {
  sources: {
    topics: string[];
    companies: string[];
    urls: string[];
    accounts: string[];
    polymarket: boolean;
  };
  onChange: (sources: SourcesStepProps["sources"]) => void;
}

export const SourcesStep = ({ sources, onChange }: SourcesStepProps) => {
  const [inputValues, setInputValues] = useState({
    topic: "",
    company: "",
    url: "",
    account: "",
  });

  const addItem = (type: "topics" | "companies" | "urls" | "accounts") => {
    const inputKey = type === "topics" ? "topic" : type === "companies" ? "company" : type === "urls" ? "url" : "account";
    const value = inputValues[inputKey].trim();
    if (value && !sources[type].includes(value)) {
      onChange({
        ...sources,
        [type]: [...sources[type], value],
      });
      setInputValues(prev => ({ ...prev, [inputKey]: "" }));
    }
  };

  const removeItem = (type: "topics" | "companies" | "urls" | "accounts", value: string) => {
    onChange({
      ...sources,
      [type]: sources[type].filter(item => item !== value),
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent, type: "topics" | "companies" | "urls" | "accounts") => {
    if (e.key === "Enter") {
      e.preventDefault();
      addItem(type);
    }
  };

  const totalSources = sources.topics.length + sources.companies.length + sources.urls.length + sources.accounts.length;

  return (
    <div>
      <h2 className="text-3xl font-medium tracking-tight mb-2">
        Connect your news sources
      </h2>
      <p className="text-muted-foreground mb-10">
        Tell us what to watch. We'll monitor these sources and generate content for you.
      </p>

      <Tabs defaultValue="topics" className="space-y-6">
        <TabsList className="bg-muted/50 p-1">
          <TabsTrigger value="topics" className="gap-2">
            <Hash className="w-4 h-4" />
            Topics
          </TabsTrigger>
          <TabsTrigger value="companies" className="gap-2">
            <Building2 className="w-4 h-4" />
            Companies
          </TabsTrigger>
          <TabsTrigger value="urls" className="gap-2">
            <Globe className="w-4 h-4" />
            URLs
          </TabsTrigger>
          <TabsTrigger value="accounts" className="gap-2">
            <AtSign className="w-4 h-4" />
            Accounts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="topics" className="space-y-4">
          <Input
            placeholder="e.g. AI, cryptocurrency, climate tech... (press Enter to add)"
            value={inputValues.topic}
            onChange={(e) => setInputValues(prev => ({ ...prev, topic: e.target.value }))}
            onKeyDown={(e) => handleKeyDown(e, "topics")}
          />
          <div className="flex flex-wrap gap-2">
            {sources.topics.map((topic) => (
              <div
                key={topic}
                className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full text-sm"
              >
                <Hash className="w-3 h-3 text-muted-foreground" />
                {topic}
                <button
                  onClick={() => removeItem("topics", topic)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="companies" className="space-y-4">
          <Input
            placeholder="e.g. OpenAI, Tesla, Stripe... (press Enter to add)"
            value={inputValues.company}
            onChange={(e) => setInputValues(prev => ({ ...prev, company: e.target.value }))}
            onKeyDown={(e) => handleKeyDown(e, "companies")}
          />
          <div className="flex flex-wrap gap-2">
            {sources.companies.map((company) => (
              <div
                key={company}
                className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full text-sm"
              >
                <Building2 className="w-3 h-3 text-muted-foreground" />
                {company}
                <button
                  onClick={() => removeItem("companies", company)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="urls" className="space-y-4">
          <Input
            placeholder="e.g. https://techcrunch.com/feed... (press Enter to add)"
            value={inputValues.url}
            onChange={(e) => setInputValues(prev => ({ ...prev, url: e.target.value }))}
            onKeyDown={(e) => handleKeyDown(e, "urls")}
          />
          <div className="flex flex-wrap gap-2">
            {sources.urls.map((url) => (
              <div
                key={url}
                className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full text-sm max-w-full"
              >
                <Globe className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                <span className="truncate">{url}</span>
                <button
                  onClick={() => removeItem("urls", url)}
                  className="text-muted-foreground hover:text-foreground flex-shrink-0"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <Input
            placeholder="e.g. @elonmusk, @sama... (press Enter to add)"
            value={inputValues.account}
            onChange={(e) => setInputValues(prev => ({ ...prev, account: e.target.value }))}
            onKeyDown={(e) => handleKeyDown(e, "accounts")}
          />
          <div className="flex flex-wrap gap-2">
            {sources.accounts.map((account) => (
              <div
                key={account}
                className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full text-sm"
              >
                <AtSign className="w-3 h-3 text-muted-foreground" />
                {account.replace("@", "")}
                <button
                  onClick={() => removeItem("accounts", account)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {totalSources > 0 && (
        <p className="text-xs text-muted-foreground mt-6">
          {totalSources} source{totalSources !== 1 ? "s" : ""} configured
        </p>
      )}
    </div>
  );
};
