import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SourcesStep } from "./SourcesStep";
import { AccountStep } from "./AccountStep";
import { LaunchStep } from "./LaunchStep";

interface OnboardingWizardProps {
  onComplete: (config: OnboardingConfig) => void;
}

export interface OnboardingConfig {
  sources: {
    topics: string[];
    companies: string[];
    urls: string[];
    accounts: string[];
    polymarket: boolean;
  };
  account: {
    name: string;
    handle: string;
    connected: boolean;
    apiKey?: string;
    apiSecret?: string;
    accessToken?: string;
    accessTokenSecret?: string;
  };
  topic: string;
}

const steps = [
  { id: "sources", label: "Connect Sources" },
  { id: "account", label: "X Account" },
  { id: "launch", label: "Launch" },
];

export const OnboardingWizard = ({ onComplete }: OnboardingWizardProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [config, setConfig] = useState<OnboardingConfig>({
    sources: {
      topics: [],
      companies: [],
      urls: [],
      accounts: [],
      polymarket: false,
    },
    account: {
      name: "",
      handle: "",
      connected: false,
    },
    topic: "",
  });

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(config);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const updateConfig = (updates: Partial<OnboardingConfig>) => {
    setConfig(prev => ({ ...prev, ...updates }));
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Progress */}
      <div className="border-b border-border">
        <div className="container mx-auto px-8 py-6 max-w-3xl">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                      index < currentStep
                        ? "bg-foreground text-background"
                        : index === currentStep
                        ? "bg-foreground text-background"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {index < currentStep ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      index + 1
                    )}
                  </div>
                  <span
                    className={`text-sm ${
                      index <= currentStep
                        ? "text-foreground"
                        : "text-muted-foreground"
                    }`}
                  >
                    {step.label}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`w-24 h-px mx-4 ${
                      index < currentStep ? "bg-foreground" : "bg-border"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 container mx-auto px-8 py-16 max-w-3xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {currentStep === 0 && (
              <SourcesStep
                sources={config.sources}
                onChange={(sources) => updateConfig({ sources })}
              />
            )}
            {currentStep === 1 && (
              <AccountStep
                account={config.account}
                onChange={(account) => updateConfig({ account })}
              />
            )}
            {currentStep === 2 && (
              <LaunchStep
                topic={config.topic}
                onTopicChange={(topic) => updateConfig({ topic })}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation */}
      <div className="border-t border-border">
        <div className="container mx-auto px-8 py-6 max-w-3xl flex justify-between">
          <Button
            variant="ghost"
            onClick={handleBack}
            disabled={currentStep === 0}
          >
            Back
          </Button>
          <Button onClick={handleNext}>
            {currentStep === steps.length - 1 ? "Launch" : "Continue"}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
};
