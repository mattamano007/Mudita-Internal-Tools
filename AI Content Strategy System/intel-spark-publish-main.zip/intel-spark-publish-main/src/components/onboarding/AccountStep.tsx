import { useState } from "react";
import { Check, ExternalLink, ChevronDown, ChevronUp, Eye, EyeOff, CheckCircle2, AlertTriangle, Info, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";

interface AccountStepProps {
  account: {
    name: string;
    handle: string;
    connected: boolean;
    apiKey?: string;
    apiSecret?: string;
    accessToken?: string;
    accessTokenSecret?: string;
  };
  onChange: (account: AccountStepProps["account"]) => void;
}

const steps = [
  {
    number: 1,
    title: "Open X Developer Portal",
    description: "Sign in with the X account you want to automate posting for.",
    link: "https://developer.twitter.com/en/portal/dashboard",
    linkText: "Open Developer Portal →",
    visual: {
      type: "illustration",
      content: (
        <div className="bg-muted/30 rounded-lg p-6 border border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-foreground flex items-center justify-center">
              <Twitter className="w-5 h-5 text-background" />
            </div>
            <div>
              <p className="font-medium text-sm">X Developer Portal</p>
              <p className="text-xs text-muted-foreground">developer.twitter.com</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-3 bg-muted rounded w-3/4" />
            <div className="h-3 bg-muted rounded w-1/2" />
          </div>
        </div>
      ),
    },
  },
  {
    number: 2,
    title: "Create a New Project & App",
    description: "Click 'Create Project' in the sidebar. Choose any name, select 'Production', then create your App.",
    tip: "Name it something like 'Content Automator' or 'Social Poster'",
    visual: {
      type: "steps",
      content: (
        <div className="bg-muted/30 rounded-lg p-4 border border-border space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-medium">1</div>
            <p className="text-sm">Click <span className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">+ Create Project</span> in sidebar</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-medium">2</div>
            <p className="text-sm">Name your project → Click Next</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-medium">3</div>
            <p className="text-sm">Select <span className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">Production</span> use case</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-medium">4</div>
            <p className="text-sm">Create your App inside the project</p>
          </div>
        </div>
      ),
    },
  },
  {
    number: 3,
    title: "Set Up User Authentication",
    description: "This is the most important step! Configure OAuth settings so your app can post tweets.",
    important: true,
    visual: {
      type: "guide",
      content: (
        <div className="space-y-4">
          <div className="bg-muted/30 rounded-lg p-4 border border-border space-y-3">
            <p className="text-sm font-medium">In your App Settings, find:</p>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-500 flex items-center justify-center text-xs font-medium">!</div>
              <p className="text-sm"><span className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">User authentication settings</span> → Click <span className="font-medium">Set up</span></p>
            </div>
          </div>
          
          <div className="bg-muted/30 rounded-lg p-4 border border-border space-y-3">
            <p className="text-sm font-medium text-amber-500">⚠️ Critical Settings:</p>
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                <div>
                  <p><span className="font-medium">App permissions:</span> Select <span className="font-mono bg-green-500/10 text-green-500 px-1.5 py-0.5 rounded text-xs">Read and write</span></p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                <div>
                  <p><span className="font-medium">Type of App:</span> Select <span className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">Web App, Automated App or Bot</span></p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                <div>
                  <p><span className="font-medium">Callback URL:</span> Enter <span className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">https://example.com</span></p>
                  <p className="text-xs text-muted-foreground">(Any valid URL works - we don't use OAuth redirects)</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                <div>
                  <p><span className="font-medium">Website URL:</span> Enter <span className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">https://example.com</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ),
    },
  },
  {
    number: 4,
    title: "Generate & Copy Your Keys",
    description: "Go to 'Keys and Tokens' tab. You need exactly 4 credentials - make sure to copy the right ones!",
    visual: {
      type: "credentials-guide",
      content: (
        <div className="space-y-4">
          <div className="bg-muted/30 rounded-lg p-4 border border-border">
            <p className="text-sm font-medium mb-3 flex items-center gap-2">
              <Info className="w-4 h-4 text-primary" />
              Where to find each credential:
            </p>
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-background rounded border border-border">
                <div className="shrink-0">
                  <span className="text-xs font-mono bg-primary/10 text-primary px-2 py-1 rounded">1</span>
                </div>
                <div>
                  <p className="text-sm font-medium">API Key & API Secret</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Under "Consumer Keys" → Click "Regenerate" if needed
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 font-mono">
                    API Key ≈ 25 characters (e.g., W0vZreHTNDz...)
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 bg-background rounded border border-border">
                <div className="shrink-0">
                  <span className="text-xs font-mono bg-primary/10 text-primary px-2 py-1 rounded">2</span>
                </div>
                <div>
                  <p className="text-sm font-medium">Access Token & Access Token Secret</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Under "Authentication Tokens" → Click "Generate"
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 font-mono">
                    Access Token starts with numbers (e.g., 2010802583712247808-xxx...)
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-red-500/5 border border-red-500/20 rounded-lg p-4">
            <p className="text-sm font-medium text-red-500 flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4" />
              Common Mistakes to Avoid
            </p>
            <ul className="text-xs text-muted-foreground space-y-1.5">
              <li>• <span className="text-red-400">Don't use</span> Bearer Token (that's for read-only access)</li>
              <li>• <span className="text-red-400">Don't use</span> Client ID / Client Secret (those are OAuth 2.0)</li>
              <li>• <span className="text-green-400">Do regenerate</span> Access Token AFTER setting Read+Write permissions</li>
            </ul>
          </div>
        </div>
      ),
    },
  },
];

const credentials = [
  { 
    key: "apiKey", 
    label: "API Key", 
    placeholder: "Paste your API Key here",
    hint: "~25 characters, under 'Consumer Keys'",
  },
  { 
    key: "apiSecret", 
    label: "API Secret", 
    placeholder: "Paste your API Secret here",
    hint: "~50 characters, under 'Consumer Keys'",
  },
  { 
    key: "accessToken", 
    label: "Access Token", 
    placeholder: "Paste your Access Token here",
    hint: "Starts with numbers like 2010802...",
  },
  { 
    key: "accessTokenSecret", 
    label: "Access Token Secret", 
    placeholder: "Paste your Access Token Secret here",
    hint: "~45 characters",
  },
] as const;

export const AccountStep = ({ account, onChange }: AccountStepProps) => {
  const [expandedStep, setExpandedStep] = useState<number | null>(1);
  const [showSecrets, setShowSecrets] = useState({
    apiKey: false,
    apiSecret: false,
    accessToken: false,
    accessTokenSecret: false,
  });

  const allCredentialsFilled = 
    account.apiKey && 
    account.apiSecret && 
    account.accessToken && 
    account.accessTokenSecret;

  const handleConnect = () => {
    if (allCredentialsFilled) {
      onChange({
        ...account,
        connected: true,
        name: account.name || "X Account",
        handle: account.handle || "@connected",
      });
    }
  };

  const toggleShowSecret = (field: keyof typeof showSecrets) => {
    setShowSecrets(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const getFieldValidation = (key: string, value: string | undefined) => {
    if (!value) return null;
    
    switch (key) {
      case "apiKey":
        return value.length >= 20 && value.length <= 30;
      case "apiSecret":
        return value.length >= 45 && value.length <= 55;
      case "accessToken":
        return value.includes("-") && value.length >= 45;
      case "accessTokenSecret":
        return value.length >= 40 && value.length <= 50;
      default:
        return null;
    }
  };

  return (
    <div>
      <h2 className="text-3xl font-medium tracking-tight mb-2">
        Connect your X account
      </h2>
      <p className="text-muted-foreground mb-8">
        Follow these steps to get your API credentials. Takes about 5-10 minutes.
      </p>

      {!account.connected ? (
        <div className="space-y-4">
          {/* Step-by-step guide */}
          <div className="space-y-3">
            {steps.map((step) => (
              <div
                key={step.number}
                className="border border-border rounded-lg overflow-hidden"
              >
                <button
                  onClick={() => setExpandedStep(expandedStep === step.number ? null : step.number)}
                  className="w-full p-4 flex items-center gap-4 text-left hover:bg-muted/50 transition-colors"
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    expandedStep === step.number || (step.number < (expandedStep || 0))
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {step.number}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{step.title}</p>
                    {step.important && (
                      <span className="text-xs text-amber-500">Required for posting</span>
                    )}
                  </div>
                  {expandedStep === step.number ? (
                    <ChevronUp className="w-5 h-5 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-muted-foreground" />
                  )}
                </button>

                <AnimatePresence>
                  {expandedStep === step.number && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 pl-16 space-y-4">
                        <p className="text-sm text-muted-foreground">
                          {step.description}
                        </p>
                        
                        {step.tip && (
                          <p className="text-xs text-muted-foreground/70 italic">
                            💡 {step.tip}
                          </p>
                        )}
                        
                        {step.link && (
                          <a
                            href={step.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 text-sm bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 transition-colors"
                          >
                            {step.linkText}
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}

                        {/* Visual guide */}
                        {step.visual && (
                          <div className="mt-4">
                            {step.visual.content}
                          </div>
                        )}

                        {/* Credentials form in step 4 */}
                        {step.number === 4 && (
                          <div className="mt-6 space-y-4 pt-4 border-t border-border">
                            <p className="text-sm font-medium">Paste your credentials below:</p>
                            {credentials.map((cred) => {
                              const value = account[cred.key];
                              const isValid = getFieldValidation(cred.key, value);
                              
                              return (
                                <div key={cred.key} className="space-y-1.5">
                                  <div className="flex items-center justify-between">
                                    <label className="text-sm text-muted-foreground">
                                      {cred.label}
                                    </label>
                                    {value && (
                                      <span className={`text-xs flex items-center gap-1 ${isValid ? 'text-green-500' : 'text-amber-500'}`}>
                                        {isValid ? (
                                          <>
                                            <CheckCircle2 className="w-3 h-3" />
                                            Looks good
                                          </>
                                        ) : (
                                          <>
                                            <AlertTriangle className="w-3 h-3" />
                                            Check format
                                          </>
                                        )}
                                      </span>
                                    )}
                                  </div>
                                  <div className="relative">
                                    <Input
                                      type={showSecrets[cred.key] ? "text" : "password"}
                                      placeholder={cred.placeholder}
                                      value={account[cred.key] || ""}
                                      onChange={(e) =>
                                        onChange({ ...account, [cred.key]: e.target.value.trim() })
                                      }
                                      className={`pr-12 font-mono text-sm ${
                                        value && isValid === false ? 'border-amber-500/50' : ''
                                      } ${value && isValid === true ? 'border-green-500/50' : ''}`}
                                    />
                                    <button
                                      type="button"
                                      onClick={() => toggleShowSecret(cred.key)}
                                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-muted rounded text-muted-foreground hover:text-foreground transition-colors"
                                    >
                                      {showSecrets[cred.key] ? (
                                        <EyeOff className="w-4 h-4" />
                                      ) : (
                                        <Eye className="w-4 h-4" />
                                      )}
                                    </button>
                                  </div>
                                  <p className="text-xs text-muted-foreground/60">{cred.hint}</p>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {step.number < 4 && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2"
                            onClick={() => setExpandedStep(step.number + 1)}
                          >
                            Next step →
                          </Button>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>

          {/* Account name/handle (optional) */}
          {allCredentialsFilled && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 border border-green-500/30 bg-green-500/5 rounded-lg space-y-4"
            >
              <p className="text-sm font-medium text-green-500 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                All credentials entered! Ready to connect.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-1.5 block">
                    Display Name (optional)
                  </label>
                  <Input
                    placeholder="My X Account"
                    value={account.name}
                    onChange={(e) => onChange({ ...account, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1.5 block">
                    Handle (optional)
                  </label>
                  <Input
                    placeholder="@youraccount"
                    value={account.handle}
                    onChange={(e) => onChange({ ...account, handle: e.target.value })}
                  />
                </div>
              </div>
              <Button onClick={handleConnect} className="w-full">
                <Twitter className="w-4 h-4 mr-2" />
                Connect Account
              </Button>
            </motion.div>
          )}
        </div>
      ) : (
        <div className="p-8 border border-border rounded-lg">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center">
              <Check className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-medium">{account.name}</h3>
              <p className="text-sm text-muted-foreground">{account.handle}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            className="mt-6 text-muted-foreground"
            onClick={() => onChange({ 
              ...account, 
              connected: false,
              apiKey: "",
              apiSecret: "",
              accessToken: "",
              accessTokenSecret: "",
            })}
          >
            Disconnect
          </Button>
        </div>
      )}
    </div>
  );
};
