import { QualityBadge, getQualityLevel } from "./QualityBadge";
import { Button } from "./ui/button";

type Platform = "twitter" | "linkedin";

interface ContentCardProps {
  id: string;
  platform: Platform;
  content: string;
  score: number;
  source: string;
  time: string;
  onPublish?: (id: string) => void;
  onArchive?: (id: string) => void;
  onReview?: (id: string) => void;
}

const platformLabel = {
  twitter: "X",
  linkedin: "LinkedIn",
};

export const ContentCard = ({
  id,
  platform,
  content,
  score,
  source,
  time,
  onPublish,
  onArchive,
  onReview,
}: ContentCardProps) => {
  const level = getQualityLevel(score);

  return (
    <div className="card-elevated p-5 group">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>{platformLabel[platform]}</span>
          <span>·</span>
          <span>{time}</span>
        </div>
        <QualityBadge score={score} />
      </div>

      <p className="text-sm leading-relaxed text-foreground/90 line-clamp-3 mb-3">
        {content}
      </p>

      <p className="text-xs text-muted-foreground truncate mb-4">
        {source}
      </p>

      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        {level === "medium" && onReview && (
          <Button
            size="sm"
            variant="outline"
            onClick={() => onReview(id)}
            className="text-xs h-7"
          >
            Review
          </Button>
        )}
        {(level === "high" || level === "medium") && onPublish && (
          <Button
            size="sm"
            onClick={() => onPublish(id)}
            className="text-xs h-7 bg-foreground text-background hover:bg-foreground/90"
          >
            Publish
          </Button>
        )}
        {onArchive && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onArchive(id)}
            className="text-xs h-7 text-muted-foreground"
          >
            Archive
          </Button>
        )}
      </div>
    </div>
  );
};
