import { Circle } from "lucide-react";

interface NewsItemProps {
  title: string;
  source: string;
  time: string;
  status: "processed" | "pending" | "filtered";
}

const statusStyles = {
  processed: "fill-success text-success",
  pending: "fill-muted-foreground text-muted-foreground",
  filtered: "fill-destructive text-destructive",
};

export const NewsItem = ({ title, source, time, status }: NewsItemProps) => {
  const isFiltered = status === "filtered";
  
  return (
    <div className={`py-2.5 ${isFiltered ? "opacity-40" : ""}`}>
      <div className="flex items-start gap-2">
        <Circle className={`w-1.5 h-1.5 mt-1.5 flex-shrink-0 ${statusStyles[status]}`} />
        <div className="min-w-0">
          <p className={`text-sm leading-snug ${isFiltered ? "line-through" : ""}`}>
            {title}
          </p>
          <p className="text-xs text-muted-foreground mt-0.5">
            {source} · {time}
          </p>
        </div>
      </div>
    </div>
  );
};
