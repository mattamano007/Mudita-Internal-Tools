import { useState, useEffect } from "react";
import { OnboardingWizard, OnboardingConfig } from "@/components/onboarding";
import { MainDashboard } from "@/components/dashboard";
import { AuthForm } from "@/components/auth";
import { useAuth } from "@/hooks/useAuth";

const STORAGE_KEY = "mudita_onboarding_config";

const Index = () => {
  const { user, isLoading: authLoading, signOut } = useAuth();
  const [config, setConfig] = useState<OnboardingConfig | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user has completed onboarding
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setConfig(JSON.parse(stored));
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
    setIsLoading(false);
  }, []);

  const handleOnboardingComplete = (newConfig: OnboardingConfig) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newConfig));
    setConfig(newConfig);
  };

  const handleConfigChange = (newConfig: OnboardingConfig) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newConfig));
    setConfig(newConfig);
  };

  const handleReset = () => {
    localStorage.removeItem(STORAGE_KEY);
    setConfig(null);
  };

  const handleSignOut = async () => {
    await signOut();
    handleReset();
  };

  // Show loading while checking auth
  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-foreground border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Show login if not authenticated
  if (!user) {
    return <AuthForm />;
  }

  // Show onboarding if no config
  if (!config) {
    return <OnboardingWizard onComplete={handleOnboardingComplete} />;
  }

  return (
    <MainDashboard 
      config={config} 
      onReset={handleReset} 
      onConfigChange={handleConfigChange}
      onSignOut={handleSignOut}
    />
  );
};

export default Index;
