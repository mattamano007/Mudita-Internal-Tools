# Mudita Studios Design System

A cohesive design system for Mudita Studios applications featuring a Deep Space Blue theme with Electric Violet accents.

## Color Palette

### Primary Colors
- **Electric Violet** (Primary): `hsl(265 85% 65%)` - `#8B5CF6`
- **Cyan** (Secondary): `hsl(190 90% 50%)` - `#06B6D4`
- **Deep Space Blue** (Background): `hsl(230 35% 7%)` - `#0C0F1A`

### Surface Colors
- **Card**: `hsl(230 35% 10%)`
- **Muted**: `hsl(230 25% 18%)`
- **Border**: `hsl(230 25% 18%)`

### Status Colors
- **Beta** (Green): `rgb(34 197 94)`
- **Building** (Blue): `rgb(59 130 246)`
- **Concept** (Purple): `rgb(168 85 247)`

## Typography

### Font Families
- **Display/Headings**: Outfit (weights: 400-800)
- **Body/Sans**: DM Sans (weights: 400-700)

### Usage
```css
h1, h2, h3 {
  font-family: var(--font-display); /* Outfit */
}

body, p {
  font-family: var(--font-sans); /* DM Sans */
}
```

## Installation

### Option 1: CSS Only
1. Copy `css/mudita-theme.css` to your project
2. Import it in your main CSS or HTML file:
```html
<link rel="stylesheet" href="path/to/mudita-theme.css">
```

### Option 2: With Tailwind CSS
1. Copy the CSS variables from `css/mudita-theme.css` into your global CSS
2. Use `config/tailwind.config.example.ts` as reference for your Tailwind config
3. Install required Tailwind plugins:
```bash
npm install tailwindcss-animate @tailwindcss/typography
```

## Utility Classes

### Glassmorphism
```html
<!-- Full glass effect with blur and border -->
<div class="glass-card">Content</div>

<!-- Subtle glass panel -->
<div class="glass-panel">Content</div>
```

### Gradient Text
```html
<h1 class="text-gradient">Shaping the Future</h1>
```

### Neon Glow
```html
<span class="neon-glow">Glowing Text</span>
<span class="neon-glow-cyan">Cyan Glow</span>
```

### Status Badges
```html
<span class="status-beta">Beta</span>
<span class="status-building">Building</span>
<span class="status-concept">Concept</span>
```

### Animations
```html
<div class="animate-fade-in">Fades in</div>
<div class="animate-slide-up">Slides up</div>
<div class="animate-scale-in">Scales in</div>
<div class="animate-pulse-glow">Pulsing glow</div>

<!-- Staggered animations -->
<div class="animate-slide-up stagger-1">First</div>
<div class="animate-slide-up stagger-2">Second</div>
<div class="animate-slide-up stagger-3">Third</div>
```

### Hover Effects
```html
<div class="hover-lift">Lifts on hover</div>
<div class="hover-glow">Glows on hover</div>
```

## Assets

The `assets/` folder contains:
- `hero-background.png` - Abstract mesh gradient background for hero sections

### Using the Hero Background
```css
.hero {
  background-image: 
    linear-gradient(to bottom, transparent 0%, hsl(230 35% 7%) 100%),
    url('./assets/hero-background.png');
  background-size: cover;
  background-position: center;
}
```

## Framer Motion Animations

For React apps using Framer Motion, here are recommended animation presets:

```tsx
// Fade in from bottom
const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

// Stagger children
const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

// Scale on hover
const hoverScale = {
  whileHover: { scale: 1.02 },
  whileTap: { scale: 0.98 }
};
```

## Best Practices

1. **Dark Mode First**: This theme is designed for dark mode. Add `class="dark"` to your `<html>` element.

2. **Glassmorphism**: Use sparingly for key UI elements like cards, modals, and navigation.

3. **Gradient Text**: Reserve for headlines and important callouts.

4. **Animations**: Use subtle, purposeful animations. Avoid excessive motion.

5. **Contrast**: Ensure sufficient contrast for accessibility. Use `--foreground` for primary text and `--muted-foreground` for secondary text.

## License

Proprietary - Mudita Studios. For internal use only.
