# Design Guidelines: Competitor Follower Scraper

## Design Approach

**Selected Approach**: Dark, minimal SaaS design inspired by Mudita Studios Innovation Lab

**Justification**: A professional, dark-themed interface that emphasizes data clarity and modern aesthetics. The design prioritizes readability, clean typography, and efficient data display.

**Core Principles**:
- Dark theme as default for professional appearance
- Bold, clear typography for hierarchy
- Minimal visual noise - let the data speak
- Purple accent color for actions and highlights

## Color Palette

**Background Colors**:
- Primary background: Near-black (240 10% 4%)
- Card/elevated surfaces: Slightly lighter (240 10% 6%)
- Muted backgrounds: (240 6% 12%)

**Accent Colors**:
- Primary: Purple (262 83% 58%)
- Success: Green-400 for connected states
- Warning: Amber-400 for setup notices
- Error: Red for destructive actions

**Text Colors**:
- Primary text: Near-white (0 0% 95%)
- Muted/secondary text: Gray (240 5% 55%)

## Typography System

**Font Families** (via Google Fonts CDN):
- Primary: Inter (400, 500, 600, 700)
- Monospace: JetBrains Mono (400, 500) for data/IDs

**Hierarchy**:
- Hero Title (h1): text-4xl md:text-5xl font-bold tracking-tight
- Section Headers (h2): text-xl font-semibold
- Body Text: text-base (16px)
- Small Labels: text-sm (14px)
- Micro Text: text-xs (12px)

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, and 8 consistently
- Micro spacing: gap-2 (8px)
- Standard spacing: gap-4, p-4 (16px)
- Section spacing: p-6, py-8 (24-32px)
- Hero spacing: py-12 md:py-16 (48-64px)

**Container Strategy**:
- Max width: max-w-6xl mx-auto
- Page padding: px-4 md:px-6
- Full-bleed hero section with border-b separator

## Component Patterns

### Hero Section
- Full-width with border-b border-border
- Large title with subtle tracking-tight
- Muted description text
- Status badge in top area

### Cards & Panels
- rounded-lg border border-border bg-card
- Consistent p-6 padding
- No heavy shadows - rely on border contrast

### Tables
- Clean header with bg-muted/50
- Subtle hover states on rows
- Badge-based status indicators
- Action buttons aligned right

### Buttons
- Primary: Purple background for main actions
- Outline: For secondary actions (filters, export)
- Ghost: For tertiary actions (settings, close)

### Badges
- Default: Purple for active/1st degree
- Secondary: Gray for 2nd degree
- Outline: For 3rd degree and metadata

### Inputs
- h-12 for primary search input
- Standard height for filter inputs
- Icon prefix for search with pl-12

## Responsive Behavior

**Breakpoints**:
- Mobile (base): Single column, stacked layout
- Desktop (md:): Full table layout, multi-column filters

**Mobile Optimizations**:
- Convert table to cards
- Stack filter controls
- Full-width buttons with flex-wrap
- Larger touch targets

## Accessibility

- All form inputs have associated labels
- Status messages use semantic colors
- Focus indicators on interactive elements
- ARIA labels for icon-only buttons
- Keyboard navigation support
