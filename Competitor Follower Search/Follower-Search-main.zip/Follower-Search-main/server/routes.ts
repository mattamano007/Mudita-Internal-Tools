import type { Express } from "express";
import { createServer, type Server } from "http";
import { parseRequestSchema, startScrapeRequestSchema, enrichRequestSchema, insertUserSchema, type ScrapedFollower, type ScrapeJob } from "@shared/schema";
import { parseCSV, parsePastedText } from "./parseFollowers";
import { scrapeCompanyFollowers } from "./linkedin-scraper";
import { storage } from "./storage";
import bcrypt from "bcryptjs";
import { z } from "zod";

// In-memory storage for scrape jobs
const scrapeJobs = new Map<string, ScrapeJob>();

// Feature flag for real scraping vs mock data
const USE_REAL_SCRAPING = process.env.USE_REAL_SCRAPING === "true";

function generateId(): string {
  return `job_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

function generateFollowerId(): string {
  return `follower_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

// Auth request schemas
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Login endpoint
  app.post("/api/auth/login", async (req, res) => {
    try {
      const result = loginSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ success: false, message: "Invalid email or password format" });
      }

      const { email, password } = result.data;
      const user = await storage.getUserByUsername(email);
      
      if (!user) {
        return res.status(401).json({ success: false, message: "Invalid email or password" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ success: false, message: "Invalid email or password" });
      }

      // Set server-side session
      if (req.session) {
        req.session.userId = user.id;
        req.session.userEmail = user.username;
      }

      return res.json({ 
        success: true, 
        user: { id: user.id, email: user.username }
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ success: false, message: "Login failed" });
    }
  });

  // Register endpoint
  app.post("/api/auth/register", async (req, res) => {
    try {
      const result = registerSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          message: result.error.errors[0]?.message || "Invalid registration data" 
        });
      }

      const { email, password } = result.data;
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(email);
      if (existingUser) {
        return res.status(400).json({ success: false, message: "Account already exists with this email" });
      }

      // Hash password and create user
      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({ username: email, password: hashedPassword });

      // Set server-side session
      if (req.session) {
        req.session.userId = user.id;
        req.session.userEmail = user.username;
      }

      return res.json({ 
        success: true, 
        user: { id: user.id, email: user.username }
      });
    } catch (error) {
      console.error("Registration error:", error);
      return res.status(500).json({ success: false, message: "Registration failed" });
    }
  });

  // Get current user (check session)
  app.get("/api/auth/me", async (req, res) => {
    if (req.session?.userId) {
      return res.json({ 
        user: { id: req.session.userId, email: req.session.userEmail }
      });
    }
    return res.json({ user: null });
  });

  // Logout endpoint
  app.post("/api/auth/logout", (req, res) => {
    req.session = null;
    return res.json({ success: true });
  });
  // Start a new scrape job
  app.post("/api/scrape", async (req, res) => {
    try {
      const result = startScrapeRequestSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid LinkedIn URL",
          errors: result.error.flatten()
        });
      }

      const { competitorUrl } = result.data;
      
      // Validate LinkedIn URL format
      if (!competitorUrl.includes("linkedin.com/company/")) {
        return res.status(400).json({
          success: false,
          message: "Please enter a valid LinkedIn company URL (e.g., https://linkedin.com/company/acme)"
        });
      }
      
      // Extract company name from URL
      const urlMatch = competitorUrl.match(/linkedin\.com\/company\/([^\/\?]+)/);
      const competitorName = urlMatch ? urlMatch[1].replace(/-/g, ' ') : 'Unknown Company';
      
      const jobId = generateId();
      const now = new Date().toISOString();
      
      const job: ScrapeJob = {
        id: jobId,
        competitorUrl,
        competitorName,
        status: "pending",
        progress: 0,
        totalFollowers: 0,
        scrapedCount: 0,
        enrichedCount: 0,
        followers: [],
        createdAt: now,
        updatedAt: now,
        mode: USE_REAL_SCRAPING ? "real" : "demo",
      };
      
      scrapeJobs.set(jobId, job);
      
      // Start scraping in background
      if (USE_REAL_SCRAPING) {
        startRealScrapeProcess(jobId, competitorUrl);
      } else {
        startMockScrapeProcess(jobId, competitorName);
      }
      
      return res.json({ 
        success: true, 
        job
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false, 
        message: "Failed to start scrape job" 
      });
    }
  });

  // Get scrape job status
  app.get("/api/scrape/:jobId", async (req, res) => {
    const { jobId } = req.params;
    const job = scrapeJobs.get(jobId);
    
    if (!job) {
      return res.status(404).json({ 
        success: false, 
        message: "Job not found" 
      });
    }
    
    return res.json({ success: true, job });
  });

  // Enrich followers with Apollo
  app.post("/api/enrich", async (req, res) => {
    try {
      const result = enrichRequestSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request",
          errors: result.error.flatten()
        });
      }

      const { jobId, followerIds } = result.data;
      const job = scrapeJobs.get(jobId);
      
      if (!job) {
        return res.status(404).json({ 
          success: false, 
          message: "Job not found" 
        });
      }

      // Check for Apollo API key
      const apolloApiKey = process.env.APOLLO_API_KEY;
      if (!apolloApiKey) {
        return res.status(400).json({
          success: false,
          message: "Apollo API key not configured. Please add APOLLO_API_KEY to your secrets."
        });
      }

      // Start enrichment process
      job.status = "enriching";
      job.updatedAt = new Date().toISOString();
      scrapeJobs.set(jobId, job);

      // Enrich in background
      enrichFollowers(jobId, followerIds || job.followers.map(f => f.id), apolloApiKey);
      
      return res.json({ 
        success: true, 
        message: "Enrichment started",
        job
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false, 
        message: "Failed to start enrichment" 
      });
    }
  });

  // Parse followers from CSV or pasted text (legacy support)
  app.post("/api/parse", async (req, res) => {
    try {
      const result = parseRequestSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          followers: [],
          total: 0,
          duplicatesRemoved: 0,
          errors: ["Invalid request format"]
        });
      }

      const { content, source } = result.data;
      
      let parseResult;
      if (source === "salesnav_export_csv") {
        parseResult = parseCSV(content);
      } else {
        parseResult = parsePastedText(content);
      }

      const uniqueCompanies = new Set(parseResult.followers.map(f => f.company_name.toLowerCase())).size;
      const withProfileUrl = parseResult.followers.filter(f => f.profile_url).length;
      const withTitle = parseResult.followers.filter(f => f.title).length;
      const incompleteProfiles = parseResult.followers.filter(f => !f.person_name || !f.title || !f.profile_url).length;

      const warnings: string[] = [];
      if (incompleteProfiles > 0) {
        warnings.push(`${incompleteProfiles} profiles are missing some information (name, title, or profile URL)`);
      }

      return res.json({
        success: parseResult.errors.length === 0 || parseResult.followers.length > 0,
        followers: parseResult.followers,
        total: parseResult.followers.length,
        duplicatesRemoved: parseResult.duplicatesRemoved,
        errors: parseResult.errors.length > 0 ? parseResult.errors : undefined,
        warnings: warnings.length > 0 ? warnings : undefined,
        stats: {
          uniqueCompanies,
          withProfileUrl,
          withTitle,
          incompleteProfiles,
        }
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false, 
        followers: [],
        total: 0,
        duplicatesRemoved: 0,
        errors: ["Failed to parse content"]
      });
    }
  });

  return httpServer;
}

// Real LinkedIn scraping with Playwright
async function startRealScrapeProcess(jobId: string, competitorUrl: string) {
  const job = scrapeJobs.get(jobId);
  if (!job) return;

  try {
    await scrapeCompanyFollowers(competitorUrl, (progress) => {
      job.status = progress.status;
      job.progress = progress.progress;
      job.totalFollowers = progress.totalFollowers;
      job.scrapedCount = progress.scrapedCount;
      job.followers = progress.followers;
      job.error = progress.error;
      job.updatedAt = new Date().toISOString();
      scrapeJobs.set(jobId, job);
    });
  } catch (error: any) {
    job.status = "failed";
    job.error = error.message || "Scraping failed";
    job.updatedAt = new Date().toISOString();
    scrapeJobs.set(jobId, job);
  }
}

// Mock scrape process for testing/demo
async function startMockScrapeProcess(jobId: string, competitorName: string) {
  const job = scrapeJobs.get(jobId);
  if (!job) return;

  // Update status to scraping
  job.status = "scraping";
  job.updatedAt = new Date().toISOString();
  scrapeJobs.set(jobId, job);

  // Generate mock followers
  const mockFollowers: ScrapedFollower[] = generateMockFollowers(competitorName);
  job.totalFollowers = mockFollowers.length;
  
  // Simulate progress
  for (let i = 0; i < mockFollowers.length; i++) {
    await new Promise(resolve => setTimeout(resolve, 150));
    job.followers.push(mockFollowers[i]);
    job.scrapedCount = i + 1;
    job.progress = Math.round(((i + 1) / mockFollowers.length) * 100);
    job.updatedAt = new Date().toISOString();
    scrapeJobs.set(jobId, job);
  }

  job.status = "completed";
  job.updatedAt = new Date().toISOString();
  scrapeJobs.set(jobId, job);
}

// Enrich followers with Apollo API
async function enrichFollowers(jobId: string, followerIds: string[], apiKey: string) {
  const job = scrapeJobs.get(jobId);
  if (!job) return;

  const followersToEnrich = job.followers.filter(f => followerIds.includes(f.id));
  
  for (const follower of followersToEnrich) {
    try {
      // Call Apollo API for people match
      const response = await fetch('https://api.apollo.io/api/v1/people/match', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Api-Key': apiKey,
          'Cache-Control': 'no-cache',
        },
        body: JSON.stringify({
          first_name: follower.firstName,
          last_name: follower.lastName,
          organization_name: follower.company,
          domain: follower.companyDomain,
          reveal_personal_emails: false,
          reveal_phone_number: false,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.person?.email) {
          follower.email = data.person.email;
          follower.emailConfidence = data.person.email_status === 'verified' ? 100 : 70;
          follower.enrichmentStatus = "found";
        } else {
          follower.enrichmentStatus = "not_found";
        }
      } else {
        const errorText = await response.text();
        console.error("Apollo API error:", response.status, errorText);
        follower.enrichmentStatus = "error";
      }
    } catch (error) {
      console.error("Enrichment error:", error);
      follower.enrichmentStatus = "error";
    }
    
    follower.enrichedAt = new Date().toISOString();
    job.enrichedCount++;
    job.updatedAt = new Date().toISOString();
    scrapeJobs.set(jobId, job);

    // Small delay between API calls to respect rate limits
    await new Promise(resolve => setTimeout(resolve, 200));
  }

  job.status = "completed";
  job.updatedAt = new Date().toISOString();
  scrapeJobs.set(jobId, job);
}

// Generate mock followers for testing
function generateMockFollowers(companyName: string): ScrapedFollower[] {
  const titles = [
    "CEO", "CFO", "CTO", "VP Sales", "VP Finance", "Director of Finance",
    "Head of Marketing", "Senior Engineer", "Product Manager", "Operations Manager"
  ];
  
  const companies = [
    "Tech Innovators", "Growth Partners", "Digital Solutions", "Cloud Systems",
    "Analytics Pro", "Data Insights"
  ];
  
  const firstNames = ["James", "Emma", "Michael", "Sarah", "David", "Lisa", "Robert", "Jennifer", "William", "Amanda"];
  const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Wilson", "Anderson", "Taylor"];

  return Array.from({ length: 12 }, (_, i) => {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const company = companies[Math.floor(Math.random() * companies.length)];
    
    return {
      id: generateFollowerId(),
      name: `${firstName} ${lastName}`,
      firstName,
      lastName,
      title: titles[Math.floor(Math.random() * titles.length)],
      company,
      companyDomain: `${company.toLowerCase().replace(/\s+/g, '')}.com`,
      profileUrl: `https://linkedin.com/in/${firstName.toLowerCase()}-${lastName.toLowerCase()}-${i}`,
      location: "San Francisco, CA",
      connectionDegree: "2nd",
      enrichmentStatus: "pending" as const,
    };
  });
}
