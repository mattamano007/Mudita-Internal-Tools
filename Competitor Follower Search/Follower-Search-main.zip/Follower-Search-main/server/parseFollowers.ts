import type { ImportedFollower } from "@shared/schema";

const HEADER_MAPPINGS: Record<string, string[]> = {
  person_name: [
    "name", "full name", "fullname", "first name", "firstname", "contact name", "lead name",
    "person", "contact", "member name", "member", "account holder", "lead", "prospect",
    "first", "last name", "lastname", "given name"
  ],
  title: [
    "title", "job title", "jobtitle", "position", "role", "current title",
    "job", "occupation", "designation", "function", "current position",
    "current role", "professional title"
  ],
  company_name: [
    "company", "company name", "companyname", "current company", "organization", "employer",
    "works at", "employer name", "account", "account name", "org", "organisation",
    "business", "firm", "workplace", "current employer", "current organization"
  ],
  company_url: [
    "company url", "companyurl", "company website", "company link", "organization url",
    "company linkedin", "company profile", "org url", "website", "company site"
  ],
  profile_url: [
    "profile url", "profileurl", "linkedin url", "linkedinurl", "linkedin", "profile link", "url",
    "profile", "member url", "person url", "contact url", "link", "sales navigator url",
    "public profile url", "linkedin profile"
  ],
  location: [
    "location", "geography", "city", "state", "country", "region", "area", "address",
    "geo", "place", "locale"
  ],
  industry: [
    "industry", "sector", "vertical", "market", "field", "domain", "business type"
  ],
  company_size: [
    "company size", "companysize", "employees", "company employees", "headcount", "size",
    "number of employees", "employee count", "org size", "team size"
  ],
  headline: [
    "headline", "tagline", "summary", "bio", "about", "description", "professional headline"
  ],
};

function normalizeHeader(header: string): string {
  return header
    .toLowerCase()
    .trim()
    .replace(/[_\-\.]/g, " ")
    .replace(/\s+/g, " ")
    .replace(/['"]/g, "");
}

function matchHeader(header: string): string | null {
  const normalized = normalizeHeader(header);
  
  for (const [field, patterns] of Object.entries(HEADER_MAPPINGS)) {
    for (const pattern of patterns) {
      if (normalized === pattern || normalized.includes(pattern) || pattern.includes(normalized)) {
        return field;
      }
    }
  }
  
  if (normalized.includes("company") || normalized.includes("org") || normalized.includes("employer")) {
    if (!normalized.includes("url") && !normalized.includes("link") && !normalized.includes("website")) {
      return "company_name";
    }
  }
  if (normalized.includes("name") && !normalized.includes("company")) {
    return "person_name";
  }
  
  return null;
}

function normalizeCompanyName(name: string): string {
  return name
    .trim()
    .replace(/\s+/g, " ")
    .replace(/[.,;:!?]+$/, "")
    .trim();
}

function generateId(): string {
  return `import_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

function createDedupeKey(follower: Partial<ImportedFollower>): string {
  if (follower.profile_url) {
    return `url:${follower.profile_url.toLowerCase().trim()}`;
  }
  if (follower.company_url && follower.person_name) {
    return `companyurl:${follower.company_url.toLowerCase().trim()}|${follower.person_name.toLowerCase().trim()}`;
  }
  const name = (follower.person_name || "").toLowerCase().trim();
  const company = (follower.company_name || "").toLowerCase().trim();
  const title = (follower.title || "").toLowerCase().trim();
  return `composite:${name}|${company}|${title}`;
}

export function parseCSV(content: string): { followers: ImportedFollower[]; errors: string[]; duplicatesRemoved: number } {
  const errors: string[] = [];
  const lines = content.split(/\r?\n/).filter(line => line.trim());
  
  if (lines.length < 2) {
    errors.push("CSV must have at least a header row and one data row");
    return { followers: [], errors, duplicatesRemoved: 0 };
  }

  const headerLine = lines[0];
  const headers = parseCSVLine(headerLine);
  
  const columnMap: Record<number, string> = {};
  let hasCompanyColumn = false;
  
  headers.forEach((header, index) => {
    const field = matchHeader(header);
    if (field) {
      columnMap[index] = field;
      if (field === "company_name") {
        hasCompanyColumn = true;
      }
    }
  });

  if (!hasCompanyColumn) {
    errors.push("No recognizable company column found. Expected headers like: Company, Company Name, Current Company, Organization");
    return { followers: [], errors, duplicatesRemoved: 0 };
  }

  const timestamp = new Date().toISOString();
  const seen = new Set<string>();
  const followers: ImportedFollower[] = [];
  let duplicatesRemoved = 0;

  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    if (values.length === 0 || values.every(v => !v.trim())) continue;

    const row: Partial<ImportedFollower> = {};
    
    for (const [indexStr, field] of Object.entries(columnMap)) {
      const index = parseInt(indexStr);
      const value = values[index]?.trim();
      if (value) {
        if (field === "company_name") {
          row[field] = normalizeCompanyName(value);
        } else {
          (row as Record<string, string>)[field] = value;
        }
      }
    }

    if (!row.company_name) continue;

    const dedupeKey = createDedupeKey(row);
    if (seen.has(dedupeKey)) {
      duplicatesRemoved++;
      continue;
    }
    seen.add(dedupeKey);

    followers.push({
      id: generateId(),
      person_name: row.person_name,
      title: row.title,
      company_name: row.company_name,
      company_url: row.company_url,
      profile_url: row.profile_url,
      location: row.location,
      industry: row.industry,
      company_size: row.company_size,
      headline: row.headline,
      source: "salesnav_export_csv",
      import_timestamp: timestamp,
    });
  }

  if (followers.length === 0) {
    errors.push("No valid follower rows found in CSV");
  }

  return { followers, errors, duplicatesRemoved };
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      result.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  
  return result;
}

export function parsePastedText(content: string): { followers: ImportedFollower[]; errors: string[]; duplicatesRemoved: number } {
  const errors: string[] = [];
  const lines = content.split(/\r?\n/).filter(line => line.trim());
  
  if (lines.length === 0) {
    errors.push("No content to parse");
    return { followers: [], errors, duplicatesRemoved: 0 };
  }

  const delimiter = detectDelimiter(lines[0]);
  
  if (delimiter) {
    return parseDelimitedText(lines, delimiter);
  }
  
  // Check if it looks like CSV (comma-separated with recognizable headers)
  if (looksLikeCSVWithHeaders(lines[0])) {
    return parseCSV(content);
  }
  
  return parseUnstructuredText(lines);
}

function looksLikeCSVWithHeaders(firstLine: string): boolean {
  const commaCount = (firstLine.match(/,/g) || []).length;
  if (commaCount < 2) return false;
  
  // Check if commas separate words that look like headers
  const parts = firstLine.split(",").map(p => p.trim().toLowerCase());
  let headerMatches = 0;
  
  for (const part of parts) {
    if (matchHeader(part)) {
      headerMatches++;
    }
  }
  
  // If at least 2 parts match known headers, treat as CSV
  return headerMatches >= 2;
}

function detectDelimiter(line: string): string | null {
  const tabCount = (line.match(/\t/g) || []).length;
  const pipeCount = (line.match(/\|/g) || []).length;
  const semicolonCount = (line.match(/;/g) || []).length;
  
  if (tabCount >= 2) return "\t";
  if (pipeCount >= 2) return "|";
  if (semicolonCount >= 2) return ";";
  return null;
}

function parseDelimitedText(lines: string[], delimiter: string): { followers: ImportedFollower[]; errors: string[]; duplicatesRemoved: number } {
  const errors: string[] = [];
  const headers = lines[0].split(delimiter).map(h => h.trim());
  
  const columnMap: Record<number, string> = {};
  let hasCompanyColumn = false;
  
  headers.forEach((header, index) => {
    const field = matchHeader(header);
    if (field) {
      columnMap[index] = field;
      if (field === "company_name") hasCompanyColumn = true;
    }
  });

  if (!hasCompanyColumn && headers.length >= 3) {
    columnMap[2] = "company_name";
    hasCompanyColumn = true;
    if (!columnMap[0]) columnMap[0] = "person_name";
    if (!columnMap[1]) columnMap[1] = "title";
  } else if (!hasCompanyColumn && headers.length === 2) {
    columnMap[1] = "company_name";
    hasCompanyColumn = true;
    if (!columnMap[0]) columnMap[0] = "person_name";
  } else if (!hasCompanyColumn && headers.length === 1) {
    columnMap[0] = "company_name";
    hasCompanyColumn = true;
  }

  if (!hasCompanyColumn) {
    errors.push("Could not identify company column in pasted data");
    return { followers: [], errors, duplicatesRemoved: 0 };
  }

  const timestamp = new Date().toISOString();
  const seen = new Set<string>();
  const followers: ImportedFollower[] = [];
  let duplicatesRemoved = 0;

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(delimiter).map(v => v.trim());
    if (values.every(v => !v)) continue;

    const row: Partial<ImportedFollower> = {};
    
    for (const [indexStr, field] of Object.entries(columnMap)) {
      const index = parseInt(indexStr);
      const value = values[index]?.trim();
      if (value) {
        if (field === "company_name") {
          row[field] = normalizeCompanyName(value);
        } else {
          (row as Record<string, string>)[field] = value;
        }
      }
    }

    if (!row.company_name) continue;

    const dedupeKey = createDedupeKey(row);
    if (seen.has(dedupeKey)) {
      duplicatesRemoved++;
      continue;
    }
    seen.add(dedupeKey);

    followers.push({
      id: generateId(),
      person_name: row.person_name,
      title: row.title,
      company_name: row.company_name,
      company_url: row.company_url,
      profile_url: row.profile_url,
      location: row.location,
      industry: row.industry,
      company_size: row.company_size,
      headline: row.headline,
      source: "pasted_text",
      import_timestamp: timestamp,
    });
  }

  return { followers, errors, duplicatesRemoved };
}

function parseUnstructuredText(lines: string[]): { followers: ImportedFollower[]; errors: string[]; duplicatesRemoved: number } {
  const errors: string[] = [];
  const timestamp = new Date().toISOString();
  const seen = new Set<string>();
  const followers: ImportedFollower[] = [];
  let duplicatesRemoved = 0;

  for (const line of lines) {
    const parsed = extractPersonCompanyFromLine(line);
    
    if (!parsed.company_name || parsed.company_name.length < 2) continue;

    const row: Partial<ImportedFollower> = parsed;
    const dedupeKey = createDedupeKey(row);
    
    if (seen.has(dedupeKey)) {
      duplicatesRemoved++;
      continue;
    }
    seen.add(dedupeKey);

    followers.push({
      id: generateId(),
      person_name: parsed.person_name,
      title: parsed.title,
      company_name: parsed.company_name,
      profile_url: parsed.profile_url,
      source: "pasted_text",
      import_timestamp: timestamp,
    });
  }

  if (followers.length === 0) {
    errors.push("Could not extract any company names from the pasted text");
  }

  return { followers, errors, duplicatesRemoved };
}

function extractPersonCompanyFromLine(line: string): Partial<ImportedFollower> {
  const result: Partial<ImportedFollower> = {};
  
  const linkedinMatch = line.match(/(https?:\/\/(?:www\.)?linkedin\.com\/in\/[^\s,|]+)/i);
  if (linkedinMatch) {
    result.profile_url = linkedinMatch[1];
  }
  
  const cleanLine = line
    .replace(/(https?:\/\/[^\s,|]+)/g, "")
    .trim();

  const patterns = [
    /^(.+?)\s*[-–—]\s*(.+?)\s+(?:at|@)\s+(.+)$/i,
    /^(.+?)\s*,\s*(.+?)\s*,\s*(.+)$/,
    /^(.+?)\s+(?:at|@)\s+(.+)$/i,
    /^(.+?)\s*[-–—]\s*(.+)$/,
    /^(.+?)\s*\|\s*(.+?)\s*\|\s*(.+)$/,
    /^(.+?)\s*\|\s*(.+)$/,
  ];

  for (const pattern of patterns) {
    const match = cleanLine.match(pattern);
    if (match) {
      if (match.length === 4) {
        result.person_name = match[1].trim();
        result.title = match[2].trim();
        result.company_name = normalizeCompanyName(match[3]);
        return result;
      } else if (match.length === 3) {
        const part1 = match[1].trim();
        const part2 = match[2].trim();
        
        if (looksLikeTitle(part2)) {
          result.person_name = part1;
          result.title = part2;
        } else if (looksLikeCompany(part2)) {
          result.person_name = part1;
          result.company_name = normalizeCompanyName(part2);
        } else if (looksLikeTitle(part1)) {
          result.title = part1;
          result.company_name = normalizeCompanyName(part2);
        } else {
          result.person_name = part1;
          result.company_name = normalizeCompanyName(part2);
        }
        return result;
      }
    }
  }

  if (cleanLine.length >= 2) {
    result.company_name = normalizeCompanyName(cleanLine);
  }

  return result;
}

function looksLikeTitle(text: string): boolean {
  const titleKeywords = [
    "ceo", "cfo", "cto", "coo", "cmo", "cpo", "vp", "vice president",
    "director", "manager", "head", "lead", "senior", "junior", "associate",
    "engineer", "developer", "designer", "analyst", "consultant", "specialist",
    "coordinator", "executive", "president", "founder", "owner", "partner",
    "chief", "principal", "architect", "scientist", "researcher", "professor"
  ];
  const lower = text.toLowerCase();
  return titleKeywords.some(keyword => lower.includes(keyword));
}

function looksLikeCompany(text: string): boolean {
  const companyKeywords = [
    "inc", "llc", "ltd", "corp", "corporation", "company", "co.",
    "group", "holdings", "enterprises", "solutions", "services",
    "technologies", "tech", "software", "systems", "consulting",
    "partners", "associates", "labs", "studio", "studios", "agency"
  ];
  const lower = text.toLowerCase();
  return companyKeywords.some(keyword => lower.includes(keyword));
}
