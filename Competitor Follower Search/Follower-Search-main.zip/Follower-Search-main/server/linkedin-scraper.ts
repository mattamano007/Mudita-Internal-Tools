import { chromium, Browser, BrowserContext } from "playwright";
import type { ScrapedFollower } from "@shared/schema";

interface ScrapeProgress {
  status: "authenticating" | "scraping" | "completed" | "failed";
  progress: number;
  totalFollowers: number;
  scrapedCount: number;
  followers: ScrapedFollower[];
  error?: string;
}

type ProgressCallback = (progress: ScrapeProgress) => void;

let browser: Browser | null = null;
let context: BrowserContext | null = null;

async function getBrowser(): Promise<Browser> {
  if (!browser) {
    browser = await chromium.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--disable-gpu',
        '--window-size=1920x1080',
      ],
    });
  }
  return browser;
}

async function getContext(): Promise<BrowserContext> {
  if (!context) {
    const browserInstance = await getBrowser();
    
    // Check for LinkedIn session cookies in environment
    const linkedInCookies = process.env.LINKEDIN_SESSION_COOKIES;
    
    const contextOptions: any = {
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
      viewport: { width: 1920, height: 1080 },
    };
    
    // If we have a storage state file path, use it
    const storageStatePath = process.env.LINKEDIN_STORAGE_STATE;
    if (storageStatePath) {
      try {
        contextOptions.storageState = storageStatePath;
      } catch (e) {
        console.log("Could not load storage state file");
      }
    }
    
    context = await browserInstance.newContext(contextOptions);
    
    // If we have session cookies as JSON, add them
    if (linkedInCookies) {
      try {
        const cookies = JSON.parse(linkedInCookies);
        await context.addCookies(cookies);
      } catch (e) {
        console.log("Could not parse LinkedIn session cookies");
      }
    }
  }
  return context;
}

function generateFollowerId(): string {
  return `follower_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

function parseName(fullName: string): { firstName: string; lastName: string } {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) {
    return { firstName: parts[0], lastName: "" };
  }
  const firstName = parts[0];
  const lastName = parts.slice(1).join(" ");
  return { firstName, lastName };
}

function extractDomain(companyName: string): string {
  const cleaned = companyName.toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, "");
  return `${cleaned}.com`;
}

export async function scrapeCompanyFollowers(
  companyUrl: string,
  onProgress: ProgressCallback
): Promise<ScrapedFollower[]> {
  const followers: ScrapedFollower[] = [];
  
  try {
    onProgress({
      status: "authenticating",
      progress: 0,
      totalFollowers: 0,
      scrapedCount: 0,
      followers: [],
    });

    const ctx = await getContext();
    const page = await ctx.newPage();

    // Navigate to LinkedIn
    await page.goto("https://www.linkedin.com/", { waitUntil: "domcontentloaded" });
    
    // Check if logged in
    const isLoggedIn = await page.locator('[data-control-name="identity_welcome_message"]').count() > 0 ||
                       await page.locator('.global-nav__me-photo').count() > 0 ||
                       await page.locator('[data-test-id="nav-settings-menu"]').count() > 0;
    
    if (!isLoggedIn) {
      const hasLoginWall = await page.locator('input[id="session_key"]').count() > 0;
      
      if (hasLoginWall) {
        onProgress({
          status: "failed",
          progress: 0,
          totalFollowers: 0,
          scrapedCount: 0,
          followers: [],
          error: "LinkedIn session not configured. Add LINKEDIN_SESSION_COOKIES secret.",
        });
        await page.close();
        return [];
      }
    }

    onProgress({
      status: "scraping",
      progress: 10,
      totalFollowers: 0,
      scrapedCount: 0,
      followers: [],
    });

    // Extract company identifier from URL
    const companyMatch = companyUrl.match(/linkedin\.com\/company\/([^\/\?]+)/);
    if (!companyMatch) {
      onProgress({
        status: "failed",
        progress: 0,
        totalFollowers: 0,
        scrapedCount: 0,
        followers: [],
        error: "Invalid LinkedIn company URL",
      });
      await page.close();
      return [];
    }

    const companyId = companyMatch[1];
    
    // Check if Sales Navigator URL
    const isSalesNav = companyUrl.includes("sales/company") || process.env.USE_SALES_NAVIGATOR === "true";
    
    let targetUrl: string;
    if (isSalesNav) {
      // Sales Navigator company leads page
      targetUrl = `https://www.linkedin.com/sales/search/people?query=(recentSearchParam:(id:${companyId},doLogHistory:true),filters:List((type:CURRENT_COMPANY,values:List((id:${companyId})))))`;
    } else {
      // Regular LinkedIn company people page
      targetUrl = `https://www.linkedin.com/company/${companyId}/people/`;
    }
    
    await page.goto(targetUrl, { waitUntil: "networkidle", timeout: 30000 });
    await page.waitForTimeout(2000);

    // Try to get follower/lead count
    let totalCount = 0;
    try {
      if (isSalesNav) {
        const countText = await page.locator('.search-results__total').textContent();
        if (countText) {
          const match = countText.match(/[\d,]+/);
          if (match) {
            totalCount = parseInt(match[0].replace(/,/g, ""), 10);
          }
        }
      } else {
        const followerText = await page.locator('.org-top-card-secondary-content__follower-count').textContent();
        if (followerText) {
          const match = followerText.match(/[\d,]+/);
          if (match) {
            totalCount = parseInt(match[0].replace(/,/g, ""), 10);
          }
        }
      }
    } catch (e) {
      console.log("Could not get count");
    }

    onProgress({
      status: "scraping",
      progress: 30,
      totalFollowers: totalCount || 50,
      scrapedCount: 0,
      followers: [],
    });

    // Scroll and collect people
    let previousHeight = 0;
    let scrollAttempts = 0;
    const maxScrollAttempts = 10; // More attempts for Sales Nav
    const maxResults = 100; // Reasonable limit per scrape
    
    while (scrollAttempts < maxScrollAttempts && followers.length < maxResults) {
      // Different selectors for Sales Nav vs regular LinkedIn
      const cardSelector = isSalesNav 
        ? '.search-results__result-item'
        : '.org-people-profile-card';
      
      const profileCards = await page.locator(cardSelector).all();
      
      for (const card of profileCards) {
        if (followers.length >= maxResults) break;
        
        try {
          let name = "";
          let title = "";
          let profileUrl = "";
          let company = "";
          
          if (isSalesNav) {
            // Sales Navigator selectors
            const nameEl = await card.locator('.result-lockup__name a').first();
            const titleEl = await card.locator('.result-lockup__highlight-keyword').first();
            const companyEl = await card.locator('.result-lockup__position-company a').first();
            
            name = await nameEl.textContent() || "";
            title = await titleEl.textContent() || "";
            company = await companyEl.textContent() || "";
            profileUrl = await nameEl.getAttribute("href") || "";
          } else {
            // Regular LinkedIn selectors
            const nameEl = await card.locator('.org-people-profile-card__profile-title').first();
            const titleEl = await card.locator('.artdeco-entity-lockup__subtitle').first();
            const linkEl = await card.locator('a[href*="/in/"]').first();
            
            name = await nameEl.textContent() || "";
            title = await titleEl.textContent() || "";
            company = companyId.replace(/-/g, " ");
            profileUrl = await linkEl.getAttribute("href") || "";
          }
          
          if (name && !followers.some(f => f.profileUrl === profileUrl)) {
            const { firstName, lastName } = parseName(name.trim());
            
            followers.push({
              id: generateFollowerId(),
              name: name.trim(),
              firstName,
              lastName,
              title: title.trim(),
              company: company.trim() || companyId.replace(/-/g, " "),
              companyDomain: extractDomain(company || companyId),
              profileUrl: profileUrl.startsWith("http") ? profileUrl : `https://www.linkedin.com${profileUrl}`,
              enrichmentStatus: "pending",
            });
          }
        } catch (e) {
          // Skip invalid cards
        }
      }

      onProgress({
        status: "scraping",
        progress: 30 + Math.min(60, (followers.length / maxResults) * 60),
        totalFollowers: Math.max(totalCount, followers.length),
        scrapedCount: followers.length,
        followers: [...followers],
      });

      // Scroll down
      const currentHeight = await page.evaluate(() => document.body.scrollHeight);
      if (currentHeight === previousHeight) {
        scrollAttempts++;
      } else {
        scrollAttempts = 0;
      }
      previousHeight = currentHeight;

      await page.evaluate(() => window.scrollBy(0, 500));
      await page.waitForTimeout(1000);

      // Check for pagination / "Show more" button
      const showMoreBtn = isSalesNav
        ? await page.locator('button.search-results__pagination-next-button').first()
        : await page.locator('button:has-text("Show more results")').first();
        
      if (await showMoreBtn.count() > 0) {
        try {
          await showMoreBtn.click();
          await page.waitForTimeout(2000);
        } catch (e) {
          // Button might not be clickable
        }
      }
    }

    await page.close();

    onProgress({
      status: "completed",
      progress: 100,
      totalFollowers: followers.length,
      scrapedCount: followers.length,
      followers,
    });

    return followers;

  } catch (error: any) {
    console.error("Scraping error:", error);
    onProgress({
      status: "failed",
      progress: 0,
      totalFollowers: 0,
      scrapedCount: 0,
      followers: [],
      error: error.message || "Failed to scrape followers",
    });
    return [];
  }
}

// Force new context on next scrape (useful after updating cookies)
export async function resetContext(): Promise<void> {
  if (context) {
    await context.close();
    context = null;
  }
}

export async function closeBrowser(): Promise<void> {
  if (context) {
    await context.close();
    context = null;
  }
  if (browser) {
    await browser.close();
    browser = null;
  }
}
