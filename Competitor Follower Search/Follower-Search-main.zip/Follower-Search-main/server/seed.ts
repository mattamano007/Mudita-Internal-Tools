import { db } from "./db";
import { users } from "@shared/schema";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("Seeding database...");
  
  const email = "gtm@muditastudios.com";
  const password = "Mudita";
  
  // Check if user already exists
  const [existingUser] = await db.select().from(users).where(eq(users.username, email));
  
  if (existingUser) {
    console.log(`User ${email} already exists, skipping...`);
  } else {
    const hashedPassword = await bcrypt.hash(password, 10);
    await db.insert(users).values({
      username: email,
      password: hashedPassword,
    });
    console.log(`Created user: ${email}`);
  }
  
  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch((error) => {
  console.error("Seeding failed:", error);
  process.exit(1);
});
