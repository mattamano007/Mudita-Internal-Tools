import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Scrape Job Status
export const scrapeStatusEnum = z.enum([
  "pending",
  "authenticating", 
  "scraping",
  "enriching",
  "completed",
  "failed"
]);

export type ScrapeStatus = z.infer<typeof scrapeStatusEnum>;

// Enrichment Status
export const enrichmentStatusEnum = z.enum([
  "pending",
  "enriching",
  "found",
  "not_found",
  "error"
]);

export type EnrichmentStatus = z.infer<typeof enrichmentStatusEnum>;

// Scraped Follower - what we get from LinkedIn
export const scrapedFollowerSchema = z.object({
  id: z.string(),
  name: z.string(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  title: z.string().optional(),
  company: z.string().optional(),
  companyDomain: z.string().optional(),
  profileUrl: z.string(),
  imageUrl: z.string().optional(),
  location: z.string().optional(),
  connectionDegree: z.string().optional(),
  // Enrichment fields
  email: z.string().optional(),
  emailConfidence: z.number().optional(),
  phone: z.string().optional(),
  enrichmentStatus: enrichmentStatusEnum.default("pending"),
  enrichedAt: z.string().optional(),
});

export type ScrapedFollower = z.infer<typeof scrapedFollowerSchema>;

// Scrape Mode
export const scrapeModeEnum = z.enum(["demo", "real"]);
export type ScrapeMode = z.infer<typeof scrapeModeEnum>;

// Scrape Job - tracks the overall scraping operation
export const scrapeJobSchema = z.object({
  id: z.string(),
  competitorUrl: z.string(),
  competitorName: z.string().optional(),
  status: scrapeStatusEnum,
  progress: z.number().default(0),
  totalFollowers: z.number().default(0),
  scrapedCount: z.number().default(0),
  enrichedCount: z.number().default(0),
  followers: z.array(scrapedFollowerSchema).default([]),
  error: z.string().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
  mode: scrapeModeEnum.optional(),
});

export type ScrapeJob = z.infer<typeof scrapeJobSchema>;

// Request to start a scrape
export const startScrapeRequestSchema = z.object({
  competitorUrl: z.string().url("Please enter a valid LinkedIn URL"),
});

export type StartScrapeRequest = z.infer<typeof startScrapeRequestSchema>;

// Request to enrich followers
export const enrichRequestSchema = z.object({
  jobId: z.string(),
  followerIds: z.array(z.string()).optional(), // If not provided, enrich all
});

export type EnrichRequest = z.infer<typeof enrichRequestSchema>;

// Apollo Enrichment Response (simplified)
export const apolloPersonSchema = z.object({
  id: z.string().optional(),
  first_name: z.string().optional(),
  last_name: z.string().optional(),
  name: z.string().optional(),
  email: z.string().optional(),
  email_status: z.string().optional(),
  organization_name: z.string().optional(),
  title: z.string().optional(),
  phone_numbers: z.array(z.object({
    raw_number: z.string().optional(),
  })).optional(),
});

export type ApolloPerson = z.infer<typeof apolloPersonSchema>;

// Legacy schemas for backwards compatibility
export const followerSchema = z.object({
  id: z.string(),
  name: z.string(),
  title: z.string(),
  company: z.string(),
  location: z.string(),
  connectionDegree: z.enum(["1st", "2nd", "3rd"]),
  industry: z.string(),
  followingCompany: z.string(),
  profileUrl: z.string(),
  email: z.string(),
});

export type Follower = z.infer<typeof followerSchema>;

export const importedFollowerSchema = z.object({
  id: z.string(),
  person_name: z.string().optional(),
  title: z.string().optional(),
  company_name: z.string(),
  company_url: z.string().optional(),
  profile_url: z.string().optional(),
  company_size: z.string().optional(),
  industry: z.string().optional(),
  location: z.string().optional(),
  headline: z.string().optional(),
  source: z.enum(["salesnav_export_csv", "pasted_text", "linkedin_scrape"]),
  import_timestamp: z.string(),
  email: z.string().optional(),
  emailScore: z.number().optional(),
  enrichmentStatus: enrichmentStatusEnum.optional(),
});

export type ImportedFollower = z.infer<typeof importedFollowerSchema>;

export const parseRequestSchema = z.object({
  content: z.string().min(1, "Content is required"),
  source: z.enum(["salesnav_export_csv", "pasted_text"]),
});

export type ParseRequest = z.infer<typeof parseRequestSchema>;

export const parseResponseSchema = z.object({
  success: z.boolean(),
  followers: z.array(importedFollowerSchema),
  total: z.number(),
  duplicatesRemoved: z.number(),
  errors: z.array(z.string()).optional(),
  warnings: z.array(z.string()).optional(),
  stats: z.object({
    uniqueCompanies: z.number(),
    withProfileUrl: z.number(),
    withTitle: z.number(),
    incompleteProfiles: z.number(),
  }).optional(),
});

export type ParseResponse = z.infer<typeof parseResponseSchema>;
