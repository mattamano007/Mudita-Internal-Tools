import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";

interface AuthContextType {
  isAuthenticated: boolean;
  userEmail: string | null;
  login: (email: string) => void;
  logout: () => Promise<void>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_KEY = "competitor_follower_auth";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check both localStorage and server session
    const checkAuth = async () => {
      // First check localStorage for quick loading
      const stored = localStorage.getItem(AUTH_KEY);
      if (stored) {
        try {
          const data = JSON.parse(stored);
          setIsAuthenticated(true);
          setUserEmail(data.email);
        } catch {
          localStorage.removeItem(AUTH_KEY);
        }
      }
      
      // Then verify with server
      try {
        const res = await fetch("/api/auth/me");
        const data = await res.json();
        if (data.user) {
          setIsAuthenticated(true);
          setUserEmail(data.user.email);
          localStorage.setItem(AUTH_KEY, JSON.stringify({ email: data.user.email, timestamp: Date.now() }));
        } else if (!stored) {
          // Only clear if no localStorage either
          setIsAuthenticated(false);
          setUserEmail(null);
        }
      } catch {
        // Server check failed, rely on localStorage
      }
      
      setIsLoading(false);
    };
    
    checkAuth();
  }, []);

  const login = (email: string) => {
    localStorage.setItem(AUTH_KEY, JSON.stringify({ email, timestamp: Date.now() }));
    setIsAuthenticated(true);
    setUserEmail(email);
  };

  const logout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
    } catch {
      // Logout even if server call fails
    }
    localStorage.removeItem(AUTH_KEY);
    setIsAuthenticated(false);
    setUserEmail(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ isAuthenticated, userEmail, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
