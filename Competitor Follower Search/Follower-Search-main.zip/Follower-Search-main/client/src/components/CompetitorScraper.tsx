import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { ScrapeJob, ScrapedFollower } from "@shared/schema";
import { 
  Search, 
  Download, 
  Loader2, 
  Users, 
  Mail, 
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  Sparkles,
  AlertCircle
} from "lucide-react";

type JobStatus = "idle" | "scraping" | "enriching" | "completed" | "failed";

export default function CompetitorScraper() {
  const [competitorUrl, setCompetitorUrl] = useState("");
  const [currentJob, setCurrentJob] = useState<ScrapeJob | null>(null);
  const [selectedFollowers, setSelectedFollowers] = useState<Set<string>>(new Set());
  const [pollingInterval, setPollingInterval] = useState<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Start scraping mutation
  const scrapeMutation = useMutation({
    mutationFn: async (url: string) => {
      const res = await apiRequest("POST", "/api/scrape", { competitorUrl: url });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        setCurrentJob(data.job);
        startPolling(data.job.id);
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to start scraping",
          variant: "destructive",
        });
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to connect to server",
        variant: "destructive",
      });
    },
  });

  // Enrich mutation
  const enrichMutation = useMutation({
    mutationFn: async (jobId: string) => {
      const followerIds = Array.from(selectedFollowers);
      const res = await apiRequest("POST", "/api/enrich", { 
        jobId, 
        followerIds: followerIds.length > 0 ? followerIds : undefined 
      });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        setCurrentJob(data.job);
        startPolling(data.job.id);
        toast({
          title: "Enrichment Started",
          description: "Finding contact information...",
        });
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to start enrichment",
          variant: "destructive",
        });
      }
    },
  });

  // Poll for job updates
  const startPolling = (jobId: string) => {
    if (pollingInterval) {
      clearInterval(pollingInterval);
    }
    
    let hasAutoSelected = false;
    
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/scrape/${jobId}`);
        const data = await res.json();
        
        if (data.success && data.job) {
          setCurrentJob(data.job);
          
          // Auto-select all followers when scraping completes (only once)
          if (data.job.status === "completed" && data.job.followers.length > 0 && !hasAutoSelected) {
            hasAutoSelected = true;
            setSelectedFollowers(new Set(data.job.followers.map((f: ScrapedFollower) => f.id)));
          }
          
          // Stop polling when done
          if (data.job.status === "completed" || data.job.status === "failed") {
            clearInterval(interval);
            setPollingInterval(null);
          }
        }
      } catch (error) {
        console.error("Polling error:", error);
      }
    }, 500);
    
    setPollingInterval(interval);
  };

  // Cleanup polling on unmount
  useEffect(() => {
    return () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
      }
    };
  }, [pollingInterval]);

  const handleScrape = () => {
    if (!competitorUrl.trim()) {
      toast({
        title: "URL Required",
        description: "Please enter a LinkedIn company URL",
        variant: "destructive",
      });
      return;
    }
    scrapeMutation.mutate(competitorUrl);
  };

  const handleEnrich = () => {
    if (currentJob) {
      enrichMutation.mutate(currentJob.id);
    }
  };

  const handleSelectAll = () => {
    if (currentJob) {
      if (selectedFollowers.size === currentJob.followers.length) {
        setSelectedFollowers(new Set());
      } else {
        setSelectedFollowers(new Set(currentJob.followers.map(f => f.id)));
      }
    }
  };

  const handleToggleFollower = (id: string) => {
    const newSelected = new Set(selectedFollowers);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedFollowers(newSelected);
  };

  const handleExport = () => {
    if (!currentJob) return;
    
    const followersToExport = currentJob.followers.filter(f => selectedFollowers.has(f.id));
    
    const headers = ["Name", "Title", "Company", "Email", "LinkedIn URL", "Location"];
    const rows = followersToExport.map(f => [
      f.name || "",
      f.title || "",
      f.company || "",
      f.email || "",
      f.profileUrl || "",
      f.location || ""
    ]);
    
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(","))
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${currentJob.competitorName || "followers"}_export.csv`;
    link.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Export Complete",
      description: `Exported ${followersToExport.length} contacts`,
    });
  };

  const handleReset = () => {
    setCurrentJob(null);
    setSelectedFollowers(new Set());
    setCompetitorUrl("");
    if (pollingInterval) {
      clearInterval(pollingInterval);
      setPollingInterval(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case "found":
        return <Badge variant="default" className="bg-green-600"><CheckCircle2 className="w-3 h-3 mr-1" />Found</Badge>;
      case "not_found":
        return <Badge variant="secondary"><XCircle className="w-3 h-3 mr-1" />Not Found</Badge>;
      case "error":
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Error</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const isProcessing = Boolean(currentJob && (currentJob.status === "scraping" || currentJob.status === "enriching" || currentJob.status === "authenticating"));

  return (
    <div className="space-y-8">
      {/* URL Input Section */}
      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Search className="w-5 h-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold" data-testid="section-scrape-title">Find Competitor Followers</h2>
          </div>
          
          <p className="text-sm text-muted-foreground">
            Enter a LinkedIn company page URL to scrape their followers and enrich with contact information.
          </p>
          
          <div className="flex gap-3">
            <Input
              type="url"
              placeholder="https://linkedin.com/company/acme-corp"
              value={competitorUrl}
              onChange={(e) => setCompetitorUrl(e.target.value)}
              disabled={isProcessing}
              className="flex-1"
              data-testid="input-competitor-url"
            />
            <Button 
              onClick={handleScrape} 
              disabled={isProcessing || !competitorUrl.trim()}
              data-testid="button-start-scrape"
            >
              {scrapeMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Scrape
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>

      {/* Progress Section */}
      {isProcessing && currentJob && (
        <Card className="p-6" data-testid="section-progress">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Loader2 className="w-5 h-5 animate-spin text-primary" />
                <span className="font-medium">
                  {currentJob.status === "scraping" ? "Scraping followers..." : 
                   currentJob.status === "enriching" ? "Enriching contacts..." :
                   currentJob.status === "authenticating" ? "Authenticating..." : "Processing..."}
                </span>
              </div>
              <span className="text-sm text-muted-foreground">
                {currentJob.scrapedCount} / {currentJob.totalFollowers || "..."}
              </span>
            </div>
            <Progress value={currentJob.progress} className="h-2" />
          </div>
        </Card>
      )}

      {/* Results Section */}
      {currentJob && currentJob.status === "completed" && currentJob.followers.length > 0 && (
        <div className="space-y-4" data-testid="section-results">
          {/* Demo Mode Banner */}
          {currentJob.mode === "demo" && (
            <div className="flex items-center gap-2 p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-md text-sm text-amber-800 dark:text-amber-200" data-testid="banner-demo-mode">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>
                <strong>Demo Mode:</strong> Showing sample data. Real LinkedIn scraping requires authentication setup.
              </span>
            </div>
          )}
          
          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-4">
            <Card className="p-4 text-center">
              <Users className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
              <div className="text-2xl font-bold" data-testid="stat-total">{currentJob.followers.length}</div>
              <div className="text-sm text-muted-foreground">Followers Found</div>
            </Card>
            <Card className="p-4 text-center">
              <Mail className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
              <div className="text-2xl font-bold" data-testid="stat-enriched">
                {currentJob.followers.filter(f => f.enrichmentStatus === "found").length}
              </div>
              <div className="text-sm text-muted-foreground">Emails Found</div>
            </Card>
            <Card className="p-4 text-center">
              <CheckCircle2 className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
              <div className="text-2xl font-bold" data-testid="stat-selected">{selectedFollowers.size}</div>
              <div className="text-sm text-muted-foreground">Selected</div>
            </Card>
          </div>

          {/* Actions Row */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Checkbox
                checked={selectedFollowers.size === currentJob.followers.length}
                onCheckedChange={handleSelectAll}
                data-testid="checkbox-select-all"
              />
              <span className="text-sm text-muted-foreground">Select All</span>
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={handleReset}
                data-testid="button-reset"
              >
                New Search
              </Button>
              
              {currentJob.followers.some(f => f.enrichmentStatus === "pending") && (
                <Button
                  variant="secondary"
                  onClick={handleEnrich}
                  disabled={enrichMutation.isPending || selectedFollowers.size === 0}
                  data-testid="button-enrich"
                >
                  {enrichMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Sparkles className="w-4 h-4 mr-2" />
                  )}
                  Enrich ({selectedFollowers.size})
                </Button>
              )}
              
              <Button
                onClick={handleExport}
                disabled={selectedFollowers.size === 0}
                data-testid="button-export"
              >
                <Download className="w-4 h-4 mr-2" />
                Export CSV ({selectedFollowers.size})
              </Button>
            </div>
          </div>

          {/* Followers Table */}
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="table-followers">
                <thead className="bg-muted/50 border-b">
                  <tr>
                    <th className="w-12 p-3"></th>
                    <th className="text-left p-3 font-medium text-sm">Name</th>
                    <th className="text-left p-3 font-medium text-sm">Title</th>
                    <th className="text-left p-3 font-medium text-sm">Company</th>
                    <th className="text-left p-3 font-medium text-sm">Email</th>
                    <th className="text-left p-3 font-medium text-sm">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {currentJob.followers.map((follower) => (
                    <tr 
                      key={follower.id} 
                      className="border-b hover-elevate"
                      data-testid={`row-follower-${follower.id}`}
                    >
                      <td className="p-3">
                        <Checkbox
                          checked={selectedFollowers.has(follower.id)}
                          onCheckedChange={() => handleToggleFollower(follower.id)}
                          data-testid={`checkbox-follower-${follower.id}`}
                        />
                      </td>
                      <td className="p-3">
                        <a 
                          href={follower.profileUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-primary hover:underline font-medium"
                        >
                          {follower.name}
                        </a>
                      </td>
                      <td className="p-3 text-sm text-muted-foreground">{follower.title || "-"}</td>
                      <td className="p-3 text-sm">{follower.company || "-"}</td>
                      <td className="p-3 text-sm">
                        {follower.email ? (
                          <span className="font-mono text-xs">{follower.email}</span>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </td>
                      <td className="p-3">{getStatusBadge(follower.enrichmentStatus)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* Empty/Error State */}
      {currentJob && currentJob.status === "failed" && (
        <Card className="p-8 text-center" data-testid="section-error">
          <XCircle className="w-12 h-12 mx-auto mb-4 text-destructive" />
          <h3 className="text-lg font-semibold mb-2">Scraping Failed</h3>
          <p className="text-muted-foreground mb-4">{currentJob.error || "An error occurred while scraping followers."}</p>
          <Button variant="outline" onClick={handleReset}>Try Again</Button>
        </Card>
      )}

      {/* Initial State - How it works */}
      {!currentJob && (
        <Card className="p-6 bg-muted/30" data-testid="section-how-it-works">
          <h3 className="font-semibold mb-4">How it works</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <span className="text-sm font-medium">1</span>
              </div>
              <div>
                <h4 className="font-medium mb-1">Enter URL</h4>
                <p className="text-sm text-muted-foreground">Paste a LinkedIn company page URL</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <span className="text-sm font-medium">2</span>
              </div>
              <div>
                <h4 className="font-medium mb-1">Scrape Followers</h4>
                <p className="text-sm text-muted-foreground">We'll extract all company followers</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <span className="text-sm font-medium">3</span>
              </div>
              <div>
                <h4 className="font-medium mb-1">Enrich & Export</h4>
                <p className="text-sm text-muted-foreground">Find emails and download your list</p>
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
