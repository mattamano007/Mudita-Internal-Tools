import CompetitorScraper from "@/components/CompetitorScraper";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

export default function Home() {
  const { logout, userEmail } = useAuth();
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation("/sign-in");
  };

  return (
    <div className="min-h-screen bg-background" data-testid="page-home">
      {/* Clean minimal header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <h1 className="text-xl font-semibold tracking-tight" data-testid="text-app-title">
            Competitor Scraper
          </h1>
          
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground hidden sm:inline">{userEmail}</span>
            <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Sign out</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section - Clean and minimal */}
      <div className="border-b bg-muted/30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 md:py-16">
          <div className="max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight mb-4" data-testid="text-page-title">
              Find your competitor's followers
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-page-description">
              Enter a LinkedIn company URL, scrape their followers, and enrich with contact information. Export your leads in seconds.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8 md:py-12">
        <CompetitorScraper />
      </main>

      {/* Footer */}
      <footer className="border-t mt-auto">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 text-center text-sm text-muted-foreground">
          Powered by browser automation and Apollo enrichment
        </div>
      </footer>
    </div>
  );
}
