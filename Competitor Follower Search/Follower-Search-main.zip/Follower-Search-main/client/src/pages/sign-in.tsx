import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Mail, Lock, ArrowRight, UserPlus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";

type AuthMode = "login" | "register";

export default function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);
  const [mode, setMode] = useState<AuthMode>("login");
  const [, setLocation] = useLocation();
  const { login } = useAuth();

  const loginMutation = useMutation({
    mutationFn: async (data: { email: string; password: string }) => {
      const res = await apiRequest("POST", "/api/auth/login", data);
      return res.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        login(data.user.email);
        setLocation("/");
      } else {
        setError(data.message || "Login failed");
        triggerShake();
      }
    },
    onError: () => {
      setError("Failed to connect to server");
      triggerShake();
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: { email: string; password: string }) => {
      const res = await apiRequest("POST", "/api/auth/register", data);
      return res.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        login(data.user.email);
        setLocation("/");
      } else {
        setError(data.message || "Registration failed");
        triggerShake();
      }
    },
    onError: () => {
      setError("Failed to connect to server");
      triggerShake();
    },
  });

  const triggerShake = () => {
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (mode === "register") {
      if (password !== confirmPassword) {
        setError("Passwords do not match");
        triggerShake();
        return;
      }
      if (password.length < 6) {
        setError("Password must be at least 6 characters");
        triggerShake();
        return;
      }
      registerMutation.mutate({ email, password });
    } else {
      loginMutation.mutate({ email, password });
    }
  };

  const isLoading = loginMutation.isPending || registerMutation.isPending;

  const switchMode = () => {
    setMode(mode === "login" ? "register" : "login");
    setError("");
    setConfirmPassword("");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-semibold tracking-tight mb-2" data-testid="text-app-title">
          Competitor Scraper
        </h1>
        <p className="text-muted-foreground" data-testid="text-subtitle">
          Scrape LinkedIn followers and enrich with contact info
        </p>
      </div>

      <Card 
        className={`w-full max-w-md p-8 ${shake ? 'animate-shake' : ''}`}
      >
        <h2 className="text-xl font-semibold mb-1" data-testid="text-welcome">
          {mode === "login" ? "Welcome back" : "Create an account"}
        </h2>
        <p className="text-sm text-muted-foreground mb-6">
          {mode === "login" 
            ? "Enter your credentials to continue" 
            : "Enter your details to get started"}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10"
                required
                aria-label="Email address"
                data-testid="input-email"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                placeholder={mode === "register" ? "At least 6 characters" : "Enter your password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10"
                required
                aria-label="Password"
                data-testid="input-password"
              />
            </div>
          </div>

          {mode === "register" && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Confirm your password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="pl-10"
                  required
                  aria-label="Confirm password"
                  data-testid="input-confirm-password"
                />
              </div>
            </div>
          )}

          {error && (
            <p className="text-sm text-destructive text-center" data-testid="text-error">
              {error}
            </p>
          )}

          <Button 
            type="submit" 
            className="w-full"
            disabled={isLoading}
            data-testid="button-submit"
          >
            {isLoading ? (
              mode === "login" ? "Signing in..." : "Creating account..."
            ) : (
              <>
                {mode === "login" ? "Sign In" : "Create Account"}
                {mode === "login" ? (
                  <ArrowRight className="w-4 h-4 ml-2" />
                ) : (
                  <UserPlus className="w-4 h-4 ml-2" />
                )}
              </>
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={switchMode}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="button-switch-mode"
          >
            {mode === "login" 
              ? "Don't have an account? Create one" 
              : "Already have an account? Sign in"}
          </button>
        </div>
      </Card>

      <p className="mt-6 text-sm text-muted-foreground">
        Powered by browser automation
      </p>
    </div>
  );
}
