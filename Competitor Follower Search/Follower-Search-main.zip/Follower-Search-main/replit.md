# Competitor Follower Scraper

## Overview
A tool for scraping LinkedIn competitor followers and enriching them with contact information. Users enter a LinkedIn company URL, the app scrapes followers, enriches data with Apollo API, and exports clean contact lists.

## Features
- **LinkedIn Scraping**: Enter a competitor's LinkedIn company URL to scrape their followers
- **Apollo Enrichment**: Enrich scraped contacts with email addresses via Apollo API
- **CSV Export**: Download enriched contact lists as CSV
- **Authentication**: Simple sign-in with hardcoded credentials (MVP)
  - Email: gtm@muditastudios.com, Password: Mudita

## Design System
- **Aesthetic**: Cursor/Rivian/OpenAI-inspired minimalist design
- **Colors**: Neutral grays, clean whites, subtle borders
- **Typography**: Inter font family
- **Layout**: Clean, spacious, minimal visual noise

## Project Architecture

### Frontend (`client/src/`)
- **pages/sign-in.tsx**: Clean authentication page
- **pages/home.tsx**: Main app with hero and scraper
- **components/CompetitorScraper.tsx**: Core component
  - URL input for LinkedIn company pages
  - Progress indicator during scraping
  - Results table with selection
  - Enrich and Export buttons
- **hooks/use-auth.tsx**: AuthProvider for session management

### Backend (`server/`)
- **routes.ts**: API endpoints
  - `POST /api/scrape`: Start a scrape job for a LinkedIn company URL
  - `GET /api/scrape/:jobId`: Get scrape job status and results
  - `POST /api/enrich`: Enrich followers with Apollo API
  - `POST /api/parse`: Legacy CSV/text parsing (for manual import)
- **linkedin-scraper.ts**: Playwright-based LinkedIn scraper
  - Scrapes company people/followers
  - Handles pagination and scrolling
  - Falls back to mock data when real scraping not enabled
- **parseFollowers.ts**: CSV/text parsing engine (legacy)

### Shared (`shared/schema.ts`)
- **ScrapeJob**: Tracks scraping operations (id, status, progress, followers)
- **ScrapedFollower**: Individual follower data (name, title, company, email, enrichmentStatus)
- **EnrichRequest**: Apollo enrichment request schema

## Tech Stack
- React + TypeScript + Vite
- Express.js backend
- Playwright for browser automation
- TanStack Query for data fetching
- shadcn/ui components
- Tailwind CSS

## Environment Variables
- `APOLLO_API_KEY`: Apollo.io API key for email enrichment (required for enrichment)
- `USE_REAL_SCRAPING`: Set to "true" to enable real LinkedIn scraping (default: mock data)
- `LINKEDIN_SESSION_COOKIES`: JSON array of LinkedIn cookies for authenticated scraping (see below)
- `USE_SALES_NAVIGATOR`: Set to "true" to use Sales Navigator search instead of regular LinkedIn

## Configuring LinkedIn/Sales Navigator Access

To enable real scraping with your Sales Navigator account:

1. **Log into LinkedIn/Sales Navigator** in Chrome
2. **Export your cookies** using a browser extension like "EditThisCookie" or "Cookie-Editor"
3. **Copy the cookies as JSON** (should be an array of cookie objects)
4. **Add as secret**: In Replit, go to Secrets and add:
   - Key: `LINKEDIN_SESSION_COOKIES`
   - Value: The JSON cookie array
5. **Enable real scraping**: Add environment variable `USE_REAL_SCRAPING=true`
6. **For Sales Navigator**: Also add `USE_SALES_NAVIGATOR=true`

**Important cookies to include:**
- `li_at` (main authentication token)
- `JSESSIONID`
- `li_mc` (optional, helps with anti-bot)

**Cookie JSON format example:**
```json
[
  {"name": "li_at", "value": "your_token", "domain": ".linkedin.com", "path": "/"},
  {"name": "JSESSIONID", "value": "your_session", "domain": ".linkedin.com", "path": "/"}
]
```

**Note:** LinkedIn sessions expire periodically. You may need to re-export cookies every few weeks.

## How It Works
1. **Enter URL**: Paste a LinkedIn company page URL (e.g., linkedin.com/company/acme)
2. **Scrape**: App scrapes followers/employees from the company page
3. **Review**: View scraped contacts in a table, select which to enrich
4. **Enrich**: Click "Enrich" to find email addresses via Apollo API
5. **Export**: Download selected contacts as CSV

## Running the App
The app runs on port 5000 with `npm run dev`. Frontend and backend are served together via Vite middleware.

## Notes
- LinkedIn scraping uses browser automation (Playwright)
- Real scraping requires LinkedIn session/authentication
- Mock data is used by default for testing/demo
- Apollo API has rate limits - enrichment processes sequentially
